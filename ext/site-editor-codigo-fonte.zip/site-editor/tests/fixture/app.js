// Um "sistema" de página única, redesenhado por JavaScript como um framework faria: a navegação usa pushState, e a
// tela inicial redesenha o contador a cada 2 segundos (o motor precisa reaplicar as alterações).
const routes = {
  '/': () => `
    <h1 class="title">Painel de controle</h1>
    <p class="subtitle">Bem-vindo de volta ao sistema.</p>
    <section class="kpi">
      <div class="card"><h3>Vendas</h3><div class="num" id="kpi-sales">R$ 12.300</div></div>
      <div class="card"><h3>Clientes</h3><div class="num" id="kpi-clients">48</div></div>
      <div class="card"><h3>Online agora</h3><div class="num" id="kpi-online">0</div></div>
    </section>
    <div class="card"><button class="btn-primary" id="action-btn" type="button">Gerar relatório</button> <span id="action-result"></span></div>
    <div class="card"><label>Seu nome <input id="name-input" name="nome" placeholder="Digite"></label></div>
    <div class="card secret" id="secret">Token: 9f8e7d6c5b4a</div>`,
  '/clientes': () => `
    <h1 class="title">Clientes</h1>
    <table id="clients-table"><thead><tr><th>Nome</th><th>Cidade</th></tr></thead>
    <tbody>
      <tr><td>Ana</td><td>São Paulo</td></tr>
      <tr><td>Bruno</td><td>Recife</td></tr>
      <tr><td>Carla</td><td>Curitiba</td></tr>
    </tbody></table>`,
  '/relatorios': () => `<h1 class="title">Relatórios</h1><p>Nenhum relatório ainda.</p><a href="https://example.com/externo" id="ext-link">Link externo</a>`,
};
let online = 0;
function render() {
  const view = routes[location.pathname] || routes['/'];
  document.getElementById('app').innerHTML = view();
  const btn = document.getElementById('action-btn');
  if (btn) btn.addEventListener('click', () => { document.getElementById('action-result').textContent = 'Relatório gerado pelo sistema'; });
}
document.addEventListener('click', (event) => {
  const link = event.target.closest('a[data-link]');
  if (!link) return;
  event.preventDefault();
  history.pushState({}, '', link.getAttribute('href'));
  render();
});
window.addEventListener('popstate', render);
render();
setInterval(() => {
  online += 1;
  const el = document.getElementById('kpi-online');
  if (el) el.textContent = String(online);
  // o "framework" redesenha o subtítulo de tempos em tempos (desfaz alterações feitas no DOM)
  const sub = document.querySelector('.subtitle');
  if (sub && online % 3 === 0) sub.textContent = 'Bem-vindo de volta ao sistema.';
}, 500);
window.appVersion = '2.4.1';
