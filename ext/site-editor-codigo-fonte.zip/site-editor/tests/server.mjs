// Servidor do sistema de teste: arquivos da pasta fixture, e qualquer rota sem extensão devolve o index (SPA).
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';

const root = path.join(path.dirname(new URL(import.meta.url).pathname), 'fixture');
const types = { '.html': 'text/html; charset=utf-8', '.css': 'text/css', '.js': 'text/javascript', '.svg': 'image/svg+xml', '.json': 'application/json' };

export function startServer(port = 0) {
  const server = http.createServer((req, res) => {
    const url = new URL(req.url ?? '/', 'http://x');
    let file = path.join(root, decodeURIComponent(url.pathname));
    if (!file.startsWith(root)) return res.writeHead(403).end();
    if (!path.extname(file) || !fs.existsSync(file)) file = path.join(root, 'index.html');
    if (url.pathname === '/api/cors-blocked') {
      res.writeHead(200, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ mensagem: 'dados de outra origem' }));
    }
    res.writeHead(200, { 'content-type': types[path.extname(file)] ?? 'application/octet-stream' });
    fs.createReadStream(file).pipe(res);
  });
  return new Promise((resolve) => server.listen(port, '127.0.0.1', () => resolve(server)));
}

if (process.argv[1] === new URL(import.meta.url).pathname) {
  const server = await startServer(Number(process.argv[2] ?? 4173));
  console.log(`http://127.0.0.1:${server.address().port}`);
}
