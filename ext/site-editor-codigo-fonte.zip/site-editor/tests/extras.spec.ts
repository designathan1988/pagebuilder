// O resto do produto, também do jeito que a pessoa usa: gerenciador, popup, ponte com o Webconstructor, dados de
// outra origem, scripts próprios desligados, exportação ZIP e o wc-runtime.js num site sem a extensão.
import { chromium, expect, test, type Page } from '@playwright/test';
import fs from 'node:fs';
import path from 'node:path';
import type { Server } from 'node:http';
import { editor, launch, openEditor, storedProjects, waitSaved, type Harness } from './helpers.ts';
import { startServer } from './server.mjs';

let harness: Harness;
test.beforeAll(async () => {
  harness = await launch();
});
test.afterAll(async () => {
  await harness.close();
});
test.beforeEach(async () => {
  await harness.worker.evaluate(() => chrome.storage.local.clear());
});

// Um projeto completo, como o editor grava.
function project(overrides: Record<string, unknown> = {}): Record<string, unknown> {
  const now = Date.now();
  return {
    format: 1,
    id: 'p_teste',
    name: 'Sistema Demo',
    matches: ['http://127.0.0.1/*'],
    enabled: true,
    clients: [
      { id: 'c_a', name: 'Loja Azul', values: { empresa: 'Loja Azul' } },
      { id: 'c_b', name: 'Mercado Verde', values: { empresa: 'Mercado Verde' } },
    ],
    activeClientId: 'c_a',
    variables: [{ id: 'v_1', name: 'empresa', type: 'text', default: 'Sem nome', persist: 'none' }],
    edits: [{ id: 'e_1', op: 'text', value: '{{ empresa }}', target: { selector: '.brand-name' }, enabled: true, createdAt: now }],
    rules: [],
    sources: [],
    css: '',
    scripts: [],
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

async function store(projects: Record<string, unknown>[]): Promise<void> {
  await harness.worker.evaluate(async (list) => {
    const entries: Record<string, unknown> = {};
    for (const item of list) entries[`wce:project:${item.id as string}`] = item;
    entries['wce:index'] = list.map((item) => ({ id: item.id, name: item.name, matches: item.matches, enabled: item.enabled, updatedAt: item.updatedAt }));
    await chrome.storage.local.set(entries);
  }, projects);
}

async function tabId(page: Page): Promise<number> {
  return harness.worker.evaluate(async (url) => (await chrome.tabs.query({})).find((tab) => tab.url === url)?.id ?? -1, page.url());
}

test('gerenciador: matriz de clientes muda o site aberto e o JSON salva', async () => {
  await store([project()]);
  const site = await harness.context.newPage();
  await site.goto(`${harness.base}/`);
  await expect(site.locator('.brand-name')).toHaveText('Loja Azul');
  const manager = await harness.context.newPage();
  await manager.goto(`chrome-extension://${harness.extensionId}/manager.html#project=p_teste&tab=clients`);
  const value = manager.getByTestId('m-value-Loja Azul-empresa');
  await value.fill('Loja Azul Matriz');
  await value.press('Tab');
  await expect(site.locator('.brand-name')).toHaveText('Loja Azul Matriz');
  // marcar o outro cliente como ativo troca o site
  await manager.getByRole('radio', { name: 'Mostrar Mercado Verde' }).check();
  await expect(site.locator('.brand-name')).toHaveText('Mercado Verde');
  await manager.screenshot({ path: 'test-results/07-gerenciador.png' });
  // a aba JSON grava o projeto inteiro
  await manager.getByTestId('m-tab-json').click();
  const json = manager.getByTestId('m-json');
  const spec = JSON.parse(await json.inputValue());
  spec.name = 'Renomeado pelo JSON';
  await json.fill(JSON.stringify(spec, null, 2));
  await manager.getByTestId('m-json-save').click();
  await expect.poll(async () => (await storedProjects(harness))[0]?.name).toBe('Renomeado pelo JSON');
  await manager.close();
  await site.close();
});

test('popup: mostra o projeto, troca o cliente e abre o editor', async () => {
  await store([project()]);
  const site = await harness.context.newPage();
  await site.goto(`${harness.base}/`);
  await expect(site.locator('.brand-name')).toHaveText('Loja Azul');
  const id = await tabId(site);
  const popup = await harness.context.newPage();
  await popup.setViewportSize({ width: 380, height: 600 });
  await popup.goto(`chrome-extension://${harness.extensionId}/popup.html?tab=${id}`);
  const card = popup.getByTestId('popup-project');
  await expect(card).toContainText('Sistema Demo');
  await card.locator('select').selectOption({ label: 'Cliente: Mercado Verde' });
  await expect(site.locator('.brand-name')).toHaveText('Mercado Verde');
  await popup.screenshot({ path: 'test-results/08-popup.png' });
  await popup.getByTestId('popup-edit').click();
  await expect(editor(site).locator('.toolbar')).toBeVisible();
  await site.close();
});

test('ponte com o Webconstructor: ping, pedido de conexão e lista', async () => {
  await store([project()]);
  const page = await harness.context.newPage();
  await page.goto(`${harness.base}/`);
  const call = (action: string, payload?: unknown) =>
    page.evaluate(
      ({ action, payload }) =>
        new Promise<{ ok: boolean; result?: unknown; error?: string }>((resolve) => {
          const id = Math.random().toString(36).slice(2);
          addEventListener('message', function listen(event) {
            if (event.data?.wce === 'response' && event.data.id === id) {
              removeEventListener('message', listen);
              resolve(event.data);
            }
          });
          postMessage({ wce: 'request', id, action, payload }, location.origin);
        }),
      { action, payload },
    );
  await expect(page.locator('html')).toHaveAttribute('data-wce-bridge', /.*/);
  expect(await call('ping')).toMatchObject({ ok: true, result: { installed: true, paired: false } });
  expect(await call('list')).toMatchObject({ ok: false, error: 'not_paired' });
  // a página não consegue se autorizar sozinha: só o clique da pessoa vale
  const pairing = call('pair');
  await page.locator('wce-pair').waitFor({ state: 'attached' });
  await page.keyboard.press('Enter');
  expect(await pairing).toMatchObject({ ok: true, result: { paired: true } });
  const listed = await call('list');
  expect(listed.ok).toBe(true);
  expect(listed.result).toEqual([expect.objectContaining({ id: 'p_teste', name: 'Sistema Demo' })]);
  const saved = await call('save', { project: { ...project(), id: 'p_novo', name: 'Vindo do painel' } });
  expect(saved.ok).toBe(true);
  expect((await storedProjects(harness)).map((item) => item.name).sort()).toEqual(['Sistema Demo', 'Vindo do painel']);
  await page.close();
});

test('dados de outra origem passam pela extensão (sem CORS)', async () => {
  const other = (await startServer(0)) as Server;
  const port = (other.address() as { port: number }).port;
  try {
    await store([
      project({
        sources: [{ id: 's_1', name: 'remoto', kind: 'http', url: `http://127.0.0.1:${port}/api/cors-blocked`, format: 'json', auto: true }],
        edits: [{ id: 'e_1', op: 'bind', kind: 'text', expr: 'data.remoto.mensagem | default("carregando")', target: { selector: 'h1.title' }, enabled: true, createdAt: Date.now() }],
      }),
    ]);
    const page = await harness.context.newPage();
    await page.goto(`${harness.base}/`);
    await expect(page.locator('h1.title')).toHaveText('dados de outra origem');
    // a própria página não consegue ler (CORS), o que mostra que veio pela extensão
    const direct = await page.evaluate((url) => fetch(url).then(() => 'leu', () => 'bloqueado'), `http://127.0.0.1:${port}/api/cors-blocked`);
    expect(direct).toBe('bloqueado');
    await page.close();
  } finally {
    other.close();
  }
});

test('script próprio com os scripts de usuário desligados: avisa sem quebrar a página', async () => {
  await store([
    project({
      rules: [{ id: 'r_1', name: 'Script', enabled: true, trigger: { type: 'click', selector: '#action-btn' }, preventDefault: true, actions: [{ type: 'script', code: 'return { set: { empresa: "via script" } }' }] }],
    }),
  ]);
  const page = await harness.context.newPage();
  const errors: string[] = [];
  page.on('pageerror', (error) => errors.push(String(error)));
  await page.goto(`${harness.base}/`);
  await page.locator('#action-btn').click();
  const id = await tabId(page);
  const popup = await harness.context.newPage();
  await popup.goto(`chrome-extension://${harness.extensionId}/popup.html?tab=${id}`);
  await expect(popup.getByText(/aviso\(s\) nesta página/)).toBeVisible();
  await popup.getByText(/aviso\(s\) nesta página/).click();
  await expect(popup.locator('details')).toContainText('Permitir scripts de usuário');
  expect(errors).toEqual([]);
  await popup.close();
  await page.close();
});

test('exportar a página como ZIP para importar no Webconstructor', async () => {
  const page = await harness.context.newPage();
  await page.goto(`${harness.base}/`);
  await openEditor(harness, page);
  await page.locator('h1.title').dblclick();
  await page.keyboard.press('ControlOrMeta+a');
  await page.keyboard.type('Página exportada');
  await page.keyboard.press('Enter');
  await waitSaved(page);
  await editor(page).getByTestId('tab-project').click();
  const [download] = await Promise.all([page.waitForEvent('download'), editor(page).getByTestId('export-zip').click()]);
  const file = path.join('test-results', 'export.zip');
  await download.saveAs(file);
  const zip = fs.readFileSync(file);
  expect(zip.subarray(0, 4).toString('hex')).toBe('504b0304');
  const text = zip.toString('utf8');
  expect(text).toContain('index.html');
  expect(text).toContain('styles.css');
  expect(text).toContain('Página exportada');
  expect(text).not.toContain('wce-editor');
  await page.close();
});

test('wc-runtime.js num site sem a extensão: cliente pelo script, API WCE e nuvem', async () => {
  const runtime = fs.readFileSync(path.resolve('dist', 'runtime', 'wc-runtime.min.js'), 'utf8');
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH ?? '/opt/pw-browsers/chromium' });
  const page = await browser.newPage();
  const errors: string[] = [];
  page.on('pageerror', (error) => errors.push(String(error)));
  const spec = project({ matches: [] });
  await page.route('https://cliente.test/**', (route) => {
    const url = new URL(route.request().url());
    if (url.pathname === '/wc-runtime.js') return route.fulfill({ contentType: 'text/javascript', body: runtime });
    if (url.pathname === '/overlay') {
      expect(url.searchParams.get('key')).toBe('chave-publica');
      return route.fulfill({ contentType: 'application/json', headers: { 'access-control-allow-origin': '*' }, body: JSON.stringify({ project: spec }) });
    }
    const local = url.pathname === '/local';
    return route.fulfill({
      contentType: 'text/html',
      body: `<!doctype html><html><body><span class="brand-name">Empresa Antiga</span>
        ${local ? `<script>window.WCE_PROJECTS = ${JSON.stringify([spec])}</script><script src="/wc-runtime.js" data-wce-client="c_b" defer></script>` : `<script src="/wc-runtime.js" data-wce-endpoint="https://cliente.test/overlay" data-wce-key="chave-publica" defer></script>`}
      </body></html>`,
    });
  });
  // projeto embutido na página, cliente escolhido no <script>
  await page.goto('https://cliente.test/local');
  await expect(page.locator('.brand-name')).toHaveText('Mercado Verde');
  await page.evaluate(() => (window as unknown as { WCE: { set(name: string, value: unknown): void } }).WCE.set('empresa', 'Definido pela API'));
  await expect(page.locator('.brand-name')).toHaveText('Definido pela API');
  // projeto publicado na nuvem, cliente ativo
  await page.goto('https://cliente.test/nuvem');
  await expect(page.locator('.brand-name')).toHaveText('Loja Azul');
  await page.goto('https://cliente.test/nuvem?wce_client=c_b');
  await expect(page.locator('.brand-name')).toHaveText('Mercado Verde');
  expect(errors).toEqual([]);
  await browser.close();
});

test('tela estreita (celular): painel vira gaveta e a barra cabe', async () => {
  const page = await harness.context.newPage();
  await page.setViewportSize({ width: 390, height: 800 });
  await page.goto(`${harness.base}/`);
  await openEditor(harness, page);
  await page.locator('h1.title').click();
  const toolbar = await editor(page).locator('.toolbar').boundingBox();
  const panel = await editor(page).locator('.panel').boundingBox();
  expect(toolbar && toolbar.x >= 0 && toolbar.x + toolbar.width <= 390).toBe(true);
  expect(panel && panel.width <= 390 && panel.y > 200).toBe(true);
  await page.screenshot({ path: 'test-results/09-celular.png' });
  await page.close();
});
