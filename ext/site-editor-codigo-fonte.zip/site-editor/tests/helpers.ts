// Abre o Chromium com a extensão carregada (Playwright: playwright.dev/docs/chrome-extensions) e o sistema de teste.
import { chromium, type BrowserContext, type Page, type Worker } from '@playwright/test';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import type { Server } from 'node:http';
import { startServer } from './server.mjs';

export const EXTENSION = path.resolve('dist', 'chrome');
export const CHROMIUM = process.env.CHROMIUM_PATH ?? '/opt/pw-browsers/chromium';

export interface Harness {
  context: BrowserContext;
  worker: Worker;
  extensionId: string;
  base: string;
  server: Server;
  close(): Promise<void>;
}

export async function launch(): Promise<Harness> {
  const server = (await startServer(0)) as Server;
  const address = server.address();
  const base = `http://127.0.0.1:${typeof address === 'object' && address ? address.port : 0}`;
  const userData = fs.mkdtempSync(path.join(os.tmpdir(), 'wce-'));
  const context = await chromium.launchPersistentContext(userData, {
    executablePath: CHROMIUM,
    headless: true,
    viewport: { width: 1400, height: 900 },
    args: [`--disable-extensions-except=${EXTENSION}`, `--load-extension=${EXTENSION}`],
  });
  let [worker] = context.serviceWorkers();
  if (!worker) worker = await context.waitForEvent('serviceworker');
  const extensionId = worker.url().split('/')[2] ?? '';
  return {
    context,
    worker,
    extensionId,
    base,
    server,
    close: async () => {
      await context.close();
      server.close();
      fs.rmSync(userData, { recursive: true, force: true });
    },
  };
}

export async function openEditor(harness: Harness, page: Page, projectId?: string): Promise<void> {
  const url = page.url();
  const result = await harness.worker.evaluate(
    async ({ url, projectId }) => {
      const tabs = await chrome.tabs.query({});
      const tab = tabs.find((candidate) => candidate.url === url);
      if (!tab?.id) return { ok: false, error: `aba não achada: ${url}` };
      return (globalThis as unknown as { wceOpenEditor: (id: number, options: { projectId?: string }) => Promise<{ ok: boolean; error?: string }> }).wceOpenEditor(tab.id, projectId ? { projectId } : {});
    },
    { url, projectId },
  );
  if (!result.ok) throw new Error(result.error);
  await page.locator('wce-editor').locator('.toolbar').waitFor();
}

export function editor(page: Page) {
  return page.locator('wce-editor');
}

export async function storedProjects(harness: Harness): Promise<any[]> {
  return harness.worker.evaluate(async () => {
    const all = await chrome.storage.local.get(null);
    return Object.entries(all)
      .filter(([key]) => key.startsWith('wce:project:'))
      .map(([, value]) => value);
  });
}

export async function waitSaved(page: Page): Promise<void> {
  await editor(page).getByTestId('save-status').filter({ hasText: 'Salvo' }).waitFor();
  await page.waitForTimeout(150);
}
