// O editor usado como a pessoa usa: clicar, digitar, escolher nas abas. Cada teste começa sem projetos.
import { expect, test, type Page } from '@playwright/test';
import { editor, launch, openEditor, storedProjects, waitSaved, type Harness } from './helpers.ts';

let harness: Harness;
let page: Page;
const errors: string[] = [];

test.beforeAll(async () => {
  harness = await launch();
});
test.afterAll(async () => {
  await harness.close();
});
test.beforeEach(async () => {
  await harness.worker.evaluate(() => chrome.storage.local.clear());
  page = await harness.context.newPage();
  errors.length = 0;
  page.on('pageerror', (error) => errors.push(String(error)));
  await page.goto(`${harness.base}/`);
  await openEditor(harness, page);
});
test.afterEach(async () => {
  expect(errors, 'erros de JavaScript na página').toEqual([]);
  await page.close();
});

const ed = () => editor(page);
const tab = (name: string) => ed().getByTestId(`tab-${name}`).click();

test('texto com framework que redesenha: a alteração se mantém', async () => {
  await page.locator('.subtitle').dblclick();
  await page.keyboard.press('ControlOrMeta+a');
  await page.keyboard.type('Texto novo do cliente');
  await page.keyboard.press('Enter');
  await waitSaved(page);
  // o sistema reescreve o subtítulo a cada 1,5 s
  await page.waitForTimeout(2500);
  await expect(page.locator('.subtitle')).toHaveText('Texto novo do cliente');
});

test('esc cancela a edição no lugar', async () => {
  await page.locator('h1.title').dblclick();
  await page.keyboard.type('xxx');
  await page.keyboard.press('Escape');
  await expect(page.locator('h1.title')).toHaveText('Painel de controle');
  expect(await storedProjects(harness)).toEqual([expect.objectContaining({ edits: [] })]);
});

test('ocultar com Delete, desfazer e refazer', async () => {
  await page.locator('#secret').click();
  await page.keyboard.press('Delete');
  await waitSaved(page);
  await expect(page.locator('#secret')).toBeHidden();
  await ed().getByTestId('undo').click();
  await expect(page.locator('#secret')).toBeVisible();
  await ed().getByTestId('redo').click();
  await expect(page.locator('#secret')).toBeHidden();
  await ed().getByTestId('toggle-hidden').click();
  await expect(page.locator('#secret')).toBeVisible();
});

test('clicar não dispara o sistema enquanto edita; o modo navegar dispara', async () => {
  await page.locator('#action-btn').click();
  await expect(page.locator('#action-result')).toHaveText('');
  await ed().getByTestId('toggle-browse').click();
  await page.locator('#action-btn').click();
  await expect(page.locator('#action-result')).toHaveText('Relatório gerado pelo sistema');
});

test('estilo pelo painel', async () => {
  await page.locator('#action-btn').click();
  await ed().getByTestId('style-background-color').fill('#16a34a');
  await ed().getByTestId('style-background-color').press('Tab');
  await ed().getByTestId('style-border-radius').fill('999px');
  await ed().getByTestId('style-border-radius').press('Tab');
  await waitSaved(page);
  await expect(page.locator('#action-btn')).toHaveCSS('background-color', 'rgb(22, 163, 74)');
  await expect(page.locator('#action-btn')).toHaveCSS('border-radius', '999px');
  const [project] = await storedProjects(harness);
  expect(project.edits).toHaveLength(1);
  expect(project.edits[0].props).toEqual({ 'background-color': '#16a34a', 'border-radius': '999px' });
});

test('variáveis por cliente: logo e nome mudam ao trocar de cliente', async () => {
  await tab('variables');
  await ed().getByTestId('var-name').fill('empresa');
  await ed().getByTestId('var-add').click();
  await ed().getByTestId('var-name').fill('logo');
  await ed().getByTestId('var-type').selectOption('image');
  await ed().getByTestId('var-add').click();
  await waitSaved(page);
  // nome da marca vem da variável
  await page.locator('.brand-name').click();
  await ed().getByTestId('text-value').fill('{{ empresa | default("Sem nome") }}');
  await ed().getByTestId('text-value').press('Tab');
  await waitSaved(page);
  await expect(page.locator('.brand-name')).toHaveText('Sem nome');
  // logo vem da variável
  await page.locator('img.logo').click();
  await ed().getByTestId('image-src').fill('{{ logo | default("/logo.svg") }}');
  await ed().getByTestId('image-src').press('Tab');
  await waitSaved(page);
  // dois clientes com valores
  await tab('clients');
  await ed().getByTestId('client-Padrão').getByTestId('client-value-empresa').fill('Loja Azul');
  await ed().getByTestId('client-Padrão').getByTestId('client-value-empresa').press('Tab');
  await waitSaved(page);
  await expect(page.locator('.brand-name')).toHaveText('Loja Azul');
  page.once('dialog', (dialog) => void dialog.accept('Mercado Verde'));
  await ed().getByTestId('client-add').click();
  await waitSaved(page);
  const verde = ed().getByTestId('client-Mercado Verde');
  await verde.getByTestId('client-value-empresa').fill('Mercado Verde');
  await verde.getByTestId('client-value-empresa').press('Tab');
  await waitSaved(page);
  await verde.getByTestId('client-value-logo').fill('/logo2.svg');
  await verde.getByTestId('client-value-logo').press('Tab');
  await waitSaved(page);
  await expect(page.locator('.brand-name')).toHaveText('Mercado Verde');
  await expect(page.locator('img.logo')).toHaveAttribute('src', '/logo2.svg');
  await expect(page.locator('img.logo')).not.toHaveAttribute('srcset', /.*/);
  // troca pela barra
  const select = ed().getByTestId('client-select');
  await select.selectOption({ label: '👤 Padrão' });
  await waitSaved(page);
  await expect(page.locator('.brand-name')).toHaveText('Loja Azul');
  await expect(page.locator('img.logo')).toHaveAttribute('src', '/logo.svg');
  await page.screenshot({ path: 'test-results/03-clientes.png' });
});

test('substituir texto no site todo, com o nome do cliente', async () => {
  await ed().getByTestId('replace-find').fill('Empresa Antiga');
  await ed().getByTestId('replace-with').fill('{{ client.name }} S.A.');
  await ed().getByTestId('replace-apply').click();
  await waitSaved(page);
  await expect(page.locator('.brand-name')).toHaveText('Padrão S.A.');
  await expect(page.locator('footer')).toContainText('Padrão S.A.');
  // navega no sistema (pushState) e o texto novo continua
  await ed().getByTestId('toggle-browse').click();
  await page.getByRole('link', { name: 'Clientes' }).click();
  await expect(page.locator('h1.title')).toHaveText('Clientes');
  await expect(page.locator('footer')).toContainText('Padrão S.A.');
});

test('alteração só nesta página vale só nela (navegação de SPA)', async () => {
  await ed().getByTestId('scope-page').selectOption('this');
  await page.locator('h1.title').dblclick();
  await page.keyboard.press('ControlOrMeta+a');
  await page.keyboard.type('Só no início');
  await page.keyboard.press('Enter');
  await waitSaved(page);
  await ed().getByTestId('toggle-browse').click();
  await page.getByRole('link', { name: 'Clientes' }).click();
  await expect(page.locator('h1.title')).toHaveText('Clientes');
  await page.getByRole('link', { name: 'Início' }).click();
  await expect(page.locator('h1.title')).toHaveText('Só no início');
});

test('inserir carrossel: os botões trocam o slide', async () => {
  await page.locator('.kpi').click();
  await tab('insert');
  await ed().getByTestId('component-carousel').click();
  await waitSaved(page);
  const carousel = page.locator('.wce-c-carousel');
  await expect(carousel).toBeVisible();
  const slides = carousel.locator('[data-wce-slide]');
  await expect(slides.nth(0)).toBeVisible();
  await expect(slides.nth(1)).toBeHidden();
  await ed().getByTestId('toggle-browse').click();
  await carousel.locator('[data-wce-next]').click();
  await expect(slides.nth(1)).toBeVisible();
  await expect(slides.nth(0)).toBeHidden();
  await page.screenshot({ path: 'test-results/04-carrossel.png' });
});

test('inserir mapa pergunta o endereço', async () => {
  await page.locator('.kpi').click();
  await tab('insert');
  await ed().getByTestId('component-map').click();
  await ed().getByTestId('ask-address').fill('Rua XV de Novembro, Curitiba');
  await ed().getByTestId('ask-insert').click();
  await waitSaved(page);
  await expect(page.locator('.wce-c-map iframe')).toHaveAttribute('src', /Rua%20XV%20de%20Novembro/);
});

test('produto e carrinho: estado em lista, total e remover', async () => {
  await page.locator('#kpi-online').click();
  await tab('insert');
  await ed().getByTestId('insert-position').selectOption('before');
  await ed().getByTestId('component-product').click();
  await waitSaved(page);
  await page.locator('#secret').click();
  await tab('insert');
  await ed().getByTestId('component-cart').click();
  await waitSaved(page);
  await ed().getByTestId('toggle-browse').click();
  const add = page.locator('.wce-c-product button');
  await add.click();
  await add.click();
  const cart = page.locator('.wce-c-cart');
  await expect(cart.locator('h3')).toHaveText('Carrinho (2)');
  await expect(cart).toContainText('R$ 259,80');
  await cart.locator('li [aria-label="Remover"]').first().click();
  await expect(cart.locator('h3')).toHaveText('Carrinho (1)');
  await expect(cart).toContainText('R$ 129,90');
  await page.screenshot({ path: 'test-results/05-carrinho.png' });
  // o carrinho fica guardado (persist local) ao recarregar
  await page.reload();
  await expect(page.locator('.wce-c-cart h3')).toHaveText('Carrinho (1)');
});

test('regra: clique num botão define estado, mostra aviso e muda a tela', async () => {
  await tab('variables');
  await ed().getByTestId('var-name').fill('modo');
  await ed().getByTestId('var-type').selectOption('state');
  await ed().getByTestId('var-add').click();
  await waitSaved(page);
  // o cartão do token só aparece no estado "ativo"
  await page.locator('#secret').click();
  await ed().getByTestId('show-when').fill('modo == "ativo"');
  await ed().getByTestId('show-when').press('Tab');
  await waitSaved(page);
  await expect(page.locator('#secret')).toBeHidden();
  await page.locator('#action-btn').click();
  await ed().getByTestId('new-rule-click').click();
  await waitSaved(page);
  const rule = ed().getByTestId('rule').first();
  await rule.getByTestId('add-action').selectOption('toggle');
  await waitSaved(page);
  await rule.locator('[data-testid="action"]').nth(1).locator('select').selectOption('modo');
  await waitSaved(page);
  await ed().getByTestId('toggle-browse').click();
  await page.locator('#action-btn').click();
  await expect(page.locator('wce-layer').locator('.toast')).toHaveText('Funcionou!');
  await expect(page.locator('#secret')).toBeVisible();
  // o sistema não recebeu o clique (impedir a ação normal)
  await expect(page.locator('#action-result')).toHaveText('');
  await page.locator('#action-btn').click();
  await expect(page.locator('#secret')).toBeHidden();
});

test('campo ligado a variável e texto que mostra a variável', async () => {
  await tab('variables');
  await ed().getByTestId('var-name').fill('nome');
  await ed().getByTestId('var-add').click();
  await waitSaved(page);
  await page.locator('#name-input').click();
  await ed().getByTestId('bind-value').selectOption('nome');
  await waitSaved(page);
  await page.locator('h1.title').click();
  await ed().getByTestId('text-value').fill('Olá, {{ nome | default("visitante") | capitalize }}!');
  await ed().getByTestId('text-value').press('Tab');
  await waitSaved(page);
  await expect(page.locator('h1.title')).toHaveText('Olá, Visitante!');
  await ed().getByTestId('toggle-browse').click();
  await page.locator('#name-input').fill('maria clara');
  await expect(page.locator('h1.title')).toHaveText('Olá, Maria Clara!');
});

test('dados: fonte JSON e repetição de linhas da tabela', async () => {
  await tab('data');
  await ed().getByTestId('source-add').click();
  await waitSaved(page);
  await ed().getByTestId('source-name').fill('cidades');
  await ed().getByTestId('source-name').press('Tab');
  await waitSaved(page);
  await ed().getByTestId('source-data').fill('[{"nome":"Diego","cidade":"Natal"},{"nome":"Elisa","cidade":"Belém"},{"nome":"Fábio","cidade":"Manaus"},{"nome":"Gabi","cidade":"Goiânia"}]');
  await ed().getByTestId('source-data').press('Tab');
  await waitSaved(page);
  await ed().getByTestId('toggle-browse').click();
  await page.getByRole('link', { name: 'Clientes' }).click();
  await ed().getByTestId('toggle-browse').click();
  await page.locator('#clients-table tbody tr').first().click();
  await ed().getByTestId('tab-element').click();
  await ed().getByTestId('selector').fill('#clients-table tbody tr:nth-of-type(1)');
  await ed().getByTestId('selector').press('Tab');
  await ed().getByTestId('repeat-expr').fill('data.cidades');
  await ed().getByTestId('repeat-template').fill('<tr><td>{{ item.nome }}</td><td>{{ item.cidade }}</td></tr>');
  await ed().getByTestId('repeat-apply').click();
  await waitSaved(page);
  // os dois exemplos originais seguem, a primeira linha virou o modelo (escondida) e as 4 novas entram depois dela
  const rows = page.locator('#clients-table tbody tr:visible');
  await expect(rows).toHaveCount(6);
  await expect(rows.nth(0)).toHaveText('DiegoNatal');
  await expect(rows.nth(3)).toHaveText('GabiGoiânia');
  await page.screenshot({ path: 'test-results/06-tabela.png' });
});

test('mover um elemento para antes de outro', async () => {
  await page.locator('#secret').click();
  await ed().getByTestId('mini-move').click();
  await page.locator('.kpi').click();
  await ed().getByTestId('choose-before').click();
  await waitSaved(page);
  const order = await page.evaluate(() => Array.from(document.querySelectorAll('#app > *')).map((node) => node.id || node.className));
  expect(order.indexOf('card secret')).toBeLessThan(order.indexOf('kpi'));
});

test('ver original desfaz tudo na tela e volta', async () => {
  await page.locator('h1.title').dblclick();
  await page.keyboard.press('ControlOrMeta+a');
  await page.keyboard.type('Editado');
  await page.keyboard.press('Enter');
  await waitSaved(page);
  await ed().getByTestId('toggle-original').click();
  await expect(page.locator('h1.title')).toHaveText('Painel de controle');
  await ed().getByTestId('toggle-original').click();
  await expect(page.locator('h1.title')).toHaveText('Editado');
});

test('fechar o editor mantém as alterações aplicadas', async () => {
  await page.locator('#secret').click();
  await page.keyboard.press('Delete');
  await waitSaved(page);
  await ed().getByTestId('close-editor').click();
  await expect(ed()).toHaveCount(0);
  await expect(page.locator('#secret')).toBeHidden();
  // e o clique volta a funcionar no sistema
  await page.locator('#action-btn').click();
  await expect(page.locator('#action-result')).toHaveText('Relatório gerado pelo sistema');
});
