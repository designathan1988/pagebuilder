import { expect, test } from '@playwright/test';
import { editor, launch, openEditor, storedProjects, waitSaved, type Harness } from './helpers.ts';

let harness: Harness;
test.beforeAll(async () => {
  harness = await launch();
});
test.afterAll(async () => {
  await harness.close();
});

test('abre o editor, edita um texto no lugar e a alteração volta ao recarregar', async () => {
  const page = await harness.context.newPage();
  page.on('console', (message) => message.type() === 'error' && console.log('console:', message.text()));
  await page.goto(`${harness.base}/`);
  await openEditor(harness, page);
  await page.screenshot({ path: 'test-results/01-editor-aberto.png' });
  const title = page.locator('h1.title');
  await title.dblclick();
  await page.keyboard.press('ControlOrMeta+a');
  await page.keyboard.type('Painel do Cliente');
  await page.keyboard.press('Enter');
  await waitSaved(page);
  await expect(title).toHaveText('Painel do Cliente');
  const projects = await storedProjects(harness);
  expect(projects).toHaveLength(1);
  expect(projects[0].edits[0]).toMatchObject({ op: 'text', value: 'Painel do Cliente' });
  await page.screenshot({ path: 'test-results/02-texto-editado.png' });
  await page.reload();
  await expect(page.locator('h1.title')).toHaveText('Painel do Cliente');
  await expect(editor(page)).toHaveCount(0);
  await page.close();
});
