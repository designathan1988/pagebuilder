// ZIP de uma pasta (sem compressão), para o pacote da extensão: reusa o escritor de src/shared/zip.ts.
import fs from 'node:fs';
import path from 'node:path';
import * as esbuild from 'esbuild';

const here = path.dirname(new URL(import.meta.url).pathname);
const bundled = esbuild.buildSync({ entryPoints: [path.join(here, '..', 'src', 'shared', 'zip.ts')], bundle: true, format: 'esm', write: false, platform: 'neutral' });
const { makeZip } = await import(`data:text/javascript;base64,${Buffer.from(bundled.outputFiles[0].text).toString('base64')}`);

function walk(dir, base = dir) {
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
    const full = path.join(dir, entry.name);
    return entry.isDirectory() ? walk(full, base) : [{ path: path.relative(base, full).split(path.sep).join('/'), data: new Uint8Array(fs.readFileSync(full)) }];
  });
}

export function makeZipNode(dir) {
  return makeZip(walk(dir));
}
