// Desenha os ícones da extensão (icons/*.png) a partir de um SVG, com o Chromium do Playwright. node tools/icons.mjs
import { chromium } from '@playwright/test';
import fs from 'node:fs';

const svg = (size) => `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 128 128">
<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#3b82f6"/><stop offset="1" stop-color="#1d4ed8"/></linearGradient></defs>
<rect x="4" y="4" width="120" height="120" rx="28" fill="url(#g)"/>
<rect x="24" y="30" width="80" height="58" rx="8" fill="none" stroke="#fff" stroke-width="8"/>
<path d="M24 46h80" stroke="#fff" stroke-width="8"/>
<path d="M70 70l26 26-10 2-5 10z" fill="#fbbf24" stroke="#fff" stroke-width="5" stroke-linejoin="round"/>
</svg>`;

const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
const page = await browser.newPage();
fs.mkdirSync('icons', { recursive: true });
for (const size of [16, 32, 48, 128]) {
  await page.setViewportSize({ width: size, height: size });
  await page.setContent(`<html><body style="margin:0;background:transparent">${svg(size)}</body></html>`);
  await page.screenshot({ path: `icons/${size}.png`, omitBackground: true, clip: { x: 0, y: 0, width: size, height: size } });
}
await browser.close();
console.log('ícones gerados');
