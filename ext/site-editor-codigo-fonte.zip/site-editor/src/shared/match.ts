// Endereços: os padrões de um projeto dizem em que páginas ele vale.
// - "https://app.exemplo.com/*" ou "*://*.exemplo.com/*": o formato de padrão de correspondência do Chrome;
// - "app.exemplo.com/clientes/*": sem protocolo, compara com o domínio e o caminho;
// - "/^https:\/\/.+\.exemplo\.com\//": entre barras, uma expressão regular.
// O * vale por qualquer sequência de caracteres.

function globToRegex(glob: string): RegExp {
  const escaped = glob.replace(/[.+^${}()|[\]\\?]/g, '\\$&').replace(/\*/g, '.*');
  return new RegExp(`^${escaped}$`, 'i');
}

export function urlMatches(pattern: string, href: string): boolean {
  const trimmed = pattern.trim();
  if (trimmed === '') return false;
  if (trimmed === '<all_urls>' || trimmed === '*') return /^(https?|file):/.test(href);
  if (trimmed.length > 2 && trimmed.startsWith('/') && trimmed.lastIndexOf('/') > 0) {
    const end = trimmed.lastIndexOf('/');
    try {
      return new RegExp(trimmed.slice(1, end), trimmed.slice(end + 1)).test(href);
    } catch {
      return false;
    }
  }
  let url: URL;
  try {
    url = new URL(href);
  } catch {
    return false;
  }
  const scheme = /^([a-z*]+):\/\//i.exec(trimmed);
  if (scheme) {
    const wantedScheme = (scheme[1] ?? '').toLowerCase();
    if (wantedScheme !== '*' && wantedScheme !== url.protocol.replace(':', '')) return false;
    if (wantedScheme === '*' && !/^https?:$/.test(url.protocol)) return false;
    const rest = trimmed.slice(scheme[0].length);
    const slash = rest.indexOf('/');
    const hostPattern = slash === -1 ? rest : rest.slice(0, slash);
    const pathPattern = slash === -1 ? '/*' : rest.slice(slash);
    const host = hostPattern.replace(/:(\d+|\*)$/, '').toLowerCase();
    const port = /:(\d+)$/.exec(hostPattern)?.[1];
    if (port !== undefined && port !== url.port) return false;
    const hostOk = host === '*' || (host.startsWith('*.') ? url.hostname === host.slice(2) || url.hostname.endsWith(host.slice(1)) : globToRegex(host).test(url.hostname));
    if (!hostOk) return false;
    return globToRegex(pathPattern).test(url.pathname + url.search + url.hash) || globToRegex(pathPattern).test(url.pathname);
  }
  const withoutScheme = href.replace(/^[a-z]+:\/\//i, '');
  return globToRegex(trimmed).test(withoutScheme) || globToRegex(trimmed.endsWith('*') ? trimmed : `${trimmed}*`).test(withoutScheme);
}

export function anyMatches(patterns: readonly string[], href: string): boolean {
  return patterns.some((pattern) => urlMatches(pattern, href));
}

// O padrão de caminho de uma alteração (edit.page): compara com o caminho, a busca e o hash.
export function pageMatches(pattern: string | undefined, location: { readonly pathname: string; readonly search: string; readonly hash: string }): boolean {
  if (pattern === undefined || pattern.trim() === '' || pattern.trim() === '*') return true;
  const trimmed = pattern.trim();
  const regex = globToRegex(trimmed);
  return regex.test(location.pathname) || regex.test(location.pathname + location.search) || regex.test(location.pathname + location.search + location.hash) || (trimmed.startsWith('#') && regex.test(location.hash));
}

// O padrão que a extensão sugere para um endereço: o site inteiro.
export function suggestPattern(href: string): string {
  try {
    const url = new URL(href);
    if (url.protocol === 'file:') return `file://${url.pathname.replace(/[^/]*$/, '')}*`;
    return `${url.protocol}//${url.host}/*`;
  } catch {
    return href;
  }
}
