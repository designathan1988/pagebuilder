// O modelo de uma personalização: um projeto se aplica às páginas que os padrões de endereço descrevem, e cada
// cliente (variante) dá os seus valores às variáveis. As alterações, regras e fontes de dados são as mesmas para
// todos os clientes, salvo quando uma alteração diz para quais clientes vale. É o mesmo formato na extensão, na nuvem
// (saas/supabase, tabela site_overlays) e no script que roda nos sites (wc-runtime.js).

export const FORMAT_VERSION = 1;

export type VariableType = 'text' | 'number' | 'boolean' | 'state' | 'list' | 'json' | 'color' | 'image' | 'url';

// De onde uma variável tira o valor inicial, além do valor do cliente.
export type VariableSource =
  | { readonly kind: 'static' }
  | { readonly kind: 'query'; readonly param: string }
  | { readonly kind: 'cookie'; readonly name: string }
  | { readonly kind: 'storage'; readonly key: string }
  | { readonly kind: 'element'; readonly selector: string; readonly attr?: string }
  | { readonly kind: 'expression'; readonly expr: string }
  | { readonly kind: 'source'; readonly sourceId: string; readonly path?: string };

export interface VariableDef {
  id: string;
  name: string;
  type: VariableType;
  // os valores possíveis de um estado (type 'state')
  options?: string[];
  default: unknown;
  // 'none': volta ao valor inicial a cada página; 'session': dura a aba; 'local': fica salvo no navegador
  persist: 'none' | 'session' | 'local';
  source?: VariableSource;
  description?: string;
}

export interface Client {
  id: string;
  name: string;
  // valores das variáveis para este cliente (pelo nome da variável)
  values: Record<string, unknown>;
  // CSS a mais só para este cliente
  css?: string;
  notes?: string;
}

export interface Target {
  selector: string;
  // texto que o elemento tinha quando foi escolhido: ajuda a achar de novo se o seletor mudar
  hint?: string;
}

export type InsertPosition = 'before' | 'after' | 'prepend' | 'append';

export type EditOp =
  | { readonly op: 'text'; value: string }
  | { readonly op: 'html'; value: string }
  | { readonly op: 'attr'; name: string; value: string | null }
  | { readonly op: 'style'; props: Record<string, string> }
  | { readonly op: 'class'; add: string[]; remove: string[] }
  | { readonly op: 'hide' }
  | { readonly op: 'remove' }
  | { readonly op: 'blur'; amount: number }
  | { readonly op: 'insert'; position: InsertPosition; html: string; component?: string }
  | { readonly op: 'move'; ref: Target; position: InsertPosition }
  | { readonly op: 'replace'; find: string; replace: string; regex?: boolean; caseSensitive?: boolean }
  | { readonly op: 'bind'; kind: BindKind; expr: string; name?: string }
  | { readonly op: 'repeat'; expr: string; template: string; itemName?: string };

export type BindKind = 'text' | 'html' | 'attr' | 'style' | 'class' | 'show' | 'value';

export type Edit = EditOp & {
  id: string;
  target: Target;
  enabled: boolean;
  // padrão de caminho da página (ex.: /clientes/*); ausente: todas as páginas do projeto
  page?: string;
  // só para estes clientes; ausente ou vazio: todos
  clients?: string[];
  // expressão: a alteração só vale quando for verdadeira
  when?: string;
  label?: string;
  createdAt: number;
};

export type TriggerType =
  | 'click'
  | 'dblclick'
  | 'hover'
  | 'submit'
  | 'change'
  | 'input'
  | 'keydown'
  | 'load'
  | 'interval'
  | 'timeout'
  | 'urlchange'
  | 'varchange'
  | 'visible';

export interface Trigger {
  type: TriggerType;
  selector?: string;
  key?: string;
  ms?: number;
  variable?: string;
}

export type Action =
  | { type: 'set'; variable: string; expr: string }
  | { type: 'toggle'; variable: string }
  | { type: 'reset'; variable: string }
  | { type: 'push'; variable: string; expr: string }
  | { type: 'show' | 'hide' | 'toggleVisible'; selector: string }
  | { type: 'addClass' | 'removeClass' | 'toggleClass'; selector: string; className: string }
  | { type: 'setText'; selector: string; expr: string }
  | { type: 'setHtml'; selector: string; expr: string }
  | { type: 'setAttr'; selector: string; name: string; expr: string }
  | { type: 'setStyle'; selector: string; prop: string; expr: string }
  | { type: 'setValue'; selector: string; expr: string }
  | { type: 'click' | 'focus' | 'scroll'; selector: string }
  | { type: 'navigate'; expr: string; newTab?: boolean }
  | { type: 'toast'; expr: string; tone?: 'info' | 'success' | 'error' }
  | { type: 'modal'; title: string; html: string }
  | { type: 'closeModal' }
  | { type: 'fetch'; sourceId: string }
  | { type: 'copy'; expr: string }
  | { type: 'delay'; ms: number }
  | { type: 'log'; expr: string }
  | { type: 'script'; code: string }
  | { type: 'if'; condition: string; then: Action[]; else: Action[] };

export type ActionType = Action['type'];

export interface Rule {
  id: string;
  name: string;
  enabled: boolean;
  trigger: Trigger;
  condition?: string;
  preventDefault?: boolean;
  actions: Action[];
  page?: string;
}

export interface DataSource {
  id: string;
  // o nome com que os dados aparecem nas expressões: data.<name>
  name: string;
  kind: 'json' | 'csv' | 'http';
  // conteúdo para json e csv
  data?: string;
  url?: string;
  method?: 'GET' | 'POST';
  headers?: Record<string, string>;
  body?: string;
  // caminho dentro da resposta (ex.: results.items)
  path?: string;
  // 'csv' ou 'json' quando kind é 'http'
  format?: 'json' | 'csv' | 'text';
  refreshSec?: number;
  auto: boolean;
}

export interface CustomScript {
  id: string;
  name: string;
  code: string;
  enabled: boolean;
  page?: string;
}

export interface CloudLink {
  id: string;
  workspaceId: string;
  publicKey?: string;
  published?: boolean;
  remoteUpdatedAt?: string;
  syncedAt?: number;
  // o projeto do Webconstructor ligado a esta personalização
  builderProjectId?: string | null;
}

export interface Project {
  format: number;
  id: string;
  name: string;
  description?: string;
  matches: string[];
  enabled: boolean;
  clients: Client[];
  activeClientId: string | null;
  variables: VariableDef[];
  edits: Edit[];
  rules: Rule[];
  sources: DataSource[];
  css: string;
  scripts: CustomScript[];
  createdAt: number;
  updatedAt: number;
  cloud?: CloudLink;
}

export function uid(prefix = ''): string {
  const random = crypto.getRandomValues(new Uint8Array(8));
  return prefix + Array.from(random, (b) => b.toString(16).padStart(2, '0')).join('');
}

export function newProject(name: string, matches: string[]): Project {
  const now = Date.now();
  const client: Client = { id: uid('c_'), name: 'Padrão', values: {} };
  return {
    format: FORMAT_VERSION,
    id: uid('p_'),
    name,
    matches,
    enabled: true,
    clients: [client],
    activeClientId: client.id,
    variables: [],
    edits: [],
    rules: [],
    sources: [],
    css: '',
    scripts: [],
    createdAt: now,
    updatedAt: now,
  };
}

export const VARIABLE_NAME = /^[A-Za-z_][A-Za-z0-9_]*$/;
export const RESERVED_NAMES = new Set(['page', 'client', 'data', 'event', 'item', 'index', 'now', 'true', 'false', 'null', 'vars', 'this']);

export function defaultFor(type: VariableType, options?: string[]): unknown {
  switch (type) {
    case 'number':
      return 0;
    case 'boolean':
      return false;
    case 'state':
      return options?.[0] ?? '';
    case 'list':
      return [];
    case 'json':
      return {};
    case 'color':
      return '#2563eb';
    default:
      return '';
  }
}

// Confere e completa um projeto vindo de fora (importação, nuvem): campos ausentes ganham o valor padrão, e o que não
// tem a forma esperada é recusado com o motivo.
export function normalizeProject(raw: unknown): Project {
  if (typeof raw !== 'object' || raw === null) throw new Error('O arquivo não contém um projeto.');
  const input = raw as Partial<Project>;
  if (typeof input.name !== 'string' || input.name.trim() === '') throw new Error('O projeto não tem nome.');
  const base = newProject(input.name, []);
  const list = <T>(value: unknown): T[] => (Array.isArray(value) ? (value as T[]) : []);
  const project: Project = {
    ...base,
    ...input,
    format: FORMAT_VERSION,
    id: typeof input.id === 'string' && input.id ? input.id : base.id,
    matches: list<string>(input.matches).filter((m) => typeof m === 'string'),
    enabled: input.enabled !== false,
    clients: list<Client>(input.clients),
    variables: list<VariableDef>(input.variables),
    edits: list<Edit>(input.edits),
    rules: list<Rule>(input.rules),
    sources: list<DataSource>(input.sources),
    scripts: list<CustomScript>(input.scripts),
    css: typeof input.css === 'string' ? input.css : '',
    createdAt: typeof input.createdAt === 'number' ? input.createdAt : base.createdAt,
    updatedAt: typeof input.updatedAt === 'number' ? input.updatedAt : base.updatedAt,
  };
  if (project.clients.length === 0) project.clients = base.clients;
  if (project.activeClientId === null || !project.clients.some((c) => c.id === project.activeClientId)) project.activeClientId = project.clients[0]?.id ?? null;
  for (const edit of project.edits) {
    if (typeof edit.target?.selector !== 'string') throw new Error('Uma alteração do projeto não tem seletor.');
    if (edit.enabled === undefined) edit.enabled = true;
  }
  return project;
}

export function activeClient(project: Project, clientId?: string | null): Client | null {
  const id = clientId ?? project.activeClientId;
  return project.clients.find((c) => c.id === id) ?? project.clients[0] ?? null;
}
