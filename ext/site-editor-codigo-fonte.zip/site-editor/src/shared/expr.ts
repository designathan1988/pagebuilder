// A linguagem de expressões das personalizações: lida por um analisador próprio, sem eval nem new Function, porque o
// Manifest V3 proíbe código montado em tempo de execução nas páginas da extensão e nos scripts de conteúdo
// (developer.chrome.com/docs/extensions/develop/migrate/improve-security), e os sites podem ter CSP sem 'unsafe-eval'.
//
// Aceita: números, textos ('…' ou "…"), true/false/null, listas [a, b], objetos {a: 1}, nomes e acesso a membros
// (cliente.nome, lista[0]), operadores ! - + * / % == != === !== < > <= >= && || ?? e ?:, chamadas das funções da
// lista FUNCTIONS e filtros com | (preco | money, nome | default('Visitante')).

export type Scope = Readonly<Record<string, unknown>>;

type Token =
  | { readonly t: 'num'; readonly v: number }
  | { readonly t: 'str'; readonly v: string }
  | { readonly t: 'id'; readonly v: string }
  | { readonly t: 'op'; readonly v: string }
  | { readonly t: 'end' };

const OPERATORS = ['===', '!==', '==', '!=', '<=', '>=', '&&', '||', '??', '?.', '<', '>', '+', '-', '*', '/', '%', '!', '?', ':', '.', ',', '(', ')', '[', ']', '{', '}', '|'];

export class ExpressionError extends Error {}

function lex(source: string): Token[] {
  const tokens: Token[] = [];
  let at = 0;
  while (at < source.length) {
    const ch = source[at] ?? '';
    if (/\s/.test(ch)) {
      at += 1;
      continue;
    }
    if (/[0-9]/.test(ch) || (ch === '.' && /[0-9]/.test(source[at + 1] ?? ''))) {
      const match = /^(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?/.exec(source.slice(at));
      const text = match?.[0] ?? ch;
      tokens.push({ t: 'num', v: Number(text) });
      at += text.length;
      continue;
    }
    if (ch === '"' || ch === "'" || ch === '`') {
      let value = '';
      let end = at + 1;
      while (end < source.length && source[end] !== ch) {
        if (source[end] === '\\') {
          const next = source[end + 1] ?? '';
          value += next === 'n' ? '\n' : next === 't' ? '\t' : next;
          end += 2;
        } else {
          value += source[end];
          end += 1;
        }
      }
      if (end >= source.length) throw new ExpressionError('Texto sem aspas de fechamento.');
      tokens.push({ t: 'str', v: value });
      at = end + 1;
      continue;
    }
    if (/[A-Za-z_$\u00C0-\u024F]/.test(ch)) {
      const match = /^[A-Za-z_$\u00C0-\u024F][A-Za-z0-9_$\u00C0-\u024F]*/.exec(source.slice(at));
      const text = match?.[0] ?? ch;
      tokens.push({ t: 'id', v: text });
      at += text.length;
      continue;
    }
    const op = OPERATORS.find((candidate) => source.startsWith(candidate, at));
    if (op === undefined) throw new ExpressionError(`Caractere inesperado: ${ch}`);
    tokens.push({ t: 'op', v: op });
    at += op.length;
  }
  tokens.push({ t: 'end' });
  return tokens;
}

export type Node =
  | { readonly k: 'lit'; readonly v: unknown }
  | { readonly k: 'name'; readonly v: string }
  | { readonly k: 'member'; readonly obj: Node; readonly prop: Node; readonly optional: boolean }
  | { readonly k: 'call'; readonly fn: string; readonly args: readonly Node[] }
  | { readonly k: 'unary'; readonly op: string; readonly arg: Node }
  | { readonly k: 'binary'; readonly op: string; readonly left: Node; readonly right: Node }
  | { readonly k: 'cond'; readonly test: Node; readonly yes: Node; readonly no: Node }
  | { readonly k: 'array'; readonly items: readonly Node[] }
  | { readonly k: 'object'; readonly entries: readonly (readonly [string, Node])[] };

const BINARY: Record<string, number> = {
  '|': 1,
  '??': 3,
  '||': 4,
  '&&': 5,
  '==': 6,
  '!=': 6,
  '===': 6,
  '!==': 6,
  '<': 7,
  '>': 7,
  '<=': 7,
  '>=': 7,
  '+': 8,
  '-': 8,
  '*': 9,
  '/': 9,
  '%': 9,
};

class Parser {
  private at = 0;
  constructor(private readonly tokens: Token[]) {}

  private peek(): Token {
    return this.tokens[this.at] ?? { t: 'end' };
  }
  private next(): Token {
    const token = this.peek();
    this.at += 1;
    return token;
  }
  private isOp(value: string): boolean {
    const token = this.peek();
    return token.t === 'op' && token.v === value;
  }
  private expect(value: string): void {
    if (!this.isOp(value)) throw new ExpressionError(`Esperava "${value}".`);
    this.at += 1;
  }

  parseAll(): Node {
    const node = this.expression(0);
    if (this.peek().t !== 'end') throw new ExpressionError('Sobrou texto depois da expressão.');
    return node;
  }

  expression(minPrecedence: number): Node {
    let left = this.unary();
    for (;;) {
      const token = this.peek();
      if (token.t === 'op' && token.v === '?' && minPrecedence <= 2) {
        this.next();
        const yes = this.expression(0);
        this.expect(':');
        const no = this.expression(2);
        left = { k: 'cond', test: left, yes, no };
        continue;
      }
      if (token.t !== 'op') break;
      const precedence = BINARY[token.v];
      if (precedence === undefined || precedence < minPrecedence) break;
      this.next();
      if (token.v === '|') {
        // filtro: valor | nome(args)  ->  nome(valor, args)
        const name = this.next();
        if (name.t !== 'id') throw new ExpressionError('Esperava o nome de um filtro depois de "|".');
        const args: Node[] = [left];
        if (this.isOp('(')) args.push(...this.args());
        left = { k: 'call', fn: name.v, args };
        continue;
      }
      const right = this.expression(precedence + 1);
      left = { k: 'binary', op: token.v, left, right };
    }
    return left;
  }

  private args(): Node[] {
    this.expect('(');
    const args: Node[] = [];
    while (!this.isOp(')')) {
      args.push(this.expression(2));
      if (!this.isOp(')')) this.expect(',');
    }
    this.expect(')');
    return args;
  }

  private unary(): Node {
    const token = this.peek();
    if (token.t === 'op' && (token.v === '!' || token.v === '-' || token.v === '+')) {
      this.next();
      return { k: 'unary', op: token.v, arg: this.unary() };
    }
    return this.postfix(this.primary());
  }

  private postfix(start: Node): Node {
    let node = start;
    for (;;) {
      if (this.isOp('.') || this.isOp('?.')) {
        const optional = this.isOp('?.');
        this.next();
        const name = this.next();
        if (name.t !== 'id') throw new ExpressionError('Esperava um nome depois do ponto.');
        node = { k: 'member', obj: node, prop: { k: 'lit', v: name.v }, optional };
      } else if (this.isOp('[')) {
        this.next();
        const prop = this.expression(0);
        this.expect(']');
        node = { k: 'member', obj: node, prop, optional: false };
      } else break;
    }
    return node;
  }

  private primary(): Node {
    const token = this.next();
    switch (token.t) {
      case 'num':
      case 'str':
        return { k: 'lit', v: token.v };
      case 'id': {
        if (token.v === 'true') return { k: 'lit', v: true };
        if (token.v === 'false') return { k: 'lit', v: false };
        if (token.v === 'null' || token.v === 'undefined') return { k: 'lit', v: null };
        if (this.isOp('(')) return { k: 'call', fn: token.v, args: this.args() };
        return { k: 'name', v: token.v };
      }
      case 'op': {
        if (token.v === '(') {
          const inner = this.expression(0);
          this.expect(')');
          return inner;
        }
        if (token.v === '[') {
          const items: Node[] = [];
          while (!this.isOp(']')) {
            items.push(this.expression(2));
            if (!this.isOp(']')) this.expect(',');
          }
          this.expect(']');
          return { k: 'array', items };
        }
        if (token.v === '{') {
          const entries: [string, Node][] = [];
          while (!this.isOp('}')) {
            const key = this.next();
            if (key.t !== 'id' && key.t !== 'str') throw new ExpressionError('Esperava o nome de um campo.');
            this.expect(':');
            entries.push([String(key.v), this.expression(2)]);
            if (!this.isOp('}')) this.expect(',');
          }
          this.expect('}');
          return { k: 'object', entries };
        }
        throw new ExpressionError(`Símbolo inesperado: ${token.v}`);
      }
      default:
        throw new ExpressionError('A expressão terminou cedo demais.');
    }
  }
}

const cache = new Map<string, Node>();

export function parse(source: string): Node {
  const hit = cache.get(source);
  if (hit) return hit;
  const node = new Parser(lex(source)).parseAll();
  if (cache.size > 2000) cache.clear();
  cache.set(source, node);
  return node;
}

const BLOCKED = new Set(['__proto__', 'constructor', 'prototype']);

function member(obj: unknown, prop: unknown): unknown {
  if (obj === null || obj === undefined) return undefined;
  const key = String(prop);
  if (BLOCKED.has(key)) return undefined;
  if (typeof obj === 'string') {
    if (key === 'length') return obj.length;
    const index = Number(key);
    return Number.isInteger(index) ? obj[index] : undefined;
  }
  if (Array.isArray(obj) && key === 'length') return obj.length;
  if (typeof obj !== 'object') return undefined;
  return Object.prototype.hasOwnProperty.call(obj, key) ? (obj as Record<string, unknown>)[key] : undefined;
}

export function truthy(value: unknown): boolean {
  if (Array.isArray(value)) return value.length > 0;
  if (value === 'false' || value === '0') return false;
  return Boolean(value);
}

function num(value: unknown): number {
  if (typeof value === 'number') return value;
  if (typeof value === 'string') {
    const cleaned = value.trim().replace(/\s/g, '');
    // aceita 1.234,56 (pt-BR) e 1,234.56
    if (/^-?[\d.]+,\d+$/.test(cleaned)) return Number(cleaned.replace(/\./g, '').replace(',', '.'));
    return Number(cleaned.replace(/,/g, ''));
  }
  if (typeof value === 'boolean') return value ? 1 : 0;
  return Number(value);
}

export function toText(value: unknown): string {
  if (value === null || value === undefined) return '';
  if (typeof value === 'string') return value;
  if (typeof value === 'number') return Number.isFinite(value) ? String(value) : '';
  if (typeof value === 'boolean') return value ? 'true' : 'false';
  if (value instanceof Date) return value.toISOString();
  return JSON.stringify(value);
}

function looseEqual(a: unknown, b: unknown): boolean {
  if (a === b) return true;
  if (a === null || a === undefined || b === null || b === undefined) return (a ?? null) === (b ?? null);
  if (typeof a === 'object' || typeof b === 'object') return JSON.stringify(a) === JSON.stringify(b);
  return toText(a) === toText(b);
}

function toDate(value: unknown): Date {
  if (value instanceof Date) return value;
  if (typeof value === 'number') return new Date(value);
  if (typeof value === 'string' && /^\d{2}\/\d{2}\/\d{4}/.test(value)) {
    const [d, m, y] = value.split(/[/\s]/);
    return new Date(Number(y), Number(m) - 1, Number(d));
  }
  return value === undefined || value === null || value === '' ? new Date() : new Date(String(value));
}

function pad(n: number, size = 2): string {
  return String(n).padStart(size, '0');
}

function formatDate(value: unknown, pattern = 'dd/MM/yyyy'): string {
  const date = toDate(value);
  if (Number.isNaN(date.getTime())) return '';
  const months = ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
  const days = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado'];
  const parts: Record<string, string> = {
    yyyy: String(date.getFullYear()),
    yy: String(date.getFullYear()).slice(-2),
    MMMM: months[date.getMonth()] ?? '',
    MMM: (months[date.getMonth()] ?? '').slice(0, 3),
    MM: pad(date.getMonth() + 1),
    M: String(date.getMonth() + 1),
    dddd: days[date.getDay()] ?? '',
    dd: pad(date.getDate()),
    d: String(date.getDate()),
    HH: pad(date.getHours()),
    H: String(date.getHours()),
    mm: pad(date.getMinutes()),
    ss: pad(date.getSeconds()),
  };
  return pattern.replace(/yyyy|yy|MMMM|MMM|MM|M|dddd|dd|d|HH|H|mm|ss/g, (token) => parts[token] ?? token);
}

function pick(item: unknown, field: unknown): unknown {
  if (field === undefined || field === null || field === '') return item;
  return String(field)
    .split('.')
    .reduce<unknown>((value, key) => member(value, key), item);
}

function asList(value: unknown): unknown[] {
  if (Array.isArray(value)) return value;
  if (value === null || value === undefined || value === '') return [];
  if (typeof value === 'object') return Object.values(value);
  return [value];
}

// As funções disponíveis nas expressões e como filtros. Nenhuma tem efeito colateral.
export const FUNCTIONS: Record<string, (...args: unknown[]) => unknown> = {
  upper: (v) => toText(v).toUpperCase(),
  lower: (v) => toText(v).toLowerCase(),
  capitalize: (v) => toText(v).replace(/(^|\s)(\p{L})/gu, (_m, s: string, c: string) => s + c.toUpperCase()),
  trim: (v) => toText(v).trim(),
  len: (v) => (Array.isArray(v) ? v.length : typeof v === 'object' && v !== null ? Object.keys(v).length : toText(v).length),
  default: (v, fallback) => (v === null || v === undefined || v === '' ? fallback : v),
  money: (v, currency = 'BRL', locale = 'pt-BR') => {
    const n = num(v);
    return Number.isFinite(n) ? n.toLocaleString(String(locale), { style: 'currency', currency: String(currency) }) : '';
  },
  number: (v, decimals = 0, locale = 'pt-BR') => {
    const n = num(v);
    const d = num(decimals);
    return Number.isFinite(n) ? n.toLocaleString(String(locale), { minimumFractionDigits: d, maximumFractionDigits: d }) : '';
  },
  percent: (v, decimals = 0) => {
    const n = num(v);
    return Number.isFinite(n) ? `${n.toLocaleString('pt-BR', { maximumFractionDigits: num(decimals) })}%` : '';
  },
  date: (v, pattern) => formatDate(v, pattern === undefined ? 'dd/MM/yyyy' : toText(pattern)),
  datetime: (v) => formatDate(v, 'dd/MM/yyyy HH:mm'),
  now: () => Date.now(),
  today: () => formatDate(new Date(), 'dd/MM/yyyy'),
  addDays: (v, days) => {
    const date = toDate(v);
    date.setDate(date.getDate() + num(days));
    return date.getTime();
  },
  daysBetween: (a, b) => Math.round((toDate(b).getTime() - toDate(a).getTime()) / 86400000),
  round: (v, decimals = 0) => {
    const factor = 10 ** num(decimals);
    return Math.round(num(v) * factor) / factor;
  },
  floor: (v) => Math.floor(num(v)),
  ceil: (v) => Math.ceil(num(v)),
  abs: (v) => Math.abs(num(v)),
  min: (...v) => Math.min(...(v.length === 1 ? asList(v[0]) : v).map(num)),
  max: (...v) => Math.max(...(v.length === 1 ? asList(v[0]) : v).map(num)),
  sum: (list, field) => asList(list).reduce<number>((total, item) => total + (num(pick(item, field)) || 0), 0),
  avg: (list, field) => {
    const items = asList(list);
    return items.length === 0 ? 0 : items.reduce<number>((total, item) => total + (num(pick(item, field)) || 0), 0) / items.length;
  },
  count: (list, field, value) => (field === undefined ? asList(list).length : asList(list).filter((item) => looseEqual(pick(item, field), value)).length),
  int: (v) => Math.trunc(num(v)) || 0,
  float: (v) => num(v) || 0,
  str: (v) => toText(v),
  bool: (v) => truthy(v),
  json: (v) => JSON.stringify(v, null, 2),
  parse: (v) => {
    try {
      return JSON.parse(toText(v)) as unknown;
    } catch {
      return null;
    }
  },
  join: (list, separator = ', ') => asList(list).map(toText).join(toText(separator)),
  split: (v, separator = ',') => toText(v).split(toText(separator)).map((part) => part.trim()),
  includes: (haystack, needle) => (Array.isArray(haystack) ? haystack.some((item) => looseEqual(item, needle)) : toText(haystack).toLowerCase().includes(toText(needle).toLowerCase())),
  startsWith: (v, prefix) => toText(v).startsWith(toText(prefix)),
  endsWith: (v, suffix) => toText(v).endsWith(toText(suffix)),
  replace: (v, find, replacement = '') => toText(v).split(toText(find)).join(toText(replacement)),
  slice: (v, start = 0, end) => (Array.isArray(v) ? v.slice(num(start), end === undefined ? undefined : num(end)) : toText(v).slice(num(start), end === undefined ? undefined : num(end))),
  truncate: (v, size = 80) => {
    const text = toText(v);
    const max = num(size);
    return text.length > max ? `${text.slice(0, Math.max(0, max - 1))}…` : text;
  },
  first: (v) => asList(v)[0],
  last: (v) => asList(v).at(-1),
  keys: (v) => (typeof v === 'object' && v !== null ? Object.keys(v) : []),
  values: (v) => asList(v),
  map: (list, field) => asList(list).map((item) => pick(item, field)),
  filter: (list, field, value) => asList(list).filter((item) => (value === undefined ? truthy(pick(item, field)) : looseEqual(pick(item, field), value))),
  search: (list, text, field) => {
    const needle = toText(text).toLowerCase();
    if (!needle) return asList(list);
    return asList(list).filter((item) => toText(field === undefined ? item : pick(item, field)).toLowerCase().includes(needle));
  },
  find: (list, field, value) => asList(list).find((item) => looseEqual(pick(item, field), value)),
  sort: (list, field, direction = 'asc') => {
    const items = [...asList(list)];
    const sign = toText(direction) === 'desc' ? -1 : 1;
    return items.sort((a, b) => {
      const x = pick(a, field);
      const y = pick(b, field);
      const nx = num(x);
      const ny = num(y);
      if (Number.isFinite(nx) && Number.isFinite(ny)) return (nx - ny) * sign;
      return toText(x).localeCompare(toText(y), 'pt-BR') * sign;
    });
  },
  reverse: (list) => [...asList(list)].reverse(),
  unique: (list) => [...new Set(asList(list).map((item) => JSON.stringify(item)))].map((item) => JSON.parse(item) as unknown),
  range: (a, b) => {
    const start = b === undefined ? 0 : num(a);
    const end = b === undefined ? num(a) : num(b);
    const out: number[] = [];
    for (let i = start; i < end && out.length < 10000; i += 1) out.push(i);
    return out;
  },
  concat: (...v) => (Array.isArray(v[0]) ? v.flatMap(asList) : v.map(toText).join('')),
  if: (test, yes, no) => (truthy(test) ? yes : no),
  random: (a, b) => (a === undefined ? Math.random() : Math.floor(num(a) + Math.random() * (num(b ?? a) - num(b === undefined ? 0 : a) + 1))),
  uuid: () => crypto.randomUUID(),
  encode: (v) => encodeURIComponent(toText(v)),
  escape: (v) => escapeHtml(toText(v)),
  pluralize: (n, one, many) => (num(n) === 1 ? toText(one) : toText(many)),
  initials: (v) =>
    toText(v)
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, 2)
      .map((part) => part[0]?.toUpperCase() ?? '')
      .join(''),
  cpf: (v) => toText(v).replace(/\D/g, '').replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4'),
  cnpj: (v) => toText(v).replace(/\D/g, '').replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5'),
  phone: (v) => {
    const digits = toText(v).replace(/\D/g, '');
    return digits.length === 11 ? digits.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3') : digits.replace(/(\d{2})(\d{4})(\d{4})/, '($1) $2-$3');
  },
};

export function evaluate(node: Node, scope: Scope): unknown {
  switch (node.k) {
    case 'lit':
      return node.v;
    case 'name':
      if (Object.prototype.hasOwnProperty.call(scope, node.v)) return scope[node.v];
      if (node.v === 'Infinity') return Infinity;
      return undefined;
    case 'member':
      return member(evaluate(node.obj, scope), evaluate(node.prop, scope));
    case 'array':
      return node.items.map((item) => evaluate(item, scope));
    case 'object':
      return Object.fromEntries(node.entries.filter(([key]) => !BLOCKED.has(key)).map(([key, value]) => [key, evaluate(value, scope)]));
    case 'call': {
      const fn = FUNCTIONS[node.fn];
      if (!fn) throw new ExpressionError(`Função desconhecida: ${node.fn}`);
      return fn(...node.args.map((arg) => evaluate(arg, scope)));
    }
    case 'unary': {
      const value = evaluate(node.arg, scope);
      if (node.op === '!') return !truthy(value);
      if (node.op === '-') return -num(value);
      return num(value);
    }
    case 'cond':
      return truthy(evaluate(node.test, scope)) ? evaluate(node.yes, scope) : evaluate(node.no, scope);
    case 'binary': {
      if (node.op === '&&') {
        const left = evaluate(node.left, scope);
        return truthy(left) ? evaluate(node.right, scope) : left;
      }
      if (node.op === '||') {
        const left = evaluate(node.left, scope);
        return truthy(left) ? left : evaluate(node.right, scope);
      }
      if (node.op === '??') {
        const left = evaluate(node.left, scope);
        return left === null || left === undefined ? evaluate(node.right, scope) : left;
      }
      const left = evaluate(node.left, scope);
      const right = evaluate(node.right, scope);
      switch (node.op) {
        case '+': {
          if (Array.isArray(left)) return [...left, ...asList(right)];
          const bothNumeric = (typeof left === 'number' || typeof left === 'boolean') && (typeof right === 'number' || typeof right === 'boolean');
          return bothNumeric ? num(left) + num(right) : toText(left) + toText(right);
        }
        case '-':
          return num(left) - num(right);
        case '*':
          return num(left) * num(right);
        case '/':
          return num(right) === 0 ? 0 : num(left) / num(right);
        case '%':
          return num(right) === 0 ? 0 : num(left) % num(right);
        case '==':
        case '===':
          return looseEqual(left, right);
        case '!=':
        case '!==':
          return !looseEqual(left, right);
        case '<':
        case '>':
        case '<=':
        case '>=': {
          const numeric = Number.isFinite(num(left)) && Number.isFinite(num(right)) && left !== '' && right !== '';
          const a = numeric ? num(left) : toText(left);
          const b = numeric ? num(right) : toText(right);
          if (node.op === '<') return a < b;
          if (node.op === '>') return a > b;
          if (node.op === '<=') return a <= b;
          return a >= b;
        }
        default:
          throw new ExpressionError(`Operador desconhecido: ${node.op}`);
      }
    }
  }
}

export function run(source: string, scope: Scope): unknown {
  if (source.trim() === '') return undefined;
  return evaluate(parse(source), scope);
}

// Avalia sem lançar: devolve o erro como texto, para a interface mostrar.
export function tryRun(source: string, scope: Scope): { readonly value: unknown; readonly error: string | null } {
  try {
    return { value: run(source, scope), error: null };
  } catch (error) {
    return { value: undefined, error: error instanceof Error ? error.message : String(error) };
  }
}

export function check(source: string): string | null {
  try {
    if (source.trim() !== '') parse(source);
    return null;
  } catch (error) {
    return error instanceof Error ? error.message : String(error);
  }
}

export function escapeHtml(text: string): string {
  return text.replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[ch] ?? ch);
}

const TEMPLATE = /\{\{\{([\s\S]+?)\}\}\}|\{\{([\s\S]+?)\}\}/g;

export function hasTemplate(text: string): boolean {
  return text.includes('{{');
}

// Um texto com {{ expressões }}. Em HTML, o valor é escapado; {{{ expressão }}} insere sem escapar.
export function renderTemplate(text: string, scope: Scope, html = false): string {
  if (!text.includes('{{')) return text;
  return text.replace(TEMPLATE, (_match, raw: string | undefined, escaped: string | undefined) => {
    const source = (raw ?? escaped ?? '').trim();
    let value: unknown;
    try {
      value = run(source, scope);
    } catch {
      value = '';
    }
    const textValue = toText(value);
    return html && raw === undefined ? escapeHtml(textValue) : textValue;
  });
}

// Os nomes de primeiro nível que um texto com {{ }} ou uma expressão lê: a extensão só reavalia o que depende da
// variável que mudou.
export function namesIn(source: string, isTemplate: boolean): Set<string> {
  const names = new Set<string>();
  const visit = (node: Node): void => {
    switch (node.k) {
      case 'name':
        names.add(node.v);
        break;
      case 'member':
        visit(node.obj);
        visit(node.prop);
        break;
      case 'call':
        node.args.forEach(visit);
        if (node.fn === 'now' || node.fn === 'today' || node.fn === 'random' || node.fn === 'uuid') names.add('now');
        break;
      case 'unary':
        visit(node.arg);
        break;
      case 'binary':
        visit(node.left);
        visit(node.right);
        break;
      case 'cond':
        visit(node.test);
        visit(node.yes);
        visit(node.no);
        break;
      case 'array':
        node.items.forEach(visit);
        break;
      case 'object':
        node.entries.forEach(([, value]) => visit(value));
        break;
      case 'lit':
        break;
    }
  };
  const sources = isTemplate ? [...source.matchAll(TEMPLATE)].map((m) => (m[1] ?? m[2] ?? '').trim()) : [source];
  for (const piece of sources) {
    try {
      if (piece) visit(parse(piece));
    } catch {
      // expressão inválida: a interface já mostra o erro; aqui ela não depende de nada
    }
  }
  return names;
}

// Lê um texto de CSV (com aspas e separador , ou ;) como lista de objetos, pelo cabeçalho.
export function parseCsv(text: string): Record<string, string>[] {
  const firstLine = text.split(/\r?\n/, 1)[0] ?? '';
  const separator = (firstLine.match(/;/g)?.length ?? 0) > (firstLine.match(/,/g)?.length ?? 0) ? ';' : ',';
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = '';
  let quoted = false;
  for (let i = 0; i < text.length; i += 1) {
    const ch = text[i];
    if (quoted) {
      if (ch === '"' && text[i + 1] === '"') {
        cell += '"';
        i += 1;
      } else if (ch === '"') quoted = false;
      else cell += ch;
    } else if (ch === '"') quoted = true;
    else if (ch === separator) {
      row.push(cell);
      cell = '';
    } else if (ch === '\n' || ch === '\r') {
      if (ch === '\r' && text[i + 1] === '\n') i += 1;
      row.push(cell);
      rows.push(row);
      row = [];
      cell = '';
    } else cell += ch;
  }
  if (cell !== '' || row.length > 0) {
    row.push(cell);
    rows.push(row);
  }
  const [header, ...body] = rows.filter((r) => r.some((c) => c.trim() !== ''));
  if (!header) return [];
  const keys = header.map((h) => h.trim());
  return body.map((cells) => Object.fromEntries(keys.map((key, index) => [key, (cells[index] ?? '').trim()])));
}

export function setPath(target: Record<string, unknown>, path: string, value: unknown): void {
  const keys = path.split('.').filter(Boolean);
  let cursor: Record<string, unknown> = target;
  keys.forEach((key, index) => {
    if (BLOCKED.has(key)) return;
    if (index === keys.length - 1) cursor[key] = value;
    else {
      const next = cursor[key];
      if (typeof next !== 'object' || next === null) cursor[key] = {};
      cursor = cursor[key] as Record<string, unknown>;
    }
  });
}

export function getPath(source: unknown, path: string | undefined): unknown {
  return pick(source, path);
}
