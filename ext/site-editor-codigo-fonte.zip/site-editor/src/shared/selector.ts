// O seletor CSS de um elemento escolhido na página: o mais curto que o acha sozinho e que sobrevive a uma nova
// renderização. Ids e classes geradas por ferramentas (css-1x2y3z, sc-abc, jsx-123, :r1:) mudam a cada build e
// ficam de fora; atributos feitos para testes e acessibilidade (data-testid, aria-label, name) vêm primeiro.

const STABLE_ATTRIBUTES = ['data-testid', 'data-test', 'data-test-id', 'data-cy', 'data-qa', 'data-id', 'data-key', 'name', 'aria-label', 'title', 'alt', 'placeholder', 'for', 'role', 'type'];

const GENERATED = /^(css|sc|jsx|emotion|styled|svelte|astro|ng|_|mui|chakra|tw|v-)[-_]?[a-z0-9]*\d|[a-f0-9]{6,}|^[a-z]{1,3}\d{3,}|__[a-zA-Z0-9]{5}$|^\d|[:]/i;

export function cssEscape(value: string): string {
  if (typeof CSS !== 'undefined' && typeof CSS.escape === 'function') return CSS.escape(value);
  return value.replace(/[^a-zA-Z0-9_-]/g, (ch) => `\\${ch}`);
}

function stableId(id: string): boolean {
  return id.length > 0 && id.length < 60 && !GENERATED.test(id) && !/\d{4,}/.test(id);
}

function stableClasses(element: Element): string[] {
  return Array.from(element.classList)
    .filter((name) => name.length < 40 && !GENERATED.test(name) && !name.startsWith('wce-') && !/\d{3,}/.test(name) && !/^(active|hover|focus|selected|open|show|is-|has-)/.test(name))
    .slice(0, 3);
}

function unique(root: ParentNode, selector: string, element: Element): boolean {
  try {
    const found = root.querySelectorAll(selector);
    return found.length === 1 && found[0] === element;
  } catch {
    return false;
  }
}

function attributeSelector(element: Element, name: string): string | null {
  const value = element.getAttribute(name);
  if (value === null || value === '' || value.length > 80) return null;
  return `${element.localName}[${name}="${value.replace(/["\\]/g, '\\$&')}"]`;
}

// O passo de um elemento dentro do pai: tag, classes estáveis e, se preciso, :nth-of-type.
function step(element: Element): string {
  let part = element.localName;
  if (element.id && stableId(element.id)) return `#${cssEscape(element.id)}`;
  const classes = stableClasses(element);
  if (classes.length > 0) part += classes.map((name) => `.${cssEscape(name)}`).join('');
  const parent = element.parentElement;
  if (parent) {
    const siblings = Array.from(parent.children).filter((sibling) => sibling.localName === element.localName);
    const same = siblings.filter((sibling) => {
      try {
        return sibling.matches(part);
      } catch {
        return false;
      }
    });
    if (same.length > 1) part = `${element.localName}${classes.map((name) => `.${cssEscape(name)}`).join('')}:nth-of-type(${siblings.indexOf(element) + 1})`;
  }
  return part;
}

export function selectorFor(element: Element): string {
  const doc = element.ownerDocument;
  const root: ParentNode = element.getRootNode() instanceof ShadowRoot ? (element.getRootNode() as ShadowRoot) : doc;
  if (element === doc.body) return 'body';
  if (element === doc.documentElement) return 'html';
  // dentro de um componente inserido pelo editor: o caminho parte do próprio componente, que tem id fixo
  const holder = element.closest('wce-insert[data-wce-edit]');
  if (holder && holder !== element) {
    const steps: string[] = [];
    for (let cursor: Element | null = element; cursor && cursor !== holder; cursor = cursor.parentElement) steps.unshift(step(cursor));
    const anchored = `wce-insert[data-wce-edit="${holder.getAttribute('data-wce-edit')}"] > ${steps.join(' > ')}`;
    if (unique(root, anchored, element)) return anchored;
  }
  if (element.id && stableId(element.id) && unique(root, `#${cssEscape(element.id)}`, element)) return `#${cssEscape(element.id)}`;
  for (const name of STABLE_ATTRIBUTES) {
    const candidate = attributeSelector(element, name);
    if (candidate && unique(root, candidate, element)) return candidate;
  }
  const classes = stableClasses(element);
  if (classes.length > 0) {
    const candidate = `${element.localName}${classes.map((name) => `.${cssEscape(name)}`).join('')}`;
    if (unique(root, candidate, element)) return candidate;
  }
  // caminho a partir do ancestral mais próximo que se acha sozinho
  const parts: string[] = [];
  let cursor: Element | null = element;
  while (cursor && cursor !== doc.documentElement) {
    parts.unshift(step(cursor));
    const candidate = parts.join(' > ');
    if (unique(root, candidate, element)) return candidate;
    const parent: Element | null = cursor.parentElement;
    if (parent && parent !== doc.body && parent !== doc.documentElement) {
      if (parent.id && stableId(parent.id) && unique(root, `#${cssEscape(parent.id)}`, parent)) {
        const anchored = `#${cssEscape(parent.id)} > ${candidate}`;
        if (unique(root, anchored, element)) return anchored;
      }
      for (const name of STABLE_ATTRIBUTES) {
        const anchor = attributeSelector(parent, name);
        if (anchor && unique(root, anchor, parent)) {
          const anchored = `${anchor} > ${candidate}`;
          if (unique(root, anchored, element)) return anchored;
        }
      }
    }
    cursor = parent;
  }
  return parts.length > 0 ? `body > ${parts.join(' > ')}` : element.localName;
}

// Um seletor para todos os irmãos parecidos (os itens de uma lista, as linhas de uma tabela).
export function similarSelector(element: Element): string {
  const exact = selectorFor(element);
  return exact.replace(/:nth-of-type\(\d+\)(?!.*:nth-of-type)/, '');
}

export function safeQueryAll(root: ParentNode, selector: string): Element[] {
  try {
    return Array.from(root.querySelectorAll(selector));
  } catch {
    return [];
  }
}

export function validSelector(selector: string): boolean {
  try {
    document.createDocumentFragment().querySelector(selector);
    return true;
  } catch {
    return false;
  }
}

export function describe(element: Element): string {
  const tag = element.localName;
  const id = element.id ? `#${element.id}` : '';
  const cls = Array.from(element.classList)
    .filter((name) => !name.startsWith('wce-'))
    .slice(0, 2)
    .map((name) => `.${name}`)
    .join('');
  return `${tag}${id}${cls}`;
}

const TAG_NAMES: Record<string, string> = {
  a: 'Link',
  button: 'Botão',
  img: 'Imagem',
  h1: 'Título 1',
  h2: 'Título 2',
  h3: 'Título 3',
  h4: 'Título 4',
  h5: 'Título 5',
  h6: 'Título 6',
  p: 'Parágrafo',
  span: 'Texto',
  div: 'Bloco',
  section: 'Seção',
  header: 'Cabeçalho',
  footer: 'Rodapé',
  nav: 'Navegação',
  ul: 'Lista',
  ol: 'Lista numerada',
  li: 'Item de lista',
  input: 'Campo',
  textarea: 'Área de texto',
  select: 'Seleção',
  label: 'Rótulo',
  form: 'Formulário',
  table: 'Tabela',
  tr: 'Linha',
  td: 'Célula',
  th: 'Cabeçalho de coluna',
  video: 'Vídeo',
  iframe: 'Quadro incorporado',
  svg: 'Ícone',
  main: 'Conteúdo principal',
  aside: 'Barra lateral',
  article: 'Artigo',
  figure: 'Figura',
};

export function friendlyName(element: Element): string {
  return TAG_NAMES[element.localName] ?? element.localName;
}
