// O que sai de um projeto: o arquivo do projeto (JSON), o código para instalar as personalizações em qualquer site
// (wc-runtime.js com o projeto embutido ou buscado da nuvem) e o ZIP da página editada para o importador do
// Webconstructor (Arquivo › Importar HTML/ZIP).
import { isDynamicEdit } from '../engine/engine.ts';
import type { Project } from './model.ts';
import { makeZip } from './zip.ts';

export function projectFile(projects: readonly Project[]): string {
  return JSON.stringify({ kind: 'webconstructor-site-editor', format: 1, exportedAt: new Date().toISOString(), projects }, null, 2);
}

function safeJson(value: unknown): string {
  // dentro de <script>: </script> e <!-- não podem aparecer no texto
  return JSON.stringify(value).replace(/</g, '\\u003c').replace(/>/g, '\\u003e').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
}

export interface SnippetOptions {
  readonly runtimeUrl: string;
  readonly clientId?: string | null;
  // modo nuvem: o script busca o projeto publicado
  readonly cloud?: { readonly endpoint: string; readonly key: string };
}

export function installSnippet(project: Project, options: SnippetOptions): string {
  const client = options.clientId ? ` data-wce-client="${options.clientId}"` : '';
  if (options.cloud) return `<script src="${options.runtimeUrl}" data-wce-endpoint="${options.cloud.endpoint}" data-wce-key="${options.cloud.key}"${client} defer></script>`;
  return `<script>window.WCE_PROJECTS = (window.WCE_PROJECTS || []).concat(${safeJson([project])});</script>\n<script src="${options.runtimeUrl}"${client} defer></script>`;
}

// Um arquivo único: o motor e o projeto juntos, para colar num <script> ou servir como .js.
export function standaloneScript(project: Project, runtimeSource: string, clientId?: string | null): string {
  return `/* Webconstructor Site Editor: ${project.name.replace(/\*\//g, '')} */\nwindow.WCE_PROJECTS = (window.WCE_PROJECTS || []).concat(${safeJson([project])});\n${clientId ? `window.WCE_CLIENT = ${JSON.stringify(clientId)};\n` : ''}${runtimeSource}`;
}

const URL_ATTRIBUTES = ['src', 'href', 'poster', 'action', 'data-full'];

function absolutize(root: Element, base: string): void {
  for (const element of [root, ...Array.from(root.querySelectorAll('*'))]) {
    for (const name of URL_ATTRIBUTES) {
      const value = element.getAttribute(name);
      if (value === null || value === '' || value.startsWith('#') || /^(data|blob|javascript|mailto|tel):/i.test(value)) continue;
      try {
        element.setAttribute(name, new URL(value, base).href);
      } catch {
        // endereço inválido: fica como está
      }
    }
    const srcset = element.getAttribute('srcset');
    if (srcset) {
      element.setAttribute(
        'srcset',
        srcset
          .split(',')
          .map((part) => {
            const [address, ...rest] = part.trim().split(/\s+/);
            try {
              return [new URL(address ?? '', base).href, ...rest].join(' ');
            } catch {
              return part.trim();
            }
          })
          .join(', '),
      );
    }
  }
}

function sheetText(sheet: CSSStyleSheet, base: string): string | null {
  let rules: CSSRuleList;
  try {
    rules = sheet.cssRules;
  } catch {
    return null;
  }
  const sheetBase = sheet.href ?? base;
  return Array.from(rules)
    .map((rule) => rule.cssText)
    .join('\n')
    .replace(/url\(\s*(['"]?)([^'")]+)\1\s*\)/g, (match, quote: string, address: string) => {
      if (/^(data|blob):/i.test(address) || address.startsWith('#')) return match;
      try {
        return `url(${quote}${new URL(address, sheetBase).href}${quote})`;
      } catch {
        return match;
      }
    });
}

export interface PageZip {
  readonly bytes: Uint8Array;
  readonly files: readonly string[];
}

// A página como está na tela (com as alterações), pronta para o Webconstructor: index.html, styles.css com as folhas
// legíveis e, se o projeto tem partes dinâmicas (variáveis, regras, dados, ligações), o motor com essas partes.
export function pageZip(doc: Document, project: Project, runtimeSource: string | null, options: { readonly keepScripts?: boolean } = {}): PageZip {
  const base = doc.baseURI;
  // cada folha da página ganha um número antes da cópia: a cópia acha a sua folha (e as regras dela) pelo número
  const originals = Array.from(doc.querySelectorAll<HTMLLinkElement | HTMLStyleElement>('link[rel~="stylesheet"], style'));
  originals.forEach((node, index) => node.setAttribute('data-wce-sheet', String(index)));
  const clone = doc.documentElement.cloneNode(true) as HTMLElement;
  originals.forEach((node) => node.removeAttribute('data-wce-sheet'));
  // o editor e as camadas da extensão saem
  clone.querySelectorAll('[data-wce-ui]').forEach((node) => node.remove());
  clone.querySelectorAll('wce-editor,wce-layer,wce-pair').forEach((node) => node.remove());
  const dynamicIds = new Set(project.edits.filter(isDynamicEdit).map((edit) => edit.id));
  const hasDynamic = runtimeSource !== null && (dynamicIds.size > 0 || project.rules.length > 0 || project.sources.length > 0 || project.variables.length > 0);
  // o que o motor gera a partir de dados volta a ser gerado no site; o resto fica como está
  clone.querySelectorAll('[data-wce-index]').forEach((node) => {
    if (hasDynamic) node.remove();
    else node.removeAttribute('data-wce-index');
  });
  clone.querySelectorAll('wce-insert').forEach((holder) => {
    const id = holder.getAttribute('data-wce-edit') ?? '';
    if (hasDynamic && dynamicIds.has(id)) holder.remove();
    else holder.replaceWith(...Array.from(holder.childNodes));
  });
  clone.querySelectorAll('[data-wce-hidden],[data-wce-bind-hidden],[data-wce-rule-hidden]').forEach((node) => {
    if (!hasDynamic) node.remove();
  });
  clone.querySelectorAll('[data-wce-html],[data-wce-two-way]').forEach((node) => {
    node.removeAttribute('data-wce-html');
    node.removeAttribute('data-wce-two-way');
  });
  clone.classList.remove('wce-editing', 'wce-show-hidden', 'wce-pick');
  clone.removeAttribute('data-wce-bridge');
  clone.querySelectorAll('[data-wce-editing]').forEach((node) => {
    node.removeAttribute('data-wce-editing');
    node.removeAttribute('contenteditable');
  });
  if (!options.keepScripts) clone.querySelectorAll('script').forEach((node) => node.remove());
  clone.querySelectorAll('noscript').forEach((node) => node.remove());
  // folhas de estilo: as legíveis viram styles.css; as de outro domínio que o navegador não deixa ler ficam como link
  const css: string[] = [];
  const copies = Array.from(clone.querySelectorAll('link[rel~="stylesheet"], style'));
  copies.forEach((node, index) => {
    const original = originals[Number(node.getAttribute('data-wce-sheet'))];
    node.removeAttribute('data-wce-sheet');
    const sheet = original?.sheet ?? null;
    const text = sheet ? sheetText(sheet, base) : null;
    if (text !== null) {
      css.push(`/* ${sheet?.href ?? `estilo ${index + 1}`} */\n${text}`);
      node.remove();
    }
  });
  const ourStyle = Array.from(doc.querySelectorAll('style[data-wce-ui="style"]'))
    .map((node) => node.textContent ?? '')
    .join('\n');
  css.push(`/* Site Editor */\n${ourStyle.replace(/html\.wce-show-hidden[^\n]*\n/g, '')}`);
  absolutize(clone, base);
  const head = clone.querySelector('head') ?? clone.insertBefore(doc.createElement('head'), clone.firstChild);
  head.querySelectorAll('base').forEach((node) => node.remove());
  const link = doc.createElement('link');
  link.rel = 'stylesheet';
  link.href = 'styles.css';
  head.appendChild(link);
  const files: { path: string; data: string }[] = [];
  if (hasDynamic && runtimeSource !== null) {
    const subset: Project = { ...project, css: '', clients: project.clients, edits: project.edits.filter((edit) => dynamicIds.has(edit.id)) };
    const script = doc.createElement('script');
    script.src = 'wc-runtime.js';
    script.defer = true;
    const config = doc.createElement('script');
    config.textContent = `window.WCE_PROJECTS = ${safeJson([{ ...subset, matches: ['*'] }])};`;
    clone.querySelector('body')?.append(config, script);
    files.push({ path: 'wc-runtime.js', data: runtimeSource });
  }
  const html = `<!doctype html>\n${clone.outerHTML}`;
  files.unshift({ path: 'index.html', data: html }, { path: 'styles.css', data: css.join('\n\n') });
  return { bytes: makeZip(files), files: files.map((file) => file.path) };
}

export function download(doc: Document, name: string, data: Uint8Array | string, type: string): void {
  const blob = new Blob([typeof data === 'string' ? data : new Uint8Array(data)], { type });
  const url = URL.createObjectURL(blob);
  const anchor = doc.createElement('a');
  anchor.href = url;
  anchor.download = name;
  anchor.setAttribute('data-wce-ui', 'download');
  anchor.style.display = 'none';
  doc.documentElement.appendChild(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}

export function slug(text: string): string {
  return (
    text
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '')
      .slice(0, 60) || 'projeto'
  );
}
