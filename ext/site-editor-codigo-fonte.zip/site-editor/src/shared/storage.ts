// Onde a extensão guarda os projetos: chrome.storage.local (com unlimitedStorage), um item por projeto e um índice
// pequeno com os padrões de endereço, que o script de conteúdo lê em toda página para saber se há algo a aplicar.
// Cada gravação guarda também uma cópia em um histórico curto (as versões do projeto, para voltar atrás).
import { anyMatches } from './match.ts';
import { normalizeProject, type Project } from './model.ts';

export interface IndexEntry {
  readonly id: string;
  readonly name: string;
  readonly matches: string[];
  readonly enabled: boolean;
  readonly updatedAt: number;
}

export interface Revision {
  readonly at: number;
  readonly label: string;
  readonly project: Project;
}

export interface Settings {
  // a origem do editor Webconstructor (ex.: https://app.seudominio.com.br), para a integração
  builderUrl: string;
  supabaseUrl: string;
  supabaseKey: string;
  showHidden: boolean;
  toolbarSide: 'left' | 'right';
  companionPort: number;
  companionToken: string;
  // origens que podem falar com a extensão pela ponte (o editor e o painel do Webconstructor)
  allowedOrigins: string[];
}

export const DEFAULT_SETTINGS: Settings = {
  builderUrl: '',
  supabaseUrl: '',
  supabaseKey: '',
  showHidden: false,
  toolbarSide: 'right',
  companionPort: 5410,
  companionToken: '',
  allowedOrigins: [],
};

const INDEX = 'wce:index';
const SETTINGS = 'wce:settings';
const projectKey = (id: string): string => `wce:project:${id}`;
const historyKey = (id: string): string => `wce:history:${id}`;
const HISTORY_SIZE = 30;

export const STORAGE_PREFIX = 'wce:';

function area(): chrome.storage.StorageArea {
  return chrome.storage.local;
}

export async function readIndex(): Promise<IndexEntry[]> {
  const stored = await area().get(INDEX);
  const list = stored[INDEX];
  return Array.isArray(list) ? (list as IndexEntry[]) : [];
}

export async function listProjects(): Promise<Project[]> {
  const index = await readIndex();
  if (index.length === 0) return [];
  const stored = await area().get(index.map((entry) => projectKey(entry.id)));
  return index.flatMap((entry) => {
    const value = stored[projectKey(entry.id)];
    return value ? [value as Project] : [];
  });
}

export async function getProject(id: string): Promise<Project | null> {
  const stored = await area().get(projectKey(id));
  return (stored[projectKey(id)] as Project | undefined) ?? null;
}

export async function projectsFor(href: string, includeDisabled = false): Promise<Project[]> {
  const index = await readIndex();
  const wanted = index.filter((entry) => (includeDisabled || entry.enabled) && anyMatches(entry.matches, href));
  if (wanted.length === 0) return [];
  const stored = await area().get(wanted.map((entry) => projectKey(entry.id)));
  return wanted.flatMap((entry) => {
    const value = stored[projectKey(entry.id)];
    return value ? [value as Project] : [];
  });
}

function entryOf(project: Project): IndexEntry {
  return { id: project.id, name: project.name, matches: project.matches, enabled: project.enabled, updatedAt: project.updatedAt };
}

export async function saveProject(project: Project, label = 'Alteração', options: { readonly touch?: boolean; readonly history?: boolean } = {}): Promise<Project> {
  const saved: Project = { ...project, updatedAt: options.touch === false ? project.updatedAt : Date.now() };
  const index = await readIndex();
  const at = index.findIndex((entry) => entry.id === saved.id);
  const nextIndex = [...index];
  if (at === -1) nextIndex.push(entryOf(saved));
  else nextIndex[at] = entryOf(saved);
  const writes: Record<string, unknown> = { [projectKey(saved.id)]: saved, [INDEX]: nextIndex };
  if (options.history !== false) {
    const stored = await area().get(historyKey(saved.id));
    const history = Array.isArray(stored[historyKey(saved.id)]) ? (stored[historyKey(saved.id)] as Revision[]) : [];
    const last = history[0];
    // várias gravações seguidas da mesma coisa (digitação) viram uma versão só
    if (last && last.label === label && saved.updatedAt - last.at < 60000) history[0] = { at: saved.updatedAt, label, project: saved };
    else history.unshift({ at: saved.updatedAt, label, project: saved });
    writes[historyKey(saved.id)] = history.slice(0, HISTORY_SIZE);
  }
  await area().set(writes);
  return saved;
}

export async function deleteProject(id: string): Promise<void> {
  const index = await readIndex();
  await area().set({ [INDEX]: index.filter((entry) => entry.id !== id) });
  await area().remove([projectKey(id), historyKey(id)]);
}

export async function history(id: string): Promise<Revision[]> {
  const stored = await area().get(historyKey(id));
  const list = stored[historyKey(id)];
  return Array.isArray(list) ? (list as Revision[]) : [];
}

export async function readSettings(): Promise<Settings> {
  const stored = await area().get(SETTINGS);
  return { ...DEFAULT_SETTINGS, ...((stored[SETTINGS] as Partial<Settings> | undefined) ?? {}) };
}

export async function writeSettings(patch: Partial<Settings>): Promise<Settings> {
  const next = { ...(await readSettings()), ...patch };
  await area().set({ [SETTINGS]: next });
  return next;
}

export async function importProjects(raw: unknown): Promise<Project[]> {
  const list = Array.isArray(raw) ? raw : typeof raw === 'object' && raw !== null && Array.isArray((raw as { projects?: unknown }).projects) ? (raw as { projects: unknown[] }).projects : [raw];
  const imported: Project[] = [];
  for (const item of list) imported.push(await saveProject(normalizeProject(item), 'Importado'));
  return imported;
}

export function isProjectKey(key: string): boolean {
  return key.startsWith('wce:project:') || key === INDEX;
}

// Os valores das variáveis que persistem ('local'): ficam na extensão, por projeto e cliente.
export async function loadPersisted(key: string): Promise<Record<string, unknown>> {
  const stored = await area().get(`wce:vars:${key}`);
  return (stored[`wce:vars:${key}`] as Record<string, unknown> | undefined) ?? {};
}

export async function savePersisted(key: string, values: Record<string, unknown>): Promise<void> {
  await area().set({ [`wce:vars:${key}`]: values });
}
