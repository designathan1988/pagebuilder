// O CSS do editor, dentro do Shadow DOM: o da página não entra, e este não sai.
export const EDITOR_CSS = `
:host{all:initial;--ac:#2563eb;--ac-2:#1d4ed8;--ac-soft:#eff6ff;--bg:#fff;--bg-2:#f8fafc;--bg-3:#f1f5f9;--line:#e2e8f0;--line-2:#cbd5e1;--tx:#0f172a;--tx-2:#475569;--tx-3:#64748b;--ok:#047857;--warn:#b45309;--bad:#b91c1c;--r:10px;--shadow:0 12px 40px rgba(15,23,42,.18),0 2px 6px rgba(15,23,42,.08);font:13px/1.45 system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;color:var(--tx)}
@media (prefers-color-scheme:dark){:host{--ac:#3b82f6;--ac-2:#60a5fa;--ac-soft:#172554;--bg:#0f172a;--bg-2:#111c33;--bg-3:#1e293b;--line:#1e293b;--line-2:#334155;--tx:#e2e8f0;--tx-2:#cbd5e1;--tx-3:#94a3b8;--ok:#34d399;--warn:#fbbf24;--bad:#f87171}}
*{box-sizing:border-box}
button,input,select,textarea{font:inherit;color:inherit}
.hl{position:fixed;pointer-events:none;z-index:2147483640;border:2px solid var(--ac);border-radius:3px;transition:all .06s linear;display:none}
.hl.hover{border-style:dashed;background:rgba(37,99,235,.06)}
.hl.sel{border-width:2px;box-shadow:0 0 0 9999px rgba(15,23,42,.0)}
.hl.pick{border-color:#f97316;background:rgba(249,115,22,.08)}
.tag{position:fixed;z-index:2147483641;pointer-events:none;background:var(--ac);color:#fff;font-size:11px;padding:2px 6px;border-radius:4px;white-space:nowrap;display:none;max-width:60vw;overflow:hidden;text-overflow:ellipsis}
.tag.pick{background:#f97316}
.minibar{position:fixed;z-index:2147483643;display:none;gap:2px;background:var(--bg);border:1px solid var(--line);border-radius:10px;padding:3px;box-shadow:var(--shadow)}
.minibar .btn{padding:5px 7px}
.toolbar{position:fixed;z-index:2147483644;bottom:14px;left:10px;right:10px;margin:0 auto;width:max-content;display:flex;align-items:center;gap:4px;background:var(--bg);border:1px solid var(--line);border-radius:12px;padding:5px 6px;box-shadow:var(--shadow);max-width:calc(100vw - 20px);flex-wrap:nowrap;overflow-x:auto;scrollbar-width:thin}
.toolbar>*{flex-shrink:0}
.toolbar .brand{white-space:nowrap;display:flex;align-items:center;gap:6px;font-weight:650;padding:0 6px 0 4px;cursor:grab;user-select:none}
.toolbar .brand .dot{width:10px;height:10px;border-radius:50%;background:var(--ac)}
.toolbar .sep{width:1px;height:22px;background:var(--line);margin:0 3px}
.toolbar select{width:160px;max-width:160px;padding:5px 8px;border:1px solid var(--line);border-radius:8px;background:var(--bg-2)}
.status{font-size:12px;color:var(--tx-3);padding:0 6px;min-width:56px;text-align:center}
.status.err{color:var(--bad)}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;border:1px solid var(--line);background:var(--bg);padding:6px 10px;border-radius:8px;cursor:pointer;white-space:nowrap;line-height:1.2}
.btn:hover{background:var(--bg-3)}
.btn:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{outline:2px solid var(--ac);outline-offset:1px}
.btn-primary{background:var(--ac);border-color:var(--ac);color:#fff}
.btn-primary:hover{background:var(--ac-2)}
.btn-ghost{border-color:transparent;background:transparent}
.btn-danger{color:var(--bad)}
.btn-sm{padding:4px 8px;font-size:12px}
.btn-icon{padding:6px}
.btn[aria-pressed=true]{background:var(--ac-soft);border-color:var(--ac);color:var(--ac)}
.btn:disabled{opacity:.45;cursor:default}
.panel{position:fixed;z-index:2147483642;top:0;bottom:0;width:380px;max-width:100vw;background:var(--bg);border-left:1px solid var(--line);box-shadow:var(--shadow);display:flex;flex-direction:column}
.panel.right{right:0}.panel.left{left:0;border-left:0;border-right:1px solid var(--line)}
.panel.hidden{display:none}
.panel-head{display:flex;align-items:center;gap:6px;padding:10px 10px 0 12px}
.panel-head h2{font-size:14px;margin:0;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.tabs{display:flex;gap:2px;padding:8px 8px 0;border-bottom:1px solid var(--line);overflow-x:auto;scrollbar-width:thin}
.tab{display:flex;align-items:center;gap:5px;border:0;background:transparent;padding:7px 9px;border-radius:8px 8px 0 0;cursor:pointer;color:var(--tx-2);border-bottom:2px solid transparent;white-space:nowrap}
.tab[aria-selected=true]{color:var(--ac);border-bottom-color:var(--ac);font-weight:600}
.tab:hover{background:var(--bg-3)}
.body{flex:1;overflow:auto;padding:12px;scrollbar-width:thin}
.sec{border:1px solid var(--line);border-radius:var(--r);padding:10px 12px;margin:0 0 10px;background:var(--bg)}
.sec h3{margin:0 0 8px;font-size:12px;letter-spacing:.02em;text-transform:uppercase;color:var(--tx-3)}
.field{display:flex;flex-direction:column;gap:4px;margin:0 0 8px}
.field label{font-size:12px;color:var(--tx-2);font-weight:550}
.hint{font-size:11.5px;color:var(--tx-3)}
input[type=text],input[type=url],input[type=number],input:not([type]),input[type=color],input[type=search],select,textarea{width:100%;border:1px solid var(--line-2);border-radius:8px;padding:6px 8px;background:var(--bg)}
input[type=color]{padding:2px;height:32px}
textarea{resize:vertical;min-height:34px}
.mono{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:12px}
.row{display:flex;gap:6px;align-items:center;flex-wrap:wrap}
.row>*{min-width:0}
.grow{flex:1}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:6px 8px}
.check{display:flex;align-items:center;gap:6px;cursor:pointer;margin:2px 0}
.empty{color:var(--tx-3);font-size:12.5px;margin:4px 0 8px}
.crumbs{display:flex;flex-wrap:wrap;gap:2px;font-size:11.5px;margin:0 0 8px}
.crumbs button{border:0;background:var(--bg-3);padding:2px 6px;border-radius:5px;cursor:pointer;color:var(--tx-2)}
.crumbs button:last-child{background:var(--ac-soft);color:var(--ac);font-weight:600}
.item{border:1px solid var(--line);border-radius:9px;padding:8px 10px;margin:0 0 6px;display:flex;flex-direction:column;gap:4px;background:var(--bg)}
.item.off{opacity:.55}
.item .top{display:flex;align-items:center;gap:6px}
.item .title{font-weight:600;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.item .sub{font-size:11.5px;color:var(--tx-3);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.badge{display:inline-block;font-size:10.5px;padding:1px 6px;border-radius:999px;background:var(--bg-3);color:var(--tx-2);white-space:nowrap}
.badge.ac{background:var(--ac-soft);color:var(--ac)}
.badge.warn{background:#fef3c7;color:#92400e}
.err{color:var(--bad);font-size:12px}
.ok{color:var(--ok);font-size:12px}
.value{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:11.5px;background:var(--bg-3);border-radius:6px;padding:4px 6px;white-space:pre-wrap;word-break:break-all;max-height:120px;overflow:auto}
.lib{display:grid;grid-template-columns:repeat(auto-fill,minmax(104px,1fr));gap:6px}
.lib button{display:flex;flex-direction:column;align-items:flex-start;gap:2px;text-align:left;border:1px solid var(--line);background:var(--bg);border-radius:9px;padding:8px;cursor:pointer;min-height:58px}
.lib button:hover{border-color:var(--ac);background:var(--ac-soft)}
.lib b{font-size:12.5px}
.lib small{font-size:11px;color:var(--tx-3)}
.cat{font-size:11.5px;font-weight:650;color:var(--tx-3);margin:10px 0 6px;text-transform:uppercase;letter-spacing:.03em}
.actions{display:flex;flex-direction:column;gap:6px}
.action{border:1px dashed var(--line-2);border-radius:8px;padding:8px;display:flex;flex-direction:column;gap:6px}
.banner{position:fixed;z-index:2147483644;left:50%;top:14px;transform:translateX(-50%);background:#f97316;color:#fff;padding:8px 14px;border-radius:10px;box-shadow:var(--shadow);display:flex;gap:10px;align-items:center}
.banner .btn{background:rgba(255,255,255,.15);border-color:rgba(255,255,255,.4);color:#fff}
.toast{position:fixed;z-index:2147483646;left:50%;top:14px;transform:translateX(-50%);background:#0f172a;color:#fff;padding:8px 14px;border-radius:10px;box-shadow:var(--shadow);max-width:calc(100vw - 32px)}
.toast.err{background:#b91c1c}
.welcome{position:fixed;z-index:2147483645;inset:0;background:rgba(15,23,42,.45);display:flex;align-items:center;justify-content:center;padding:16px}
.welcome .card{background:var(--bg);border-radius:14px;max-width:440px;width:100%;padding:18px;box-shadow:var(--shadow)}
.welcome h2{margin:0 0 6px;font-size:17px}
.welcome p{margin:0 0 12px;color:var(--tx-2)}
.inline-edit{outline:2px solid #f97316 !important;outline-offset:2px}
.kbd{font-family:ui-monospace,Menlo,monospace;font-size:11px;background:var(--bg-3);border:1px solid var(--line);border-radius:4px;padding:0 4px}
details>summary{cursor:pointer;color:var(--tx-2);font-weight:550;margin:2px 0 6px}
@media (max-width:720px){.panel{width:100vw;top:auto;height:55vh;border-left:0;border-top:1px solid var(--line)}.toolbar{bottom:auto;top:6px;gap:2px;padding:4px;flex-wrap:wrap}.toolbar .brand-label,.toolbar .sep{display:none}.toolbar select{width:104px;max-width:104px;padding:5px 4px}.toolbar .btn-icon{padding:5px}.status{min-width:0;padding:0 3px}}
`;

// O CSS que vai na página (fora do Shadow DOM) enquanto o editor está aberto: o cursor e a edição de texto no lugar.
export const PAGE_CSS = `
html.wce-editing [data-wce-editing]{outline:2px solid #f97316 !important;outline-offset:2px !important;cursor:text !important;min-height:1em}
html.wce-editing.wce-pick *{cursor:crosshair !important}
`;
