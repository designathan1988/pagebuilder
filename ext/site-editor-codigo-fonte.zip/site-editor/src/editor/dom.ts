// Montagem de elementos do editor sem framework: h('div', { class: 'x', onclick }, filhos).
export type Child = Node | string | number | null | undefined | false | readonly Child[];

type Props = Record<string, unknown> & { class?: string; style?: string };

export function h<K extends keyof HTMLElementTagNameMap>(tag: K, props: Props | null = null, ...children: Child[]): HTMLElementTagNameMap[K] {
  const element = document.createElement(tag);
  if (props) {
    for (const [key, value] of Object.entries(props)) {
      if (value === undefined || value === null || value === false) continue;
      if (key.startsWith('on') && typeof value === 'function') element.addEventListener(key.slice(2).toLowerCase(), value as EventListener);
      else if (key === 'class') element.className = String(value);
      else if (key === 'value' && 'value' in element) (element as HTMLInputElement).value = String(value);
      else if (key === 'checked' && element instanceof HTMLInputElement) element.checked = Boolean(value);
      else if (key === 'selected' && element instanceof HTMLOptionElement) element.selected = Boolean(value);
      else if (key === 'html') element.innerHTML = String(value);
      else if (value === true) element.setAttribute(key, '');
      else element.setAttribute(key, String(value));
    }
  }
  append(element, children);
  return element;
}

export function append(parent: Node, children: readonly Child[]): void {
  for (const child of children) {
    if (child === null || child === undefined || child === false) continue;
    if (Array.isArray(child)) append(parent, child);
    else if (typeof child === 'string' || typeof child === 'number') parent.appendChild(document.createTextNode(String(child)));
    else parent.appendChild(child as Node);
  }
}

export function clear(element: Element): void {
  element.replaceChildren();
}

// Ícones (traços no estilo Lucide, desenhados inline: nenhum arquivo a mais).
const PATHS: Record<string, string> = {
  cursor: '<path d="M4 4l7 16 2.5-6.5L20 11z"/>',
  text: '<path d="M4 7V4h16v3M9 20h6M12 4v16"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  eyeOff: '<path d="M3 3l18 18M10.6 10.6a2 2 0 002.8 2.8M9.9 5.2A10 10 0 0112 5c6.5 0 10 7 10 7a17 17 0 01-3.2 4.1M6.6 6.6C3.9 8.3 2 12 2 12s3.5 7 10 7a9.6 9.6 0 005.4-1.6"/>',
  undo: '<path d="M9 14L4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 010 11H11"/>',
  redo: '<path d="M15 14l5-5-5-5"/><path d="M20 9H9.5a5.5 5.5 0 000 11H13"/>',
  close: '<path d="M18 6L6 18M6 6l12 12"/>',
  panel: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M15 3v18"/>',
  up: '<path d="M12 19V5M5 12l7-7 7 7"/>',
  image: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="M21 15l-5-5L5 21"/>',
  link: '<path d="M10 13a5 5 0 007.5.5l3-3a5 5 0 00-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 00-7.5-.5l-3 3a5 5 0 007 7l1.7-1.7"/>',
  trash: '<path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"/>',
  copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/>',
  move: '<path d="M5 9l-3 3 3 3M9 5l3-3 3 3M15 19l-3 3-3-3M19 9l3 3-3 3M2 12h20M12 2v20"/>',
  zap: '<path d="M13 2L3 14h9l-1 8 10-12h-9z"/>',
  database: '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v14c0 1.7 4 3 9 3s9-1.3 9-3V5M3 12c0 1.7 4 3 9 3s9-1.3 9-3"/>',
  users: '<path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.9M16 3.1a4 4 0 010 7.8"/>',
  sliders: '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
  list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
  braces: '<path d="M8 3H7a2 2 0 00-2 2v5a2 2 0 01-2 2 2 2 0 012 2v5a2 2 0 002 2h1M16 21h1a2 2 0 002-2v-5a2 2 0 012-2 2 2 0 01-2-2V5a2 2 0 00-2-2h-1"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.8-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 11-4 0v-.1a1.7 1.7 0 00-1.1-1.5 1.7 1.7 0 00-1.8.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.7 1.7 0 00.3-1.8 1.7 1.7 0 00-1.5-1H3a2 2 0 110-4h.1a1.7 1.7 0 001.5-1.1 1.7 1.7 0 00-.3-1.8l-.1-.1a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 001.8.3H9a1.7 1.7 0 001-1.5V3a2 2 0 114 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.8-.3l.1-.1a2 2 0 112.8 2.8l-.1.1a1.7 1.7 0 00-.3 1.8V9a1.7 1.7 0 001.5 1H21a2 2 0 110 4h-.1a1.7 1.7 0 00-1.5 1z"/>',
  check: '<path d="M20 6L9 17l-5-5"/>',
  edit: '<path d="M12 20h9M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4z"/>',
  layers: '<path d="M12 2l10 5-10 5L2 7z"/><path d="M2 17l10 5 10-5M2 12l10 5 10-5"/>',
  target: '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>',
  play: '<path d="M5 3l14 9-14 9z"/>',
  download: '<path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M7 10l5 5 5-5M12 15V3"/>',
  upload: '<path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M17 8l-5-5-5 5M12 3v12"/>',
  cloud: '<path d="M18 10h-1.3A8 8 0 109 20h9a5 5 0 000-10z"/>',
  grip: '<circle cx="9" cy="5" r="1"/><circle cx="9" cy="12" r="1"/><circle cx="9" cy="19" r="1"/><circle cx="15" cy="5" r="1"/><circle cx="15" cy="12" r="1"/><circle cx="15" cy="19" r="1"/>',
  blur: '<circle cx="12" cy="12" r="3"/><circle cx="12" cy="12" r="7" stroke-dasharray="2 3"/><circle cx="12" cy="12" r="10.5" stroke-dasharray="1 4"/>',
  code: '<path d="M16 18l6-6-6-6M8 6l-6 6 6 6"/>',
  history: '<path d="M3 3v5h5"/><path d="M3.1 13a9 9 0 102.1-8.5L3 8"/><path d="M12 7v5l4 2"/>',
  palette: '<circle cx="13.5" cy="6.5" r="1"/><circle cx="17.5" cy="10.5" r="1"/><circle cx="8.5" cy="7.5" r="1"/><circle cx="6.5" cy="12.5" r="1"/><path d="M12 2a10 10 0 000 20c1 0 1.7-.8 1.7-1.7 0-.4-.2-.8-.4-1.1-.3-.3-.4-.7-.4-1.1 0-.9.8-1.7 1.7-1.7h2a5.6 5.6 0 005.6-5.6C22.1 6 17.6 2 12 2z"/>',
  chevronDown: '<path d="M6 9l6 6 6-6"/>',
  search: '<circle cx="11" cy="11" r="8"/><path d="M21 21l-4.3-4.3"/>',
};

export function icon(name: keyof typeof PATHS | string, size = 16): SVGSVGElement {
  const wrapper = document.createElement('span');
  wrapper.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${PATHS[name] ?? ''}</svg>`;
  return wrapper.firstElementChild as SVGSVGElement;
}

export function button(label: string, onClick: (event: MouseEvent) => void, options: { icon?: string; variant?: 'primary' | 'ghost' | 'danger' | 'default'; title?: string; small?: boolean; iconOnly?: boolean; pressed?: boolean; disabled?: boolean; testid?: string } = {}): HTMLButtonElement {
  const classes = ['btn', `btn-${options.variant ?? 'default'}`];
  if (options.small) classes.push('btn-sm');
  if (options.iconOnly) classes.push('btn-icon');
  const element = h(
    'button',
    {
      type: 'button',
      class: classes.join(' '),
      title: options.title ?? (options.iconOnly ? label : undefined),
      'aria-label': options.iconOnly ? label : undefined,
      'aria-pressed': options.pressed === undefined ? undefined : String(options.pressed),
      disabled: options.disabled,
      'data-testid': options.testid,
      onclick: (event: MouseEvent) => {
        event.preventDefault();
        event.stopPropagation();
        onClick(event);
      },
    },
    options.icon ? icon(options.icon) : null,
    options.iconOnly ? null : h('span', null, label),
  );
  return element;
}

export function field(label: string, control: HTMLElement, hint?: string | Node): HTMLElement {
  const id = `f-${Math.random().toString(36).slice(2, 9)}`;
  const target = control.matches('input,select,textarea') ? control : control.querySelector('input,select,textarea');
  if (target && !target.id) target.id = id;
  return h('div', { class: 'field' }, h('label', { for: target?.id ?? id }, label), control, hint ? h('div', { class: 'hint' }, hint) : null);
}

export function input(value: string, onChange: (value: string) => void, options: { placeholder?: string; type?: string; live?: boolean; mono?: boolean; testid?: string; list?: string } = {}): HTMLInputElement {
  const element = h('input', { type: options.type ?? 'text', value, placeholder: options.placeholder, class: options.mono ? 'mono' : undefined, 'data-testid': options.testid, list: options.list, spellcheck: 'false' });
  element.addEventListener(options.live ? 'input' : 'change', () => onChange(element.value));
  element.addEventListener('keydown', (event) => event.stopPropagation());
  return element;
}

export function textarea(value: string, onChange: (value: string) => void, options: { rows?: number; placeholder?: string; mono?: boolean; live?: boolean; testid?: string } = {}): HTMLTextAreaElement {
  const element = h('textarea', { rows: options.rows ?? 3, placeholder: options.placeholder, class: options.mono ? 'mono' : undefined, 'data-testid': options.testid, spellcheck: options.mono ? 'false' : undefined });
  element.value = value;
  element.addEventListener(options.live ? 'input' : 'change', () => onChange(element.value));
  element.addEventListener('keydown', (event) => event.stopPropagation());
  return element;
}

export function select<T extends string>(value: T, options: readonly (readonly [T, string])[], onChange: (value: T) => void, testid?: string): HTMLSelectElement {
  const element = h('select', { 'data-testid': testid }, options.map(([key, label]) => h('option', { value: key, selected: key === value }, label)));
  element.addEventListener('change', () => onChange(element.value as T));
  element.addEventListener('keydown', (event) => event.stopPropagation());
  return element;
}

export function checkbox(label: string, checked: boolean, onChange: (checked: boolean) => void, testid?: string): HTMLLabelElement {
  const box = h('input', { type: 'checkbox', checked, 'data-testid': testid });
  box.addEventListener('change', () => onChange(box.checked));
  return h('label', { class: 'check' }, box, h('span', null, label));
}

export function section(title: string, ...children: Child[]): HTMLElement {
  return h('section', { class: 'sec' }, h('h3', null, title), ...children);
}

export function empty(text: string): HTMLElement {
  return h('p', { class: 'empty' }, text);
}
