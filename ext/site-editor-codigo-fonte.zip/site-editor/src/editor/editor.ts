// O editor visual, aberto sobre a página: a barra, o realce do que está sob o cursor, a seleção com a minibarra de
// ações rápidas, a edição de texto no lugar e o painel com as abas. Tudo dentro de um Shadow DOM fechado à página.
// Cada mudança passa por commit(): guarda a versão anterior para desfazer, grava o projeto e pede ao motor que
// aplique de novo, então o que se vê é sempre o que fica salvo.
import type { ContentApi } from '../content/content.ts';
import type { Engine } from '../engine/engine.ts';
import { newProject, uid, type Edit, type EditOp, type Project, type Target } from '../shared/model.ts';
import { suggestPattern } from '../shared/match.ts';
import { describe, friendlyName, safeQueryAll, selectorFor } from '../shared/selector.ts';
import { getProject, projectsFor, readSettings, saveProject, writeSettings, type Settings } from '../shared/storage.ts';
import { append, button, clear, h, icon } from './dom.ts';
import { EDITOR_CSS, PAGE_CSS } from './styles.ts';
import { renderPanel, type PanelTab } from './panels.ts';

export interface EditScope {
  page: 'all' | 'this';
  clients: 'all' | 'current';
}

export interface EditorContext {
  readonly doc: Document;
  readonly project: Project;
  readonly engine: Engine;
  readonly selected: Element | null;
  readonly selector: string;
  readonly scope: EditScope;
  readonly settings: Settings;
  readonly projects: readonly Project[];
  commit(label: string, mutate: (project: Project) => void): Promise<void>;
  upsert(op: EditOp, options?: { readonly match?: (edit: Edit) => boolean; readonly target?: Target; readonly label?: string }): Promise<Edit>;
  removeEdits(predicate: (edit: Edit) => boolean, label?: string): Promise<void>;
  select(element: Element | null): void;
  setSelector(selector: string): void;
  pick(prompt: string, done: (element: Element) => void): void;
  toast(message: string, error?: boolean): void;
  rerender(): void;
  setTab(tab: PanelTab, focus?: string): void;
  focusId: string | null;
  setScope(scope: EditScope): void;
  startInline(element: Element): void;
  switchProject(id: string): Promise<void>;
  createProject(): Promise<void>;
  setSettings(patch: Partial<Settings>): Promise<void>;
  previewOriginal(on: boolean): void;
  close(): void;
}

const UNDO_LIMIT = 100;

class Editor {
  private host: HTMLElement | null = null;
  private root: ShadowRoot | null = null;
  private pageStyle: HTMLStyleElement | null = null;
  private project!: Project;
  private engine!: Engine;
  private projects: Project[] = [];
  private settings!: Settings;
  private selected: Element | null = null;
  private hovered: Element | null = null;
  private selectorOverride: string | null = null;
  private tab: PanelTab = 'element';
  private focusId: string | null = null;
  private scope: EditScope = { page: 'all', clients: 'all' };
  private browsing = false;
  private panelOpen = true;
  private picking: { prompt: string; done: (element: Element) => void } | null = null;
  private inline: { element: HTMLElement; before: string; edit: Edit | null } | null = null;
  private undoStack: string[] = [];
  private redoStack: string[] = [];
  private saveTimer: number | null = null;
  private status = 'Salvo';
  private frame = 0;
  private original = false;
  private readonly listeners: [EventTarget, string, EventListener, boolean][] = [];
  // elementos do Shadow DOM
  private hoverBox!: HTMLElement;
  private selBox!: HTMLElement;
  private hoverTag!: HTMLElement;
  private selTag!: HTMLElement;
  private minibar!: HTMLElement;
  private toolbar!: HTMLElement;
  private panel!: HTMLElement;
  private panelBody!: HTMLElement;
  private toastEl: HTMLElement | null = null;
  private banner: HTMLElement | null = null;
  private statusEl!: HTMLElement;

  constructor(private readonly api: ContentApi) {}

  isOpen(): boolean {
    return this.host !== null;
  }

  async open(projectId?: string, options: { create?: boolean; select?: Element | null } = {}): Promise<void> {
    this.settings = await readSettings();
    this.projects = await projectsFor(location.href, true);
    let project: Project | null = null;
    if (projectId) project = await getProject(projectId);
    if (!project && this.isOpen()) project = this.project;
    if (!project) project = [...this.projects].sort((a, b) => b.updatedAt - a.updatedAt)[0] ?? null;
    if (!project) {
      project = newProject(document.title.trim().slice(0, 80) || location.hostname || 'Novo projeto', [suggestPattern(location.href)]);
      project = await saveProject(project, 'Projeto criado');
      this.projects = [project];
    }
    await this.useProject(project);
    if (!this.isOpen()) this.mount();
    if (options.select) this.select(options.select);
    this.rerender();
  }

  private async useProject(project: Project): Promise<void> {
    if (this.project && this.project.id !== project.id) this.api.editorOwns.delete(this.project.id);
    this.project = project;
    this.api.editorOwns.add(project.id);
    this.engine = await this.api.engineFor(project);
    if (this.engine.currentProject.updatedAt !== project.updatedAt) await this.engine.update(project);
    this.undoStack = [];
    this.redoStack = [];
  }

  close(): void {
    if (!this.host) return;
    this.finishInline(true);
    for (const [target, type, listener, capture] of this.listeners) target.removeEventListener(type, listener, capture);
    this.listeners.length = 0;
    cancelAnimationFrame(this.frame);
    if (this.saveTimer !== null) {
      clearTimeout(this.saveTimer);
      void this.flush();
    }
    if (this.original) this.previewOriginal(false);
    this.host.remove();
    this.pageStyle?.remove();
    this.host = null;
    this.root = null;
    document.documentElement.classList.remove('wce-editing', 'wce-pick', 'wce-show-hidden');
    this.api.editorOwns.delete(this.project.id);
    void this.api.refresh();
  }

  // ---------------------------------------------------------------- montagem

  private mount(): void {
    this.host = document.createElement('wce-editor');
    this.host.setAttribute('data-wce-ui', 'editor');
    this.root = this.host.attachShadow({ mode: 'open' });
    const style = document.createElement('style');
    style.textContent = EDITOR_CSS;
    this.hoverBox = h('div', { class: 'hl hover' });
    this.selBox = h('div', { class: 'hl sel' });
    this.hoverTag = h('div', { class: 'tag' });
    this.selTag = h('div', { class: 'tag' });
    this.minibar = h('div', { class: 'minibar', role: 'toolbar', 'aria-label': 'Ações do elemento' });
    this.toolbar = h('div', { class: 'toolbar', role: 'toolbar', 'aria-label': 'Site Editor' });
    this.panelBody = h('div', { class: 'body' });
    this.panel = h('aside', { class: `panel ${this.settings.toolbarSide}`, 'aria-label': 'Painel do Site Editor' });
    this.root.append(style, this.hoverBox, this.selBox, this.hoverTag, this.selTag, this.minibar, this.toolbar, this.panel);
    document.documentElement.appendChild(this.host);
    this.pageStyle = document.createElement('style');
    this.pageStyle.setAttribute('data-wce-ui', 'editor-page');
    this.pageStyle.textContent = PAGE_CSS;
    (document.head ?? document.documentElement).appendChild(this.pageStyle);
    document.documentElement.classList.add('wce-editing');
    document.documentElement.classList.toggle('wce-show-hidden', this.settings.showHidden);
    this.listen();
    const loop = (): void => {
      this.position();
      this.frame = requestAnimationFrame(loop);
    };
    this.frame = requestAnimationFrame(loop);
  }

  private on(target: EventTarget, type: string, listener: (event: Event) => void, capture = true): void {
    target.addEventListener(type, listener as EventListener, capture);
    this.listeners.push([target, type, listener as EventListener, capture]);
  }

  private fromUs(event: Event): boolean {
    return event.composedPath().some((node) => node === this.host);
  }

  private pageTarget(event: Event): Element | null {
    const path = event.composedPath();
    if (path.some((node) => node === this.host)) return null;
    const first = path.find((node) => node instanceof Element) as Element | undefined;
    if (!first) return null;
    if (first.closest('[data-wce-ui]')) return null;
    return first;
  }

  private listen(): void {
    const block = (event: Event): void => {
      if (this.browsing || this.fromUs(event)) return;
      const target = this.pageTarget(event);
      if (!target) return;
      if (this.inline && this.inline.element.contains(target)) return;
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
    };
    for (const type of ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'submit', 'auxclick', 'touchstart', 'dragstart']) this.on(window, type, block);
    this.on(window, 'mousemove', (event) => {
      if (this.browsing && !this.picking) {
        this.hovered = null;
        return;
      }
      const target = this.pageTarget(event);
      this.hovered = target && target !== document.documentElement ? target : null;
    });
    this.on(window, 'mouseleave', () => {
      this.hovered = null;
    });
    this.on(window, 'click', (event) => {
      if (this.fromUs(event)) return;
      const target = this.pageTarget(event);
      if (!target) return;
      if (this.inline && this.inline.element.contains(target)) return;
      if (this.picking) {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        const { done } = this.picking;
        this.stopPicking();
        done(target);
        return;
      }
      if (this.browsing) return;
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      if (this.inline) this.finishInline(false);
      this.select(target);
      if (this.tab !== 'element' && this.tab !== 'insert') this.setTab('element');
    });
    this.on(window, 'dblclick', (event) => {
      if (this.browsing || this.fromUs(event)) return;
      const target = this.pageTarget(event);
      if (!target) return;
      event.preventDefault();
      event.stopPropagation();
      this.startInline(target);
    });
    this.on(window, 'keydown', (event) => {
      const key = event as KeyboardEvent;
      if (this.inline) {
        if (key.key === 'Escape') {
          key.preventDefault();
          this.finishInline(true);
        } else if (key.key === 'Enter' && !key.shiftKey && !/^(div|section|article|td|li)$/.test(this.inline.element.localName)) {
          key.preventDefault();
          this.finishInline(false);
        }
        return;
      }
      if (this.fromUs(event)) {
        if (key.key === 'Escape' && this.picking) this.stopPicking();
        return;
      }
      const typing = event.target instanceof HTMLElement && (event.target.isContentEditable || /^(input|textarea|select)$/i.test(event.target.localName));
      if (typing) return;
      const mod = key.ctrlKey || key.metaKey;
      if (mod && key.key.toLowerCase() === 'z') {
        key.preventDefault();
        if (key.shiftKey) void this.redo();
        else void this.undo();
      } else if (mod && key.key.toLowerCase() === 'y') {
        key.preventDefault();
        void this.redo();
      } else if (key.key === 'Escape') {
        if (this.picking) this.stopPicking();
        else this.select(null);
      } else if ((key.key === 'Delete' || key.key === 'Backspace') && this.selected) {
        key.preventDefault();
        void this.upsert({ op: 'hide' }, { label: 'Ocultar' });
      } else if (key.key === 'Enter' && this.selected) {
        key.preventDefault();
        this.startInline(this.selected);
      } else if (key.altKey && key.key === 'ArrowUp' && this.selected?.parentElement) {
        key.preventDefault();
        this.select(this.selected.parentElement);
      }
    });
    this.on(window, 'scroll', () => this.position(), true);
    this.on(window, 'resize', () => {
      this.position();
      this.placeToolbar();
    }, false);
  }

  // ---------------------------------------------------------------- realces

  private placeBox(box: HTMLElement, tag: HTMLElement, element: Element | null, label: string): void {
    if (!element || !element.isConnected) {
      box.style.display = 'none';
      tag.style.display = 'none';
      return;
    }
    const rect = element.getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0) {
      box.style.display = 'none';
      tag.style.display = 'none';
      return;
    }
    box.style.display = 'block';
    box.style.left = `${rect.left - 2}px`;
    box.style.top = `${rect.top - 2}px`;
    box.style.width = `${rect.width + 4}px`;
    box.style.height = `${rect.height + 4}px`;
    tag.style.display = 'block';
    tag.textContent = label;
    const above = rect.top > 22;
    tag.style.left = `${Math.max(4, rect.left - 2)}px`;
    tag.style.top = `${above ? rect.top - 22 : Math.min(window.innerHeight - 22, rect.bottom + 4)}px`;
  }

  private position(): void {
    if (!this.host) return;
    const hover = this.hovered && this.hovered !== this.selected ? this.hovered : null;
    this.hoverBox.classList.toggle('pick', this.picking !== null);
    this.hoverTag.classList.toggle('pick', this.picking !== null);
    this.placeBox(this.hoverBox, this.hoverTag, hover, hover ? `${friendlyName(hover)} · ${describe(hover)}` : '');
    this.placeBox(this.selBox, this.selTag, this.selected, this.selected ? `${friendlyName(this.selected)} · ${describe(this.selected)}` : '');
    if (this.selected && this.selected.isConnected && !this.picking && !this.inline) {
      const rect = this.selected.getBoundingClientRect();
      this.minibar.style.display = 'flex';
      const bar = this.minibar.getBoundingClientRect();
      const width = bar.width || 300;
      const panelWidth = this.panelOpen && window.innerWidth > 720 ? this.panel.getBoundingClientRect().width : 0;
      const maxLeft = window.innerWidth - width - 8 - (this.settings.toolbarSide === 'right' ? panelWidth : 0);
      const minLeft = 8 + (this.settings.toolbarSide === 'left' ? panelWidth : 0);
      const left = Math.min(Math.max(minLeft, rect.left), Math.max(minLeft, maxLeft));
      let top = rect.bottom + 8;
      if (top + 40 > window.innerHeight) top = Math.max(60, rect.top - 46);
      this.minibar.style.left = `${left}px`;
      this.minibar.style.top = `${Math.min(window.innerHeight - 44, top)}px`;
    } else this.minibar.style.display = 'none';
  }

  // ---------------------------------------------------------------- seleção

  select(element: Element | null): void {
    if (element && (element === document.documentElement || element.closest('[data-wce-ui]'))) element = null;
    this.selected = element;
    this.selectorOverride = null;
    this.renderMinibar();
    if (this.tab === 'element' || this.tab === 'insert') this.rerender();
  }

  private get selector(): string {
    if (this.selectorOverride) return this.selectorOverride;
    return this.selected ? selectorFor(this.selected) : '';
  }

  private renderMinibar(): void {
    clear(this.minibar);
    const element = this.selected;
    if (!element) return;
    const isImage = element.localName === 'img';
    const isLink = element.closest('a') !== null;
    append(this.minibar, [
      button('Selecionar o elemento de fora', () => element.parentElement && this.select(element.parentElement), { icon: 'up', iconOnly: true, variant: 'ghost', testid: 'mini-parent' }),
      button('Editar texto (duplo clique)', () => this.startInline(element), { icon: 'text', iconOnly: true, variant: 'ghost', testid: 'mini-text' }),
      isImage ? button('Trocar imagem', () => this.setTab('element', 'image'), { icon: 'image', iconOnly: true, variant: 'ghost', testid: 'mini-image' }) : null,
      isLink ? button('Editar link', () => this.setTab('element', 'link'), { icon: 'link', iconOnly: true, variant: 'ghost', testid: 'mini-link' }) : null,
      button('Estilo', () => this.setTab('element', 'style'), { icon: 'palette', iconOnly: true, variant: 'ghost', testid: 'mini-style' }),
      button('Ocultar (Delete)', () => void this.upsert({ op: 'hide' }, { label: 'Ocultar' }), { icon: 'eyeOff', iconOnly: true, variant: 'ghost', testid: 'mini-hide' }),
      button('Desfocar (dados sensíveis)', () => void this.upsert({ op: 'blur', amount: 6 }, { label: 'Desfocar' }), { icon: 'blur', iconOnly: true, variant: 'ghost', testid: 'mini-blur' }),
      button('Duplicar', () => void this.duplicate(element), { icon: 'copy', iconOnly: true, variant: 'ghost', testid: 'mini-duplicate' }),
      button('Mover para…', () => this.startMove(element), { icon: 'move', iconOnly: true, variant: 'ghost', testid: 'mini-move' }),
      button('Inserir componente aqui', () => this.setTab('insert'), { icon: 'plus', iconOnly: true, variant: 'ghost', testid: 'mini-insert' }),
      button('Dados dinâmicos', () => this.setTab('element', 'dynamic'), { icon: 'braces', iconOnly: true, variant: 'ghost', testid: 'mini-dynamic' }),
      button('Evento ao clicar', () => this.setTab('element', 'events'), { icon: 'zap', iconOnly: true, variant: 'ghost', testid: 'mini-event' }),
    ]);
  }

  private async duplicate(element: Element): Promise<void> {
    const clone = element.cloneNode(true) as Element;
    clone.removeAttribute('id');
    clone.querySelectorAll('[id]').forEach((node) => node.removeAttribute('id'));
    await this.upsert({ op: 'insert', position: 'after', html: clone.outerHTML }, { label: 'Cópia', match: () => false });
    this.toast('Elemento duplicado logo depois do original.');
  }

  private startMove(element: Element): void {
    const selector = this.selector;
    this.pick('Clique no elemento ao lado do qual ele vai ficar', (target) => {
      if (target === element || element.contains(target)) {
        this.toast('Escolha um elemento fora do que está sendo movido.', true);
        return;
      }
      const ref: Target = { selector: selectorFor(target) };
      void this.choose('Onde colocar em relação ao elemento clicado?', [
        ['before', 'Antes'],
        ['after', 'Depois'],
        ['prepend', 'Dentro, no início'],
        ['append', 'Dentro, no fim'],
      ]).then((position) => {
        if (!position) return;
        void this.upsert({ op: 'move', ref, position: position as 'before' | 'after' | 'prepend' | 'append' }, { target: { selector }, label: 'Mover' }).then(() => this.select(element));
      });
    });
  }

  // uma pergunta rápida no topo da tela, com botões (sem os diálogos do navegador)
  private choose(prompt: string, options: readonly (readonly [string, string])[]): Promise<string | null> {
    return new Promise((resolve) => {
      this.banner?.remove();
      const done = (value: string | null): void => {
        this.banner?.remove();
        this.banner = null;
        resolve(value);
      };
      this.banner = h('div', { class: 'banner', role: 'dialog', 'aria-label': prompt }, h('span', null, prompt), ...options.map(([value, label]) => button(label, () => done(value), { small: true, testid: `choose-${value}` })), button('Cancelar', () => done(null), { small: true }));
      this.root?.appendChild(this.banner);
    });
  }

  pick(prompt: string, done: (element: Element) => void): void {
    this.picking = { prompt, done };
    document.documentElement.classList.add('wce-pick');
    this.banner?.remove();
    this.banner = h('div', { class: 'banner', role: 'status' }, h('span', null, prompt), button('Cancelar', () => this.stopPicking(), { small: true }));
    this.root?.appendChild(this.banner);
  }

  private stopPicking(): void {
    this.picking = null;
    document.documentElement.classList.remove('wce-pick');
    this.banner?.remove();
    this.banner = null;
  }

  // ---------------------------------------------------------------- texto no lugar

  startInline(element: Element): void {
    if (!(element instanceof HTMLElement) || element.closest('[data-wce-ui]')) return;
    if (/^(img|input|select|video|iframe|svg|hr|br)$/.test(element.localName)) {
      this.select(element);
      this.setTab('element');
      return;
    }
    this.finishInline(false);
    this.select(element);
    const selector = this.selector;
    const edit = this.project.edits.find((candidate) => candidate.target.selector === selector && (candidate.op === 'text' || candidate.op === 'html') && this.sameScope(candidate)) ?? null;
    this.engine.hold();
    const before = element.innerHTML;
    // o texto com {{ }} aparece como foi escrito, não como o motor o mostra
    if (edit && edit.op === 'text' && edit.value.includes('{{')) element.textContent = edit.value;
    if (edit && edit.op === 'html' && edit.value.includes('{{')) element.innerHTML = edit.value;
    element.setAttribute('data-wce-editing', '');
    element.contentEditable = 'true';
    element.focus();
    const range = document.createRange();
    range.selectNodeContents(element);
    const selection = window.getSelection();
    selection?.removeAllRanges();
    selection?.addRange(range);
    this.inline = { element, before, edit };
    const blur = (): void => {
      element.removeEventListener('blur', blur);
      if (this.inline?.element === element) this.finishInline(false);
    };
    element.addEventListener('blur', blur);
    this.renderMinibar();
  }

  private finishInline(cancel: boolean): void {
    const inline = this.inline;
    if (!inline) return;
    this.inline = null;
    const { element, before } = inline;
    element.removeAttribute('contenteditable');
    element.removeAttribute('data-wce-editing');
    const hasChildren = Array.from(element.children).some((child) => !/^(br)$/.test(child.localName));
    const html = element.innerHTML;
    const text = (element.innerText ?? element.textContent ?? '').replace(/\n$/, '');
    if (cancel || html === before) {
      element.innerHTML = before;
      this.engine.release();
      return;
    }
    element.innerHTML = before;
    this.engine.release();
    const selector = this.selector;
    const op: EditOp = hasChildren ? { op: 'html', value: html } : { op: 'text', value: text };
    // um texto já editado troca de tipo (texto <-> HTML) sem deixar a versão antiga aplicada
    void this.removeEdits((edit) => edit.target.selector === selector && (edit.op === 'text' || edit.op === 'html') && edit.op !== op.op && this.sameScope(edit), null).then(() => this.upsert(op, { label: hasChildren ? 'Conteúdo' : 'Texto' }));
  }

  // ---------------------------------------------------------------- gravar

  private sameScope(edit: Edit): boolean {
    const page = this.scope.page === 'this' ? location.pathname : undefined;
    const clients = this.scope.clients === 'current' && this.engine.currentClient ? [this.engine.currentClient.id] : undefined;
    return (edit.page ?? undefined) === page && JSON.stringify(edit.clients ?? []) === JSON.stringify(clients ?? []);
  }

  async commit(label: string, mutate: (project: Project) => void): Promise<void> {
    const snapshot = JSON.stringify(this.project);
    const next = JSON.parse(snapshot) as Project;
    mutate(next);
    next.updatedAt = Date.now();
    if (JSON.stringify(next) === snapshot) return;
    this.undoStack.push(snapshot);
    if (this.undoStack.length > UNDO_LIMIT) this.undoStack.shift();
    this.redoStack = [];
    await this.apply(next, label);
  }

  private async apply(next: Project, label: string): Promise<void> {
    this.project = next;
    await this.engine.update(next, this.api.clientOverride.get(next.id) ?? next.activeClientId);
    this.queueSave(label);
    this.renderToolbar();
    this.rerender();
  }

  private queueSave(label: string): void {
    this.setStatus('Salvando…');
    if (this.saveTimer !== null) clearTimeout(this.saveTimer);
    this.saveTimer = window.setTimeout(() => {
      this.saveTimer = null;
      void this.flush(label);
    }, 250);
  }

  private async flush(label = 'Alteração'): Promise<void> {
    try {
      const saved = await saveProject(this.project, label, { touch: false });
      this.projects = this.projects.map((project) => (project.id === saved.id ? saved : project));
      if (!this.projects.some((project) => project.id === saved.id)) this.projects.push(saved);
      this.setStatus('Salvo');
    } catch (error) {
      this.setStatus('Erro ao salvar', true);
      this.toast(`Não foi possível salvar: ${error instanceof Error ? error.message : String(error)}`, true);
    }
  }

  private setStatus(text: string, error = false): void {
    this.status = text;
    if (this.statusEl) {
      this.statusEl.textContent = text;
      this.statusEl.classList.toggle('err', error);
    }
  }

  async undo(): Promise<void> {
    const previous = this.undoStack.pop();
    if (!previous) return;
    this.redoStack.push(JSON.stringify(this.project));
    const project = JSON.parse(previous) as Project;
    project.updatedAt = Date.now();
    await this.apply(project, 'Desfazer');
  }

  async redo(): Promise<void> {
    const next = this.redoStack.pop();
    if (!next) return;
    this.undoStack.push(JSON.stringify(this.project));
    const project = JSON.parse(next) as Project;
    project.updatedAt = Date.now();
    await this.apply(project, 'Refazer');
  }

  async upsert(op: EditOp, options: { readonly match?: (edit: Edit) => boolean; readonly target?: Target; readonly label?: string } = {}): Promise<Edit> {
    const target: Target = options.target ?? { selector: this.selector, hint: (this.selected?.textContent ?? '').trim().slice(0, 60) };
    if (!target.selector) throw new Error('Selecione um elemento primeiro.');
    const page = this.scope.page === 'this' ? location.pathname : undefined;
    const clients = this.scope.clients === 'current' && this.engine.currentClient ? [this.engine.currentClient.id] : undefined;
    const sameKind = (edit: Edit): boolean => {
      if (edit.target.selector !== target.selector || edit.op !== op.op || !this.sameScope(edit)) return false;
      if (op.op === 'attr' && edit.op === 'attr') return edit.name === op.name;
      if (op.op === 'bind' && edit.op === 'bind') return edit.kind === op.kind && (edit.name ?? '') === (op.name ?? '');
      if (op.op === 'insert' || op.op === 'replace') return false;
      return true;
    };
    const match = options.match ?? sameKind;
    let result: Edit | null = null;
    await this.commit(options.label ?? 'Alteração', (project) => {
      const existing = project.edits.find(match);
      if (existing) {
        if (op.op === 'style' && existing.op === 'style') {
          const props = { ...existing.props, ...op.props };
          for (const [key, value] of Object.entries(props)) if (value === '') delete props[key];
          Object.assign(existing, { props });
        } else if (op.op === 'class' && existing.op === 'class') {
          Object.assign(existing, { add: [...new Set([...existing.add, ...op.add])].filter((name) => !op.remove.includes(name)), remove: [...new Set([...existing.remove, ...op.remove])].filter((name) => !op.add.includes(name)) });
        } else Object.assign(existing, op);
        existing.enabled = true;
        result = existing;
      } else {
        const edit = { ...op, id: uid('e_'), target, enabled: true, createdAt: Date.now(), ...(page ? { page } : {}), ...(clients ? { clients } : {}), ...(options.label ? { label: options.label } : {}) } as Edit;
        project.edits.push(edit);
        result = edit;
      }
    });
    if (!result) {
      // nada mudou (o mesmo valor de antes): devolve a alteração que já existe
      result = this.project.edits.find(match) ?? null;
    }
    if (!result) throw new Error('A alteração não foi gravada.');
    return result;
  }

  async removeEdits(predicate: (edit: Edit) => boolean, label: string | null = 'Remover alteração'): Promise<void> {
    if (!this.project.edits.some(predicate)) return;
    if (label === null) {
      // parte de uma operação maior: entra no mesmo passo de desfazer da próxima gravação
      this.project = { ...this.project, edits: this.project.edits.filter((edit) => !predicate(edit)) };
      await this.engine.update(this.project);
      return;
    }
    await this.commit(label, (project) => {
      project.edits = project.edits.filter((edit) => !predicate(edit));
    });
  }

  previewOriginal(on: boolean): void {
    this.original = on;
    for (const engine of this.api.engines.values()) {
      if (on) engine.suspend();
      else engine.resume();
    }
    this.renderToolbar();
  }

  toast(message: string, error = false): void {
    this.toastEl?.remove();
    this.toastEl = h('div', { class: `toast${error ? ' err' : ''}`, role: 'status' }, message);
    this.root?.appendChild(this.toastEl);
    const mine = this.toastEl;
    window.setTimeout(() => mine.remove(), 3200);
  }

  setTab(tab: PanelTab, focus?: string): void {
    this.tab = tab;
    this.focusId = focus ?? null;
    if (!this.panelOpen) this.panelOpen = true;
    this.rerender();
  }

  private context(): EditorContext {
    return {
      doc: document,
      project: this.project,
      engine: this.engine,
      selected: this.selected,
      selector: this.selector,
      scope: this.scope,
      settings: this.settings,
      projects: this.projects,
      focusId: this.focusId,
      commit: (label, mutate) => this.commit(label, mutate),
      upsert: (op, options) => this.upsert(op, options),
      removeEdits: (predicate, label) => this.removeEdits(predicate, label ?? 'Remover alteração'),
      select: (element) => this.select(element),
      setSelector: (selector) => {
        this.selectorOverride = selector;
        const first = safeQueryAll(document, selector).find((element) => !element.closest('[data-wce-ui]'));
        if (first) this.selected = first;
        this.renderMinibar();
        this.rerender();
      },
      pick: (prompt, done) => this.pick(prompt, done),
      toast: (message, error) => this.toast(message, error),
      rerender: () => this.rerender(),
      setTab: (tab, focus) => this.setTab(tab, focus),
      setScope: (scope) => {
        this.scope = scope;
        this.rerender();
      },
      startInline: (element) => this.startInline(element),
      switchProject: async (id) => {
        const project = this.projects.find((candidate) => candidate.id === id) ?? (await getProject(id));
        if (!project) return;
        await this.useProject(project);
        this.select(null);
        this.renderToolbar();
        this.rerender();
      },
      createProject: async () => {
        const name = window.prompt('Nome do novo projeto', `${location.hostname} (cópia)`);
        if (!name) return;
        const project = await saveProject(newProject(name, [suggestPattern(location.href)]), 'Projeto criado');
        this.projects.push(project);
        await this.useProject(project);
        this.renderToolbar();
        this.rerender();
      },
      setSettings: async (patch) => {
        this.settings = await writeSettings(patch);
        document.documentElement.classList.toggle('wce-show-hidden', this.settings.showHidden);
        this.panel.className = `panel ${this.settings.toolbarSide}${this.panelOpen ? '' : ' hidden'}`;
        this.rerender();
      },
      previewOriginal: (on) => this.previewOriginal(on),
      close: () => this.close(),
    };
  }

  // ---------------------------------------------------------------- barra e painel

  private renderToolbar(): void {
    clear(this.toolbar);
    const brand = h('div', { class: 'brand', title: 'Arraste para mover a barra' }, h('span', { class: 'dot' }), h('span', { class: 'brand-label' }, 'Site Editor'));
    this.dragToolbar(brand);
    const projectSelect = h(
      'select',
      { 'aria-label': 'Projeto', 'data-testid': 'project-select' },
      this.projects.map((project) => h('option', { value: project.id, selected: project.id === this.project.id }, project.name)),
      h('option', { value: '__new' }, '+ Novo projeto…'),
    );
    projectSelect.addEventListener('change', () => {
      if (projectSelect.value === '__new') void this.context().createProject();
      else void this.context().switchProject(projectSelect.value);
    });
    const currentClient = this.engine.currentClient?.id ?? '';
    const clientSelect = h(
      'select',
      { 'aria-label': 'Cliente', 'data-testid': 'client-select', title: 'Cliente (variante) mostrado' },
      this.project.clients.map((client) => h('option', { value: client.id, selected: client.id === currentClient }, `👤 ${client.name}`)),
    );
    clientSelect.addEventListener('change', () => {
      this.api.clientOverride.delete(this.project.id);
      void this.commit('Trocar cliente', (project) => {
        project.activeClientId = clientSelect.value;
      });
    });
    this.statusEl = h('span', { class: 'status', role: 'status', 'data-testid': 'save-status' }, this.status);
    this.toolbar.append(
      brand,
      projectSelect,
      clientSelect,
      h('span', { class: 'sep' }),
      button(this.browsing ? 'Navegando: clique para editar' : 'Navegar no sistema', () => {
        this.browsing = !this.browsing;
        if (this.browsing) this.select(null);
        this.renderToolbar();
        this.toast(this.browsing ? 'Modo navegação: use o sistema normalmente. Clique de novo para voltar a editar.' : 'Modo edição: clique num elemento para editar.');
      }, { icon: 'cursor', iconOnly: true, variant: 'ghost', pressed: this.browsing, testid: 'toggle-browse' }),
      button('Inserir componente', () => this.setTab('insert'), { icon: 'plus', iconOnly: true, variant: 'ghost', testid: 'open-insert' }),
      button(this.settings.showHidden ? 'Esconder ocultos' : 'Mostrar ocultos', () => void this.context().setSettings({ showHidden: !this.settings.showHidden }).then(() => this.renderToolbar()), { icon: 'eye', iconOnly: true, variant: 'ghost', pressed: this.settings.showHidden, testid: 'toggle-hidden' }),
      button(this.original ? 'Voltar às alterações' : 'Ver original', () => this.previewOriginal(!this.original), { icon: 'layers', iconOnly: true, variant: 'ghost', pressed: this.original, testid: 'toggle-original' }),
      button('Desfazer (Ctrl+Z)', () => void this.undo(), { icon: 'undo', iconOnly: true, variant: 'ghost', disabled: this.undoStack.length === 0, testid: 'undo' }),
      button('Refazer (Ctrl+Shift+Z)', () => void this.redo(), { icon: 'redo', iconOnly: true, variant: 'ghost', disabled: this.redoStack.length === 0, testid: 'redo' }),
      this.statusEl,
      button(this.panelOpen ? 'Fechar painel' : 'Abrir painel', () => {
        this.panelOpen = !this.panelOpen;
        this.rerender();
      }, { icon: 'panel', iconOnly: true, variant: 'ghost', pressed: this.panelOpen, testid: 'toggle-panel' }),
      button('Fechar o editor', () => this.close(), { icon: 'close', iconOnly: true, variant: 'ghost', testid: 'close-editor' }),
    );
  }

  private toolbarMoved = false;

  // a barra fica centrada na área da página que o painel não cobre, até a pessoa arrastá-la
  private placeToolbar(): void {
    if (this.toolbarMoved || !this.host) return;
    // centrada na parte da tela que o painel não cobre (left e right fixos com margin:auto)
    const panelWidth = this.panelOpen && window.innerWidth > 720 ? Math.min(380, window.innerWidth) : 0;
    const panelLeft = this.settings.toolbarSide === 'left';
    this.toolbar.style.left = `${(panelLeft ? panelWidth : 0) + 10}px`;
    this.toolbar.style.right = `${(panelLeft ? 0 : panelWidth) + 10}px`;
    this.toolbar.style.maxWidth = '';
  }

  private dragToolbar(handle: HTMLElement): void {
    handle.addEventListener('pointerdown', (event) => {
      this.toolbarMoved = true;
      const start = { x: event.clientX, y: event.clientY };
      const rect = this.toolbar.getBoundingClientRect();
      const move = (next: PointerEvent): void => {
        this.toolbar.style.bottom = 'auto';
        this.toolbar.style.right = 'auto';
        this.toolbar.style.margin = '0';
        this.toolbar.style.left = `${Math.max(0, Math.min(window.innerWidth - rect.width, rect.left + next.clientX - start.x))}px`;
        this.toolbar.style.top = `${Math.max(0, Math.min(window.innerHeight - rect.height, rect.top + next.clientY - start.y))}px`;
      };
      const up = (): void => {
        window.removeEventListener('pointermove', move, true);
        window.removeEventListener('pointerup', up, true);
      };
      window.addEventListener('pointermove', move, true);
      window.addEventListener('pointerup', up, true);
    });
  }

  rerender(): void {
    if (!this.host) return;
    this.renderToolbar();
    this.panel.className = `panel ${this.settings.toolbarSide}${this.panelOpen ? '' : ' hidden'}`;
    this.placeToolbar();
    if (!this.panelOpen) return;
    const scrollTop = this.panelBody.scrollTop;
    const active = this.root?.activeElement as HTMLElement | null;
    const activeTestId = active?.getAttribute('data-testid');
    clear(this.panel);
    const tabs: [PanelTab, string, string][] = [
      ['element', 'Elemento', 'target'],
      ['insert', 'Inserir', 'plus'],
      ['changes', 'Alterações', 'list'],
      ['variables', 'Variáveis', 'braces'],
      ['rules', 'Eventos', 'zap'],
      ['data', 'Dados', 'database'],
      ['clients', 'Clientes', 'users'],
      ['project', 'Projeto', 'settings'],
    ];
    const tabBar = h(
      'div',
      { class: 'tabs', role: 'tablist' },
      tabs.map(([id, label, glyph]) =>
        h(
          'button',
          {
            type: 'button',
            class: 'tab',
            role: 'tab',
            'aria-selected': String(this.tab === id),
            'data-testid': `tab-${id}`,
            onclick: () => this.setTab(id),
          },
          icon(glyph, 14),
          label,
          id === 'changes' ? h('span', { class: 'badge' }, String(this.project.edits.length)) : null,
        ),
      ),
    );
    this.panelBody = h('div', { class: 'body', 'data-testid': 'panel-body' });
    this.panel.append(h('div', { class: 'panel-head' }, h('h2', null, this.project.name)), tabBar, this.panelBody);
    try {
      renderPanel(this.tab, this.panelBody, this.context());
    } catch (error) {
      this.panelBody.append(h('p', { class: 'err' }, `Erro ao mostrar o painel: ${error instanceof Error ? error.message : String(error)}`));
    }
    this.panelBody.scrollTop = this.focusId ? 0 : scrollTop;
    if (this.focusId) {
      const target = this.panelBody.querySelector(`[data-section="${this.focusId}"]`);
      target?.scrollIntoView({ block: 'start' });
      (target?.querySelector('input,textarea,select') as HTMLElement | null)?.focus();
      this.focusId = null;
    } else if (activeTestId) (this.panelBody.querySelector(`[data-testid="${activeTestId}"]`) as HTMLElement | null)?.focus();
  }
}

if (globalThis.__wce && !globalThis.__wce.editor) {
  const editor = new Editor(globalThis.__wce);
  globalThis.__wce.editor = {
    open: (projectId, options) => editor.open(projectId, options),
    close: () => editor.close(),
    isOpen: () => editor.isOpen(),
  };
}
