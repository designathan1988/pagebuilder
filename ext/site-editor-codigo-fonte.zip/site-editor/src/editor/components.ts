// A biblioteca de componentes que o editor insere em qualquer página. Cada um é HTML com estilos próprios (classes
// wce-c-*, que não colidem com as da página) e {{ }} para os dados. O que precisa de comportamento usa os atributos
// data-wce-* (engine/behaviors.ts); o que precisa de estado declara as variáveis que cria ao ser inserido.
import type { VariableDef } from '../shared/model.ts';

export interface ComponentDef {
  readonly id: string;
  readonly name: string;
  readonly category: string;
  readonly description: string;
  readonly html: string;
  readonly variables?: readonly Omit<VariableDef, 'id'>[];
  // perguntas feitas antes de inserir (ex.: o endereço do mapa); a resposta substitui [[chave]] no HTML
  readonly asks?: readonly { readonly key: string; readonly label: string; readonly value: string }[];
}

const BASE = `font-family:inherit;box-sizing:border-box`;

export const COMPONENTS: readonly ComponentDef[] = [
  // ------------------------------------------------------------- básico
  { id: 'heading', name: 'Título', category: 'Básico', description: 'Um título de seção', html: `<h2 class="wce-c-heading" style="${BASE};margin:16px 0 8px;font-size:28px;line-height:1.2">Novo título</h2>` },
  { id: 'paragraph', name: 'Parágrafo', category: 'Básico', description: 'Texto corrido', html: `<p class="wce-c-p" style="${BASE};margin:8px 0;line-height:1.6">Escreva aqui o seu texto. Use {{ variavel }} para dados dinâmicos.</p>` },
  {
    id: 'button',
    name: 'Botão',
    category: 'Básico',
    description: 'Botão com link',
    html: `<a class="wce-c-btn" href="#" style="${BASE};display:inline-block;background:#2563eb;color:#fff;padding:10px 18px;border-radius:8px;text-decoration:none;font-weight:600">Clique aqui</a>`,
  },
  { id: 'link', name: 'Link', category: 'Básico', description: 'Um link de texto', html: `<a class="wce-c-link" href="https://" style="color:#2563eb">Novo link</a>` },
  { id: 'image', name: 'Imagem', category: 'Básico', description: 'Imagem responsiva', html: `<img class="wce-c-img" src="https://picsum.photos/seed/wce/800/450" alt="Imagem" style="display:block;max-width:100%;height:auto;border-radius:8px">` },
  { id: 'divider', name: 'Divisor', category: 'Básico', description: 'Linha horizontal', html: `<hr class="wce-c-hr" style="border:0;border-top:1px solid #e5e7eb;margin:20px 0">` },
  { id: 'spacer', name: 'Espaço', category: 'Básico', description: 'Espaço vertical', html: `<div class="wce-c-spacer" style="height:32px" aria-hidden="true"></div>` },
  { id: 'list', name: 'Lista', category: 'Básico', description: 'Lista com marcadores', html: `<ul class="wce-c-list" style="${BASE};margin:8px 0;padding-left:20px;line-height:1.7"><li>Primeiro item</li><li>Segundo item</li><li>Terceiro item</li></ul>` },
  {
    id: 'html',
    name: 'HTML livre',
    category: 'Básico',
    description: 'Qualquer HTML',
    html: `<div class="wce-c-html">[[html]]</div>`,
    asks: [{ key: 'html', label: 'HTML', value: '<div style="padding:16px;border:1px dashed #94a3b8;border-radius:8px">Seu HTML aqui</div>' }],
  },
  // ------------------------------------------------------------- seções
  {
    id: 'banner',
    name: 'Aviso',
    category: 'Seções',
    description: 'Faixa de aviso',
    html: `<div class="wce-c-banner" role="status" style="${BASE};background:#eff6ff;border:1px solid #bfdbfe;color:#1e3a8a;padding:12px 16px;border-radius:10px;margin:12px 0">📣 Aviso importante para {{ client.name }}.</div>`,
  },
  {
    id: 'announcement',
    name: 'Barra de anúncio',
    category: 'Seções',
    description: 'Faixa fixa no topo',
    html: `<div class="wce-c-bar" style="${BASE};position:sticky;top:0;z-index:999;background:#111827;color:#fff;text-align:center;padding:8px 12px;font-size:14px">Frete grátis nesta semana · <a href="#" style="color:#93c5fd">saiba mais</a></div>`,
  },
  {
    id: 'hero',
    name: 'Destaque (hero)',
    category: 'Seções',
    description: 'Título, texto e botão',
    html: `<section class="wce-c-hero" style="${BASE};padding:56px 24px;text-align:center;background:linear-gradient(135deg,#1e3a8a,#2563eb);color:#fff;border-radius:16px;margin:16px 0"><h1 style="margin:0 0 12px;font-size:40px;line-height:1.1">Bem-vindo, {{ client.name }}</h1><p style="margin:0 auto 20px;max-width:560px;font-size:18px;opacity:.9">Uma frase que explica o valor do produto em poucas palavras.</p><a href="#" style="display:inline-block;background:#fff;color:#1e3a8a;padding:12px 22px;border-radius:10px;font-weight:700;text-decoration:none">Começar agora</a></section>`,
  },
  {
    id: 'card',
    name: 'Cartão',
    category: 'Seções',
    description: 'Imagem, título e texto',
    html: `<article class="wce-c-card" style="${BASE};border:1px solid #e5e7eb;border-radius:14px;overflow:hidden;max-width:360px;background:#fff;color:#111827"><img src="https://picsum.photos/seed/card/720/400" alt="" style="display:block;width:100%;height:auto"><div style="padding:14px 16px"><h3 style="margin:0 0 6px;font-size:18px">Título do cartão</h3><p style="margin:0;color:#4b5563;line-height:1.5">Descrição curta do conteúdo.</p></div></article>`,
  },
  {
    id: 'features',
    name: 'Recursos (3 colunas)',
    category: 'Seções',
    description: 'Três benefícios lado a lado',
    html: `<section class="wce-c-features" style="${BASE};display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px;margin:16px 0">${['⚡ Rápido', '🔒 Seguro', '💬 Suporte']
      .map((title) => `<div style="padding:18px;border:1px solid #e5e7eb;border-radius:12px;background:#fff;color:#111827"><h3 style="margin:0 0 6px;font-size:17px">${title}</h3><p style="margin:0;color:#4b5563">Explique o benefício em uma frase.</p></div>`)
      .join('')}</section>`,
  },
  {
    id: 'stats',
    name: 'Números',
    category: 'Seções',
    description: 'Estatísticas em destaque',
    html: `<section class="wce-c-stats" style="${BASE};display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin:16px 0;text-align:center">${[
      ['+1.200', 'clientes'],
      ['98%', 'satisfação'],
      ['24h', 'suporte'],
    ]
      .map(([n, l]) => `<div style="padding:16px;border-radius:12px;background:#f8fafc;color:#0f172a"><div style="font-size:30px;font-weight:800">${n}</div><div style="color:#64748b">${l}</div></div>`)
      .join('')}</section>`,
  },
  {
    id: 'testimonial',
    name: 'Depoimento',
    category: 'Seções',
    description: 'Citação de cliente',
    html: `<figure class="wce-c-quote" style="${BASE};margin:16px 0;padding:20px;border-left:4px solid #2563eb;background:#f8fafc;color:#0f172a;border-radius:8px"><blockquote style="margin:0 0 8px;font-size:17px;line-height:1.5">“O melhor serviço que já contratamos.”</blockquote><figcaption style="color:#64748b">— Maria Souza, Empresa X</figcaption></figure>`,
  },
  {
    id: 'pricing',
    name: 'Tabela de preços',
    category: 'Seções',
    description: 'Planos lado a lado',
    html: `<section class="wce-c-pricing" style="${BASE};display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:14px;margin:16px 0">${[
      ['Básico', '49'],
      ['Pro', '99'],
      ['Empresa', '199'],
    ]
      .map(([name, price], i) => `<div style="padding:20px;border:${i === 1 ? '2px solid #2563eb' : '1px solid #e5e7eb'};border-radius:14px;background:#fff;color:#111827"><h3 style="margin:0 0 4px">${name}</h3><div style="font-size:30px;font-weight:800;margin:6px 0">{{ ${price} | money }}<small style="font-size:14px;color:#64748b">/mês</small></div><ul style="padding-left:18px;color:#4b5563;line-height:1.8"><li>Recurso incluído</li><li>Outro recurso</li></ul><a href="#" style="display:block;text-align:center;background:#2563eb;color:#fff;padding:10px;border-radius:8px;text-decoration:none;font-weight:600">Assinar</a></div>`)
      .join('')}</section>`,
  },
  {
    id: 'faq',
    name: 'Perguntas frequentes',
    category: 'Seções',
    description: 'Acordeão nativo',
    html: `<section class="wce-c-faq" style="${BASE};margin:16px 0">${['Como funciona?', 'Quanto custa?', 'Posso cancelar?']
      .map((q) => `<details style="border:1px solid #e5e7eb;border-radius:10px;padding:10px 14px;margin:0 0 8px;background:#fff;color:#111827"><summary style="cursor:pointer;font-weight:600">${q}</summary><p style="margin:8px 0 0;color:#4b5563">Resposta para a pergunta.</p></details>`)
      .join('')}</section>`,
  },
  {
    id: 'timeline',
    name: 'Linha do tempo',
    category: 'Seções',
    description: 'Etapas em sequência',
    html: `<ol class="wce-c-timeline" style="${BASE};list-style:none;margin:16px 0;padding:0;border-left:2px solid #2563eb">${['Pedido recebido', 'Em preparação', 'Enviado', 'Entregue']
      .map((s) => `<li style="position:relative;padding:0 0 14px 18px"><span style="position:absolute;left:-7px;top:4px;width:12px;height:12px;border-radius:50%;background:#2563eb"></span><b>${s}</b><div style="color:#64748b;font-size:14px">Descrição da etapa</div></li>`)
      .join('')}</ol>`,
  },
  {
    id: 'footer',
    name: 'Rodapé',
    category: 'Seções',
    description: 'Links e direitos',
    html: `<footer class="wce-c-footer" style="${BASE};padding:24px;background:#0f172a;color:#cbd5e1;display:flex;flex-wrap:wrap;gap:16px;justify-content:space-between;align-items:center;margin-top:24px"><span>© {{ date(now(), 'yyyy') }} {{ client.name }}</span><nav style="display:flex;gap:14px"><a href="#" style="color:#cbd5e1">Privacidade</a><a href="#" style="color:#cbd5e1">Termos</a><a href="#" style="color:#cbd5e1">Contato</a></nav></footer>`,
  },
  // ------------------------------------------------------------- mídia
  {
    id: 'carousel',
    name: 'Carrossel de fotos',
    category: 'Mídia',
    description: 'Slides com setas e pontos',
    html: `<div class="wce-c-carousel" data-wce-carousel data-wce-autoplay="5000" style="${BASE};position:relative;max-width:100%;border-radius:14px;overflow:hidden;margin:16px 0;background:#000"><div data-wce-track>${[1, 2, 3]
      .map((n) => `<figure data-wce-slide style="margin:0;aspect-ratio:2/1;background:#1e293b"><img src="https://picsum.photos/seed/slide${n}/1200/600" alt="Foto ${n}" style="display:block;width:100%;height:100%;object-fit:cover"></figure>`)
      .join('')}</div><button type="button" data-wce-prev aria-label="Anterior" style="position:absolute;left:10px;top:50%;transform:translateY(-50%);border:0;border-radius:50%;width:38px;height:38px;background:rgba(255,255,255,.85);cursor:pointer;font-size:20px">‹</button><button type="button" data-wce-next aria-label="Próxima" style="position:absolute;right:10px;top:50%;transform:translateY(-50%);border:0;border-radius:50%;width:38px;height:38px;background:rgba(255,255,255,.85);cursor:pointer;font-size:20px">›</button><div data-wce-dots style="position:absolute;bottom:10px;left:0;right:0;display:flex;gap:6px;justify-content:center;pointer-events:none"></div><style>.wce-c-carousel [data-wce-dots] button{pointer-events:auto;width:9px;height:9px;border-radius:50%;border:0;background:rgba(255,255,255,.5);cursor:pointer;padding:0}.wce-c-carousel [data-wce-dots] button[aria-current=true]{background:#fff}</style></div>`,
  },
  {
    id: 'gallery',
    name: 'Galeria',
    category: 'Mídia',
    description: 'Grade de fotos com ampliação',
    html: `<div class="wce-c-gallery" data-wce-lightbox style="${BASE};display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:8px;margin:16px 0">${[1, 2, 3, 4, 5, 6]
      .map((n) => `<img src="https://picsum.photos/seed/g${n}/600/600" data-full="https://picsum.photos/seed/g${n}/1400/1400" alt="Foto ${n}" style="width:100%;aspect-ratio:1;object-fit:cover;border-radius:8px;cursor:zoom-in">`)
      .join('')}</div>`,
  },
  {
    id: 'video',
    name: 'Vídeo (YouTube/Vimeo)',
    category: 'Mídia',
    description: 'Vídeo incorporado',
    html: `<div class="wce-c-video" style="${BASE};position:relative;aspect-ratio:16/9;margin:16px 0;border-radius:12px;overflow:hidden;background:#000"><iframe src="[[url]]" title="Vídeo" style="position:absolute;inset:0;width:100%;height:100%;border:0" allow="accelerometer;autoplay;clipboard-write;encrypted-media;gyroscope;picture-in-picture" allowfullscreen loading="lazy"></iframe></div>`,
    asks: [{ key: 'url', label: 'Endereço do vídeo (YouTube, Vimeo ou embed)', value: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' }],
  },
  {
    id: 'video-file',
    name: 'Vídeo (arquivo)',
    category: 'Mídia',
    description: 'MP4/WebM com controles',
    html: `<video class="wce-c-video-file" src="[[url]]" controls playsinline style="display:block;max-width:100%;border-radius:12px;margin:16px 0"></video>`,
    asks: [{ key: 'url', label: 'Endereço do arquivo de vídeo', value: 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4' }],
  },
  {
    id: 'audio',
    name: 'Áudio',
    category: 'Mídia',
    description: 'Player de áudio',
    html: `<audio class="wce-c-audio" src="[[url]]" controls style="width:100%;margin:12px 0"></audio>`,
    asks: [{ key: 'url', label: 'Endereço do áudio', value: 'https://interactive-examples.mdn.mozilla.net/media/cc0-audio/t-rex-roar.mp3' }],
  },
  {
    id: 'map',
    name: 'Mapa',
    category: 'Mídia',
    description: 'Google Maps por endereço',
    html: `<div class="wce-c-map" style="${BASE};aspect-ratio:16/9;margin:16px 0;border-radius:12px;overflow:hidden"><iframe title="Mapa" src="https://maps.google.com/maps?q=[[address]]&output=embed" style="width:100%;height:100%;border:0" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></div>`,
    asks: [{ key: 'address', label: 'Endereço ou lugar', value: 'Avenida Paulista, 1000, São Paulo' }],
  },
  {
    id: 'embed',
    name: 'Incorporar página',
    category: 'Mídia',
    description: 'Iframe de outro endereço',
    html: `<iframe class="wce-c-embed" src="[[url]]" title="Conteúdo incorporado" style="width:100%;height:480px;border:1px solid #e5e7eb;border-radius:12px;margin:16px 0" loading="lazy"></iframe>`,
    asks: [{ key: 'url', label: 'Endereço', value: 'https://example.com' }],
  },
  // ------------------------------------------------------------- interativos
  {
    id: 'tabs',
    name: 'Abas',
    category: 'Interativos',
    description: 'Conteúdo em abas',
    html: `<div class="wce-c-tabs" data-wce-tabs style="${BASE};margin:16px 0"><div role="tablist" style="display:flex;gap:4px;border-bottom:1px solid #e5e7eb">${['Visão geral', 'Detalhes', 'Avaliações']
      .map((t, i) => `<button type="button" role="tab" data-wce-tab="t${i}" style="border:0;background:none;padding:8px 14px;cursor:pointer;font:inherit;border-bottom:2px solid transparent">${t}</button>`)
      .join('')}</div>${['Conteúdo da visão geral.', 'Conteúdo dos detalhes.', 'Conteúdo das avaliações.']
      .map((c, i) => `<div role="tabpanel" data-wce-panel="t${i}" style="padding:14px 4px">${c}</div>`)
      .join('')}<style>.wce-c-tabs [data-wce-tab].is-active{border-bottom-color:#2563eb!important;color:#2563eb;font-weight:600}</style></div>`,
  },
  {
    id: 'countdown',
    name: 'Contagem regressiva',
    category: 'Interativos',
    description: 'Tempo até uma data',
    html: `<div class="wce-c-countdown" style="${BASE};display:inline-flex;align-items:center;gap:10px;padding:10px 16px;border-radius:10px;background:#111827;color:#fff;margin:12px 0"><span>Oferta termina em</span><b data-wce-countdown="[[date]]" style="font-variant-numeric:tabular-nums;font-size:20px">--:--:--</b></div>`,
    asks: [{ key: 'date', label: 'Data e hora (AAAA-MM-DDTHH:MM)', value: new Date(Date.now() + 3 * 86400000).toISOString().slice(0, 16) }],
  },
  {
    id: 'modal-button',
    name: 'Botão com janela',
    category: 'Interativos',
    description: 'Abre uma janela com conteúdo',
    html: `<button type="button" class="wce-c-modal-btn" data-wce-actions='[{"type":"modal","title":"Saiba mais","html":"<p>Conteúdo da janela para {{ client.name }}.</p>"}]' style="${BASE};background:#2563eb;color:#fff;border:0;padding:10px 18px;border-radius:8px;font-weight:600;cursor:pointer">Saiba mais</button>`,
  },
  {
    id: 'contact-form',
    name: 'Formulário de contato',
    category: 'Interativos',
    description: 'Guarda os envios numa variável',
    variables: [{ name: 'contatos', type: 'list', default: [], persist: 'local', description: 'Mensagens enviadas pelo formulário inserido' }],
    html: `<form class="wce-c-form" data-wce-actions='[{"type":"push","variable":"contatos","expr":"event.form"},{"type":"toast","expr":"\\"Obrigado, \\" + event.form.nome + \\"! Recebemos sua mensagem.\\"","tone":"success"}]' style="${BASE};display:grid;gap:10px;max-width:460px;margin:16px 0;padding:18px;border:1px solid #e5e7eb;border-radius:14px;background:#fff;color:#111827"><label style="display:grid;gap:4px">Nome<input name="nome" required style="padding:8px;border:1px solid #cbd5e1;border-radius:8px;font:inherit"></label><label style="display:grid;gap:4px">E-mail<input name="email" type="email" required style="padding:8px;border:1px solid #cbd5e1;border-radius:8px;font:inherit"></label><label style="display:grid;gap:4px">Mensagem<textarea name="mensagem" rows="3" style="padding:8px;border:1px solid #cbd5e1;border-radius:8px;font:inherit"></textarea></label><button type="submit" style="background:#2563eb;color:#fff;border:0;padding:10px;border-radius:8px;font-weight:600;cursor:pointer">Enviar</button></form>`,
  },
  {
    id: 'rating',
    name: 'Avaliação',
    category: 'Interativos',
    description: 'Estrelas de 1 a 5',
    variables: [{ name: 'nota', type: 'number', default: 4, persist: 'local' }],
    html: `<div class="wce-c-rating" style="font-size:24px;color:#f59e0b;margin:8px 0" aria-label="Nota {{ nota }} de 5">${[1, 2, 3, 4, 5]
      .map((n) => `<button type="button" aria-label="${n} estrelas" data-wce-actions='[{"type":"set","variable":"nota","expr":"${n}"}]' style="border:0;background:none;cursor:pointer;font-size:inherit;color:inherit;padding:0 2px">{{ nota >= ${n} ? '★' : '☆' }}</button>`)
      .join('')}</div>`,
  },
  {
    id: 'whatsapp',
    name: 'Botão do WhatsApp',
    category: 'Interativos',
    description: 'Botão flutuante',
    html: `<a class="wce-c-whatsapp" href="https://wa.me/[[phone]]?text={{ encode('Olá! Vim pelo site.') }}" target="_blank" rel="noopener" aria-label="Conversar no WhatsApp" style="position:fixed;right:20px;bottom:20px;z-index:99999;width:56px;height:56px;border-radius:50%;background:#25d366;color:#fff;display:flex;align-items:center;justify-content:center;box-shadow:0 8px 24px rgba(0,0,0,.25);font-size:28px;text-decoration:none">✆</a>`,
    asks: [{ key: 'phone', label: 'Número com DDI e DDD (só dígitos)', value: '5511999999999' }],
  },
  {
    id: 'social',
    name: 'Redes sociais',
    category: 'Interativos',
    description: 'Links para as redes',
    html: `<nav class="wce-c-social" aria-label="Redes sociais" style="display:flex;gap:10px;margin:12px 0">${['Instagram', 'Facebook', 'LinkedIn', 'YouTube']
      .map((n) => `<a href="#" style="padding:6px 12px;border-radius:999px;background:#f1f5f9;color:#0f172a;text-decoration:none;font-size:14px">${n}</a>`)
      .join('')}</nav>`,
  },
  // ------------------------------------------------------------- comércio
  {
    id: 'product',
    name: 'Produto',
    category: 'Comércio',
    description: 'Adiciona ao carrinho',
    variables: [{ name: 'carrinho', type: 'list', default: [], persist: 'local', description: 'Itens do carrinho' }],
    html: `<article class="wce-c-product" style="${BASE};border:1px solid #e5e7eb;border-radius:14px;overflow:hidden;max-width:300px;background:#fff;color:#111827"><img src="https://picsum.photos/seed/produto/600/600" alt="Produto" style="display:block;width:100%;height:auto"><div style="padding:14px"><h3 style="margin:0 0 4px;font-size:17px">Nome do produto</h3><div style="font-size:20px;font-weight:800;margin:4px 0 10px">{{ 129.9 | money }}</div><button type="button" data-wce-actions='[{"type":"push","variable":"carrinho","expr":"{nome: \\"Nome do produto\\", preco: 129.9, qtd: 1}"},{"type":"toast","expr":"\\"Adicionado ao carrinho\\"","tone":"success"}]' style="width:100%;background:#16a34a;color:#fff;border:0;padding:10px;border-radius:8px;font-weight:600;cursor:pointer">Adicionar ao carrinho</button></div></article>`,
  },
  {
    id: 'cart',
    name: 'Carrinho',
    category: 'Comércio',
    description: 'Itens, total e esvaziar',
    variables: [{ name: 'carrinho', type: 'list', default: [], persist: 'local', description: 'Itens do carrinho' }],
    html: `<aside class="wce-c-cart" style="${BASE};border:1px solid #e5e7eb;border-radius:14px;padding:16px;max-width:360px;background:#fff;color:#111827;margin:16px 0"><h3 style="margin:0 0 10px">Carrinho ({{ len(carrinho) }})</h3>{{{ len(carrinho) == 0 ? '<p style="color:#64748b;margin:0">Seu carrinho está vazio.</p>' : '' }}}<ul style="list-style:none;margin:0;padding:0"><li data-wce-repeat-slot></li></ul><div style="display:flex;justify-content:space-between;font-weight:800;margin:12px 0">Total <span>{{ sum(carrinho, 'preco') | money }}</span></div><button type="button" data-wce-actions='[{"type":"set","variable":"carrinho","expr":"[]"}]' style="width:100%;background:#f1f5f9;border:0;padding:9px;border-radius:8px;cursor:pointer">Esvaziar</button></aside>`,
  },
  {
    id: 'cart-count',
    name: 'Contador do carrinho',
    category: 'Comércio',
    description: 'Selo com a quantidade',
    variables: [{ name: 'carrinho', type: 'list', default: [], persist: 'local', description: 'Itens do carrinho' }],
    html: `<span class="wce-c-cart-count" style="display:inline-flex;align-items:center;gap:4px;background:#16a34a;color:#fff;border-radius:999px;padding:2px 10px;font-size:13px;font-weight:700">🛒 {{ len(carrinho) }}</span>`,
  },
  {
    id: 'coupon',
    name: 'Cupom',
    category: 'Comércio',
    description: 'Código para copiar',
    html: `<div class="wce-c-coupon" style="${BASE};display:inline-flex;gap:10px;align-items:center;border:2px dashed #16a34a;border-radius:12px;padding:10px 14px;margin:12px 0;background:#f0fdf4;color:#14532d"><span>Use o cupom <b>[[code]]</b></span><button type="button" data-wce-actions='[{"type":"copy","expr":"\\"[[code]]\\""},{"type":"toast","expr":"\\"Cupom copiado\\"","tone":"success"}]' style="border:0;background:#16a34a;color:#fff;border-radius:8px;padding:6px 10px;cursor:pointer">Copiar</button></div>`,
    asks: [{ key: 'code', label: 'Código do cupom', value: 'BEMVINDO10' }],
  },
  // ------------------------------------------------------------- dados
  {
    id: 'data-list',
    name: 'Lista de posts',
    category: 'Dados',
    description: 'Cartões a partir de uma lista',
    variables: [
      {
        name: 'posts',
        type: 'list',
        default: [
          { titulo: 'Primeiro post', resumo: 'Um resumo curto do post.', data: '2026-10-01', imagem: 'https://picsum.photos/seed/p1/600/340' },
          { titulo: 'Segundo post', resumo: 'Outro resumo para mostrar.', data: '2026-10-08', imagem: 'https://picsum.photos/seed/p2/600/340' },
          { titulo: 'Terceiro post', resumo: 'Mais um exemplo de conteúdo.', data: '2026-10-15', imagem: 'https://picsum.photos/seed/p3/600/340' },
        ],
        persist: 'none',
        description: 'Posts (troque por uma fonte de dados em Dados)',
      },
    ],
    html: `<section class="wce-c-posts" style="${BASE};display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:14px;margin:16px 0">{{{ len(posts) == 0 ? '<p>Nenhum post.</p>' : '' }}}<div data-wce-repeat-slot></div></section>`,
  },
  {
    id: 'data-table',
    name: 'Tabela de dados',
    category: 'Dados',
    description: 'Tabela a partir de uma lista',
    variables: [
      {
        name: 'linhas',
        type: 'list',
        default: [
          { nome: 'Ana', cidade: 'São Paulo', valor: 1200 },
          { nome: 'Bruno', cidade: 'Recife', valor: 860 },
          { nome: 'Carla', cidade: 'Curitiba', valor: 1530 },
        ],
        persist: 'none',
      },
    ],
    html: `<table class="wce-c-table" style="${BASE};width:100%;border-collapse:collapse;margin:16px 0;font-size:14px"><thead><tr style="background:#f8fafc"><th style="text-align:left;padding:8px;border-bottom:1px solid #e5e7eb">Nome</th><th style="text-align:left;padding:8px;border-bottom:1px solid #e5e7eb">Cidade</th><th style="text-align:right;padding:8px;border-bottom:1px solid #e5e7eb">Valor</th></tr></thead><tbody><tr data-wce-repeat-slot></tr></tbody></table>`,
  },
  {
    id: 'value',
    name: 'Valor de variável',
    category: 'Dados',
    description: 'Mostra uma variável',
    html: `<span class="wce-c-value">{{ [[name]] }}</span>`,
    asks: [{ key: 'name', label: 'Expressão (ex.: client.name, total | money)', value: 'client.name' }],
  },
  {
    id: 'search',
    name: 'Campo de busca',
    category: 'Dados',
    description: 'Filtra listas pela variável busca',
    variables: [{ name: 'busca', type: 'text', default: '', persist: 'none' }],
    html: `<input class="wce-c-search" type="search" placeholder="Buscar…" data-wce-actions='[{"type":"set","variable":"busca","expr":"event.value"}]' data-wce-on="input" style="${BASE};width:100%;max-width:420px;padding:10px 12px;border:1px solid #cbd5e1;border-radius:10px;font:inherit;margin:8px 0">`,
  },
];

// O que cada componente de dados repete: o HTML de um item. O editor cria uma alteração de repetição para o slot.
export const REPEATERS: Record<string, { readonly expr: string; readonly template: string }> = {
  'data-list': {
    expr: "search(posts, busca ?? '', 'titulo')",
    template: `<article style="border:1px solid #e5e7eb;border-radius:12px;overflow:hidden;background:#fff;color:#111827"><img src="{{ item.imagem }}" alt="" style="display:block;width:100%;height:auto"><div style="padding:12px"><small style="color:#64748b">{{ date(item.data) }}</small><h3 style="margin:4px 0 6px;font-size:17px">{{ item.titulo }}</h3><p style="margin:0;color:#4b5563">{{ item.resumo }}</p></div></article>`,
  },
  cart: {
    expr: 'carrinho',
    template: `<li style="display:flex;justify-content:space-between;gap:8px;padding:6px 0;border-bottom:1px solid #f1f5f9"><span>{{ item.nome }}</span><span>{{ item.preco | money }} <button type="button" aria-label="Remover" data-wce-actions='[{"type":"set","variable":"carrinho","expr":"concat(slice(carrinho, 0, event.index), slice(carrinho, event.index + 1))"}]' style="border:0;background:none;cursor:pointer;color:#b91c1c">×</button></span></li>`,
  },
  'data-table': {
    expr: 'linhas',
    template: `<tr><td style="padding:8px;border-bottom:1px solid #f1f5f9">{{ item.nome }}</td><td style="padding:8px;border-bottom:1px solid #f1f5f9">{{ item.cidade }}</td><td style="padding:8px;border-bottom:1px solid #f1f5f9;text-align:right">{{ item.valor | money }}</td></tr>`,
  },
};

// Endereços de vídeo comuns viram o endereço de incorporação.
export function embedUrl(url: string): string {
  const youtube = /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/shorts\/)([\w-]{6,})/.exec(url);
  if (youtube) return `https://www.youtube-nocookie.com/embed/${youtube[1]}`;
  const vimeo = /vimeo\.com\/(\d+)/.exec(url);
  if (vimeo) return `https://player.vimeo.com/video/${vimeo[1]}`;
  return url;
}

export function fillAsks(component: ComponentDef, answers: Record<string, string>): string {
  return component.html.replace(/\[\[(\w+)\]\]/g, (_m, key: string) => {
    const raw = answers[key] ?? component.asks?.find((ask) => ask.key === key)?.value ?? '';
    if (key === 'url' && component.id === 'video') return embedUrl(raw).replace(/"/g, '&quot;');
    if (key === 'address') return encodeURIComponent(raw);
    if (key === 'html') return raw;
    return raw.replace(/[<>"]/g, '');
  });
}
