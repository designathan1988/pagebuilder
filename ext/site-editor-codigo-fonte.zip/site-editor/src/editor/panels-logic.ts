// As abas da lógica do projeto: variáveis e estados, regras (eventos e ações), fontes de dados, clientes e o projeto
// (endereços, exportação, integração, versões e scripts próprios).
import type { EditorContext } from './editor.ts';
import { RESERVED_NAMES, VARIABLE_NAME, defaultFor, uid, type Action, type ActionType, type Client, type DataSource, type Rule, type TriggerType, type VariableDef, type VariableSource, type VariableType } from '../shared/model.ts';
import { toText } from '../shared/expr.ts';
import { history } from '../shared/storage.ts';
import { selectorFor } from '../shared/selector.ts';
import { download, installSnippet, pageZip, projectFile, slug, standaloneScript } from '../shared/exporters.ts';
import { button, checkbox, empty, field, h, icon, input, section, select, textarea } from './dom.ts';
import { expressionInput } from './panels.ts';

// ---------------------------------------------------------------- variáveis

const TYPES: readonly (readonly [VariableType, string])[] = [
  ['text', 'Texto'],
  ['number', 'Número'],
  ['boolean', 'Sim/Não'],
  ['state', 'Estado (opções)'],
  ['list', 'Lista'],
  ['json', 'Objeto (JSON)'],
  ['color', 'Cor'],
  ['image', 'Imagem (endereço)'],
  ['url', 'Endereço'],
];

const SOURCES: readonly (readonly [VariableSource['kind'], string])[] = [
  ['static', 'Valor do cliente ou padrão'],
  ['query', 'Parâmetro do endereço (?x=)'],
  ['cookie', 'Cookie'],
  ['storage', 'localStorage da página'],
  ['element', 'Texto de um elemento'],
  ['expression', 'Calculada (expressão)'],
  ['source', 'Fonte de dados'],
];

function show(value: unknown): string {
  return typeof value === 'string' ? value : JSON.stringify(value, null, 2);
}

function parseLoose(type: VariableType, raw: string): unknown {
  if (type === 'number') return Number(raw.replace(',', '.')) || 0;
  if (type === 'boolean') return raw === 'true' || raw === '1' || raw === 'sim';
  if (type === 'list' || type === 'json') {
    try {
      return JSON.parse(raw) as unknown;
    } catch {
      return type === 'list' ? raw.split(/\n|,/).map((part) => part.trim()).filter(Boolean) : raw;
    }
  }
  return raw;
}

export function valueControl(variable: VariableDef, value: unknown, onChange: (value: unknown) => void, testid?: string): HTMLElement {
  switch (variable.type) {
    case 'boolean':
      return checkbox(value ? 'Sim' : 'Não', Boolean(value), (on) => onChange(on), testid);
    case 'state':
      return h(
        'div',
        { class: 'row' },
        (variable.options ?? []).map((option) => button(option, () => onChange(option), { small: true, pressed: toText(value) === option, ...(testid ? { testid: `${testid}-${option}` } : {}) })),
      );
    case 'list':
    case 'json':
      return textarea(show(value), (raw) => onChange(parseLoose(variable.type, raw)), { rows: 3, mono: true, ...(testid ? { testid } : {}) });
    case 'color': {
      const text = toText(value) || '#000000';
      const picker = h('input', { type: 'color', value: /^#[0-9a-f]{6}$/i.test(text) ? text : '#000000', style: 'width:38px;flex:none' });
      const box = input(text, (next) => onChange(next), { mono: true, ...(testid ? { testid } : {}) });
      picker.addEventListener('change', () => {
        box.value = picker.value;
        onChange(picker.value);
      });
      return h('div', { class: 'row', style: 'flex-wrap:nowrap' }, picker, box);
    }
    case 'number':
      return input(toText(value), (raw) => onChange(parseLoose('number', raw)), { type: 'number', ...(testid ? { testid } : {}) });
    default:
      return input(toText(value), (raw) => onChange(raw), { ...(testid ? { testid } : {}) });
  }
}

function variableEditor(ctx: EditorContext, variable: VariableDef): HTMLElement {
  const mutate = (label: string, change: (target: VariableDef) => void): void =>
    void ctx.commit(label, (project) => {
      const target = project.variables.find((candidate) => candidate.id === variable.id);
      if (target) change(target);
    });
  const source = variable.source ?? { kind: 'static' };
  const sourceFields = h('div');
  const sourceParam = (label: string, key: string, value: string, placeholder = ''): HTMLElement =>
    field(label, input(value, (next) => mutate('Origem', (target) => (target.source = { ...(target.source ?? { kind: 'static' }), [key]: next } as VariableSource)), { mono: true, placeholder }));
  if (source.kind === 'query') sourceFields.append(sourceParam('Parâmetro', 'param', source.param, 'cliente'));
  if (source.kind === 'cookie') sourceFields.append(sourceParam('Nome do cookie', 'name', source.name));
  if (source.kind === 'storage') sourceFields.append(sourceParam('Chave', 'key', source.key));
  if (source.kind === 'element') {
    sourceFields.append(
      sourceParam('Seletor do elemento', 'selector', source.selector, '.usuario-nome'),
      button('Escolher na página', () => ctx.pick('Clique no elemento de onde vem o valor', (element) => mutate('Origem', (target) => (target.source = { kind: 'element', selector: selectorOf(element) }))), { small: true, icon: 'target' }),
      sourceParam('Atributo (vazio: o texto)', 'attr', source.attr ?? ''),
    );
  }
  if (source.kind === 'expression') sourceFields.append(field('Expressão', expressionInput(source.expr, (expr) => mutate('Origem', (target) => (target.source = { kind: 'expression', expr })), { placeholder: 'ex.: preco * quantidade' })));
  if (source.kind === 'source') {
    sourceFields.append(
      field('Fonte', select(source.sourceId, [['', '—'], ...ctx.project.sources.map((item) => [item.id, item.name] as [string, string])], (sourceId) => mutate('Origem', (target) => (target.source = { kind: 'source', sourceId, path: source.path ?? '' })))),
      field('Caminho nos dados', input(source.path ?? '', (path) => mutate('Origem', (target) => (target.source = { kind: 'source', sourceId: source.sourceId, path })), { mono: true, placeholder: 'ex.: usuario.nome' })),
    );
  }
  const optionsInput = variable.type === 'state' ? field('Opções (uma por linha)', textarea((variable.options ?? []).join('\n'), (raw) => mutate('Opções', (target) => (target.options = raw.split('\n').map((line) => line.trim()).filter(Boolean))), { rows: 3 })) : null;
  return h(
    'details',
    null,
    h('summary', null, 'Definição'),
    field('Tipo', select(variable.type, TYPES, (type) => mutate('Tipo', (target) => {
      target.type = type;
      target.default = defaultFor(type, target.options);
      if (type === 'state' && (!target.options || target.options.length === 0)) target.options = ['inicial', 'ativo'];
    }))),
    optionsInput,
    field('Valor padrão', valueControl(variable, variable.default, (value) => mutate('Valor padrão', (target) => (target.default = value)))),
    field('Guardar o valor', select(variable.persist, [
      ['none', 'Não (volta ao padrão a cada página)'],
      ['session', 'Enquanto a aba estiver aberta'],
      ['local', 'Sempre, neste navegador'],
    ], (persist) => mutate('Guardar', (target) => (target.persist = persist)))),
    field('Origem do valor', select(source.kind, SOURCES, (kind) => mutate('Origem', (target) => {
      target.source = kind === 'static' ? { kind } : kind === 'query' ? { kind, param: target.name } : kind === 'cookie' ? { kind, name: target.name } : kind === 'storage' ? { kind, key: target.name } : kind === 'element' ? { kind, selector: '' } : kind === 'expression' ? { kind, expr: '' } : { kind, sourceId: ctx.project.sources[0]?.id ?? '', path: '' };
    }))),
    sourceFields,
    field('Descrição', input(variable.description ?? '', (description) => mutate('Descrição', (target) => (target.description = description)))),
    button('Excluir variável', () => window.confirm(`Excluir a variável ${variable.name}?`) && void ctx.commit('Excluir variável', (project) => (project.variables = project.variables.filter((candidate) => candidate.id !== variable.id))), { small: true, variant: 'danger', icon: 'trash' }),
  );
}

const selectorOf = selectorFor;

export function renderVariables(body: HTMLElement, ctx: EditorContext): void {
  const name = input('', () => undefined, { placeholder: 'nome (ex.: plano, logado, cor_marca)', mono: true, testid: 'var-name' });
  let type: VariableType = 'text';
  const typeSelect = select<VariableType>('text', TYPES, (value) => (type = value), 'var-type');
  const add = (): void => {
    const value = name.value.trim();
    if (!VARIABLE_NAME.test(value)) return ctx.toast('Nome inválido: use letras, números e _, começando por letra.', true);
    if (RESERVED_NAMES.has(value)) return ctx.toast(`"${value}" é um nome reservado.`, true);
    if (ctx.project.variables.some((variable) => variable.name === value)) return ctx.toast('Já existe uma variável com esse nome.', true);
    const options = type === 'state' ? ['inicial', 'ativo'] : undefined;
    void ctx.commit('Nova variável', (project) => {
      project.variables.push({ id: uid('v_'), name: value, type, default: defaultFor(type, options), persist: 'none', ...(options ? { options } : {}) });
    });
  };
  body.append(
    section(
      'Nova variável ou estado',
      h('div', { class: 'grid2' }, name, typeSelect),
      h('div', { class: 'row', style: 'margin-top:6px' }, button('Criar', add, { variant: 'primary', small: true, icon: 'plus', testid: 'var-add' })),
      h('p', { class: 'hint', style: 'margin:8px 0 0' }, 'Use nos textos como {{ nome }}, em condições (plano == "pro") e nas regras. Um estado tem opções fixas (ex.: aberto/fechado) e as regras alternam entre elas.'),
    ),
  );
  if (ctx.project.variables.length === 0) {
    body.append(empty('Nenhuma variável ainda.'));
    return;
  }
  for (const variable of ctx.project.variables) {
    const live = ctx.engine.vars[variable.name];
    body.append(
      h(
        'div',
        { class: 'item', 'data-testid': `var-${variable.name}` },
        h('div', { class: 'top' }, icon(variable.type === 'state' ? 'layers' : 'braces', 14), h('span', { class: 'title mono' }, variable.name), h('span', { class: 'badge' }, TYPES.find(([key]) => key === variable.type)?.[1] ?? variable.type), variable.persist !== 'none' ? h('span', { class: 'badge ac' }, variable.persist === 'local' ? 'guardada' : 'na aba') : null),
        variable.description ? h('div', { class: 'sub' }, variable.description) : null,
        field('Valor agora (só nesta visita)', valueControl(variable, live, (value) => {
          ctx.engine.setVariable(variable.name, value);
          ctx.rerender();
        }, `var-live-${variable.name}`)),
        h('div', { class: 'row' }, button('Guardar como padrão', () => void ctx.commit('Valor padrão', (project) => {
          const target = project.variables.find((candidate) => candidate.id === variable.id);
          if (target) target.default = ctx.engine.vars[variable.name];
        }), { small: true }), button('Voltar ao valor inicial', () => {
          ctx.engine.resetVariable(variable.name);
          ctx.rerender();
        }, { small: true })),
        variableEditor(ctx, variable),
      ),
    );
  }
}

// ---------------------------------------------------------------- regras

const TRIGGERS: readonly (readonly [TriggerType, string])[] = [
  ['click', 'Clique em um elemento'],
  ['dblclick', 'Duplo clique'],
  ['hover', 'Mouse sobre um elemento'],
  ['submit', 'Envio de formulário'],
  ['change', 'Mudança de campo'],
  ['input', 'Digitação em campo'],
  ['keydown', 'Tecla pressionada'],
  ['visible', 'Elemento aparece na tela'],
  ['load', 'Página carregada'],
  ['urlchange', 'Mudança de endereço (navegação)'],
  ['varchange', 'Variável mudou'],
  ['interval', 'A cada intervalo'],
  ['timeout', 'Depois de um tempo'],
];

const ACTIONS: readonly (readonly [ActionType, string])[] = [
  ['set', 'Definir variável'],
  ['toggle', 'Alternar variável/estado'],
  ['reset', 'Voltar variável ao inicial'],
  ['push', 'Adicionar item à lista'],
  ['show', 'Mostrar elemento'],
  ['hide', 'Ocultar elemento'],
  ['toggleVisible', 'Mostrar/ocultar elemento'],
  ['addClass', 'Adicionar classe'],
  ['removeClass', 'Remover classe'],
  ['toggleClass', 'Alternar classe'],
  ['setText', 'Trocar texto'],
  ['setHtml', 'Trocar HTML'],
  ['setAttr', 'Definir atributo'],
  ['setStyle', 'Definir estilo'],
  ['setValue', 'Preencher campo'],
  ['click', 'Clicar em elemento'],
  ['focus', 'Focar elemento'],
  ['scroll', 'Rolar até elemento'],
  ['navigate', 'Ir para endereço'],
  ['toast', 'Mostrar aviso'],
  ['modal', 'Abrir janela'],
  ['closeModal', 'Fechar janela'],
  ['fetch', 'Recarregar fonte de dados'],
  ['copy', 'Copiar texto'],
  ['delay', 'Esperar'],
  ['log', 'Registrar no console'],
  ['if', 'Se… senão…'],
  ['script', 'Script próprio (JavaScript)'],
];

function defaultAction(type: ActionType, ctx: EditorContext): Action {
  const variable = ctx.project.variables[0]?.name ?? '';
  switch (type) {
    case 'set':
      return { type, variable, expr: '' };
    case 'toggle':
    case 'reset':
      return { type, variable };
    case 'push':
      return { type, variable, expr: '' };
    case 'show':
    case 'hide':
    case 'toggleVisible':
    case 'click':
    case 'focus':
    case 'scroll':
      return { type, selector: '' };
    case 'addClass':
    case 'removeClass':
    case 'toggleClass':
      return { type, selector: '', className: '' };
    case 'setText':
    case 'setHtml':
    case 'setValue':
      return { type, selector: '', expr: '' };
    case 'setAttr':
      return { type, selector: '', name: '', expr: '' };
    case 'setStyle':
      return { type, selector: '', prop: '', expr: '' };
    case 'navigate':
      return { type, expr: '"/"' };
    case 'toast':
      return { type, expr: '"Pronto!"', tone: 'success' };
    case 'modal':
      return { type, title: 'Título', html: '<p>Conteúdo</p>' };
    case 'closeModal':
      return { type };
    case 'fetch':
      return { type, sourceId: ctx.project.sources[0]?.id ?? '' };
    case 'copy':
      return { type, expr: '' };
    case 'delay':
      return { type, ms: 1000 };
    case 'log':
      return { type, expr: 'vars' };
    case 'if':
      return { type, condition: 'true', then: [], else: [] };
    case 'script':
      return { type, code: '// vars, data, event e page estão disponíveis\n// devolva { set: { variavel: valor } } para mudar variáveis\nreturn { set: {} };' };
  }
}

function actionsEditor(ctx: EditorContext, actions: Action[], onChange: (actions: Action[]) => void, depth = 0): HTMLElement {
  const wrap = h('div', { class: 'actions' });
  const update = (index: number, patch: Partial<Action>): void => {
    const next = actions.map((action, at) => (at === index ? ({ ...action, ...patch } as Action) : action));
    onChange(next);
  };
  actions.forEach((action, index) => {
    const variables: [string, string][] = ctx.project.variables.map((variable) => [variable.name, variable.name]);
    const selectorField = (key: 'selector', value: string): HTMLElement =>
      field('Elemento (seletor; "this" = o do evento)', h('div', { class: 'row', style: 'flex-wrap:nowrap' }, input(value, (next) => update(index, { [key]: next } as Partial<Action>), { mono: true, placeholder: '.minha-caixa ou this' }), button('Escolher', () => ctx.pick('Clique no elemento da ação', (element) => update(index, { [key]: selectorOf(element) } as Partial<Action>)), { small: true, icon: 'target', iconOnly: true })));
    const exprField = (label: string, key: string, value: string, placeholder = ''): HTMLElement => field(label, expressionInput(value, (next) => update(index, { [key]: next } as Partial<Action>), { placeholder }));
    const fields: (HTMLElement | null)[] = [];
    switch (action.type) {
      case 'set':
      case 'push':
        fields.push(field('Variável', select(action.variable, [['', '—'], ...variables], (variable) => update(index, { variable }))), exprField(action.type === 'set' ? 'Novo valor (expressão)' : 'Item (expressão)', 'expr', action.expr, 'ex.: "pro", contador + 1, event.value'));
        break;
      case 'toggle':
      case 'reset':
        fields.push(field('Variável', select(action.variable, [['', '—'], ...variables], (variable) => update(index, { variable }))));
        break;
      case 'show':
      case 'hide':
      case 'toggleVisible':
      case 'click':
      case 'focus':
      case 'scroll':
        fields.push(selectorField('selector', action.selector));
        break;
      case 'addClass':
      case 'removeClass':
      case 'toggleClass':
        fields.push(selectorField('selector', action.selector), field('Classe', input(action.className, (className) => update(index, { className }), { mono: true })));
        break;
      case 'setText':
      case 'setHtml':
      case 'setValue':
        fields.push(selectorField('selector', action.selector), exprField('Valor (expressão)', 'expr', action.expr, '"Olá, " + nome'));
        break;
      case 'setAttr':
        fields.push(selectorField('selector', action.selector), field('Atributo', input(action.name, (name) => update(index, { name }), { mono: true })), exprField('Valor', 'expr', action.expr));
        break;
      case 'setStyle':
        fields.push(selectorField('selector', action.selector), field('Propriedade CSS', input(action.prop, (prop) => update(index, { prop }), { mono: true, placeholder: 'background-color' })), exprField('Valor', 'expr', action.expr, '"#16a34a"'));
        break;
      case 'navigate':
        fields.push(exprField('Endereço (expressão)', 'expr', action.expr, '"/painel"'), checkbox('Abrir em nova aba', action.newTab === true, (newTab) => update(index, { newTab })));
        break;
      case 'toast':
        fields.push(exprField('Mensagem (expressão)', 'expr', action.expr, '"Salvo!"'), field('Tom', select(action.tone ?? 'info', [
          ['info', 'Informação'],
          ['success', 'Sucesso'],
          ['error', 'Erro'],
        ], (tone) => update(index, { tone }))));
        break;
      case 'modal':
        fields.push(field('Título', input(action.title, (title) => update(index, { title }))), field('Conteúdo (HTML com {{ }})', textarea(action.html, (html) => update(index, { html }), { rows: 4, mono: true })));
        break;
      case 'fetch':
        fields.push(field('Fonte', select(action.sourceId, [['', '—'], ...ctx.project.sources.map((source) => [source.id, source.name] as [string, string])], (sourceId) => update(index, { sourceId }))));
        break;
      case 'copy':
      case 'log':
        fields.push(exprField('Valor (expressão)', 'expr', action.expr));
        break;
      case 'delay':
        fields.push(field('Milissegundos', input(String(action.ms), (raw) => update(index, { ms: Number(raw) || 0 }), { type: 'number' })));
        break;
      case 'if':
        fields.push(
          exprField('Condição', 'condition', action.condition, 'plano == "pro"'),
          h('div', { class: 'hint' }, 'Então:'),
          depth < 3 ? actionsEditor(ctx, action.then, (then) => update(index, { then }), depth + 1) : null,
          h('div', { class: 'hint' }, 'Senão:'),
          depth < 3 ? actionsEditor(ctx, action.else, (otherwise) => update(index, { else: otherwise }), depth + 1) : null,
        );
        break;
      case 'script':
        fields.push(field('JavaScript (roda no mundo da página)', textarea(action.code, (code) => update(index, { code }), { rows: 6, mono: true })), h('div', { class: 'hint' }, 'Precisa de "Permitir scripts de usuário" ligado na página da extensão (chrome://extensions). No script dos sites, roda direto.'));
        break;
      case 'closeModal':
        break;
    }
    wrap.append(
      h(
        'div',
        { class: 'action', 'data-testid': 'action' },
        h(
          'div',
          { class: 'row', style: 'flex-wrap:nowrap' },
          h('b', { class: 'grow' }, `${index + 1}. ${ACTIONS.find(([key]) => key === action.type)?.[1] ?? action.type}`),
          button('Subir', () => index > 0 && onChange(actions.map((item, at) => (at === index - 1 ? action : at === index ? (actions[index - 1] as Action) : item))), { icon: 'up', iconOnly: true, small: true, variant: 'ghost', disabled: index === 0 }),
          button('Excluir ação', () => onChange(actions.filter((_item, at) => at !== index)), { icon: 'trash', iconOnly: true, small: true, variant: 'ghost' }),
        ),
        ...fields,
      ),
    );
  });
  const adder = select<ActionType | ''>('', [['', '+ Adicionar ação…'], ...ACTIONS], (type) => type && onChange([...actions, defaultAction(type, ctx)]), depth === 0 ? 'add-action' : undefined);
  wrap.append(adder);
  return wrap;
}

function ruleEditor(ctx: EditorContext, rule: Rule): HTMLElement {
  const mutate = (label: string, change: (target: Rule) => void): void =>
    void ctx.commit(label, (project) => {
      const target = project.rules.find((candidate) => candidate.id === rule.id);
      if (target) change(target);
    });
  const trigger = rule.trigger;
  const needsSelector = ['click', 'dblclick', 'hover', 'submit', 'change', 'input', 'visible'].includes(trigger.type);
  return h(
    'div',
    { class: 'item', 'data-testid': 'rule', 'data-section': rule.id },
    h(
      'div',
      { class: 'top' },
      h('input', { type: 'checkbox', checked: rule.enabled, 'aria-label': 'Ligada', onchange: (event: Event) => mutate('Ligar regra', (target) => (target.enabled = (event.target as HTMLInputElement).checked)) }),
      input(rule.name, (name) => mutate('Nome da regra', (target) => (target.name = name)), { testid: 'rule-name' }),
      button('Testar agora', () => void ctx.engine.runRule(rule, null, null).then(() => ctx.toast('Regra executada.')), { icon: 'play', iconOnly: true, small: true, variant: 'ghost', testid: 'rule-test' }),
      button('Excluir regra', () => void ctx.commit('Excluir regra', (project) => (project.rules = project.rules.filter((candidate) => candidate.id !== rule.id))), { icon: 'trash', iconOnly: true, small: true, variant: 'ghost' }),
    ),
    field('Quando', select(trigger.type, TRIGGERS, (type) => mutate('Gatilho', (target) => (target.trigger = { ...target.trigger, type })), 'rule-trigger')),
    needsSelector
      ? field('Em qual elemento', h('div', { class: 'row', style: 'flex-wrap:nowrap' }, input(trigger.selector ?? '', (selector) => mutate('Elemento do gatilho', (target) => (target.trigger = { ...target.trigger, selector })), { mono: true, testid: 'rule-selector' }), button('Escolher', () => ctx.pick('Clique no elemento que dispara a regra', (element) => mutate('Elemento do gatilho', (target) => (target.trigger = { ...target.trigger, selector: selectorOf(element) }))), { small: true, icon: 'target', iconOnly: true })))
      : null,
    trigger.type === 'keydown' ? field('Tecla', input(trigger.key ?? '', (key) => mutate('Tecla', (target) => (target.trigger = { ...target.trigger, key })), { placeholder: 'ex.: Enter, ctrl+k, Escape', mono: true })) : null,
    trigger.type === 'interval' || trigger.type === 'timeout' ? field('Milissegundos', input(String(trigger.ms ?? 1000), (raw) => mutate('Tempo', (target) => (target.trigger = { ...target.trigger, ms: Number(raw) || 1000 })), { type: 'number' })) : null,
    trigger.type === 'varchange' ? field('Variável', select(trigger.variable ?? '', [['', 'qualquer'], ...ctx.project.variables.map((variable) => [variable.name, variable.name] as [string, string])], (variable) => mutate('Variável do gatilho', (target) => (target.trigger = { ...target.trigger, variable })))) : null,
    field('Só se (condição)', expressionInput(rule.condition ?? '', (condition) => mutate('Condição', (target) => (condition.trim() ? (target.condition = condition) : delete target.condition)), { placeholder: 'vazio: sempre · ex.: event.value != ""' })),
    ['click', 'submit', 'keydown'].includes(trigger.type) ? checkbox('Impedir a ação normal do sistema (link, envio)', rule.preventDefault === true, (on) => mutate('Impedir padrão', (target) => (target.preventDefault = on))) : null,
    field('Só nas páginas', input(rule.page ?? '', (page) => mutate('Página da regra', (target) => (page.trim() ? (target.page = page.trim()) : delete target.page)), { mono: true, placeholder: 'vazio: todas' })),
    h('div', { class: 'hint' }, 'Então:'),
    actionsEditor(ctx, rule.actions, (actions) => mutate('Ações', (target) => (target.actions = actions))),
  );
}

export function renderRules(body: HTMLElement, ctx: EditorContext): void {
  body.append(
    section(
      'Eventos e ações',
      h('p', { class: 'hint', style: 'margin:0 0 8px' }, 'Uma regra diz: quando algo acontece (clique, envio, navegação, variável mudou, tempo…), se a condição valer, faça as ações em ordem. As expressões veem as variáveis, data, page, client e event (value, text, form, key, index).'),
      button('Nova regra', () => {
        const id = uid('r_');
        void ctx.commit('Nova regra', (project) => project.rules.push({ id, name: `Regra ${project.rules.length + 1}`, enabled: true, trigger: { type: 'click', selector: '' }, actions: [] })).then(() => ctx.setTab('rules', id));
      }, { variant: 'primary', small: true, icon: 'plus', testid: 'rule-add' }),
    ),
  );
  if (ctx.project.rules.length === 0) body.append(empty('Nenhuma regra ainda. Também dá para criar pelo elemento: selecione e use “Ao clicar…”.'));
  for (const rule of ctx.project.rules) body.append(ruleEditor(ctx, rule));
}

// ---------------------------------------------------------------- dados

function sourceEditor(ctx: EditorContext, source: DataSource): HTMLElement {
  const mutate = (label: string, change: (target: DataSource) => void): void =>
    void ctx.commit(label, (project) => {
      const target = project.sources.find((candidate) => candidate.id === source.id);
      if (target) change(target);
    });
  const preview = h('div', { class: 'value', 'data-testid': `source-preview-${source.name}` }, ctx.engine.data[source.name] === undefined ? '(não carregada)' : JSON.stringify(ctx.engine.data[source.name], null, 2).slice(0, 4000));
  return h(
    'div',
    { class: 'item', 'data-testid': 'source' },
    h(
      'div',
      { class: 'top' },
      icon('database', 14),
      input(source.name, (name) => /^[A-Za-z_]\w*$/.test(name) ? mutate('Nome da fonte', (target) => (target.name = name)) : ctx.toast('Nome inválido.', true), { mono: true, testid: 'source-name' }),
      button('Carregar agora', () => void ctx.engine.loadSource(source.id).then(() => ctx.rerender()), { icon: 'download', iconOnly: true, small: true, variant: 'ghost', testid: 'source-load' }),
      button('Excluir fonte', () => void ctx.commit('Excluir fonte', (project) => (project.sources = project.sources.filter((candidate) => candidate.id !== source.id))), { icon: 'trash', iconOnly: true, small: true, variant: 'ghost' }),
    ),
    h('div', { class: 'sub' }, `Nas expressões: data.${source.name}`),
    field('Tipo', select(source.kind, [
      ['json', 'JSON escrito aqui'],
      ['csv', 'Planilha (CSV) colada aqui'],
      ['http', 'API / endereço na internet'],
    ], (kind) => mutate('Tipo da fonte', (target) => (target.kind = kind)), 'source-kind')),
    source.kind !== 'http' ? field(source.kind === 'json' ? 'JSON' : 'CSV (primeira linha: nomes das colunas)', textarea(source.data ?? '', (data) => mutate('Dados', (target) => (target.data = data)), { rows: 6, mono: true, testid: 'source-data' })) : null,
    source.kind === 'http'
      ? h(
          'div',
          null,
          field('Endereço', input(source.url ?? '', (url) => mutate('Endereço da fonte', (target) => (target.url = url)), { mono: true, placeholder: 'https://api.exemplo.com/itens?cliente={{ client.id }}', testid: 'source-url' })),
          h('div', { class: 'grid2' }, field('Método', select(source.method ?? 'GET', [
            ['GET', 'GET'],
            ['POST', 'POST'],
          ], (method) => mutate('Método', (target) => (target.method = method)))), field('Formato', select(source.format ?? 'json', [
            ['json', 'JSON'],
            ['csv', 'CSV'],
            ['text', 'Texto'],
          ], (format) => mutate('Formato', (target) => (target.format = format))))),
          field('Cabeçalhos (JSON)', textarea(JSON.stringify(source.headers ?? {}, null, 1), (raw) => {
            try {
              const headers = JSON.parse(raw || '{}') as Record<string, string>;
              mutate('Cabeçalhos', (target) => (target.headers = headers));
            } catch {
              ctx.toast('Cabeçalhos: JSON inválido.', true);
            }
          }, { rows: 2, mono: true })),
          source.method === 'POST' ? field('Corpo', textarea(source.body ?? '', (value) => mutate('Corpo', (target) => (target.body = value)), { rows: 3, mono: true })) : null,
          h('div', { class: 'grid2' }, field('Atualizar a cada (s)', input(String(source.refreshSec ?? 0), (raw) => mutate('Atualização', (target) => (target.refreshSec = Number(raw) || 0)), { type: 'number' })), field('Carregar ao abrir', checkbox('Sim', source.auto, (auto) => mutate('Carregar ao abrir', (target) => (target.auto = auto))))),
        )
      : null,
    field('Caminho dentro dos dados', input(source.path ?? '', (path) => mutate('Caminho', (target) => (target.path = path)), { mono: true, placeholder: 'ex.: results ou data.items' })),
    h('details', null, h('summary', null, 'Ver dados carregados'), preview),
  );
}

export function renderData(body: HTMLElement, ctx: EditorContext): void {
  body.append(
    section(
      'Fontes de dados',
      h('p', { class: 'hint', style: 'margin:0 0 8px' }, 'Dados que alimentam textos, listas repetidas e regras: JSON, planilha CSV ou uma API. Chamadas a outros domínios passam pela extensão, sem bloqueio de CORS.'),
      button('Nova fonte', () => void ctx.commit('Nova fonte', (project) => project.sources.push({ id: uid('s_'), name: `dados${project.sources.length + 1}`, kind: 'json', data: '[\n  { "nome": "Exemplo", "valor": 10 }\n]', auto: true })), { variant: 'primary', small: true, icon: 'plus', testid: 'source-add' }),
    ),
  );
  if (ctx.project.sources.length === 0) body.append(empty('Nenhuma fonte ainda.'));
  for (const source of ctx.project.sources) body.append(sourceEditor(ctx, source));
}

// ---------------------------------------------------------------- clientes

function clientCard(ctx: EditorContext, client: Client, active: boolean): HTMLElement {
  const mutate = (label: string, change: (target: Client) => void): void =>
    void ctx.commit(label, (project) => {
      const target = project.clients.find((candidate) => candidate.id === client.id);
      if (target) change(target);
    });
  const demo = new URL(location.href);
  demo.searchParams.set('wce_client', client.id);
  const values = ctx.project.variables.filter((variable) => variable.source?.kind !== 'expression');
  return h(
    'div',
    { class: `item${active ? '' : ''}`, 'data-testid': `client-${client.name}` },
    h(
      'div',
      { class: 'top' },
      h('input', { type: 'radio', name: 'wce-client', checked: active, 'aria-label': `Mostrar ${client.name}`, 'data-testid': 'client-activate', onchange: () => void ctx.commit('Trocar cliente', (project) => (project.activeClientId = client.id)) }),
      input(client.name, (name) => name.trim() && mutate('Nome do cliente', (target) => (target.name = name.trim())), { testid: 'client-name' }),
      active ? h('span', { class: 'badge ac' }, 'na tela') : null,
      button('Duplicar cliente', () => void ctx.commit('Duplicar cliente', (project) => project.clients.push({ ...JSON.parse(JSON.stringify(client)) as Client, id: uid('c_'), name: `${client.name} (cópia)` })), { icon: 'copy', iconOnly: true, small: true, variant: 'ghost' }),
      ctx.project.clients.length > 1
        ? button('Excluir cliente', () => window.confirm(`Excluir o cliente ${client.name}?`) && void ctx.commit('Excluir cliente', (project) => {
            project.clients = project.clients.filter((candidate) => candidate.id !== client.id);
            if (project.activeClientId === client.id) project.activeClientId = project.clients[0]?.id ?? null;
            for (const edit of project.edits) if (edit.clients) edit.clients = edit.clients.filter((id) => id !== client.id);
          }), { icon: 'trash', iconOnly: true, small: true, variant: 'ghost' })
        : null,
    ),
    values.length === 0 ? h('div', { class: 'hint' }, 'Crie variáveis (aba Variáveis) para dar a cada cliente os seus valores: nome, logo, cores, preços…') : null,
    ...values.map((variable) =>
      field(
        `${variable.name}${Object.prototype.hasOwnProperty.call(client.values, variable.name) ? '' : ' (padrão)'}`,
        valueControl(variable, Object.prototype.hasOwnProperty.call(client.values, variable.name) ? client.values[variable.name] : variable.default, (value) => mutate('Valor do cliente', (target) => (target.values = { ...target.values, [variable.name]: value })), `client-value-${variable.name}`),
      ),
    ),
    h(
      'details',
      null,
      h('summary', null, 'CSS e notas deste cliente'),
      field('CSS só deste cliente', textarea(client.css ?? '', (css) => mutate('CSS do cliente', (target) => (target.css = css)), { rows: 4, mono: true, placeholder: ':root { --cor-principal: #e11d48; }' })),
      field('Notas', textarea(client.notes ?? '', (notes) => mutate('Notas do cliente', (target) => (target.notes = notes)), { rows: 2 })),
    ),
    h(
      'div',
      { class: 'row' },
      button('Copiar link de demonstração', () => void navigator.clipboard.writeText(demo.href).then(() => ctx.toast('Link copiado: quem tem a extensão e o projeto vê este cliente.')), { small: true, icon: 'link' }),
    ),
  );
}

export function renderClients(body: HTMLElement, ctx: EditorContext): void {
  const current = ctx.engine.currentClient?.id ?? ctx.project.activeClientId;
  body.append(
    section(
      'Clientes',
      h('p', { class: 'hint', style: 'margin:0 0 8px' }, 'O mesmo sistema, um conteúdo para cada cliente: as alterações valem para todos, e cada cliente dá os seus valores às variáveis. Uma alteração também pode valer só para alguns clientes (aba Alterações › Opções).'),
      button('Novo cliente', () => {
        const name = window.prompt('Nome do cliente');
        if (name?.trim()) void ctx.commit('Novo cliente', (project) => {
          const client: Client = { id: uid('c_'), name: name.trim(), values: {} };
          project.clients.push(client);
          project.activeClientId = client.id;
        });
      }, { variant: 'primary', small: true, icon: 'plus', testid: 'client-add' }),
    ),
  );
  for (const client of ctx.project.clients) body.append(clientCard(ctx, client, client.id === current));
}

// ---------------------------------------------------------------- projeto

async function runtimeSource(): Promise<string> {
  const answer = (await chrome.runtime.sendMessage({ type: 'wce:runtime-source' })) as { ok: boolean; source?: string } | undefined;
  if (!answer?.ok || !answer.source) throw new Error('não foi possível ler o wc-runtime.js da extensão');
  return answer.source;
}

export function renderProject(body: HTMLElement, ctx: EditorContext): void {
  const project = ctx.project;
  const status = h('div', { class: 'hint', 'data-testid': 'project-status' });
  const say = (text: string, error = false): void => {
    status.textContent = text;
    status.className = error ? 'err' : 'ok';
  };
  body.append(
    section(
      'Projeto',
      field('Nome', input(project.name, (name) => name.trim() && void ctx.commit('Nome do projeto', (target) => (target.name = name.trim())), { testid: 'project-name' })),
      field('Vale nos endereços (um por linha)', textarea(project.matches.join('\n'), (raw) => void ctx.commit('Endereços', (target) => (target.matches = raw.split('\n').map((line) => line.trim()).filter(Boolean))), { rows: 3, mono: true, testid: 'project-matches' }), 'Ex.: https://app.exemplo.com/* · *.exemplo.com/clientes/* · /regex/'),
      checkbox('Projeto ligado (aplica as alterações ao abrir as páginas)', project.enabled, (enabled) => void ctx.commit('Ligar projeto', (target) => (target.enabled = enabled))),
      field('Descrição', textarea(project.description ?? '', (description) => void ctx.commit('Descrição', (target) => (target.description = description)), { rows: 2 })),
    ),
    section(
      'Exportar e instalar',
      h('p', { class: 'hint', style: 'margin:0 0 8px' }, 'Entregue a personalização ao cliente: o script aplica as mesmas alterações, variáveis, eventos e dados em qualquer site, sem a extensão.'),
      h(
        'div',
        { class: 'row' },
        button('Arquivo do projeto (.json)', () => {
          download(document, `${slug(project.name)}.wce.json`, projectFile([project]), 'application/json');
          say('Arquivo do projeto baixado.');
        }, { small: true, icon: 'download', testid: 'export-json' }),
        button('Script para o site (.js)', () => {
          void runtimeSource().then(
            (source) => {
              download(document, `${slug(project.name)}.wce.js`, standaloneScript(project, source, ctx.engine.currentClient?.id), 'text/javascript');
              say('Script baixado. No site: <script src="…wce.js" defer></script>.');
            },
            (error: unknown) => say(String(error), true),
          );
        }, { small: true, icon: 'code', testid: 'export-script' }),
        button('Página para o Webconstructor (.zip)', () => {
          void runtimeSource()
            .catch(() => null)
            .then((source) => {
              const zip = pageZip(document, project, source);
              download(document, `${slug(project.name)}-pagina.zip`, zip.bytes, 'application/zip');
              say(`ZIP com ${zip.files.join(', ')}. No Webconstructor: Arquivo › Importar HTML/ZIP.`);
            });
        }, { small: true, icon: 'download', testid: 'export-zip' }),
      ),
      h('details', null, h('summary', null, 'Código de instalação com o projeto embutido'), h('div', { class: 'value', 'data-testid': 'install-snippet' }, installSnippet(project, { runtimeUrl: 'https://SEU-SITE/wc-runtime.js', clientId: ctx.engine.currentClient?.id ?? null }).slice(0, 1200) + '…'), h('div', { class: 'hint' }, 'Hospede o wc-runtime.js (vem no ZIP da extensão) e cole o código antes do </body>. O modo nuvem (publicar e buscar por chave) fica no gerenciador.')),
      status,
    ),
    section(
      'Integração',
      h(
        'div',
        { class: 'row' },
        button('Abrir o gerenciador', () => void chrome.runtime.sendMessage({ type: 'wce:open-manager', hash: `#project=${project.id}` }), { small: true, icon: 'settings' }),
        button('Enviar ao Builder Companion', () => void chrome.runtime.sendMessage({ type: 'wce:companion' }).then((answer: { said?: string; ok?: boolean } | undefined) => say(answer?.said ?? 'Sem resposta.', !answer?.ok)), { small: true, icon: 'upload' }),
      ),
      h('p', { class: 'hint', style: 'margin:8px 0 0' }, 'No gerenciador: entrar na conta do Webconstructor, sincronizar com a nuvem, publicar para o script buscar por chave e ligar a um projeto do editor.'),
    ),
    section(
      'Preferências do editor',
      field('Lado do painel', select(ctx.settings.toolbarSide, [
        ['right', 'Direita'],
        ['left', 'Esquerda'],
      ], (toolbarSide) => void ctx.setSettings({ toolbarSide }))),
      checkbox('Mostrar os elementos ocultos (tracejados)', ctx.settings.showHidden, (showHidden) => void ctx.setSettings({ showHidden })),
    ),
  );

  // scripts próprios
  const scripts = h('div');
  const userScripts = h('div', { class: 'hint' }, 'Verificando…');
  void chrome.runtime.sendMessage({ type: 'wce:user-scripts-status' }).then((answer: { available?: boolean; chrome?: number } | undefined) => {
    userScripts.textContent = answer?.available ? 'Scripts próprios liberados neste navegador.' : `Para rodar scripts próprios, ative “Permitir scripts de usuário” nos detalhes da extensão (chrome://extensions)${answer?.chrome && answer.chrome < 138 ? ' ou o Modo do desenvolvedor' : ''}. Sem isso, as regras e ligações funcionam normalmente.`;
    userScripts.className = answer?.available ? 'ok' : 'hint';
  });
  for (const script of project.scripts) {
    const mutate = (label: string, change: (target: (typeof project.scripts)[number]) => void): void =>
      void ctx.commit(label, (target) => {
        const found = target.scripts.find((candidate) => candidate.id === script.id);
        if (found) change(found);
      });
    scripts.append(
      h(
        'div',
        { class: 'item' },
        h('div', { class: 'top' }, h('input', { type: 'checkbox', checked: script.enabled, 'aria-label': 'Ligado', onchange: (event: Event) => mutate('Ligar script', (target) => (target.enabled = (event.target as HTMLInputElement).checked)) }), input(script.name, (name) => mutate('Nome do script', (target) => (target.name = name))), button('Excluir', () => void ctx.commit('Excluir script', (target) => (target.scripts = target.scripts.filter((candidate) => candidate.id !== script.id))), { icon: 'trash', iconOnly: true, small: true, variant: 'ghost' })),
        textarea(script.code, (code) => mutate('Código', (target) => (target.code = code)), { rows: 6, mono: true }),
        field('Só nas páginas', input(script.page ?? '', (page) => mutate('Página do script', (target) => (page ? (target.page = page) : delete target.page)), { mono: true, placeholder: 'vazio: todas' })),
      ),
    );
  }
  body.append(
    section(
      'Scripts próprios (ao carregar a página)',
      userScripts,
      scripts,
      button('Novo script', () => void ctx.commit('Novo script', (target) => target.scripts.push({ id: uid('x_'), name: 'Meu script', code: '// roda no mundo da página quando ela abre\n// vars, data, event e page estão disponíveis\nconsole.log("Olá", vars);', enabled: true })), { small: true, icon: 'plus' }),
    ),
  );

  // versões
  const versions = h('div', { 'data-testid': 'versions' }, empty('Carregando…'));
  void history(project.id).then((list) => {
    versions.replaceChildren();
    if (list.length === 0) versions.append(empty('Nenhuma versão guardada ainda.'));
    for (const revision of list.slice(0, 30)) {
      versions.append(
        h(
          'div',
          { class: 'item' },
          h(
            'div',
            { class: 'top' },
            icon('history', 14),
            h('span', { class: 'title' }, revision.label),
            h('span', { class: 'sub' }, new Date(revision.at).toLocaleString('pt-BR')),
            button('Voltar a esta versão', () => window.confirm('Voltar o projeto para esta versão? (dá para desfazer com Ctrl+Z)') && void ctx.commit('Voltar versão', (target) => Object.assign(target, JSON.parse(JSON.stringify(revision.project)))), { small: true }),
          ),
          h('div', { class: 'sub' }, `${revision.project.edits.length} alterações · ${revision.project.variables.length} variáveis · ${revision.project.rules.length} regras`),
        ),
      );
    }
  });
  body.append(section('Versões', versions));
  body.append(
    section(
      'Zona de perigo',
      button('Excluir projeto', () => {
        if (!window.confirm(`Excluir o projeto "${project.name}" e todas as alterações? Isso não tem volta.`)) return;
        void chrome.runtime.sendMessage({ type: 'wce:delete-project', id: project.id }).then(() => ctx.close());
      }, { variant: 'danger', small: true, icon: 'trash' }),
    ),
  );
}
