// As abas do painel. Cada uma lê o projeto do contexto e grava pelas funções dele (upsert, commit), então desfazer,
// salvar e reaplicar valem para todas.
import type { EditorContext } from './editor.ts';
import { type Edit, type EditOp, type InsertPosition, uid } from '../shared/model.ts';
import { check, hasTemplate } from '../shared/expr.ts';
import { friendlyName, safeQueryAll, selectorFor, similarSelector } from '../shared/selector.ts';
import { append, button, checkbox, empty, field, h, icon, input, section, select, textarea } from './dom.ts';
import { COMPONENTS, REPEATERS, fillAsks, type ComponentDef } from './components.ts';
import { renderClients, renderData, renderProject, renderRules, renderVariables } from './panels-logic.ts';

export type PanelTab = 'element' | 'insert' | 'changes' | 'variables' | 'rules' | 'data' | 'clients' | 'project';

export function renderPanel(tab: PanelTab, body: HTMLElement, ctx: EditorContext): void {
  switch (tab) {
    case 'element':
      renderElement(body, ctx);
      break;
    case 'insert':
      renderInsert(body, ctx);
      break;
    case 'changes':
      renderChanges(body, ctx);
      break;
    case 'variables':
      renderVariables(body, ctx);
      break;
    case 'rules':
      renderRules(body, ctx);
      break;
    case 'data':
      renderData(body, ctx);
      break;
    case 'clients':
      renderClients(body, ctx);
      break;
    case 'project':
      renderProject(body, ctx);
      break;
  }
}

// ---------------------------------------------------------------- utilidades

export function variablePicker(ctx: EditorContext, onPick: (text: string) => void): HTMLElement {
  const names = [
    ...ctx.project.variables.map((variable) => variable.name),
    ...ctx.project.sources.map((source) => `data.${source.name}`),
    'client.name',
    'page.path',
    'page.query',
    "date(now(), 'dd/MM/yyyy')",
  ];
  const element = h('select', { 'aria-label': 'Inserir variável', class: 'grow', 'data-testid': 'insert-variable' }, h('option', { value: '' }, '{ } Inserir variável…'), names.map((name) => h('option', { value: name }, name)));
  element.addEventListener('change', () => {
    if (element.value) onPick(`{{ ${element.value} }}`);
    element.value = '';
  });
  return element;
}

export function expressionInput(value: string, onChange: (value: string) => void, options: { placeholder?: string; testid?: string; template?: boolean } = {}): HTMLElement {
  const status = h('div', { class: 'hint' });
  const control = input(value, (next) => {
    const problem = options.template ? null : check(next);
    status.textContent = problem ? `⚠ ${problem}` : '';
    status.className = problem ? 'err' : 'hint';
    if (!problem) onChange(next);
  }, { mono: true, placeholder: options.placeholder ?? 'ex.: plano == "pro"', ...(options.testid ? { testid: options.testid } : {}) });
  const problem = value && !options.template ? check(value) : null;
  if (problem) {
    status.textContent = `⚠ ${problem}`;
    status.className = 'err';
  }
  return h('div', null, control, status);
}

function insertAtCursor(area: HTMLTextAreaElement | HTMLInputElement, text: string): void {
  const start = area.selectionStart ?? area.value.length;
  const end = area.selectionEnd ?? area.value.length;
  area.value = area.value.slice(0, start) + text + area.value.slice(end);
  area.dispatchEvent(new Event('change'));
}

function scopeBadges(ctx: EditorContext, edit: Edit): HTMLElement[] {
  const badges: HTMLElement[] = [];
  if (edit.page) badges.push(h('span', { class: 'badge', title: 'Só nesta página' }, `📄 ${edit.page}`));
  if (edit.clients && edit.clients.length > 0) badges.push(h('span', { class: 'badge ac' }, `👤 ${edit.clients.map((id) => ctx.project.clients.find((client) => client.id === id)?.name ?? '?').join(', ')}`));
  if (edit.when) badges.push(h('span', { class: 'badge warn', title: edit.when }, 'condicional'));
  return badges;
}

export function describeEdit(edit: Edit): string {
  switch (edit.op) {
    case 'text':
      return `Texto: “${edit.value.slice(0, 60)}”`;
    case 'html':
      return 'Conteúdo HTML';
    case 'attr':
      return edit.value === null ? `Remover atributo ${edit.name}` : `${edit.name} = ${edit.value.slice(0, 50)}`;
    case 'style':
      return `Estilo: ${Object.entries(edit.props)
        .map(([key, value]) => `${key}: ${value}`)
        .join('; ')
        .slice(0, 70)}`;
    case 'class':
      return `Classes ${edit.add.map((name) => `+${name}`).join(' ')} ${edit.remove.map((name) => `−${name}`).join(' ')}`;
    case 'hide':
      return 'Ocultar';
    case 'remove':
      return 'Remover da página';
    case 'blur':
      return `Desfocar (${edit.amount}px)`;
    case 'insert':
      return `Inserir ${edit.component ? `“${COMPONENTS.find((component) => component.id === edit.component)?.name ?? edit.component}”` : 'HTML'} (${positionName(edit.position)})`;
    case 'move':
      return `Mover para ${positionName(edit.position)} de ${edit.ref.selector}`;
    case 'replace':
      return `Substituir “${edit.find}” por “${edit.replace}”`;
    case 'bind':
      return `Ligação (${edit.kind}${edit.name ? ` ${edit.name}` : ''}): ${edit.expr}`;
    case 'repeat':
      return `Repetir para cada item de ${edit.expr}`;
  }
}

function positionName(position: InsertPosition): string {
  return { before: 'antes', after: 'depois', prepend: 'no início de dentro', append: 'no fim de dentro' }[position];
}

// ---------------------------------------------------------------- aba Elemento

function currentEdit<T extends Edit['op']>(ctx: EditorContext, op: T, extra?: (edit: Extract<Edit, { op: T }>) => boolean): Extract<Edit, { op: T }> | undefined {
  return ctx.project.edits.find((edit): edit is Extract<Edit, { op: T }> => edit.target.selector === ctx.selector && edit.op === op && (!extra || extra(edit as Extract<Edit, { op: T }>)));
}

function scopeSection(ctx: EditorContext): HTMLElement {
  const client = ctx.engine.currentClient;
  return h(
    'div',
    { class: 'row', style: 'margin:0 0 10px' },
    h('span', { class: 'hint' }, 'Novas alterações valem para'),
    select(ctx.scope.page, [
      ['all', 'todas as páginas'],
      ['this', 'só esta página'],
    ], (page) => ctx.setScope({ ...ctx.scope, page }), 'scope-page'),
    select(ctx.scope.clients, [
      ['all', 'todos os clientes'],
      ['current', `só ${client?.name ?? 'este cliente'}`],
    ], (clients) => ctx.setScope({ ...ctx.scope, clients }), 'scope-clients'),
  );
}

const STYLE_FIELDS: readonly { readonly prop: string; readonly label: string; readonly kind: 'color' | 'text' | 'select'; readonly options?: readonly string[]; readonly placeholder?: string }[] = [
  { prop: 'color', label: 'Cor do texto', kind: 'color' },
  { prop: 'background-color', label: 'Cor de fundo', kind: 'color' },
  { prop: 'font-size', label: 'Tamanho da fonte', kind: 'text', placeholder: '16px' },
  { prop: 'font-weight', label: 'Peso', kind: 'select', options: ['', '300', '400', '500', '600', '700', '800'] },
  { prop: 'font-family', label: 'Fonte', kind: 'text', placeholder: 'Inter, sans-serif' },
  { prop: 'text-align', label: 'Alinhamento', kind: 'select', options: ['', 'left', 'center', 'right', 'justify'] },
  { prop: 'margin', label: 'Margem', kind: 'text', placeholder: '0 0 16px' },
  { prop: 'padding', label: 'Espaço interno', kind: 'text', placeholder: '12px 16px' },
  { prop: 'border-radius', label: 'Arredondamento', kind: 'text', placeholder: '8px' },
  { prop: 'border', label: 'Borda', kind: 'text', placeholder: '1px solid #ddd' },
  { prop: 'width', label: 'Largura', kind: 'text', placeholder: 'auto, 100%, 320px' },
  { prop: 'height', label: 'Altura', kind: 'text', placeholder: 'auto' },
  { prop: 'opacity', label: 'Opacidade', kind: 'text', placeholder: '0 a 1' },
  { prop: 'display', label: 'Exibição', kind: 'select', options: ['', 'block', 'inline-block', 'flex', 'grid', 'inline', 'none'] },
  { prop: 'box-shadow', label: 'Sombra', kind: 'text', placeholder: '0 4px 12px rgba(0,0,0,.1)' },
  { prop: 'background-image', label: 'Imagem de fundo', kind: 'text', placeholder: 'url(https://…)' },
];

function rgbToHex(value: string): string {
  const match = /rgba?\((\d+),\s*(\d+),\s*(\d+)/.exec(value);
  if (!match) return /^#[0-9a-f]{6}$/i.test(value) ? value : '#000000';
  return `#${[match[1], match[2], match[3]].map((n) => Number(n).toString(16).padStart(2, '0')).join('')}`;
}

function renderElement(body: HTMLElement, ctx: EditorContext): void {
  const element = ctx.selected;
  body.append(scopeSection(ctx));
  if (!element) {
    body.append(
      section(
        'Comece por aqui',
        h('p', null, 'Clique em qualquer parte da página para selecionar. Dê ', h('b', null, 'duplo clique'), ' para editar o texto no lugar.'),
        h(
          'ul',
          { class: 'hint', style: 'padding-left:18px;margin:6px 0' },
          h('li', null, h('span', { class: 'kbd' }, 'Delete'), ' oculta o selecionado'),
          h('li', null, h('span', { class: 'kbd' }, 'Alt'), ' + ', h('span', { class: 'kbd' }, '↑'), ' seleciona o elemento de fora'),
          h('li', null, h('span', { class: 'kbd' }, 'Ctrl'), ' + ', h('span', { class: 'kbd' }, 'Z'), ' desfaz'),
          h('li', null, 'O botão de cursor na barra liga o modo de navegar no sistema, para chegar a outra tela.'),
        ),
      ),
      section(
        'Substituir texto no site todo',
        replaceForm(ctx),
      ),
    );
    return;
  }
  const html = element as HTMLElement;
  const selector = ctx.selector;
  const matches = safeQueryAll(ctx.doc, selector).filter((candidate) => !candidate.closest('[data-wce-ui]')).length;
  // caminho até o elemento
  const chain: Element[] = [];
  for (let cursor: Element | null = element; cursor && cursor !== ctx.doc.documentElement && chain.length < 6; cursor = cursor.parentElement) chain.unshift(cursor);
  body.append(
    h(
      'div',
      { class: 'crumbs', 'aria-label': 'Caminho do elemento' },
      chain.map((node) => h('button', { type: 'button', onclick: () => ctx.select(node), title: selectorFor(node) }, friendlyName(node))),
    ),
  );
  const selectorField = input(selector, (value) => ctx.setSelector(value), { mono: true, testid: 'selector' });
  body.append(
    section(
      friendlyName(element),
      field('Seletor', selectorField, `${matches} elemento${matches === 1 ? '' : 's'} na página`),
      h(
        'div',
        { class: 'row' },
        button('Todos os parecidos', () => ctx.setSelector(similarSelector(element)), { small: true, title: 'Aplicar as alterações a todos os itens iguais (linhas, cartões…)' }),
        button('Só este', () => ctx.setSelector(selectorFor(element)), { small: true }),
      ),
    ),
  );

  // conteúdo
  const textEdit = currentEdit(ctx, 'text');
  const htmlEdit = currentEdit(ctx, 'html');
  const simple = Array.from(element.children).every((child) => child.localName === 'br');
  if (!/^(img|input|select|video|iframe|hr|br|svg|audio)$/.test(element.localName)) {
    const area = textarea(textEdit?.value ?? (simple ? (html.innerText ?? element.textContent ?? '').trim() : ''), (value) => void ctx.upsert({ op: 'text', value }, { label: 'Texto' }), { rows: 3, testid: 'text-value', placeholder: simple ? '' : 'Este elemento tem outros dentro. Escrever aqui troca tudo por texto.' });
    const htmlArea = textarea(htmlEdit?.value ?? element.innerHTML, (value) => void ctx.upsert({ op: 'html', value }, { label: 'Conteúdo' }), { rows: 5, mono: true, testid: 'html-value' });
    body.append(
      h(
        'section',
        { class: 'sec', 'data-section': 'content' },
        h('h3', null, 'Conteúdo'),
        field('Texto', area, hasTemplate(area.value) ? 'Com dados dinâmicos: o {{ }} é trocado pelo valor.' : 'Use {{ nome_da_variavel }} para dados dinâmicos.'),
        h('div', { class: 'row' }, variablePicker(ctx, (text) => insertAtCursor(area, text)), button('Editar no lugar', () => ctx.startInline(element), { small: true, icon: 'edit' })),
        h('details', null, h('summary', null, 'HTML do conteúdo'), htmlArea, h('div', { class: 'row', style: 'margin-top:6px' }, variablePicker(ctx, (text) => insertAtCursor(htmlArea, text)))),
      ),
    );
  }

  // imagem
  if (element.localName === 'img') {
    const image = element as HTMLImageElement;
    const srcEdit = currentEdit(ctx, 'attr', (edit) => edit.name === 'src');
    const altEdit = currentEdit(ctx, 'attr', (edit) => edit.name === 'alt');
    const file = h('input', { type: 'file', accept: 'image/*', 'data-testid': 'image-file', style: 'display:none' });
    file.addEventListener('change', () => {
      const chosen = file.files?.[0];
      if (!chosen) return;
      if (chosen.size > 2_000_000) ctx.toast('Imagem grande (mais de 2 MB): ela fica dentro do projeto. Prefira um endereço da internet.', true);
      const reader = new FileReader();
      reader.onload = () => void ctx.upsert({ op: 'attr', name: 'src', value: String(reader.result) }, { label: 'Imagem' });
      reader.readAsDataURL(chosen);
    });
    body.append(
      h(
        'section',
        { class: 'sec', 'data-section': 'image' },
        h('h3', null, 'Imagem'),
        h('img', { src: image.currentSrc || image.src, alt: '', style: 'max-width:100%;max-height:120px;border-radius:6px;display:block;margin:0 0 8px;background:var(--bg-3)' }),
        field('Endereço da imagem', input(srcEdit?.value ?? image.getAttribute('src') ?? '', (value) => void ctx.upsert({ op: 'attr', name: 'src', value }, { label: 'Imagem' }), { mono: true, testid: 'image-src' }), 'Aceita {{ variavel }}: cada cliente com a sua logo.'),
        h('div', { class: 'row' }, button('Enviar arquivo…', () => file.click(), { small: true, icon: 'upload' }), file),
        field('Texto alternativo', input(altEdit?.value ?? image.alt, (value) => void ctx.upsert({ op: 'attr', name: 'alt', value }, { label: 'Texto alternativo' }), { testid: 'image-alt' })),
      ),
    );
  }

  // link
  const anchor = element.closest('a');
  if (anchor) {
    const anchorSelector = anchor === element ? selector : selectorFor(anchor);
    const hrefEdit = ctx.project.edits.find((edit) => edit.target.selector === anchorSelector && edit.op === 'attr' && edit.name === 'href');
    const blank = anchor.getAttribute('target') === '_blank';
    body.append(
      h(
        'section',
        { class: 'sec', 'data-section': 'link' },
        h('h3', null, 'Link'),
        field('Endereço', input(hrefEdit && hrefEdit.op === 'attr' ? hrefEdit.value ?? '' : anchor.getAttribute('href') ?? '', (value) => void ctx.upsert({ op: 'attr', name: 'href', value }, { target: { selector: anchorSelector }, label: 'Link' }), { mono: true, testid: 'link-href' })),
        checkbox('Abrir em nova aba', blank, (on) => void ctx.upsert({ op: 'attr', name: 'target', value: on ? '_blank' : null }, { target: { selector: anchorSelector }, label: 'Nova aba' })),
      ),
    );
  }

  // campo de formulário
  if (/^(input|textarea|select)$/.test(element.localName)) {
    const control = element as HTMLInputElement;
    body.append(
      section(
        'Campo',
        field('Texto de exemplo (placeholder)', input(control.getAttribute('placeholder') ?? '', (value) => void ctx.upsert({ op: 'attr', name: 'placeholder', value }, { label: 'Placeholder' }), { testid: 'field-placeholder' })),
        field('Valor', input(control.value ?? '', (value) => void ctx.upsert({ op: 'attr', name: 'value', value }, { label: 'Valor' }), { testid: 'field-value' }), 'Preenche o campo (útil em demonstrações).'),
      ),
    );
  }

  // estilo
  const styleEdit = currentEdit(ctx, 'style');
  const computed = getComputedStyle(element);
  const styleGrid = h('div', { class: 'grid2' });
  for (const spec of STYLE_FIELDS) {
    const current = styleEdit?.props[spec.prop] ?? '';
    const shown = current || (spec.kind === 'color' ? '' : '');
    let control: HTMLElement;
    const save = (value: string): void => void ctx.upsert({ op: 'style', props: { [spec.prop]: value } }, { label: 'Estilo' });
    if (spec.kind === 'color') {
      const picker = h('input', { type: 'color', value: rgbToHex(current || computed.getPropertyValue(spec.prop)), 'aria-label': spec.label, 'data-testid': `style-${spec.prop}-picker`, style: 'width:38px;flex:none' });
      const text = input(shown, save, { placeholder: computed.getPropertyValue(spec.prop), mono: true, testid: `style-${spec.prop}` });
      picker.addEventListener('change', () => {
        text.value = picker.value;
        save(picker.value);
      });
      control = h('div', { class: 'row', style: 'flex-wrap:nowrap' }, picker, text);
    } else if (spec.kind === 'select') control = select(current, (spec.options ?? []).map((option) => [option, option || '—'] as const), save, `style-${spec.prop}`);
    else control = input(current, save, { placeholder: spec.placeholder ?? computed.getPropertyValue(spec.prop), mono: true, testid: `style-${spec.prop}` });
    styleGrid.append(field(spec.label, control));
  }
  const free = textarea(
    Object.entries(styleEdit?.props ?? {})
      .filter(([prop]) => !STYLE_FIELDS.some((spec) => spec.prop === prop))
      .map(([prop, value]) => `${prop}: ${value};`)
      .join('\n'),
    (value) => {
      const props: Record<string, string> = {};
      for (const line of value.split(/;|\n/)) {
        const at = line.indexOf(':');
        if (at > 0) props[line.slice(0, at).trim()] = line.slice(at + 1).trim();
      }
      void ctx.upsert({ op: 'style', props }, { label: 'Estilo' });
    },
    { rows: 3, mono: true, placeholder: 'letter-spacing: .02em;\ntransform: rotate(-2deg);', testid: 'style-free' },
  );
  body.append(
    h(
      'section',
      { class: 'sec', 'data-section': 'style' },
      h('h3', null, 'Estilo'),
      styleGrid,
      field('Mais CSS', free, 'Uma propriedade por linha. Aceita {{ }} (ex.: cor do cliente).'),
      styleEdit ? button('Limpar estilo', () => void ctx.removeEdits((edit) => edit.id === styleEdit.id, 'Limpar estilo'), { small: true, variant: 'danger' }) : null,
    ),
  );

  // classes e atributos
  const classEdit = currentEdit(ctx, 'class');
  const attrName = input('', () => undefined, { placeholder: 'nome (ex.: title, data-x)', mono: true, testid: 'attr-name' });
  const attrValue = input('', () => undefined, { placeholder: 'valor', mono: true, testid: 'attr-value' });
  body.append(
    h(
      'details',
      { class: 'sec' },
      h('summary', null, 'Classes e atributos'),
      field('Adicionar classes', input(classEdit?.add.join(' ') ?? '', (value) => void ctx.upsert({ op: 'class', add: value.split(/\s+/).filter(Boolean), remove: classEdit?.remove ?? [] }, { label: 'Classes', match: (edit) => edit.id === classEdit?.id }), { mono: true, testid: 'class-add' })),
      field('Remover classes', input(classEdit?.remove.join(' ') ?? '', (value) => void ctx.upsert({ op: 'class', add: classEdit?.add ?? [], remove: value.split(/\s+/).filter(Boolean) }, { label: 'Classes', match: (edit) => edit.id === classEdit?.id }), { mono: true, testid: 'class-remove' }), `Classes atuais: ${Array.from(element.classList).join(' ') || '(nenhuma)'}`),
      h('div', { class: 'grid2' }, attrName, attrValue),
      h(
        'div',
        { class: 'row', style: 'margin-top:6px' },
        button('Definir atributo', () => attrName.value.trim() && void ctx.upsert({ op: 'attr', name: attrName.value.trim(), value: attrValue.value }, { label: 'Atributo' }), { small: true }),
        button('Remover atributo', () => attrName.value.trim() && void ctx.upsert({ op: 'attr', name: attrName.value.trim(), value: null }, { label: 'Atributo' }), { small: true }),
      ),
    ),
  );

  // visibilidade
  const showBind = currentEdit(ctx, 'bind', (edit) => edit.kind === 'show');
  const hidden = currentEdit(ctx, 'hide');
  body.append(
    h(
      'section',
      { class: 'sec', 'data-section': 'visibility' },
      h('h3', null, 'Visibilidade'),
      h(
        'div',
        { class: 'row' },
        hidden ? button('Mostrar de novo', () => void ctx.removeEdits((edit) => edit.id === hidden.id, 'Mostrar'), { small: true, icon: 'eye' }) : button('Ocultar', () => void ctx.upsert({ op: 'hide' }, { label: 'Ocultar' }), { small: true, icon: 'eyeOff', testid: 'hide' }),
        button('Desfocar', () => void ctx.upsert({ op: 'blur', amount: 6 }, { label: 'Desfocar' }), { small: true, icon: 'blur' }),
        button('Remover da página', () => void ctx.upsert({ op: 'remove' }, { label: 'Remover' }), { small: true, icon: 'trash', variant: 'danger' }),
      ),
      field('Mostrar só quando', expressionInput(showBind?.expr ?? '', (expr) => (expr.trim() ? void ctx.upsert({ op: 'bind', kind: 'show', expr }, { label: 'Mostrar quando' }) : showBind && void ctx.removeEdits((edit) => edit.id === showBind.id)), { placeholder: 'ex.: logado == true, plano == "pro"', testid: 'show-when' }), 'Expressão com variáveis e estados. Vazio: sempre.'),
    ),
  );

  // dados dinâmicos
  const textBind = currentEdit(ctx, 'bind', (edit) => edit.kind === 'text');
  const attrBind = currentEdit(ctx, 'bind', (edit) => edit.kind === 'attr');
  const classBind = currentEdit(ctx, 'bind', (edit) => edit.kind === 'class');
  const repeat = currentEdit(ctx, 'repeat');
  const bindAttrName = input(attrBind?.name ?? (element.localName === 'img' ? 'src' : element.localName === 'a' ? 'href' : ''), () => undefined, { placeholder: 'atributo', mono: true, testid: 'bind-attr-name' });
  const bindClassName = input(classBind?.name ?? '', () => undefined, { placeholder: 'classe', mono: true, testid: 'bind-class-name' });
  const isField = /^(input|textarea|select)$/.test(element.localName);
  const valueBind = currentEdit(ctx, 'bind', (edit) => edit.kind === 'value');
  const repeatTemplate = textarea(repeat?.template ?? element.outerHTML.replace(/\sdata-wce-[a-z-]+(="[^"]*")?/g, ''), () => undefined, { rows: 4, mono: true, testid: 'repeat-template' });
  const repeatExpr = input(repeat?.expr ?? '', () => undefined, { mono: true, placeholder: 'ex.: data.produtos, filter(lista, "ativo")', testid: 'repeat-expr' });
  body.append(
    h(
      'section',
      { class: 'sec', 'data-section': 'dynamic' },
      h('h3', null, 'Dados dinâmicos'),
      field('Texto vem de', expressionInput(textBind?.expr ?? '', (expr) => (expr.trim() ? void ctx.upsert({ op: 'bind', kind: 'text', expr }, { label: 'Texto ligado' }) : textBind && void ctx.removeEdits((edit) => edit.id === textBind.id)), { placeholder: 'ex.: usuario.nome | upper', testid: 'bind-text' })),
      h('div', { class: 'field' }, h('label', null, 'Atributo ligado'), h('div', { class: 'grid2' }, bindAttrName, expressionInput(attrBind?.expr ?? '', (expr) => bindAttrName.value.trim() && void ctx.upsert({ op: 'bind', kind: 'attr', name: bindAttrName.value.trim(), expr }, { label: 'Atributo ligado' }), { placeholder: 'expressão', testid: 'bind-attr-expr' }))),
      h('div', { class: 'field' }, h('label', null, 'Classe quando'), h('div', { class: 'grid2' }, bindClassName, expressionInput(classBind?.expr ?? '', (expr) => bindClassName.value.trim() && void ctx.upsert({ op: 'bind', kind: 'class', name: bindClassName.value.trim(), expr }, { label: 'Classe ligada' }), { placeholder: 'condição', testid: 'bind-class-expr' }))),
      isField
        ? field(
            'Campo ligado à variável',
            select(valueBind?.expr ?? '', [['', '—'], ...ctx.project.variables.map((variable) => [variable.name, variable.name] as [string, string])], (name) => (name ? void ctx.upsert({ op: 'bind', kind: 'value', expr: name }, { label: 'Campo ligado' }) : valueBind && void ctx.removeEdits((edit) => edit.id === valueBind.id)), 'bind-value'),
            'O que a pessoa digita vai para a variável, e a variável preenche o campo.',
          )
        : null,
      h(
        'details',
        { open: repeat || /^(tr|li|option)$/.test(element.localName) ? true : undefined },
        h('summary', null, 'Repetir para cada item de uma lista'),
        field('Lista', repeatExpr),
        field('Modelo de cada item', repeatTemplate, 'Use {{ item.campo }}, {{ index }} e {{ position }}.'),
        h(
          'div',
          { class: 'row' },
          button('Aplicar repetição', () => {
            if (check(repeatExpr.value)) return ctx.toast(`Lista inválida: ${check(repeatExpr.value) ?? ''}`, true);
            void ctx.upsert({ op: 'repeat', expr: repeatExpr.value, template: repeatTemplate.value, itemName: 'item' }, { label: 'Repetir' });
          }, { small: true, variant: 'primary', testid: 'repeat-apply' }),
          repeat ? button('Tirar repetição', () => void ctx.removeEdits((edit) => edit.id === repeat.id, 'Tirar repetição'), { small: true, variant: 'danger' }) : null,
        ),
      ),
    ),
  );

  // eventos
  const rules = ctx.project.rules.filter((rule) => rule.trigger.selector === selector);
  body.append(
    h(
      'section',
      { class: 'sec', 'data-section': 'events' },
      h('h3', null, 'Eventos'),
      rules.length === 0 ? empty('Nenhuma regra começa neste elemento.') : rules.map((rule) => h('div', { class: 'item' }, h('div', { class: 'top' }, icon('zap', 14), h('span', { class: 'title' }, rule.name), button('Editar', () => ctx.setTab('rules', rule.id), { small: true })))),
      h(
        'div',
        { class: 'row' },
        ...(['click', 'hover', 'submit', 'change'] as const).map((type) =>
          button(
            { click: 'Ao clicar…', hover: 'Ao passar o mouse…', submit: 'Ao enviar…', change: 'Ao mudar…' }[type],
            () => {
              const id = uid('r_');
              void ctx
                .commit('Nova regra', (project) => {
                  project.rules.push({ id, name: `${{ click: 'Clique', hover: 'Mouse sobre', submit: 'Envio', change: 'Mudança' }[type]} em ${friendlyName(element)}`, enabled: true, trigger: { type, selector }, preventDefault: type === 'click' || type === 'submit', actions: [{ type: 'toast', expr: '"Funcionou!"' }] });
                })
                .then(() => ctx.setTab('rules', id));
            },
            { small: true, testid: `new-rule-${type}` },
          ),
        ),
      ),
    ),
  );

  // alterações deste elemento
  const mine = ctx.project.edits.filter((edit) => edit.target.selector === selector);
  body.append(
    section(
      `Alterações neste elemento (${mine.length})`,
      mine.length === 0 ? empty('Nenhuma ainda.') : mine.map((edit) => editItem(ctx, edit, false)),
    ),
  );
}

// ---------------------------------------------------------------- aba Inserir

// A posição escolhida vale até a pessoa trocar, mesmo quando o painel é redesenhado.
let insertPosition: InsertPosition = 'after';

function renderInsert(body: HTMLElement, ctx: EditorContext): void {
  const element = ctx.selected;
  const positionSelect = select<InsertPosition>(
    insertPosition,
    [
      ['after', 'Depois do selecionado'],
      ['before', 'Antes do selecionado'],
      ['prepend', 'Dentro, no início'],
      ['append', 'Dentro, no fim'],
    ],
    (value) => {
      insertPosition = value;
    },
    'insert-position',
  );
  body.append(scopeSection(ctx));
  body.append(
    section(
      'Onde inserir',
      element ? h('p', { class: 'hint', style: 'margin:0 0 6px' }, `Selecionado: ${friendlyName(element)} (${ctx.selector})`) : h('p', { class: 'hint', style: 'margin:0 0 6px' }, 'Nada selecionado: entra no fim da página. Clique num elemento para escolher o lugar.'),
      positionSelect,
    ),
  );
  const asks = h('div', { 'data-testid': 'insert-asks' });
  body.append(asks);
  const insert = async (component: ComponentDef, answers: Record<string, string>): Promise<void> => {
    const target = element ? { selector: ctx.selector } : { selector: 'body' };
    const where: InsertPosition = element ? insertPosition : 'append';
    const html = fillAsks(component, answers);
    const insertId = uid('e_');
    const repeater = REPEATERS[component.id];
    const page = ctx.scope.page === 'this' ? location.pathname : undefined;
    const clients = ctx.scope.clients === 'current' && ctx.engine.currentClient ? [ctx.engine.currentClient.id] : undefined;
    await ctx.commit(`Inserir ${component.name}`, (project) => {
      for (const variable of component.variables ?? []) {
        if (!project.variables.some((existing) => existing.name === variable.name)) project.variables.push({ ...variable, id: uid('v_') });
      }
      const base = { enabled: true, createdAt: Date.now(), ...(page ? { page } : {}), ...(clients ? { clients } : {}) };
      project.edits.push({ op: 'insert', position: where, html, component: component.id, id: insertId, target, label: component.name, ...base } as Edit);
      if (repeater) project.edits.push({ op: 'repeat', expr: repeater.expr, template: repeater.template, itemName: 'item', id: uid('e_'), target: { selector: `wce-insert[data-wce-edit="${insertId}"] [data-wce-repeat-slot]` }, label: `${component.name}: itens`, ...base } as Edit);
    });
    const inserted = ctx.doc.querySelector(`wce-insert[data-wce-edit="${insertId}"]`);
    const first = inserted?.firstElementChild ?? null;
    if (first) {
      // sem animação: um clique logo depois não pode cair num elemento que ainda está se movendo
      first.scrollIntoView({ block: 'nearest' });
      ctx.select(first);
      ctx.toast(`${component.name} inserido e selecionado.`);
    }
  };
  const categories = [...new Set(COMPONENTS.map((component) => component.category))];
  for (const category of categories) {
    body.append(h('div', { class: 'cat' }, category));
    body.append(
      h(
        'div',
        { class: 'lib' },
        COMPONENTS.filter((component) => component.category === category).map((component) =>
          h(
            'button',
            {
              type: 'button',
              'data-testid': `component-${component.id}`,
              onclick: () => {
                if (!component.asks || component.asks.length === 0) {
                  void insert(component, {});
                  return;
                }
                asks.replaceChildren();
                const answers: Record<string, string> = {};
                const fields = component.asks.map((ask) => {
                  answers[ask.key] = ask.value;
                  const control = ask.key === 'html' ? textarea(ask.value, (value) => (answers[ask.key] = value), { rows: 4, mono: true, live: true, testid: `ask-${ask.key}` }) : input(ask.value, (value) => (answers[ask.key] = value), { live: true, testid: `ask-${ask.key}` });
                  return field(ask.label, control);
                });
                asks.append(
                  section(
                    component.name,
                    ...fields,
                    h('div', { class: 'row' }, button('Inserir', () => void insert(component, answers).then(() => asks.replaceChildren()), { variant: 'primary', small: true, testid: 'ask-insert' }), button('Cancelar', () => asks.replaceChildren(), { small: true })),
                  ),
                );
                asks.scrollIntoView({ block: 'start' });
                (asks.querySelector('input,textarea') as HTMLElement | null)?.focus();
              },
            },
            h('b', null, component.name),
            h('small', null, component.description),
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------- aba Alterações

function replaceForm(ctx: EditorContext): HTMLElement {
  const find = input('', () => undefined, { placeholder: 'Procurar (ex.: Empresa Antiga)', testid: 'replace-find' });
  const replace = input('', () => undefined, { placeholder: 'Trocar por (aceita {{ client.name }})', testid: 'replace-with' });
  let regex = false;
  let caseSensitive = false;
  return h(
    'div',
    null,
    field('Procurar', find),
    field('Trocar por', replace),
    h('div', { class: 'row' }, checkbox('Expressão regular', false, (on) => (regex = on)), checkbox('Diferenciar maiúsculas', false, (on) => (caseSensitive = on))),
    button(
      'Substituir em todas as páginas',
      () => {
        if (!find.value) return ctx.toast('Diga o que procurar.', true);
        if (regex) {
          try {
            new RegExp(find.value);
          } catch {
            return ctx.toast('Expressão regular inválida.', true);
          }
        }
        void ctx.upsert({ op: 'replace', find: find.value, replace: replace.value, regex, caseSensitive }, { target: { selector: 'body' }, label: 'Substituir texto', match: () => false }).then(() => {
          ctx.toast('Substituição criada.');
          find.value = '';
          replace.value = '';
        });
      },
      { variant: 'primary', small: true, testid: 'replace-apply' },
    ),
  );
}

function editItem(ctx: EditorContext, edit: Edit, showSelector: boolean): HTMLElement {
  const count = edit.target.selector === 'body' ? 1 : safeQueryAll(ctx.doc, edit.target.selector).filter((element) => !element.closest('[data-wce-ui]')).length;
  const details = h('details', null, h('summary', null, 'Opções'));
  const clientsBox = h('div', { class: 'row' });
  for (const client of ctx.project.clients) {
    clientsBox.append(
      checkbox(client.name, (edit.clients ?? []).includes(client.id), (on) =>
        void ctx.commit('Clientes da alteração', (project) => {
          const target = project.edits.find((candidate) => candidate.id === edit.id);
          if (!target) return;
          const set = new Set(target.clients ?? []);
          if (on) set.add(client.id);
          else set.delete(client.id);
          target.clients = [...set];
          if (target.clients.length === 0) delete target.clients;
        }),
      ),
    );
  }
  const mutate = (label: string, change: (target: Edit) => void): void =>
    void ctx.commit(label, (project) => {
      const target = project.edits.find((candidate) => candidate.id === edit.id);
      if (target) change(target);
    });
  append(details, [
    field('Seletor', input(edit.target.selector, (value) => mutate('Seletor', (target) => (target.target = { ...target.target, selector: value })), { mono: true })),
    field('Só nas páginas (padrão de caminho)', input(edit.page ?? '', (value) => mutate('Página', (target) => (value.trim() ? (target.page = value.trim()) : delete target.page)), { mono: true, placeholder: 'vazio: todas · ex.: /clientes/*' })),
    field('Só para os clientes', clientsBox, 'Nenhum marcado: todos os clientes.'),
    field('Só quando', expressionInput(edit.when ?? '', (value) => mutate('Condição', (target) => (value.trim() ? (target.when = value.trim()) : delete target.when)), { placeholder: 'expressão' })),
    edit.op === 'insert' || edit.op === 'html' ? field('HTML', textarea(edit.op === 'insert' ? edit.html : edit.value, (value) => mutate('HTML', (target) => (target.op === 'insert' ? (target.html = value) : target.op === 'html' ? (target.value = value) : undefined)), { rows: 5, mono: true })) : null,
    edit.op === 'text' ? field('Texto', textarea(edit.value, (value) => mutate('Texto', (target) => target.op === 'text' && (target.value = value)), { rows: 2 })) : null,
    edit.op === 'repeat' ? field('Lista', input(edit.expr, (value) => mutate('Lista', (target) => target.op === 'repeat' && (target.expr = value)), { mono: true })) : null,
    edit.op === 'repeat' ? field('Modelo', textarea(edit.template, (value) => mutate('Modelo', (target) => target.op === 'repeat' && (target.template = value)), { rows: 4, mono: true })) : null,
  ]);
  return h(
    'div',
    { class: `item${edit.enabled ? '' : ' off'}`, 'data-testid': 'edit-item', 'data-edit-id': edit.id },
    h(
      'div',
      { class: 'top' },
      h('input', {
        type: 'checkbox',
        checked: edit.enabled,
        'aria-label': 'Ligada',
        title: 'Ligar ou desligar',
        onchange: (event: Event) => mutate('Ligar/desligar', (target) => (target.enabled = (event.target as HTMLInputElement).checked)),
      }),
      h('span', { class: 'title' }, edit.label ?? edit.op),
      count === 0 ? h('span', { class: 'badge warn', title: 'O seletor não acha nada nesta página' }, 'não encontrado') : null,
      button('Localizar', () => {
        const found = safeQueryAll(ctx.doc, edit.target.selector).find((element) => !element.closest('[data-wce-ui]'));
        if (found) {
          found.scrollIntoView({ block: 'center', behavior: 'smooth' });
          ctx.select(found);
        } else ctx.toast('Não está nesta página.', true);
      }, { icon: 'target', iconOnly: true, variant: 'ghost', small: true }),
      button('Excluir', () => void ctx.removeEdits((candidate) => candidate.id === edit.id), { icon: 'trash', iconOnly: true, variant: 'ghost', small: true, testid: 'edit-delete' }),
    ),
    h('div', { class: 'sub' }, describeEdit(edit)),
    showSelector ? h('div', { class: 'sub mono' }, edit.target.selector) : null,
    h('div', { class: 'row' }, ...scopeBadges(ctx, edit)),
    details,
  );
}

function renderChanges(body: HTMLElement, ctx: EditorContext): void {
  const filter = input('', () => undefined, { placeholder: 'Filtrar alterações…', live: true, testid: 'changes-filter', type: 'search' });
  const list = h('div');
  const draw = (): void => {
    list.replaceChildren();
    const text = filter.value.toLowerCase();
    const edits = ctx.project.edits.filter((edit) => !text || `${edit.label ?? ''} ${describeEdit(edit)} ${edit.target.selector}`.toLowerCase().includes(text));
    if (edits.length === 0) list.append(empty(ctx.project.edits.length === 0 ? 'Nenhuma alteração ainda. Clique num elemento da página para começar.' : 'Nada com esse filtro.'));
    for (const edit of [...edits].reverse()) list.append(editItem(ctx, edit, true));
  };
  filter.addEventListener('input', draw);
  draw();
  const cssArea = textarea(ctx.project.css, (value) => void ctx.commit('CSS do projeto', (project) => (project.css = value)), { rows: 6, mono: true, placeholder: '.minha-classe { color: {{ cor_marca }}; }', testid: 'project-css' });
  body.append(
    section('Substituir texto no site todo', replaceForm(ctx)),
    section('CSS do projeto', cssArea, h('div', { class: 'hint' }, 'Vale em todas as páginas do projeto. Aceita {{ variáveis }}.')),
    h('div', { class: 'row', style: 'margin:0 0 8px' }, filter),
    h(
      'div',
      { class: 'row', style: 'margin:0 0 8px' },
      button('Desligar todas', () => void ctx.commit('Desligar todas', (project) => project.edits.forEach((edit) => (edit.enabled = false))), { small: true }),
      button('Ligar todas', () => void ctx.commit('Ligar todas', (project) => project.edits.forEach((edit) => (edit.enabled = true))), { small: true }),
      button('Excluir as não encontradas aqui', () => {
        const missing = ctx.project.edits.filter((edit) => edit.target.selector !== 'body' && !edit.page && safeQueryAll(ctx.doc, edit.target.selector).length === 0).map((edit) => edit.id);
        if (missing.length === 0) return ctx.toast('Todas as alterações acham o seu elemento nesta página.');
        if (window.confirm(`Excluir ${missing.length} alteração(ões) cujo elemento não está nesta página? Elas podem ser de outra tela do sistema.`)) void ctx.removeEdits((edit) => missing.includes(edit.id), 'Limpar não encontradas');
      }, { small: true, variant: 'danger' }),
    ),
    list,
  );
}

export function opLabel(op: EditOp['op']): string {
  return op;
}
