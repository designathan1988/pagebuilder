// O gerenciador (página de opções da extensão): todos os projetos, os valores de cada cliente lado a lado, importar e
// exportar, o JSON do projeto, a nuvem do Webconstructor (conta, sincronizar, publicar, ligar a um projeto do editor)
// e as configurações da integração.
import { normalizeProject, newProject, uid, type Client, type Project } from '../shared/model.ts';
import { deleteProject, history, importProjects, listProjects, readSettings, saveProject, writeSettings, type Settings } from '../shared/storage.ts';
import { installSnippet, projectFile, slug, standaloneScript } from '../shared/exporters.ts';
import { toText } from '../shared/expr.ts';
import { append, button, checkbox, field, h, input, select, textarea } from '../editor/dom.ts';
import { valueControl } from '../editor/panels-logic.ts';
import { describeEdit } from '../editor/panels.ts';
import { ConflictError, builderProjects, currentUser, linkBuilderProject, listRemote, overlayEndpoint, publish, pull, push, removeRemote, signIn, signOut, workspaces, type RemoteOverlay, type Workspace } from '../cloud/cloud.ts';

type View = { kind: 'project'; id: string; tab: ProjectTab } | { kind: 'settings' } | { kind: 'cloud' } | { kind: 'welcome' };
type ProjectTab = 'clients' | 'edits' | 'logic' | 'install' | 'json' | 'versions';

let projects: Project[] = [];
let settings: Settings;
let view: View = { kind: 'welcome' };
let filter = '';

const list = document.getElementById('list') as HTMLElement;
const main = document.getElementById('main') as HTMLElement;
const sideActions = document.getElementById('side-actions') as HTMLElement;
const bottom = document.getElementById('bottom') as HTMLElement;

function toast(message: string, error = false): void {
  const element = h('div', { class: `toast${error ? ' err' : ''}`, role: 'status' }, message);
  document.body.append(element);
  setTimeout(() => element.remove(), 3500);
}

function errorText(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

function downloadText(name: string, text: string, type: string): void {
  const url = URL.createObjectURL(new Blob([text], { type }));
  const anchor = h('a', { href: url, download: name });
  anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}

async function reload(): Promise<void> {
  projects = (await listProjects()).sort((a, b) => b.updatedAt - a.updatedAt);
  settings = await readSettings();
}

async function save(project: Project, label: string): Promise<void> {
  const saved = await saveProject(project, label);
  projects = projects.map((candidate) => (candidate.id === saved.id ? saved : candidate));
  renderList();
}

function current(): Project | null {
  const shown = view;
  return shown.kind === 'project' ? (projects.find((project) => project.id === shown.id) ?? null) : null;
}

function go(next: View): void {
  view = next;
  const hash = next.kind === 'project' ? `#project=${next.id}&tab=${next.tab}` : `#${next.kind}`;
  if (location.hash !== hash) history_replace(hash);
  render();
}

function history_replace(hash: string): void {
  window.history.replaceState(null, '', hash);
}

// ---------------------------------------------------------------- barra lateral

function renderList(): void {
  list.replaceChildren();
  const search = input(filter, (value) => {
    filter = value;
    renderList();
    (list.querySelector('input') as HTMLInputElement | null)?.focus();
  }, { placeholder: 'Buscar projeto…', live: true, type: 'search', testid: 'manager-search' });
  list.append(h('div', { style: 'padding:0 8px 8px' }, search));
  const shown = projects.filter((project) => !filter || `${project.name} ${project.matches.join(' ')}`.toLowerCase().includes(filter.toLowerCase()));
  if (shown.length === 0) list.append(h('p', { class: 'empty', style: 'padding:0 10px' }, projects.length === 0 ? 'Nenhum projeto. Abra um site e clique em “Editar esta página”, ou importe um arquivo.' : 'Nada encontrado.'));
  for (const project of shown) {
    list.append(
      h(
        'button',
        { type: 'button', class: 'proj', 'aria-current': String(view.kind === 'project' && (view as { id: string }).id === project.id), 'data-testid': 'manager-project', onclick: () => go({ kind: 'project', id: project.id, tab: view.kind === 'project' ? view.tab : 'clients' }) },
        h('b', null, project.name, project.enabled ? null : h('span', { class: 'badge', style: 'margin-left:6px' }, 'desligado'), project.cloud?.published ? h('span', { class: 'badge ok', style: 'margin-left:6px' }, 'publicado') : null),
        h('span', { class: 'sub' }, project.matches.join(' · ') || 'sem endereço'),
        h('span', { class: 'sub' }, `${project.clients.length} cliente(s) · ${project.edits.length} alterações`),
      ),
    );
  }
}

function renderSide(): void {
  const file = h('input', { type: 'file', accept: '.json,application/json', style: 'display:none', 'data-testid': 'manager-import-file' });
  file.addEventListener('change', () => {
    const chosen = file.files?.[0];
    if (!chosen) return;
    void chosen
      .text()
      .then((text) => importProjects(JSON.parse(text)))
      .then(async (imported) => {
        await reload();
        renderList();
        toast(`${imported.length} projeto(s) importado(s).`);
        if (imported[0]) go({ kind: 'project', id: imported[0].id, tab: 'clients' });
      })
      .catch((error: unknown) => toast(`Não foi possível importar: ${errorText(error)}`, true));
    file.value = '';
  });
  sideActions.replaceChildren(
    button('Novo projeto', () => {
      const name = window.prompt('Nome do projeto');
      if (!name?.trim()) return;
      const pattern = window.prompt('Em quais endereços ele vale? (ex.: https://app.exemplo.com/*)', 'https://*/*') ?? '';
      void saveProject(newProject(name.trim(), pattern ? [pattern.trim()] : []), 'Projeto criado').then(async (project) => {
        await reload();
        renderList();
        go({ kind: 'project', id: project.id, tab: 'clients' });
      });
    }, { variant: 'primary', small: true, icon: 'plus', testid: 'manager-new' }),
    button('Importar', () => file.click(), { small: true, icon: 'upload' }),
    button('Exportar tudo', () => downloadText(`site-editor-${new Date().toISOString().slice(0, 10)}.json`, projectFile(projects), 'application/json'), { small: true, icon: 'download', disabled: projects.length === 0 }),
    file,
  );
  bottom.replaceChildren(
    button('Nuvem do Webconstructor', () => go({ kind: 'cloud' }), { variant: 'ghost', icon: 'cloud', pressed: view.kind === 'cloud', testid: 'manager-cloud' }),
    button('Configurações', () => go({ kind: 'settings' }), { variant: 'ghost', icon: 'settings', pressed: view.kind === 'settings', testid: 'manager-settings' }),
  );
}

// ---------------------------------------------------------------- projeto

function renderProject(project: Project, tab: ProjectTab): void {
  const mutate = (label: string, change: (target: Project) => void): void => {
    const next = JSON.parse(JSON.stringify(project)) as Project;
    change(next);
    void save(next, label).then(() => render());
  };
  const firstUrl = project.matches.map((pattern) => pattern.replace(/\*+$/, '').replace(/^\*:\/\//, 'https://').replace(/\/\*\./, '/')).find((url) => /^https?:\/\/[^*]+$/.test(url));
  main.append(
    h(
      'div',
      { class: 'row', style: 'align-items:flex-start' },
      h('div', { class: 'grow' }, h('h1', null, project.name), h('div', { class: 'muted' }, project.matches.join(' · '))),
      firstUrl ? button('Abrir e editar', () => void chrome.runtime.sendMessage({ type: 'wce:open-url-editor', url: firstUrl, projectId: project.id }), { variant: 'primary', icon: 'edit' }) : null,
      button('Duplicar', () => {
        const copy: Project = { ...(JSON.parse(JSON.stringify(project)) as Project), id: uid('p_'), name: `${project.name} (cópia)`, createdAt: Date.now() };
        delete copy.cloud;
        void saveProject(copy, 'Duplicado').then(async (saved) => {
          await reload();
          renderList();
          go({ kind: 'project', id: saved.id, tab });
        });
      }, { icon: 'copy' }),
      button('Excluir', () => {
        if (!window.confirm(`Excluir "${project.name}"? Isso não tem volta.`)) return;
        void deleteProject(project.id).then(async () => {
          await reload();
          renderList();
          go({ kind: 'welcome' });
        });
      }, { variant: 'danger', icon: 'trash' }),
    ),
  );
  main.append(
    h(
      'div',
      { class: 'card' },
      h(
        'div',
        { style: 'display:grid;grid-template-columns:1fr 2fr;gap:12px' },
        field('Nome', input(project.name, (name) => name.trim() && mutate('Nome', (target) => (target.name = name.trim())), { testid: 'm-project-name' })),
        field('Endereços (um por linha)', textarea(project.matches.join('\n'), (raw) => mutate('Endereços', (target) => (target.matches = raw.split('\n').map((line) => line.trim()).filter(Boolean))), { rows: 2, mono: true })),
      ),
      checkbox('Ligado', project.enabled, (enabled) => mutate(enabled ? 'Ligar' : 'Desligar', (target) => (target.enabled = enabled))),
    ),
  );
  const tabs: [ProjectTab, string][] = [
    ['clients', 'Clientes e valores'],
    ['edits', `Alterações (${project.edits.length})`],
    ['logic', 'Variáveis, eventos e dados'],
    ['install', 'Instalar e publicar'],
    ['json', 'JSON'],
    ['versions', 'Versões'],
  ];
  main.append(h('div', { class: 'tabs', role: 'tablist' }, tabs.map(([id, label]) => h('button', { type: 'button', role: 'tab', 'aria-selected': String(tab === id), 'data-testid': `m-tab-${id}`, onclick: () => go({ kind: 'project', id: project.id, tab: id }) }, label))));
  if (tab === 'clients') renderClientsMatrix(project, mutate);
  if (tab === 'edits') renderEdits(project, mutate);
  if (tab === 'logic') renderLogic(project);
  if (tab === 'install') void renderInstall(project);
  if (tab === 'json') renderJson(project);
  if (tab === 'versions') void renderVersions(project);
}

function renderClientsMatrix(project: Project, mutate: (label: string, change: (target: Project) => void) => void): void {
  const variables = project.variables.filter((variable) => variable.source?.kind !== 'expression');
  const card = h('div', { class: 'card' });
  card.append(
    h('div', { class: 'row', style: 'margin:0 0 10px' }, h('h2', { class: 'grow', style: 'margin:0' }, 'Clientes'), button('Novo cliente', () => {
      const name = window.prompt('Nome do cliente');
      if (name?.trim()) mutate('Novo cliente', (target) => target.clients.push({ id: uid('c_'), name: name.trim(), values: {} }));
    }, { variant: 'primary', small: true, icon: 'plus', testid: 'm-client-add' })),
    h('p', { class: 'hint', style: 'margin:0 0 10px' }, 'Cada coluna é um cliente; cada linha, uma variável. O valor em branco usa o padrão. Marque qual cliente as páginas mostram.'),
  );
  if (variables.length === 0) card.append(h('p', { class: 'empty' }, 'Este projeto ainda não tem variáveis. Crie no editor (aba Variáveis) e use {{ nome }} nos textos, imagens e estilos.'));
  const table = h('table');
  table.append(
    h(
      'thead',
      null,
      h(
        'tr',
        null,
        h('th', null, 'Variável'),
        h('th', null, 'Padrão'),
        project.clients.map((client) =>
          h(
            'th',
            null,
            h(
              'div',
              { class: 'row', style: 'flex-wrap:nowrap' },
              h('input', { type: 'radio', name: 'active', checked: project.activeClientId === client.id, 'aria-label': `Mostrar ${client.name}`, onchange: () => mutate('Cliente ativo', (target) => (target.activeClientId = client.id)) }),
              input(client.name, (name) => name.trim() && mutate('Nome do cliente', (target) => {
                const found = target.clients.find((candidate) => candidate.id === client.id);
                if (found) found.name = name.trim();
              }), { testid: 'm-client-name' }),
              project.clients.length > 1
                ? button('Excluir cliente', () => window.confirm(`Excluir ${client.name}?`) && mutate('Excluir cliente', (target) => {
                    target.clients = target.clients.filter((candidate) => candidate.id !== client.id);
                    if (target.activeClientId === client.id) target.activeClientId = target.clients[0]?.id ?? null;
                  }), { icon: 'trash', iconOnly: true, variant: 'ghost', small: true })
                : null,
            ),
          ),
        ),
      ),
    ),
  );
  const tbody = h('tbody');
  for (const variable of variables) {
    tbody.append(
      h(
        'tr',
        null,
        h('td', { class: 'mono' }, variable.name, h('div', { class: 'hint' }, variable.type)),
        h('td', { class: 'muted' }, toText(variable.default).slice(0, 80)),
        project.clients.map((client: Client) =>
          h(
            'td',
            null,
            valueControl(variable, Object.prototype.hasOwnProperty.call(client.values, variable.name) ? client.values[variable.name] : variable.default, (value) =>
              mutate('Valor do cliente', (target) => {
                const found = target.clients.find((candidate) => candidate.id === client.id);
                if (found) found.values = { ...found.values, [variable.name]: value };
              }),
              `m-value-${client.name}-${variable.name}`,
            ),
          ),
        ),
      ),
    );
  }
  table.append(tbody);
  card.append(h('div', { class: 'matrix' }, table));
  main.append(card);
}

function renderEdits(project: Project, mutate: (label: string, change: (target: Project) => void) => void): void {
  const card = h('div', { class: 'card' });
  if (project.edits.length === 0) card.append(h('p', { class: 'empty' }, 'Nenhuma alteração. Abra o site e edite.'));
  const table = h('table');
  table.append(h('thead', null, h('tr', null, h('th', null, 'Ligada'), h('th', null, 'O quê'), h('th', null, 'Onde'), h('th', null, ''))));
  const tbody = h('tbody');
  for (const edit of [...project.edits].reverse()) {
    tbody.append(
      h(
        'tr',
        null,
        h('td', null, h('input', { type: 'checkbox', checked: edit.enabled, 'aria-label': 'Ligada', onchange: (event: Event) => mutate('Ligar alteração', (target) => {
          const found = target.edits.find((candidate) => candidate.id === edit.id);
          if (found) found.enabled = (event.target as HTMLInputElement).checked;
        }) })),
        h('td', null, h('b', null, edit.label ?? edit.op), h('div', { class: 'hint' }, describeEdit(edit))),
        h('td', { class: 'mono', style: 'max-width:320px;word-break:break-all' }, edit.target.selector, edit.page ? h('div', { class: 'hint' }, `página ${edit.page}`) : null, edit.clients?.length ? h('div', { class: 'hint' }, `clientes: ${edit.clients.map((id) => project.clients.find((client) => client.id === id)?.name ?? '?').join(', ')}`) : null),
        h('td', null, button('Excluir', () => mutate('Excluir alteração', (target) => (target.edits = target.edits.filter((candidate) => candidate.id !== edit.id))), { icon: 'trash', iconOnly: true, variant: 'ghost', small: true })),
      ),
    );
  }
  table.append(tbody);
  card.append(table);
  main.append(card);
}

function renderLogic(project: Project): void {
  main.append(
    h(
      'div',
      { class: 'card' },
      h('h2', null, `Variáveis e estados (${project.variables.length})`),
      project.variables.length === 0 ? h('p', { class: 'empty' }, 'Nenhuma.') : h('table', null, h('tbody', null, project.variables.map((variable) => h('tr', null, h('td', { class: 'mono' }, variable.name), h('td', null, variable.type), h('td', { class: 'muted' }, toText(variable.default).slice(0, 80)), h('td', null, variable.persist === 'none' ? '' : variable.persist === 'local' ? 'guardada' : 'na aba'))))),
    ),
    h(
      'div',
      { class: 'card' },
      h('h2', null, `Eventos (${project.rules.length})`),
      project.rules.length === 0 ? h('p', { class: 'empty' }, 'Nenhum.') : project.rules.map((rule) => h('div', { class: 'item' }, h('b', null, rule.name), h('div', { class: 'hint' }, `${rule.trigger.type}${rule.trigger.selector ? ` em ${rule.trigger.selector}` : ''} → ${rule.actions.map((action) => action.type).join(', ') || 'sem ações'}`))),
    ),
    h(
      'div',
      { class: 'card' },
      h('h2', null, `Fontes de dados (${project.sources.length})`),
      project.sources.length === 0 ? h('p', { class: 'empty' }, 'Nenhuma.') : project.sources.map((source) => h('div', { class: 'item' }, h('b', { class: 'mono' }, `data.${source.name}`), h('div', { class: 'hint' }, source.kind === 'http' ? source.url ?? '' : source.kind.toUpperCase()))),
    ),
    h('p', { class: 'hint' }, 'Para editar, abra o site com o editor: as abas Variáveis, Eventos e Dados mostram os valores ao vivo.'),
  );
}

async function renderInstall(project: Project): Promise<void> {
  const runtime = (await chrome.runtime.sendMessage({ type: 'wce:runtime-source' })) as { ok: boolean; source?: string };
  const clientSelect = select(project.activeClientId ?? '', project.clients.map((client) => [client.id, client.name] as [string, string]), () => undefined);
  main.append(
    h(
      'div',
      { class: 'card' },
      h('h2', null, 'Instalar no site do cliente, sem a extensão'),
      h('p', { class: 'hint' }, 'O script aplica no site as mesmas alterações, variáveis, eventos e dados. Escolha o cliente e baixe um arquivo único, ou hospede o wc-runtime.js e cole o código.'),
      field('Cliente', clientSelect),
      h(
        'div',
        { class: 'row' },
        button('Baixar script único (.js)', () => runtime.ok && runtime.source && downloadText(`${slug(project.name)}-${slug(project.clients.find((client) => client.id === clientSelect.value)?.name ?? 'cliente')}.wce.js`, standaloneScript(project, runtime.source, clientSelect.value), 'text/javascript'), { variant: 'primary', icon: 'download', testid: 'm-download-script' }),
        button('Baixar wc-runtime.js', () => runtime.ok && runtime.source && downloadText('wc-runtime.js', runtime.source, 'text/javascript'), { icon: 'download' }),
        button('Copiar código com o projeto embutido', () => void navigator.clipboard.writeText(installSnippet(project, { runtimeUrl: 'https://SEU-SITE/wc-runtime.js', clientId: clientSelect.value })).then(() => toast('Código copiado.')), { icon: 'copy' }),
      ),
    ),
  );
  // nuvem
  const cloudCard = h('div', { class: 'card', 'data-testid': 'm-cloud-card' }, h('h2', null, 'Nuvem do Webconstructor'));
  main.append(cloudCard);
  const user = await currentUser().catch(() => null);
  if (!settings.supabaseUrl || !user) {
    cloudCard.append(h('p', { class: 'hint' }, 'Entre na sua conta do Webconstructor para guardar este projeto na nuvem, publicar (o script busca a versão mais nova pela chave) e ligar ao projeto do editor.'), button('Abrir a nuvem', () => go({ kind: 'cloud' }), { icon: 'cloud' }));
    return;
  }
  let spaces: Workspace[] = [];
  try {
    spaces = await workspaces();
  } catch (error) {
    cloudCard.append(h('p', { class: 'err' }, errorText(error)));
    return;
  }
  const workspaceSelect = select(project.cloud?.workspaceId || spaces[0]?.id || '', spaces.map((space) => [space.id, `${space.name} (${space.role})`] as [string, string]), () => undefined, 'm-workspace');
  const status = h('p', { class: 'hint', role: 'status' }, project.cloud?.syncedAt ? `Sincronizado em ${new Date(project.cloud.syncedAt).toLocaleString('pt-BR')}` : 'Ainda não está na nuvem.');
  const doPush = async (force = false): Promise<void> => {
    try {
      const saved = await push(project, workspaceSelect.value, { force });
      projects = projects.map((candidate) => (candidate.id === saved.id ? saved : candidate));
      toast('Projeto enviado para a nuvem.');
      render();
    } catch (error) {
      if (error instanceof ConflictError) {
        if (window.confirm(`${error.message}\n\nOK: substituir a versão da nuvem pela deste navegador.\nCancelar: não enviar (baixe a da nuvem na página Nuvem).`)) await doPush(true);
      } else toast(errorText(error), true);
    }
  };
  cloudCard.append(field('Espaço de trabalho', workspaceSelect), status, h('div', { class: 'row' }, button(project.cloud?.id ? 'Enviar alterações' : 'Enviar para a nuvem', () => void doPush(), { variant: 'primary', icon: 'upload', testid: 'm-push' })));
  if (project.cloud?.id) {
    const endpoint = await overlayEndpoint();
    const runtimeUrl = settings.builderUrl ? `${settings.builderUrl.replace(/\/$/, '')}/painel/wc-runtime.js` : 'https://SEU-APP/painel/wc-runtime.js';
    const builderSelect = select(project.cloud.builderProjectId ?? '', [['', '— nenhum —']], (id) => void linkBuilderProject(project, id || null).then((saved) => {
      projects = projects.map((candidate) => (candidate.id === saved.id ? saved : candidate));
      toast('Ligação salva.');
    }, (error: unknown) => toast(errorText(error), true)));
    void builderProjects(project.cloud.workspaceId).then((items) => {
      for (const item of items) builderSelect.append(h('option', { value: item.id, selected: item.id === project.cloud?.builderProjectId }, item.name));
    });
    append(cloudCard, [
      h('hr', { style: 'border:0;border-top:1px solid var(--line);margin:14px 0' }),
      field('Projeto do editor ligado', builderSelect, 'Liga esta personalização a um site do Webconstructor (aparece no painel, em Personalizações).'),
      checkbox('Publicado (o script dos sites busca esta versão pela chave)', project.cloud.published === true, (on) => void publish(project, on).then((saved) => {
        projects = projects.map((candidate) => (candidate.id === saved.id ? saved : candidate));
        toast(on ? 'Publicado.' : 'Despublicado.');
        render();
      }, (error: unknown) => toast(errorText(error), true))),
      project.cloud.published && project.cloud.publicKey
        ? h(
            'div',
            null,
            h('p', { class: 'hint' }, 'Cole no site (antes do </body>). Mudanças enviadas à nuvem chegam ao site em até 1 minuto.'),
            h('div', { class: 'value', 'data-testid': 'm-cloud-snippet' }, installSnippet(project, { runtimeUrl, cloud: { endpoint, key: project.cloud.publicKey }, clientId: clientSelect.value })),
            button('Copiar', () => void navigator.clipboard.writeText(installSnippet(project, { runtimeUrl, cloud: { endpoint, key: project.cloud?.publicKey ?? '' }, clientId: clientSelect.value })).then(() => toast('Código copiado.')), { small: true, icon: 'copy' }),
          )
        : null,
    ]);
  }
}

function renderJson(project: Project): void {
  const area = textarea(JSON.stringify(project, null, 2), () => undefined, { rows: 28, mono: true, testid: 'm-json' });
  const said = h('p', { class: 'hint', role: 'status' });
  main.append(
    h(
      'div',
      { class: 'card' },
      h('p', { class: 'hint' }, 'O projeto inteiro. Edite com cuidado: ao salvar, o formato é conferido.'),
      area,
      h(
        'div',
        { class: 'row', style: 'margin-top:8px' },
        button('Salvar JSON', () => {
          try {
            const parsed = normalizeProject(JSON.parse(area.value));
            if (parsed.id !== project.id) throw new Error('O id do projeto não pode mudar.');
            void save(parsed, 'JSON editado').then(() => {
              said.textContent = 'Salvo.';
              said.className = 'ok';
            });
          } catch (error) {
            said.textContent = errorText(error);
            said.className = 'err';
          }
        }, { variant: 'primary', testid: 'm-json-save' }),
        button('Baixar', () => downloadText(`${slug(project.name)}.wce.json`, projectFile([project]), 'application/json'), { icon: 'download' }),
      ),
      said,
    ),
  );
}

async function renderVersions(project: Project): Promise<void> {
  const card = h('div', { class: 'card' });
  main.append(card);
  const list = await history(project.id);
  if (list.length === 0) card.append(h('p', { class: 'empty' }, 'Nenhuma versão.'));
  for (const revision of list) {
    card.append(
      h(
        'div',
        { class: 'item row' },
        h('div', { class: 'grow' }, h('b', null, revision.label), h('div', { class: 'hint' }, `${new Date(revision.at).toLocaleString('pt-BR')} · ${revision.project.edits.length} alterações`)),
        button('Restaurar', () => window.confirm('Restaurar esta versão? A atual vira uma versão no histórico.') && void save({ ...revision.project, id: project.id }, 'Restaurado').then(() => render()), { small: true }),
      ),
    );
  }
}

// ---------------------------------------------------------------- nuvem

async function renderCloud(): Promise<void> {
  main.append(h('h1', null, 'Nuvem do Webconstructor'), h('p', { class: 'muted' }, 'A mesma conta do editor e do painel. Os projetos ficam no seu espaço de trabalho, com as permissões da equipe.'));
  if (!settings.supabaseUrl || !settings.supabaseKey) {
    main.append(h('div', { class: 'card' }, h('p', null, 'Primeiro, informe o endereço e a chave pública do Supabase do seu Webconstructor.'), button('Ir às configurações', () => go({ kind: 'settings' }), { variant: 'primary' })));
    return;
  }
  const card = h('div', { class: 'card' });
  main.append(card);
  const user = await currentUser().catch(() => null);
  if (!user) {
    const email = h('input', { type: 'email', autocomplete: 'username', 'data-testid': 'm-email' });
    const password = h('input', { type: 'password', autocomplete: 'current-password', 'data-testid': 'm-password' });
    const said = h('p', { class: 'err', role: 'alert' });
    const form = h('form', null, field('E-mail', email), field('Senha', password), button('Entrar', () => form.requestSubmit(), { variant: 'primary' }), said);
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      void signIn(email.value.trim(), password.value).then(() => render(), (error: unknown) => (said.textContent = errorText(error)));
    });
    card.append(h('h2', null, 'Entrar'), form, h('p', { class: 'hint' }, 'Ainda não tem conta? Crie no painel do Webconstructor.'));
    return;
  }
  card.append(h('div', { class: 'row' }, h('span', { class: 'grow' }, 'Conectado como ', h('b', null, user.email)), button('Sair', () => void signOut().then(() => render()), { small: true })));
  let spaces: Workspace[];
  try {
    spaces = await workspaces();
  } catch (error) {
    card.append(h('p', { class: 'err' }, errorText(error)));
    return;
  }
  for (const space of spaces) {
    const box = h('div', { class: 'card' }, h('h2', null, space.name), h('p', { class: 'hint' }, 'Carregando…'));
    main.append(box);
    let remote: RemoteOverlay[] = [];
    try {
      remote = await listRemote(space.id);
    } catch (error) {
      box.replaceChildren(h('h2', null, space.name), h('p', { class: 'err' }, errorText(error)));
      continue;
    }
    box.replaceChildren(h('h2', null, space.name));
    if (remote.length === 0) box.append(h('p', { class: 'empty' }, 'Nenhum projeto da extensão neste espaço ainda.'));
    for (const row of remote) {
      const local = projects.find((project) => project.id === row.local_id);
      box.append(
        h(
          'div',
          { class: 'item row' },
          h('div', { class: 'grow' }, h('b', null, row.name), row.published ? h('span', { class: 'badge ok', style: 'margin-left:6px' }, 'publicado') : null, h('div', { class: 'hint' }, `Na nuvem: ${new Date(row.updated_at).toLocaleString('pt-BR')}${local ? ` · neste navegador: ${new Date(local.updatedAt).toLocaleString('pt-BR')}` : ' · não está neste navegador'}`)),
          button(local ? 'Baixar a versão da nuvem' : 'Baixar', () => (!local || window.confirm('Substituir a versão deste navegador pela da nuvem?')) && void pull(row.id).then(async (project) => {
            await reload();
            renderList();
            toast('Projeto baixado.');
            go({ kind: 'project', id: project.id, tab: 'clients' });
          }, (error: unknown) => toast(errorText(error), true)), { small: true, icon: 'download' }),
          space.role === 'owner' || space.role === 'admin' ? button('Excluir da nuvem', () => window.confirm(`Excluir "${row.name}" da nuvem? O site que usa a chave para de receber as personalizações.`) && void removeRemote(row.id).then(() => render(), (error: unknown) => toast(errorText(error), true)), { small: true, variant: 'danger', icon: 'trash' }) : null,
        ),
      );
    }
    const pending = projects.filter((project) => !remote.some((row) => row.local_id === project.id));
    if (pending.length > 0 && space.role !== 'viewer') {
      box.append(h('details', null, h('summary', null, `Enviar projetos deste navegador (${pending.length})`), ...pending.map((project) => h('div', { class: 'item row' }, h('span', { class: 'grow' }, project.name), button('Enviar', () => void push(project, space.id).then(async () => {
        await reload();
        render();
        toast('Enviado.');
      }, (error: unknown) => toast(errorText(error), true)), { small: true, icon: 'upload' })))));
    }
  }
}

// ---------------------------------------------------------------- configurações

function renderSettings(): void {
  const set = (patch: Partial<Settings>): void =>
    void writeSettings(patch).then((next) => {
      settings = next;
      toast('Configuração salva.');
    });
  main.append(
    h('h1', null, 'Configurações'),
    h(
      'div',
      { class: 'card' },
      h('h2', null, 'Webconstructor'),
      field('Endereço do editor (app)', input(settings.builderUrl, (builderUrl) => set({ builderUrl: builderUrl.trim() }), { placeholder: 'https://app.seudominio.com.br', testid: 'm-builder-url' }), 'O editor e o painel nesse endereço falam com a extensão (ponte) sem perguntar.'),
      field('Supabase: endereço do projeto', input(settings.supabaseUrl, (supabaseUrl) => set({ supabaseUrl: supabaseUrl.trim() }), { placeholder: 'https://<ref>.supabase.co', mono: true, testid: 'm-supabase-url' })),
      field('Supabase: chave pública (publishable)', input(settings.supabaseKey, (supabaseKey) => set({ supabaseKey: supabaseKey.trim() }), { placeholder: 'sb_publishable_…', mono: true, testid: 'm-supabase-key' }), 'A mesma VITE_SUPABASE_PUBLISHABLE_KEY do editor e do painel. Nunca use a chave secreta aqui.'),
    ),
    h(
      'div',
      { class: 'card' },
      h('h2', null, 'Sites autorizados a falar com a extensão'),
      settings.allowedOrigins.length === 0 ? h('p', { class: 'empty' }, 'Nenhum além do editor configurado acima.') : null,
      ...settings.allowedOrigins.map((origin) => h('div', { class: 'item row' }, h('span', { class: 'grow mono' }, origin), button('Remover', () => {
        set({ allowedOrigins: settings.allowedOrigins.filter((candidate) => candidate !== origin) });
        settings = { ...settings, allowedOrigins: settings.allowedOrigins.filter((candidate) => candidate !== origin) };
        render();
      }, { small: true, variant: 'danger' }))),
    ),
    h(
      'div',
      { class: 'card' },
      h('h2', null, 'Builder Companion'),
      h('p', { class: 'hint' }, 'O Companion (npm run companion) recebe a página para o editor abrir com Arquivo › Abrir um endereço. Ele mostra a porta e o token ao iniciar.'),
      h('div', { style: 'display:grid;grid-template-columns:120px 1fr;gap:10px' }, field('Porta', input(String(settings.companionPort), (raw) => set({ companionPort: Number(raw) || 5410 }), { type: 'number' })), field('Token', input(settings.companionToken, (companionToken) => set({ companionToken: companionToken.trim() }), { mono: true }))),
    ),
    h(
      'div',
      { class: 'card' },
      h('h2', null, 'Scripts próprios'),
      h('p', { class: 'hint' }, 'As ações “Script próprio” usam a API userScripts do navegador. No Chrome 138 ou mais novo, ative “Permitir scripts de usuário” nos detalhes da extensão (chrome://extensions › Detalhes). No Firefox, conceda a permissão abaixo.'),
      button('Pedir a permissão (Firefox)', () => void chrome.permissions.request({ permissions: ['userScripts' as chrome.runtime.ManifestPermissions] }).then((granted) => toast(granted ? 'Permissão concedida.' : 'Permissão negada.', !granted)).catch((error: unknown) => toast(errorText(error), true)), { small: true }),
    ),
  );
}

// ---------------------------------------------------------------- roteamento

function render(): void {
  renderSide();
  renderList();
  main.replaceChildren();
  if (view.kind === 'project') {
    const project = current();
    if (project) renderProject(project, view.tab);
    else view = { kind: 'welcome' };
  }
  if (view.kind === 'settings') renderSettings();
  if (view.kind === 'cloud') void renderCloud();
  if (view.kind === 'welcome') {
    main.append(
      h('h1', null, 'Site Editor'),
      h('p', { class: 'muted' }, 'Edite qualquer site, sistema ou aplicação e entregue a cada cliente o seu conteúdo.'),
      h(
        'div',
        { class: 'card' },
        h('h2', null, 'Como usar'),
        h(
          'ol',
          null,
          h('li', null, 'Abra o site ou sistema e clique no ícone da extensão › ', h('b', null, 'Editar esta página'), ' (ou Alt+Shift+E, ou botão direito › Editar este elemento).'),
          h('li', null, 'Clique num elemento para editar; duplo clique edita o texto no lugar. Insira componentes, crie variáveis, eventos e fontes de dados.'),
          h('li', null, 'Crie um cliente para cada entrega e dê a cada um os seus valores (nome, logo, cores, preços). A aba ', h('b', null, 'Clientes e valores'), ' daqui mostra todos lado a lado.'),
          h('li', null, 'Para o cliente final, instale o script no site (sem extensão) ou publique pela nuvem do Webconstructor.'),
        ),
      ),
    );
  }
}

function readHash(): void {
  const params = new URLSearchParams(location.hash.replace(/^#/, ''));
  const id = params.get('project');
  if (id) view = { kind: 'project', id, tab: (params.get('tab') as ProjectTab | null) ?? 'clients' };
  else if (location.hash === '#settings') view = { kind: 'settings' };
  else if (location.hash === '#cloud') view = { kind: 'cloud' };
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (Object.keys(changes).some((key) => key.startsWith('wce:project:') || key === 'wce:index')) {
    // não redesenha com um campo em foco: a gravação veio do próprio gerenciador ou do editor em outra aba
    void reload().then(() => {
      renderList();
      if (!(document.activeElement instanceof HTMLInputElement || document.activeElement instanceof HTMLTextAreaElement)) render();
    });
  }
});

void reload().then(() => {
  readHash();
  render();
});
