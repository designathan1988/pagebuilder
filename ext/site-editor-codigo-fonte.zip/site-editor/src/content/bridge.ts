// A ponte com o Webconstructor (o editor e o painel) e com qualquer aplicação que a pessoa autorizar: a página manda
// window.postMessage({ wce: 'request', id, action, payload }) e recebe { wce: 'response', id, ok, result | error }.
// Funciona igual no Chrome e no Firefox (externally_connectable não existe no Firefox e exige domínios fixos).
//
// Só origens autorizadas recebem dados. Uma origem nova pede 'pair': a extensão pergunta à pessoa, na própria página,
// e grava a resposta (Settings.allowedOrigins). O 'ping' responde a qualquer origem só que a extensão existe e se a
// origem já está autorizada, sem nenhum dado.
import type { ContentApi } from './content.ts';
import { getProject, importProjects, readIndex, readSettings, writeSettings } from '../shared/storage.ts';
import { normalizeProject } from '../shared/model.ts';

export const BRIDGE_VERSION = 1;

interface Request {
  readonly wce: 'request';
  readonly id: string;
  readonly action: string;
  readonly payload?: Record<string, unknown>;
}

function isRequest(data: unknown): data is Request {
  return typeof data === 'object' && data !== null && (data as Request).wce === 'request' && typeof (data as Request).id === 'string' && typeof (data as Request).action === 'string';
}

async function allowed(origin: string): Promise<boolean> {
  const settings = await readSettings();
  const builder = (() => {
    try {
      return settings.builderUrl ? new URL(settings.builderUrl).origin : '';
    } catch {
      return '';
    }
  })();
  return origin === builder || settings.allowedOrigins.includes(origin);
}

function askToPair(origin: string): Promise<boolean> {
  return new Promise((resolve) => {
    const host = document.createElement('wce-pair');
    host.setAttribute('data-wce-ui', 'pair');
    const root = host.attachShadow({ mode: 'closed' });
    root.innerHTML = `<style>
      .b{position:fixed;inset:0;z-index:2147483647;background:rgba(15,23,42,.5);display:flex;align-items:center;justify-content:center;font:14px/1.5 system-ui,sans-serif}
      .d{background:#fff;color:#111827;border-radius:14px;padding:20px;max-width:420px;box-shadow:0 24px 64px rgba(0,0,0,.3)}
      h2{margin:0 0 8px;font-size:17px}p{margin:0 0 16px;color:#374151}code{background:#f3f4f6;padding:2px 6px;border-radius:6px;word-break:break-all}
      .r{display:flex;gap:8px;justify-content:flex-end}button{font:inherit;padding:8px 14px;border-radius:8px;border:1px solid #d1d5db;background:#fff;cursor:pointer}
      button.y{background:#2563eb;border-color:#2563eb;color:#fff}</style>
      <div class="b"><div class="d" role="dialog" aria-modal="true" aria-labelledby="t"><h2 id="t">Conectar ao Site Editor?</h2>
      <p><code></code> quer ler e gravar as suas personalizações do Site Editor. Só permita se for o seu Webconstructor ou um sistema seu.</p>
      <div class="r"><button type="button" class="n">Não permitir</button><button type="button" class="y">Permitir</button></div></div></div>`;
    const code = root.querySelector('code');
    if (code) code.textContent = origin;
    const done = (answer: boolean): void => {
      host.remove();
      resolve(answer);
    };
    // só um clique de verdade da pessoa vale: a página não consegue autorizar a si mesma
    root.querySelector('.y')?.addEventListener('click', (event) => event.isTrusted && done(true));
    root.querySelector('.n')?.addEventListener('click', (event) => event.isTrusted && done(false));
    document.documentElement.appendChild(host);
    (root.querySelector('.y') as HTMLButtonElement | null)?.focus();
  });
}

async function handle(api: ContentApi, request: Request, origin: string): Promise<unknown> {
  if (request.action === 'ping') return { installed: true, version: BRIDGE_VERSION, paired: await allowed(origin) };
  if (request.action === 'pair') {
    if (await allowed(origin)) return { paired: true };
    const yes = await askToPair(origin);
    if (yes) {
      const settings = await readSettings();
      await writeSettings({ allowedOrigins: [...new Set([...settings.allowedOrigins, origin])] });
    }
    return { paired: yes };
  }
  if (!(await allowed(origin))) throw new Error('not_paired');
  const payload = request.payload ?? {};
  switch (request.action) {
    case 'list':
      return readIndex();
    case 'get': {
      const project = await getProject(String(payload.id ?? ''));
      if (!project) throw new Error('not_found');
      return project;
    }
    case 'save': {
      const project = normalizeProject(payload.project);
      const [saved] = await importProjects(project);
      return saved;
    }
    case 'open': {
      // abre um endereço em nova aba com o editor da extensão (o service worker cuida da aba)
      return chrome.runtime.sendMessage({ type: 'wce:open-url-editor', url: String(payload.url ?? ''), projectId: payload.projectId });
    }
    case 'apply-here': {
      // aplica um projeto nesta página sem gravar (prévia vinda do painel)
      const project = normalizeProject(payload.project);
      const engine = await api.engineFor(project);
      await engine.update(project, typeof payload.clientId === 'string' ? payload.clientId : project.activeClientId);
      return { ok: true };
    }
    default:
      throw new Error('unknown_action');
  }
}

export function installBridge(api: ContentApi): void {
  if (window !== window.top) return;
  window.addEventListener('message', (event: MessageEvent) => {
    if (event.source !== window || !isRequest(event.data)) return;
    const request = event.data;
    const origin = event.origin || location.origin;
    void handle(api, request, origin).then(
      (result) => window.postMessage({ wce: 'response', id: request.id, ok: true, result }, origin),
      (error: unknown) => window.postMessage({ wce: 'response', id: request.id, ok: false, error: error instanceof Error ? error.message : String(error) }, origin),
    );
  });
  // um sinal para a página saber que a ponte existe sem esperar um ping
  document.documentElement.setAttribute('data-wce-bridge', String(BRIDGE_VERSION));
}
