// O script de conteúdo: roda em toda página (document_start, todos os quadros), acha os projetos cujos padrões
// valem para o endereço e aplica cada um com o motor. O editor visual não vem aqui: o service worker o injeta sob
// demanda (editor.js), no mesmo mundo isolado, e ele usa a API que este arquivo expõe em globalThis.__wce.
import { Engine, type Host } from '../engine/engine.ts';
import { activeClient, type Project } from '../shared/model.ts';
import { isProjectKey, loadPersisted, projectsFor, savePersisted } from '../shared/storage.ts';
import { installBridge } from './bridge.ts';

export interface ContentApi {
  engines: Map<string, Engine>;
  host: Host;
  // o editor aberto: enquanto ele grava, as mudanças no armazenamento que ele mesmo fez não são reaplicadas aqui
  editorOwns: Set<string>;
  lastContextTarget: Element | null;
  clientOverride: Map<string, string>;
  refresh(): Promise<void>;
  engineFor(project: Project): Promise<Engine>;
  errors: { at: number; where: string; message: string }[];
  editor?: { open(projectId?: string, options?: { create?: boolean; select?: Element | null }): Promise<void>; close(): void; isOpen(): boolean };
}

declare global {
  // eslint-disable-next-line no-var
  var __wce: ContentApi | undefined;
}

const SESSION_PREFIX = 'wce:session:';

function makeHost(): Host {
  return {
    async fetchText(request) {
      const answer = (await chrome.runtime.sendMessage({ type: 'wce:fetch', request })) as { ok: boolean; status: number; text: string; error?: string } | undefined;
      if (!answer) throw new Error('a extensão não respondeu');
      if (answer.error) throw new Error(answer.error);
      return answer;
    },
    async loadPersisted(scope, key) {
      if (scope === 'local') return loadPersisted(key);
      try {
        return JSON.parse(sessionStorage.getItem(SESSION_PREFIX + key) ?? '{}') as Record<string, unknown>;
      } catch {
        return {};
      }
    },
    savePersisted(scope, key, values) {
      if (scope === 'local') void savePersisted(key, values);
      else {
        try {
          sessionStorage.setItem(SESSION_PREFIX + key, JSON.stringify(values));
        } catch {
          // a página bloqueia o sessionStorage (sandbox): o valor vale só enquanto a página estiver aberta
        }
      }
    },
    async runScript(code, scope) {
      const answer = (await chrome.runtime.sendMessage({ type: 'wce:script', code, scope })) as { ok: boolean; result?: unknown; error?: string } | undefined;
      if (!answer?.ok) throw new Error(answer?.error ?? 'o script não rodou');
      return answer.result;
    },
  };
}

// ?wce_client=<id ou nome> escolhe o cliente nesta aba (o link de demonstração de um cliente).
function readClientOverride(project: Project): string | null {
  try {
    const wanted = new URLSearchParams(location.search).get('wce_client');
    const key = `${SESSION_PREFIX}client:${project.id}`;
    if (wanted) {
      const client = project.clients.find((candidate) => candidate.id === wanted || candidate.name.toLowerCase() === wanted.toLowerCase());
      if (client) {
        sessionStorage.setItem(key, client.id);
        return client.id;
      }
    }
    return sessionStorage.getItem(key);
  } catch {
    return null;
  }
}

function boot(): ContentApi {
  const host = makeHost();
  const api: ContentApi = {
    engines: new Map(),
    host,
    editorOwns: new Set(),
    lastContextTarget: null,
    clientOverride: new Map(),
    errors: [],
    async engineFor(project) {
      const existing = api.engines.get(project.id);
      if (existing) return existing;
      const override = readClientOverride(project);
      if (override) api.clientOverride.set(project.id, override);
      const engine = new Engine(document, project, api.clientOverride.get(project.id) ?? project.activeClientId, host, {
        onError: (where, message) => {
          api.errors.unshift({ at: Date.now(), where, message });
          api.errors.length = Math.min(api.errors.length, 50);
          console.warn('[Site Editor]', where, message);
        },
      });
      api.engines.set(project.id, engine);
      await engine.start();
      return engine;
    },
    async refresh() {
      const projects = await projectsFor(location.href);
      const wanted = new Set(projects.map((project) => project.id));
      for (const [id, engine] of api.engines) {
        if (!wanted.has(id) && !api.editorOwns.has(id)) {
          engine.stop();
          api.engines.delete(id);
        }
      }
      for (const project of projects) {
        if (api.editorOwns.has(project.id)) continue;
        const engine = api.engines.get(project.id);
        if (!engine) await api.engineFor(project);
        else if (engine.currentProject.updatedAt !== project.updatedAt || engine.currentProject.activeClientId !== project.activeClientId) {
          const client = api.clientOverride.get(project.id) ?? activeClient(project)?.id ?? null;
          await engine.update(project, client);
        }
      }
    },
  };
  return api;
}

if (!globalThis.__wce) {
  const api = boot();
  globalThis.__wce = api;
  void api.refresh();

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (Object.keys(changes).some(isProjectKey)) void api.refresh();
  });

  document.addEventListener(
    'contextmenu',
    (event) => {
      api.lastContextTarget = event.target instanceof Element ? event.target : null;
    },
    true,
  );

  chrome.runtime.onMessage.addListener((message: { type?: string; projectId?: string; clientId?: string; enabled?: boolean }, _sender, respond) => {
    if (window !== window.top && message.type !== 'wce:frame-status') return false;
    switch (message.type) {
      case 'wce:status': {
        respond({
          url: location.href,
          title: document.title,
          editing: api.editor?.isOpen() ?? false,
          editorLoaded: api.editor !== undefined,
          running: Array.from(api.engines.values()).map((engine) => ({ id: engine.currentProject.id, client: engine.currentClient?.id ?? null })),
          errors: api.errors.slice(0, 10),
        });
        return false;
      }
      case 'wce:client': {
        const engine = api.engines.get(message.projectId ?? '');
        if (engine && message.clientId) {
          api.clientOverride.set(engine.currentProject.id, message.clientId);
          try {
            sessionStorage.setItem(`${SESSION_PREFIX}client:${engine.currentProject.id}`, message.clientId);
          } catch {
            // sem sessionStorage: a escolha vale até recarregar
          }
          void engine.update(engine.currentProject, message.clientId).then(() => respond({ ok: true }));
          return true;
        }
        respond({ ok: false });
        return false;
      }
      case 'wce:preview-original': {
        for (const engine of api.engines.values()) {
          if (message.enabled) engine.suspend();
          else engine.resume();
        }
        respond({ ok: true });
        return false;
      }
      case 'wce:open-editor': {
        if (!api.editor) {
          respond({ ok: false, needsEditor: true });
          return false;
        }
        void api.editor.open(message.projectId, { create: message.projectId === undefined, select: (message as { useContext?: boolean }).useContext ? api.lastContextTarget : null }).then(() => respond({ ok: true }));
        return true;
      }
      case 'wce:close-editor':
        api.editor?.close();
        respond({ ok: true });
        return false;
      default:
        return false;
    }
  });

  installBridge(api);
}
