// A nuvem do Webconstructor (Supabase): a mesma conta do editor e do painel. Guarda os projetos da extensão na tabela
// site_overlays (saas/supabase/migrations/20261021000200_site_overlays.sql), com o RLS de membros do workspace, e
// publica um projeto com uma chave pública que o wc-runtime.js usa na função overlay.
// A sessão fica no chrome.storage.local (adaptador de armazenamento do supabase-js: supabase.com/docs/reference/javascript/initializing).
import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import { normalizeProject, type Project } from '../shared/model.ts';
import { readSettings, saveProject } from '../shared/storage.ts';

const storage = {
  async getItem(key: string): Promise<string | null> {
    const stored = await chrome.storage.local.get(`wce:auth:${key}`);
    return (stored[`wce:auth:${key}`] as string | undefined) ?? null;
  },
  async setItem(key: string, value: string): Promise<void> {
    await chrome.storage.local.set({ [`wce:auth:${key}`]: value });
  },
  async removeItem(key: string): Promise<void> {
    await chrome.storage.local.remove(`wce:auth:${key}`);
  },
};

let cached: { url: string; key: string; client: SupabaseClient } | null = null;

export async function cloud(): Promise<SupabaseClient | null> {
  const settings = await readSettings();
  if (!settings.supabaseUrl || !settings.supabaseKey) return null;
  if (cached && cached.url === settings.supabaseUrl && cached.key === settings.supabaseKey) return cached.client;
  const client = createClient(settings.supabaseUrl, settings.supabaseKey, { auth: { storage, persistSession: true, autoRefreshToken: true, detectSessionInUrl: false } });
  cached = { url: settings.supabaseUrl, key: settings.supabaseKey, client };
  return client;
}

async function need(): Promise<SupabaseClient> {
  const client = await cloud();
  if (!client) throw new Error('Configure o endereço e a chave pública do Supabase nas configurações.');
  return client;
}

export interface Workspace {
  readonly id: string;
  readonly name: string;
  readonly role: string;
}

export interface RemoteOverlay {
  readonly id: string;
  readonly workspace_id: string;
  readonly project_id: string | null;
  readonly local_id: string;
  readonly name: string;
  readonly published: boolean;
  readonly public_key: string | null;
  readonly updated_at: string;
  readonly spec?: unknown;
}

export async function currentUser(): Promise<{ email: string; id: string } | null> {
  const client = await cloud();
  if (!client) return null;
  const { data } = await client.auth.getSession();
  const user = data.session?.user;
  return user ? { email: user.email ?? '', id: user.id } : null;
}

export async function signIn(email: string, password: string): Promise<void> {
  const { error } = await (await need()).auth.signInWithPassword({ email, password });
  if (error) throw new Error(error.message === 'Invalid login credentials' ? 'E-mail ou senha incorretos.' : error.message);
}

export async function signOut(): Promise<void> {
  await (await need()).auth.signOut();
}

export async function workspaces(): Promise<Workspace[]> {
  const client = await need();
  const user = await currentUser();
  if (!user) throw new Error('Entre na sua conta primeiro.');
  const { data, error } = await client.from('workspace_members').select('role, workspaces(id, name)').eq('user_id', user.id);
  if (error) throw new Error(error.message);
  return (data ?? []).flatMap((row) => {
    const ws = row.workspaces as unknown as { id: string; name: string } | null;
    return ws ? [{ id: ws.id, name: ws.name, role: String(row.role) }] : [];
  });
}

export async function builderProjects(workspaceId: string): Promise<{ id: string; name: string }[]> {
  const { data, error } = await (await need()).from('projects').select('id, name').eq('workspace_id', workspaceId).order('updated_at', { ascending: false });
  if (error) throw new Error(error.message);
  return data ?? [];
}

export async function listRemote(workspaceId: string): Promise<RemoteOverlay[]> {
  const { data, error } = await (await need()).from('site_overlays').select('id, workspace_id, project_id, local_id, name, published, public_key, updated_at').eq('workspace_id', workspaceId).order('updated_at', { ascending: false });
  if (error) throw new Error(error.message);
  return (data ?? []) as RemoteOverlay[];
}

export class ConflictError extends Error {
  constructor(readonly remoteUpdatedAt: string) {
    super('O projeto foi alterado na nuvem depois da sua última sincronização.');
  }
}

// Envia o projeto. Se a nuvem tem uma versão mais nova que a última sincronizada, recusa (a pessoa escolhe).
export async function push(project: Project, workspaceId: string, options: { readonly force?: boolean } = {}): Promise<Project> {
  const client = await need();
  const { data: existing } = await client.from('site_overlays').select('id, updated_at').eq('workspace_id', workspaceId).eq('local_id', project.id).maybeSingle();
  if (existing && !options.force && project.cloud?.remoteUpdatedAt && existing.updated_at !== project.cloud.remoteUpdatedAt) throw new ConflictError(existing.updated_at as string);
  const spec = { ...project, cloud: undefined };
  const row = { workspace_id: workspaceId, local_id: project.id, name: project.name, matches: project.matches, spec, project_id: project.cloud?.builderProjectId ?? null };
  const { data, error } = await client.from('site_overlays').upsert(row, { onConflict: 'workspace_id,local_id' }).select('id, updated_at, published, public_key').single();
  if (error) throw new Error(error.message);
  const linked: Project = { ...project, cloud: { ...(project.cloud ?? {}), id: data.id as string, workspaceId, remoteUpdatedAt: data.updated_at as string, syncedAt: Date.now(), published: Boolean(data.published), ...(data.public_key ? { publicKey: data.public_key as string } : {}) } };
  return saveProject(linked, 'Sincronizado', { touch: false, history: false });
}

export async function pull(remoteId: string): Promise<Project> {
  const { data, error } = await (await need()).from('site_overlays').select('*').eq('id', remoteId).single();
  if (error) throw new Error(error.message);
  const project = normalizeProject(data.spec);
  const linked: Project = { ...project, cloud: { id: data.id as string, workspaceId: data.workspace_id as string, remoteUpdatedAt: data.updated_at as string, syncedAt: Date.now(), published: Boolean(data.published), builderProjectId: (data.project_id as string | null) ?? null, ...(data.public_key ? { publicKey: data.public_key as string } : {}) } };
  return saveProject(linked, 'Baixado da nuvem', { touch: false });
}

function newKey(): string {
  const bytes = crypto.getRandomValues(new Uint8Array(24));
  return btoa(String.fromCharCode(...bytes)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

export async function publish(project: Project, on: boolean): Promise<Project> {
  if (!project.cloud?.id) throw new Error('Envie o projeto para a nuvem antes de publicar.');
  const client = await need();
  const key = on ? (project.cloud.publicKey ?? newKey()) : project.cloud.publicKey ?? null;
  const { data, error } = await client.from('site_overlays').update({ published: on, public_key: key }).eq('id', project.cloud.id).select('updated_at').single();
  if (error) throw new Error(error.message);
  return saveProject({ ...project, cloud: { ...project.cloud, published: on, ...(key ? { publicKey: key } : {}), remoteUpdatedAt: data.updated_at as string } }, on ? 'Publicado' : 'Despublicado', { touch: false, history: false });
}

export async function linkBuilderProject(project: Project, builderProjectId: string | null): Promise<Project> {
  const next: Project = { ...project, cloud: { ...(project.cloud ?? { id: '', workspaceId: '' }), builderProjectId } };
  if (project.cloud?.id) {
    const { error } = await (await need()).from('site_overlays').update({ project_id: builderProjectId }).eq('id', project.cloud.id);
    if (error) throw new Error(error.message);
  }
  return saveProject(next, 'Ligar ao projeto do editor', { touch: false, history: false });
}

export async function removeRemote(remoteId: string): Promise<void> {
  const { error } = await (await need()).from('site_overlays').delete().eq('id', remoteId);
  if (error) throw new Error(error.message);
}

export async function overlayEndpoint(): Promise<string> {
  const settings = await readSettings();
  return `${settings.supabaseUrl.replace(/\/$/, '')}/functions/v1/overlay`;
}
