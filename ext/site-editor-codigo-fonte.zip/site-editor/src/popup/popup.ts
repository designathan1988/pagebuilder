// O menu da extensão: os projetos que valem para a aba atual, o cliente mostrado, ligar e desligar, e o botão de
// editar a página.
import { activeClient, type Project } from '../shared/model.ts';
import { getProject, projectsFor, saveProject } from '../shared/storage.ts';

const main = document.getElementById('main') as HTMLElement;

function el<K extends keyof HTMLElementTagNameMap>(tag: K, props: Record<string, string> = {}, ...children: (Node | string | null)[]): HTMLElementTagNameMap[K] {
  const element = document.createElement(tag);
  for (const [key, value] of Object.entries(props)) element.setAttribute(key, value);
  for (const child of children) if (child !== null) element.append(child);
  return element;
}

interface Status {
  readonly editing: boolean;
  readonly running: { readonly id: string; readonly client: string | null }[];
  readonly errors: { readonly where: string; readonly message: string }[];
}

async function tabStatus(tabId: number): Promise<Status | null> {
  try {
    return ((await chrome.tabs.sendMessage(tabId, { type: 'wce:status' }, { frameId: 0 })) as Status | undefined) ?? null;
  } catch {
    return null;
  }
}

async function render(): Promise<void> {
  // ?tab=<id> abre o popup como página para uma aba escolhida (atalhos e testes)
  const forced = Number(new URLSearchParams(location.search).get('tab'));
  const [tab] = forced ? [await chrome.tabs.get(forced).catch(() => undefined)] : await chrome.tabs.query({ active: true, currentWindow: true });
  main.replaceChildren();
  if (!tab?.id || !tab.url || !/^(https?|file):/.test(tab.url)) {
    main.append(el('p', { class: 'muted' }, 'O navegador não deixa extensões editarem esta página (páginas internas, loja de extensões, PDF). Abra um site ou sistema.'));
    return;
  }
  const tabId = tab.id;
  const url = tab.url;
  const status = await tabStatus(tabId);
  const projects = await projectsFor(url, true);
  main.append(el('div', { class: 'site', title: url }, new URL(url).host + new URL(url).pathname));

  const edit = el('button', { type: 'button', class: 'primary', 'data-testid': 'popup-edit' }, status?.editing ? 'Fechar o editor' : 'Editar esta página');
  edit.addEventListener('click', async () => {
    edit.disabled = true;
    if (status?.editing) await chrome.tabs.sendMessage(tabId, { type: 'wce:close-editor' }, { frameId: 0 });
    else {
      const answer = (await chrome.runtime.sendMessage({ type: 'wce:open-editor-tab', tabId })) as { ok: boolean; error?: string };
      if (!answer.ok) {
        main.append(el('p', { class: 'err' }, `Não foi possível abrir o editor: ${answer.error ?? ''}`));
        edit.disabled = false;
        return;
      }
    }
    window.close();
  });
  main.append(edit, el('p', { class: 'muted' }, 'Atalho: ', el('kbd', {}, 'Alt'), '+', el('kbd', {}, 'Shift'), '+', el('kbd', {}, 'E'), ' · ou clique com o botão direito num elemento.'));

  if (projects.length === 0) main.append(el('p', { class: 'muted' }, 'Nenhum projeto para este endereço ainda. “Editar esta página” cria um.'));
  for (const project of projects) main.append(projectCard(project, tabId, status));

  if (status && status.errors.length > 0) {
    const box = el('details', {}, el('summary', { class: 'err' }, `${status.errors.length} aviso(s) nesta página`));
    for (const error of status.errors) box.append(el('div', { class: 'muted' }, `${error.where}: ${error.message}`));
    main.append(box);
  }
  if (!status) main.append(el('p', { class: 'muted' }, 'A página foi aberta antes da extensão: recarregue para aplicar os projetos (o editor funciona mesmo assim).'));

  const original = el('button', { type: 'button', 'data-testid': 'popup-original' }, 'Ver original');
  let showingOriginal = false;
  original.addEventListener('click', async () => {
    showingOriginal = !showingOriginal;
    await chrome.tabs.sendMessage(tabId, { type: 'wce:preview-original', enabled: showingOriginal }, { frameId: 0 }).catch(() => undefined);
    original.textContent = showingOriginal ? 'Ver com as alterações' : 'Ver original';
  });
  const companion = el('button', { type: 'button' }, 'Enviar ao Builder Companion');
  const said = el('p', { class: 'muted', role: 'status' });
  companion.addEventListener('click', async () => {
    said.textContent = 'Enviando…';
    const answer = (await chrome.runtime.sendMessage({ type: 'wce:companion', tabId })) as { ok: boolean; said: string };
    said.textContent = answer.said;
    said.className = answer.ok ? 'ok' : 'err';
  });
  main.append(el('div', { class: 'row' }, original, companion), said);
}

function projectCard(project: Project, tabId: number, status: Status | null): HTMLElement {
  const running = status?.running.find((item) => item.id === project.id);
  const card = el('div', { class: 'card', 'data-testid': 'popup-project' });
  const toggle = el('input', { type: 'checkbox', 'aria-label': 'Projeto ligado' }) as HTMLInputElement;
  toggle.checked = project.enabled;
  toggle.addEventListener('change', async () => {
    const fresh = await getProject(project.id);
    if (fresh) await saveProject({ ...fresh, enabled: toggle.checked }, toggle.checked ? 'Ligar' : 'Desligar');
  });
  const open = el('button', { type: 'button' }, 'Editar');
  open.addEventListener('click', async () => {
    await chrome.runtime.sendMessage({ type: 'wce:open-editor-tab', tabId, projectId: project.id });
    window.close();
  });
  card.append(el('div', { class: 'top' }, el('label', { class: 'switch' }, toggle), el('span', { class: 'name', title: project.name }, project.name), open));
  const client = el('select', { 'aria-label': 'Cliente mostrado nesta aba' }) as HTMLSelectElement;
  const current = running?.client ?? activeClient(project)?.id ?? '';
  for (const item of project.clients) {
    const option = el('option', { value: item.id }, `Cliente: ${item.name}`) as HTMLOptionElement;
    option.selected = item.id === current;
    client.append(option);
  }
  client.addEventListener('change', async () => {
    const fresh = await getProject(project.id);
    if (fresh) await saveProject({ ...fresh, activeClientId: client.value }, 'Trocar cliente');
    await chrome.tabs.sendMessage(tabId, { type: 'wce:client', projectId: project.id, clientId: client.value }, { frameId: 0 }).catch(() => undefined);
  });
  card.append(client, el('div', { class: 'muted' }, `${project.edits.length} alterações · ${project.variables.length} variáveis · ${project.rules.length} regras${running ? ' · aplicado' : ''}`));
  return card;
}

document.getElementById('manager')?.addEventListener('click', () => {
  void chrome.runtime.openOptionsPage();
  window.close();
});

void render();
