// wc-runtime.js: o motor das personalizações sem a extensão, para instalar no site do cliente (ou num site publicado
// pelo Webconstructor). Lê os projetos de window.WCE_PROJECTS, ou busca o projeto publicado na nuvem pela chave
// (data-wce-endpoint e data-wce-key no <script>), escolhe o cliente e aplica.
//
// <script src="wc-runtime.js" data-wce-endpoint="https://<ref>.supabase.co/functions/v1/overlay" data-wce-key="…" defer></script>
//
// Cliente: data-wce-client no <script>, window.WCE_CLIENT, ?wce_client= no endereço, ou o cliente ativo do projeto.
// API: window.WCE.set(nome, valor), window.WCE.get(nome), window.WCE.client(id), window.WCE.engines.
import { Engine, type Host } from '../engine/engine.ts';
import { normalizeProject, type Project } from '../shared/model.ts';
import { anyMatches } from '../shared/match.ts';

declare global {
  interface Window {
    WCE_PROJECTS?: unknown[];
    WCE_CLIENT?: string;
    WCE?: RuntimeApi;
  }
}

interface RuntimeApi {
  readonly version: string;
  readonly engines: Engine[];
  set(name: string, value: unknown): void;
  get(name: string): unknown;
  client(id: string): Promise<void>;
  load(project: unknown, clientId?: string): Promise<Engine>;
}

const script = document.currentScript as HTMLScriptElement | null;
const PREFIX = 'wce:';

const host: Host = {
  async fetchText(request) {
    const response = await fetch(request.url, { method: request.method, headers: request.headers, ...(request.body !== undefined && request.method !== 'GET' ? { body: request.body } : {}) });
    return { ok: response.ok, status: response.status, text: await response.text() };
  },
  async loadPersisted(scope, key) {
    try {
      const storage = scope === 'local' ? localStorage : sessionStorage;
      return JSON.parse(storage.getItem(PREFIX + key) ?? '{}') as Record<string, unknown>;
    } catch {
      return {};
    }
  },
  savePersisted(scope, key, values) {
    try {
      (scope === 'local' ? localStorage : sessionStorage).setItem(PREFIX + key, JSON.stringify(values));
    } catch {
      // armazenamento bloqueado: o valor vale até recarregar
    }
  },
  async runScript(code, scope) {
    // no site do próprio cliente o script roda direto; um CSP sem 'unsafe-eval' recusa, e a ação registra o erro
    const fn = new Function('vars', 'data', 'event', 'page', `return (async () => {\n${code}\n})();`) as (...args: unknown[]) => Promise<unknown>;
    return fn(scope.vars, scope.data, scope.event, scope.page);
  },
};

function chosenClient(project: Project): string | null {
  const wanted = script?.dataset.wceClient ?? window.WCE_CLIENT ?? new URLSearchParams(location.search).get('wce_client') ?? null;
  if (!wanted) return project.activeClientId;
  return project.clients.find((client) => client.id === wanted || client.name.toLowerCase() === wanted.toLowerCase())?.id ?? project.activeClientId;
}

const engines: Engine[] = [];

async function load(raw: unknown, clientId?: string): Promise<Engine> {
  const project = normalizeProject(raw);
  const engine = new Engine(document, project, clientId ?? chosenClient(project), host, {
    onError: (where, message) => console.warn('[Site Editor]', where, message),
  });
  engines.push(engine);
  await engine.start();
  for (const custom of project.scripts) {
    if (!custom.enabled) continue;
    try {
      await host.runScript?.(custom.code, { vars: { ...engine.vars }, data: engine.data, event: {}, page: { url: location.href } });
    } catch (error) {
      console.warn('[Site Editor] script', custom.name, error);
    }
  }
  return engine;
}

async function boot(): Promise<void> {
  const strict = script?.hasAttribute('data-wce-strict') ?? false;
  const projects: unknown[] = [...(window.WCE_PROJECTS ?? [])];
  const endpoint = script?.dataset.wceEndpoint;
  const key = script?.dataset.wceKey;
  if (endpoint && key) {
    try {
      const address = new URL(endpoint);
      address.searchParams.set('key', key);
      const response = await fetch(address, { headers: { accept: 'application/json' } });
      if (response.ok) {
        const body = (await response.json()) as { project?: unknown };
        if (body.project) projects.push(body.project);
      } else console.warn('[Site Editor] a nuvem respondeu', response.status);
    } catch (error) {
      console.warn('[Site Editor] não foi possível buscar o projeto', error);
    }
  }
  for (const raw of projects) {
    try {
      const project = normalizeProject(raw);
      if (strict && project.matches.length > 0 && !anyMatches(project.matches, location.href)) continue;
      await load(project);
    } catch (error) {
      console.warn('[Site Editor] projeto inválido', error);
    }
  }
  document.dispatchEvent(new CustomEvent('wce:ready', { detail: { engines: engines.length } }));
}

window.WCE = {
  version: '1.0.0',
  engines,
  set: (name, value) => engines.forEach((engine) => engine.setVariable(name, value)),
  get: (name) => engines.find((engine) => name in engine.vars)?.vars[name],
  client: async (id) => {
    for (const engine of engines) await engine.update(engine.currentProject, id);
  },
  load,
};

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => void boot(), { once: true });
else void boot();
