// O service worker (Chrome) ou a página de eventos (Firefox): injeta o editor sob demanda, busca dados de outros
// domínios para as fontes de dados (o script de conteúdo está preso ao CORS da página; o service worker tem as
// permissões de host da extensão), roda os scripts próprios pela API userScripts, cria o menu de contexto e o atalho
// de teclado, e entrega capturas ao Builder Companion.

import { captureTab } from './companion.ts';
import { deleteProject } from '../shared/storage.ts';

const MENU_ELEMENT = 'wce-edit-element';
const MENU_PAGE = 'wce-edit-page';

chrome.runtime.onInstalled.addListener(() => {
  void chrome.contextMenus.removeAll().then(() => {
    chrome.contextMenus.create({ id: MENU_ELEMENT, title: 'Editar este elemento com o Site Editor', contexts: ['all'] });
    chrome.contextMenus.create({ id: MENU_PAGE, title: 'Editar esta página com o Site Editor', contexts: ['page'] });
  });
});

async function injectEditor(tabId: number): Promise<void> {
  const [probe] = await chrome.scripting.executeScript({ target: { tabId, frameIds: [0] }, func: () => Boolean(globalThis.__wce?.editor) });
  if (probe?.result === true) return;
  const [hasContent] = await chrome.scripting.executeScript({ target: { tabId, frameIds: [0] }, func: () => Boolean(globalThis.__wce) });
  // a página foi aberta antes de a extensão ser instalada: injeta o script de conteúdo também
  if (hasContent?.result !== true) await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, files: ['content.js'] });
  await chrome.scripting.executeScript({ target: { tabId, frameIds: [0] }, files: ['editor.js'] });
}

export async function openEditor(tabId: number, options: { readonly projectId?: string; readonly useContext?: boolean } = {}): Promise<{ ok: boolean; error?: string }> {
  try {
    await injectEditor(tabId);
    await chrome.tabs.sendMessage(tabId, { type: 'wce:open-editor', projectId: options.projectId, useContext: options.useContext === true }, { frameId: 0 });
    return { ok: true };
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : String(error) };
  }
}

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (tab?.id === undefined) return;
  void openEditor(tab.id, { useContext: info.menuItemId === MENU_ELEMENT });
});

chrome.commands.onCommand.addListener((command, tab) => {
  if (command !== 'toggle-editor') return;
  const run = async (): Promise<void> => {
    const target = tab ?? (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
    if (target?.id === undefined) return;
    try {
      const status = (await chrome.tabs.sendMessage(target.id, { type: 'wce:status' }, { frameId: 0 })) as { editing?: boolean } | undefined;
      if (status?.editing) {
        await chrome.tabs.sendMessage(target.id, { type: 'wce:close-editor' }, { frameId: 0 });
        return;
      }
    } catch {
      // sem script de conteúdo ainda: openEditor injeta
    }
    await openEditor(target.id);
  };
  void run();
});

interface FetchMessage {
  readonly type: 'wce:fetch';
  readonly request: { readonly url: string; readonly method: string; readonly headers: Record<string, string>; readonly body?: string };
}

async function proxyFetch(request: FetchMessage['request']): Promise<{ ok: boolean; status: number; text: string; error?: string }> {
  const url = new URL(request.url);
  if (!/^https?:$/.test(url.protocol)) return { ok: false, status: 0, text: '', error: 'só endereços http e https' };
  const response = await fetch(url, { method: request.method, headers: request.headers, ...(request.body !== undefined && request.method !== 'GET' ? { body: request.body } : {}), credentials: 'omit' });
  const text = await response.text();
  return { ok: response.ok, status: response.status, text: text.length > 5_000_000 ? text.slice(0, 5_000_000) : text };
}

// Os scripts próprios rodam no mundo da página (MAIN) pela API userScripts: Chrome 135+ com "Permitir scripts de
// usuário" ligado nos detalhes da extensão (Chrome 138+) ou o modo de desenvolvedor (antes do 138); no Firefox, com a
// permissão opcional userScripts concedida.
export function userScriptsAvailable(): boolean {
  try {
    const api = (chrome as unknown as { userScripts?: { getScripts?: () => unknown; execute?: unknown } }).userScripts;
    if (!api?.getScripts) return false;
    void api.getScripts();
    return typeof api.execute === 'function';
  } catch {
    return false;
  }
}

async function runUserScript(tabId: number, frameId: number, code: string, scope: Record<string, unknown>): Promise<unknown> {
  const api = (chrome as unknown as { userScripts?: { execute(injection: unknown): Promise<{ result?: unknown; error?: string }[]> } }).userScripts;
  if (!api || !userScriptsAvailable()) throw new Error('Scripts próprios desligados: ative "Permitir scripts de usuário" nos detalhes da extensão (chrome://extensions).');
  const source = `(async (vars, data, event, page) => {\n${code}\n})(${JSON.stringify(scope.vars ?? {})}, ${JSON.stringify(scope.data ?? {})}, ${JSON.stringify(scope.event ?? {})}, ${JSON.stringify(scope.page ?? {})})`;
  const [result] = await api.execute({ target: { tabId, frameIds: [frameId] }, js: [{ code: source }], world: 'MAIN', injectImmediately: true });
  if (result?.error) throw new Error(result.error);
  return result?.result;
}

async function openUrlWithEditor(url: string, projectId?: string): Promise<{ ok: boolean; error?: string }> {
  const parsed = new URL(url);
  if (!/^https?:$/.test(parsed.protocol)) return { ok: false, error: 'endereço inválido' };
  const tab = await chrome.tabs.create({ url: parsed.href });
  if (tab.id === undefined) return { ok: false, error: 'a aba não abriu' };
  const tabId = tab.id;
  await new Promise<void>((resolve) => {
    const listener = (id: number, info: { status?: string }): void => {
      if (id === tabId && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
  });
  return openEditor(tabId, projectId === undefined ? {} : { projectId });
}

chrome.runtime.onMessage.addListener((message: { type?: string } & Record<string, unknown>, sender, respond) => {
  switch (message.type) {
    case 'wce:fetch':
      proxyFetch((message as unknown as FetchMessage).request).then(respond, (error: unknown) => respond({ ok: false, status: 0, text: '', error: error instanceof Error ? error.message : String(error) }));
      return true;
    case 'wce:script': {
      const tabId = sender.tab?.id;
      if (tabId === undefined) {
        respond({ ok: false, error: 'sem aba' });
        return false;
      }
      runUserScript(tabId, sender.frameId ?? 0, String(message.code ?? ''), (message.scope ?? {}) as Record<string, unknown>).then(
        (result) => respond({ ok: true, result }),
        (error: unknown) => respond({ ok: false, error: error instanceof Error ? error.message : String(error) }),
      );
      return true;
    }
    case 'wce:user-scripts-status':
      respond({ available: userScriptsAvailable(), chrome: Number(/(Chrome|Chromium)\/(\d+)/.exec(navigator.userAgent)?.[2] ?? 0) });
      return false;
    case 'wce:open-editor-tab': {
      const tabId = Number(message.tabId);
      openEditor(tabId, typeof message.projectId === 'string' ? { projectId: message.projectId } : {}).then(respond, (error: unknown) => respond({ ok: false, error: String(error) }));
      return true;
    }
    case 'wce:open-url-editor':
      openUrlWithEditor(String(message.url ?? ''), typeof message.projectId === 'string' ? message.projectId : undefined).then(respond, (error: unknown) => respond({ ok: false, error: String(error) }));
      return true;
    case 'wce:companion': {
      const tabId = Number(message.tabId ?? sender.tab?.id);
      chrome.tabs.get(tabId).then(captureTab).then(respond, (error: unknown) => respond({ ok: false, said: String(error) }));
      return true;
    }
    case 'wce:runtime-source':
      fetch(chrome.runtime.getURL('wc-runtime.js'))
        .then((response) => response.text())
        .then((source) => respond({ ok: true, source }), (error: unknown) => respond({ ok: false, error: String(error) }));
      return true;
    case 'wce:delete-project':
      void deleteProject(String(message.id ?? '')).then(() => respond({ ok: true }));
      return true;
    case 'wce:open-manager':
      void chrome.tabs.create({ url: chrome.runtime.getURL(`manager.html${typeof message.hash === 'string' ? message.hash : ''}`) });
      respond({ ok: true });
      return false;
    default:
      return false;
  }
});

// um gancho para os testes, que não clicam no menu do navegador
(globalThis as unknown as { wceOpenEditor: typeof openEditor }).wceOpenEditor = openEditor;
