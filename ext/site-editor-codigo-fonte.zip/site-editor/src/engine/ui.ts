// Os avisos e as janelas que as regras abrem (ações toast e modal), num Shadow DOM: o CSS da página não os atinge e o
// deles não vaza para a página.
const STYLE = `
:host{all:initial}
.toasts{position:fixed;z-index:2147483646;right:16px;bottom:16px;display:flex;flex-direction:column;gap:8px;max-width:min(360px,calc(100vw - 32px));font:14px/1.4 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
.toast{background:#111827;color:#fff;padding:10px 14px;border-radius:10px;box-shadow:0 8px 24px rgba(0,0,0,.25);animation:in .2s ease-out}
.toast.success{background:#047857}.toast.error{background:#b91c1c}
@keyframes in{from{transform:translateY(8px);opacity:0}to{transform:none;opacity:1}}
.backdrop{position:fixed;inset:0;z-index:2147483645;background:rgba(15,23,42,.55);display:flex;align-items:center;justify-content:center;padding:16px;font:15px/1.5 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
.dialog{background:#fff;color:#111827;border-radius:14px;max-width:560px;width:100%;max-height:calc(100vh - 32px);overflow:auto;box-shadow:0 24px 64px rgba(0,0,0,.3)}
.head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:14px 18px;border-bottom:1px solid #e5e7eb}
.head h2{margin:0;font-size:17px}
.close{border:0;background:transparent;font-size:22px;line-height:1;cursor:pointer;color:#6b7280;padding:4px 8px;border-radius:6px}
.close:hover{background:#f3f4f6}
.body{padding:16px 18px}
.body img{max-width:100%}
`;

export class UiLayer {
  private host: HTMLElement | null = null;
  private root: ShadowRoot | null = null;
  private toasts: HTMLElement | null = null;
  private backdrop: HTMLElement | null = null;

  constructor(
    private readonly doc: Document,
    private readonly marker: string,
  ) {}

  private ensure(): ShadowRoot {
    if (this.root && this.host?.isConnected) return this.root;
    this.host = this.doc.createElement('wce-layer');
    this.host.setAttribute(this.marker, 'layer');
    this.root = this.host.attachShadow({ mode: 'open' });
    const style = this.doc.createElement('style');
    style.textContent = STYLE;
    this.toasts = this.doc.createElement('div');
    this.toasts.className = 'toasts';
    this.toasts.setAttribute('role', 'status');
    this.toasts.setAttribute('aria-live', 'polite');
    this.root.append(style, this.toasts);
    this.doc.documentElement.appendChild(this.host);
    return this.root;
  }

  toast(message: string, tone: 'info' | 'success' | 'error' = 'info', ms = 3500): void {
    this.ensure();
    const item = this.doc.createElement('div');
    item.className = `toast ${tone}`;
    item.textContent = message;
    this.toasts?.appendChild(item);
    this.doc.defaultView?.setTimeout(() => item.remove(), ms);
  }

  modal(title: string, html: string): HTMLElement {
    const root = this.ensure();
    this.closeModal();
    const backdrop = this.doc.createElement('div');
    backdrop.className = 'backdrop';
    const dialog = this.doc.createElement('div');
    dialog.className = 'dialog';
    dialog.setAttribute('role', 'dialog');
    dialog.setAttribute('aria-modal', 'true');
    dialog.setAttribute('aria-label', title);
    const head = this.doc.createElement('div');
    head.className = 'head';
    const heading = this.doc.createElement('h2');
    heading.textContent = title;
    const close = this.doc.createElement('button');
    close.className = 'close';
    close.type = 'button';
    close.setAttribute('aria-label', 'Fechar');
    close.textContent = '×';
    close.addEventListener('click', () => this.closeModal());
    head.append(heading, close);
    const body = this.doc.createElement('div');
    body.className = 'body';
    body.setAttribute('data-wce-modal-body', '');
    body.innerHTML = html;
    dialog.append(head, body);
    backdrop.appendChild(dialog);
    backdrop.addEventListener('click', (event) => {
      if (event.target === backdrop) this.closeModal();
    });
    backdrop.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') this.closeModal();
    });
    root.appendChild(backdrop);
    this.backdrop = backdrop;
    close.focus();
    return body;
  }

  closeModal(): void {
    this.backdrop?.remove();
    this.backdrop = null;
  }

  destroy(): void {
    this.host?.remove();
    this.host = null;
    this.root = null;
  }
}
