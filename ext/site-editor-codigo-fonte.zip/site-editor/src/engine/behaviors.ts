// Comportamentos dos componentes inseridos (carrossel, abas, contagem regressiva, galeria com ampliação, botões com
// ações): o HTML inserido não roda <script> (innerHTML não executa scripts, e o CSP de muitos sites também não
// deixaria), então os componentes declaram o que fazem em atributos data-wce-* e o motor dá vida a eles.
import type { Action } from '../shared/model.ts';

export interface BehaviorHost {
  runActions(actions: readonly Action[], eventInfo: Record<string, unknown>, ruleName: string, element?: Element | null): Promise<void>;
  readonly ui: { modal(title: string, html: string): HTMLElement; toast(message: string, tone?: 'info' | 'success' | 'error'): void };
}

const ready = new WeakSet<Element>();

function once(element: Element): boolean {
  if (ready.has(element)) return false;
  ready.add(element);
  return true;
}

function carousel(root: HTMLElement): void {
  const track = root.querySelector<HTMLElement>('[data-wce-track]') ?? root;
  const slides = Array.from(track.querySelectorAll<HTMLElement>(':scope > [data-wce-slide]'));
  if (slides.length === 0) return;
  const dots = root.querySelector<HTMLElement>('[data-wce-dots]');
  let index = 0;
  const show = (next: number): void => {
    index = (next + slides.length) % slides.length;
    slides.forEach((slide, at) => {
      slide.style.display = at === index ? '' : 'none';
      slide.setAttribute('aria-hidden', String(at !== index));
    });
    dots?.querySelectorAll('button').forEach((dot, at) => dot.setAttribute('aria-current', String(at === index)));
  };
  if (dots) {
    dots.replaceChildren(
      ...slides.map((_slide, at) => {
        const dot = root.ownerDocument.createElement('button');
        dot.type = 'button';
        dot.setAttribute('aria-label', `Slide ${at + 1}`);
        dot.addEventListener('click', () => show(at));
        return dot;
      }),
    );
  }
  root.querySelector('[data-wce-prev]')?.addEventListener('click', () => show(index - 1));
  root.querySelector('[data-wce-next]')?.addEventListener('click', () => show(index + 1));
  const ms = Number(root.getAttribute('data-wce-autoplay') ?? 0);
  if (ms >= 1000) {
    const win = root.ownerDocument.defaultView;
    const timer = win?.setInterval(() => {
      if (!root.isConnected) win.clearInterval(timer);
      else if (!root.matches(':hover')) show(index + 1);
    }, ms);
  }
  show(0);
}

function tabs(root: HTMLElement): void {
  const buttons = Array.from(root.querySelectorAll<HTMLElement>('[data-wce-tab]'));
  const panels = Array.from(root.querySelectorAll<HTMLElement>('[data-wce-panel]'));
  const select = (name: string): void => {
    buttons.forEach((button) => {
      const on = button.getAttribute('data-wce-tab') === name;
      button.setAttribute('aria-selected', String(on));
      button.classList.toggle('is-active', on);
    });
    panels.forEach((panel) => {
      panel.hidden = panel.getAttribute('data-wce-panel') !== name;
    });
  };
  buttons.forEach((button) => button.addEventListener('click', () => select(button.getAttribute('data-wce-tab') ?? '')));
  const first = buttons[0]?.getAttribute('data-wce-tab');
  if (first) select(first);
}

function countdown(element: HTMLElement): void {
  const target = new Date(element.getAttribute('data-wce-countdown') ?? '').getTime();
  if (Number.isNaN(target)) return;
  const win = element.ownerDocument.defaultView;
  const done = element.getAttribute('data-wce-done') ?? 'Encerrado';
  const tick = (): void => {
    const left = target - Date.now();
    if (left <= 0) {
      element.textContent = done;
      return;
    }
    const days = Math.floor(left / 86400000);
    const hours = Math.floor((left % 86400000) / 3600000);
    const minutes = Math.floor((left % 3600000) / 60000);
    const seconds = Math.floor((left % 60000) / 1000);
    const pad = (n: number): string => String(n).padStart(2, '0');
    element.textContent = `${days > 0 ? `${days}d ` : ''}${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
  };
  tick();
  const timer = win?.setInterval(() => {
    if (!element.isConnected) win.clearInterval(timer);
    else tick();
  }, 1000);
}

function lightbox(root: HTMLElement, host: BehaviorHost): void {
  root.addEventListener('click', (event) => {
    const image = event.target instanceof Element ? event.target.closest('img') : null;
    if (!image || !root.contains(image)) return;
    event.preventDefault();
    const src = image.getAttribute('data-full') ?? image.currentSrc ?? image.src;
    const alt = image.alt || 'Imagem';
    const safe = src.replace(/"/g, '&quot;');
    host.ui.modal(alt, `<img src="${safe}" alt="" style="display:block;max-width:100%;height:auto;margin:auto">`);
  });
}

function actions(element: HTMLElement, host: BehaviorHost): void {
  let list: Action[];
  try {
    const parsed = JSON.parse(element.getAttribute('data-wce-actions') ?? '[]') as unknown;
    list = Array.isArray(parsed) ? (parsed as Action[]) : [parsed as Action];
  } catch {
    return;
  }
  const type = element.getAttribute('data-wce-on') ?? (element instanceof HTMLFormElement ? 'submit' : 'click');
  element.addEventListener(type, (event) => {
    event.preventDefault();
    const info: Record<string, unknown> = { type, text: element.textContent?.trim() ?? '', data: { ...element.dataset } };
    const form = element instanceof HTMLFormElement ? element : element.closest('form');
    if (form) {
      const fields: Record<string, unknown> = {};
      new FormData(form).forEach((value, key) => {
        fields[key] = typeof value === 'string' ? value : value.name;
      });
      info.form = fields;
      if (element instanceof HTMLFormElement) element.reset();
    }
    const repeated = element.closest('[data-wce-index]');
    if (repeated) info.index = Number(repeated.getAttribute('data-wce-index'));
    void host.runActions(list, info, element.getAttribute('aria-label') ?? 'componente', element);
  });
}

export function attachBehaviors(root: HTMLElement, host: BehaviorHost): void {
  const all = (selector: string): HTMLElement[] => [...(root.matches(selector) ? [root] : []), ...Array.from(root.querySelectorAll<HTMLElement>(selector))];
  for (const element of all('[data-wce-carousel]')) if (once(element)) carousel(element);
  for (const element of all('[data-wce-tabs]')) if (once(element)) tabs(element);
  for (const element of all('[data-wce-countdown]')) if (once(element)) countdown(element);
  for (const element of all('[data-wce-lightbox]')) if (once(element)) lightbox(element, host);
  for (const element of all('[data-wce-actions]')) if (once(element)) actions(element, host);
}
