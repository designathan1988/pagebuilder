// O motor: aplica um projeto a um documento e o mantém aplicado. É o mesmo na extensão (script de conteúdo) e no
// script dos sites (wc-runtime.js). Cada alteração guarda o estado original de cada elemento que tocou, para desfazer
// (desligar o projeto, trocar de cliente, a prévia do original no editor) sem recarregar a página.
//
// Sistemas feitos com React, Vue, Angular e afins redesenham partes da página a qualquer momento: um MutationObserver
// reaplica as alterações aos nós novos ou redesenhados antes da pintura (o retorno do observer roda como microtarefa),
// e um limite por alteração impede uma briga sem fim com um sistema que desfaz a mudança a cada quadro.
import { activeClient, type Action, type Client, type DataSource, type Edit, type InsertPosition, type Project, type Rule, type VariableDef } from '../shared/model.ts';
import { getPath, namesIn, parseCsv, renderTemplate, run, toText, truthy, type Scope } from '../shared/expr.ts';
import { pageMatches } from '../shared/match.ts';
import { safeQueryAll } from '../shared/selector.ts';
import { attachBehaviors } from './behaviors.ts';
import { UiLayer } from './ui.ts';

export interface FetchRequest {
  readonly url: string;
  readonly method: string;
  readonly headers: Record<string, string>;
  readonly body?: string;
}

export interface FetchAnswer {
  readonly ok: boolean;
  readonly status: number;
  readonly text: string;
}

export interface Host {
  fetchText(request: FetchRequest): Promise<FetchAnswer>;
  loadPersisted(scope: 'local' | 'session', key: string): Promise<Record<string, unknown>>;
  savePersisted(scope: 'local' | 'session', key: string, values: Record<string, unknown>): void;
  runScript?(code: string, scope: Record<string, unknown>): Promise<unknown>;
}

export const UI_ATTRIBUTE = 'data-wce-ui';
const HIDDEN = 'data-wce-hidden';
const BIND_HIDDEN = 'data-wce-bind-hidden';
const RULE_HIDDEN = 'data-wce-rule-hidden';
const INSERT_TAG = 'wce-insert';
const LOOP_LIMIT = 40;

interface ElementRecord {
  restore: () => void;
  // o que a alteração gravou da última vez, para saber se o sistema desfez
  last?: string;
  nodes?: Node[];
}

interface EditState {
  readonly records: Map<Element, ElementRecord>;
  hits: number;
  windowStart: number;
  paused: boolean;
}

export interface EngineEvents {
  onVariables?(values: Readonly<Record<string, unknown>>): void;
  onError?(where: string, message: string): void;
  onLog?(message: string): void;
}

function isOurs(node: Node): boolean {
  const element = node.nodeType === 1 ? (node as Element) : node.parentElement;
  return element?.closest(`[${UI_ATTRIBUTE}]`) !== null && element?.closest(`[${UI_ATTRIBUTE}]`) !== undefined;
}

export class Engine {
  readonly vars: Record<string, unknown> = {};
  readonly data: Record<string, unknown> = {};
  private project: Project;
  private client: Client | null;
  private readonly states = new Map<string, EditState>();
  private observer: MutationObserver | null = null;
  private style: HTMLStyleElement | null = null;
  private readonly timers: number[] = [];
  private readonly sourceTimers: number[] = [];
  private readonly listeners: [string, EventListener, boolean][] = [];
  private intersection: IntersectionObserver | null = null;
  private readonly watched = new WeakSet<Element>();
  private lastHref = '';
  private running = false;
  private suspended = false;
  private applying = false;
  private scheduled = false;
  private clockTimer: number | null = null;
  private holding = 0;
  private replaced = new WeakMap<Node, string>();
  private replacedAttributes = new WeakMap<Element, Map<string, string>>();
  readonly ui: UiLayer;

  constructor(
    private readonly doc: Document,
    project: Project,
    clientId: string | null,
    private readonly host: Host,
    private readonly events: EngineEvents = {},
  ) {
    this.project = project;
    this.client = activeClient(project, clientId);
    this.ui = new UiLayer(doc, UI_ATTRIBUTE);
  }

  get currentProject(): Project {
    return this.project;
  }

  get currentClient(): Client | null {
    return this.client;
  }

  get isRunning(): boolean {
    return this.running && !this.suspended;
  }

  private get win(): Window & typeof globalThis {
    return this.doc.defaultView as Window & typeof globalThis;
  }

  private persistKey(): string {
    return `${this.project.id}:${this.client?.id ?? ''}`;
  }

  // ---------------------------------------------------------------- escopo das expressões

  scope(extra: Record<string, unknown> = {}): Scope {
    const location = this.win.location;
    const query: Record<string, string> = {};
    new URLSearchParams(location.search).forEach((value, key) => {
      query[key] = value;
    });
    return {
      ...this.vars,
      vars: this.vars,
      data: this.data,
      page: { url: location.href, path: location.pathname, query, hash: location.hash.replace(/^#/, ''), host: location.host, title: this.doc.title },
      client: { id: this.client?.id ?? '', name: this.client?.name ?? '', ...(this.client?.values ?? {}) },
      now: Date.now(),
      ...extra,
    };
  }

  // ---------------------------------------------------------------- ciclo de vida

  async start(): Promise<void> {
    if (this.running) return;
    this.running = true;
    this.lastHref = this.win.location.href;
    this.installStyle();
    await this.initVariables();
    this.applyAll();
    this.observe();
    this.bindRules();
    this.startSources();
    this.startClock();
    this.fireTrigger('load', null);
  }

  stop(): void {
    if (!this.running) return;
    this.running = false;
    this.observer?.disconnect();
    this.observer = null;
    this.intersection?.disconnect();
    this.intersection = null;
    for (const [type, listener, capture] of this.listeners) this.doc.removeEventListener(type, listener, capture);
    this.listeners.length = 0;
    for (const timer of [...this.timers, ...this.sourceTimers]) this.win.clearInterval(timer);
    this.timers.length = 0;
    this.sourceTimers.length = 0;
    if (this.clockTimer !== null) this.win.clearInterval(this.clockTimer);
    this.clockTimer = null;
    this.revertAll();
    this.style?.remove();
    this.style = null;
    this.ui.destroy();
  }

  // Enquanto a pessoa digita no lugar, o motor não reaplica (senão desfaria a digitação).
  hold(): void {
    this.holding += 1;
  }

  release(): void {
    this.holding = Math.max(0, this.holding - 1);
    this.observer?.takeRecords();
  }

  get suspendedNow(): boolean {
    return this.suspended;
  }

  // A prévia do original: desfaz tudo sem parar o motor; resume volta a aplicar.
  suspend(): void {
    if (this.suspended) return;
    this.suspended = true;
    this.revertAll();
    if (this.style) this.style.disabled = true;
  }

  resume(): void {
    if (!this.suspended) return;
    this.suspended = false;
    if (this.style) this.style.disabled = false;
    this.applyAll();
  }

  // O projeto mudou (o editor gravou algo, ou o cliente foi trocado): desfaz e aplica de novo.
  async update(project: Project, clientId?: string | null): Promise<void> {
    const clientChanged = clientId !== undefined && clientId !== this.client?.id;
    const sourcesChanged = JSON.stringify(project.sources) !== JSON.stringify(this.project.sources);
    const rulesChanged = JSON.stringify(project.rules) !== JSON.stringify(this.project.rules);
    const variablesChanged = JSON.stringify(project.variables) !== JSON.stringify(this.project.variables) || clientChanged || JSON.stringify(activeClient(project, clientId ?? this.client?.id)?.values) !== JSON.stringify(this.client?.values);
    this.revertAll();
    this.project = project;
    this.client = activeClient(project, clientId === undefined ? this.client?.id : clientId);
    this.states.clear();
    if (variablesChanged) await this.initVariables();
    this.installStyle();
    if (sourcesChanged) this.startSources();
    if (rulesChanged) this.rebindTimers();
    if (!this.suspended) this.applyAll();
    this.startClock();
  }

  // ---------------------------------------------------------------- variáveis

  private async initVariables(): Promise<void> {
    for (const key of Object.keys(this.vars)) delete this.vars[key];
    const [local, session] = await Promise.all([this.host.loadPersisted('local', this.persistKey()), this.host.loadPersisted('session', this.persistKey())]);
    for (const variable of this.project.variables) {
      let value: unknown = variable.default;
      if (this.client && Object.prototype.hasOwnProperty.call(this.client.values, variable.name)) value = this.client.values[variable.name];
      if (variable.persist === 'local' && Object.prototype.hasOwnProperty.call(local, variable.name)) value = local[variable.name];
      if (variable.persist === 'session' && Object.prototype.hasOwnProperty.call(session, variable.name)) value = session[variable.name];
      const fromSource = this.readSource(variable);
      if (fromSource !== undefined) value = fromSource;
      this.vars[variable.name] = coerce(variable, value);
    }
    this.recomputeDerived();
    this.events.onVariables?.(this.vars);
  }

  private readSource(variable: VariableDef): unknown {
    const source = variable.source;
    if (!source || source.kind === 'static' || source.kind === 'expression') return undefined;
    try {
      switch (source.kind) {
        case 'query': {
          const value = new URLSearchParams(this.win.location.search).get(source.param);
          return value === null ? undefined : value;
        }
        case 'cookie': {
          const match = this.doc.cookie.split(';').map((part) => part.trim()).find((part) => part.startsWith(`${source.name}=`));
          return match === undefined ? undefined : decodeURIComponent(match.slice(source.name.length + 1));
        }
        case 'storage': {
          const value = this.win.localStorage.getItem(source.key);
          if (value === null) return undefined;
          try {
            return JSON.parse(value) as unknown;
          } catch {
            return value;
          }
        }
        case 'element': {
          const element = safeQueryAll(this.doc, source.selector).find((candidate) => !isOurs(candidate));
          if (!element) return undefined;
          if (source.attr) return element.getAttribute(source.attr) ?? undefined;
          if (element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement || element instanceof HTMLSelectElement) return element.value;
          return element.textContent?.trim();
        }
        case 'source': {
          const owner = this.project.sources.find((candidate) => candidate.id === source.sourceId);
          if (!owner || !(owner.name in this.data)) return undefined;
          return getPath(this.data[owner.name], source.path);
        }
      }
    } catch (error) {
      this.report(`variável ${variable.name}`, error);
    }
    return undefined;
  }

  private recomputeDerived(): void {
    // variáveis calculadas podem depender umas das outras: algumas passadas resolvem a cadeia
    const derived = this.project.variables.filter((variable) => variable.source?.kind === 'expression');
    for (let pass = 0; pass < 4 && derived.length > 0; pass += 1) {
      for (const variable of derived) {
        if (variable.source?.kind !== 'expression') continue;
        try {
          this.vars[variable.name] = coerce(variable, run(variable.source.expr, this.scope()));
        } catch (error) {
          this.report(`variável ${variable.name}`, error);
        }
      }
    }
  }

  setVariable(name: string, value: unknown, options: { readonly silent?: boolean } = {}): void {
    const definition = this.project.variables.find((variable) => variable.name === name);
    const next = definition ? coerce(definition, value) : value;
    const before = this.vars[name];
    if (JSON.stringify(before) === JSON.stringify(next)) return;
    this.vars[name] = next;
    if (definition && definition.persist !== 'none') {
      const persisted = Object.fromEntries(this.project.variables.filter((variable) => variable.persist === definition.persist).map((variable) => [variable.name, this.vars[variable.name]]));
      this.host.savePersisted(definition.persist, this.persistKey(), persisted);
    }
    this.recomputeDerived();
    this.refreshDynamic();
    this.events.onVariables?.(this.vars);
    if (!options.silent) this.fireTrigger('varchange', null, { variable: name, value: next, previous: before });
  }

  resetVariable(name: string): void {
    const definition = this.project.variables.find((variable) => variable.name === name);
    if (!definition) return;
    const value = this.client && name in this.client.values ? this.client.values[name] : definition.default;
    this.setVariable(name, value);
  }

  // ---------------------------------------------------------------- CSS do projeto

  private installStyle(): void {
    if (!this.style) {
      this.style = this.doc.createElement('style');
      this.style.setAttribute(UI_ATTRIBUTE, 'style');
      this.style.id = `wce-style-${this.project.id}`;
    }
    const parent = this.doc.head ?? this.doc.documentElement;
    if (this.style.parentNode !== parent) parent.appendChild(this.style);
    const scope = this.scope();
    const projectCss = renderTemplate(this.project.css ?? '', scope);
    const clientCss = renderTemplate(this.client?.css ?? '', scope);
    this.style.textContent = [
      `[${HIDDEN}],[${BIND_HIDDEN}],[${RULE_HIDDEN}]{display:none !important}`,
      `html.wce-show-hidden [${HIDDEN}]{display:revert !important;opacity:.35 !important;outline:2px dashed #f97316 !important}`,
      `${INSERT_TAG}{display:contents}`,
      projectCss,
      clientCss,
    ].join('\n');
  }

  // ---------------------------------------------------------------- aplicar as alterações

  private inScope(item: { readonly page?: string; readonly clients?: string[] }): boolean {
    if (!pageMatches(item.page, this.win.location)) return false;
    if (item.clients && item.clients.length > 0 && !item.clients.includes(this.client?.id ?? '')) return false;
    return true;
  }

  private state(edit: Edit): EditState {
    let state = this.states.get(edit.id);
    if (!state) {
      state = { records: new Map(), hits: 0, windowStart: Date.now(), paused: false };
      this.states.set(edit.id, state);
    }
    return state;
  }

  applyAll(): void {
    if (!this.running || this.suspended) return;
    this.applying = true;
    try {
      for (const edit of this.project.edits) this.applyEdit(edit);
    } finally {
      this.applying = false;
      this.observer?.takeRecords();
    }
  }

  private refreshDynamic(): void {
    if (!this.running || this.suspended) return;
    this.applying = true;
    try {
      this.installStyle();
      for (const edit of this.project.edits) if (isDynamicEdit(edit)) this.applyEdit(edit);
    } finally {
      this.applying = false;
      this.observer?.takeRecords();
    }
  }

  revertEdit(editId: string): void {
    const state = this.states.get(editId);
    if (!state) return;
    this.applying = true;
    // na ordem inversa: um elemento movido e depois alterado volta certo
    for (const [, record] of [...state.records.entries()].reverse()) {
      try {
        record.restore();
      } catch {
        // o elemento saiu da página: não há o que desfazer
      }
    }
    state.records.clear();
    this.applying = false;
    this.observer?.takeRecords();
  }

  private revertAll(): void {
    for (const edit of [...this.project.edits].reverse()) this.revertEdit(edit.id);
    this.states.clear();
    this.ui.closeModal();
  }

  private applyEdit(edit: Edit): void {
    const state = this.state(edit);
    let active = edit.enabled && this.inScope(edit);
    if (active && edit.when) {
      try {
        active = truthy(run(edit.when, this.scope()));
      } catch (error) {
        this.report(`condição de "${edit.label ?? edit.op}"`, error);
        active = false;
      }
    }
    if (!active) {
      if (state.records.size > 0) this.revertEdit(edit.id);
      return;
    }
    if (state.paused) return;
    const targets = edit.op === 'replace' && (edit.target.selector === '' || edit.target.selector === 'body') ? [this.doc.body].filter(Boolean) : safeQueryAll(this.doc, edit.target.selector).filter((element) => !isOurs(element));
    // os elementos que saíram da página: o registro deles não vale mais
    for (const [element, record] of state.records) {
      if (!element.isConnected && edit.op !== 'remove' && edit.op !== 'move') {
        record.nodes?.forEach((node) => (node as ChildNode).remove?.());
        state.records.delete(element);
      }
    }
    let changed = false;
    for (const element of targets) {
      try {
        if (this.applyTo(edit, element as HTMLElement, state)) changed = true;
      } catch (error) {
        this.report(`alteração "${edit.label ?? edit.op}"`, error);
      }
    }
    if (changed) {
      const now = Date.now();
      if (now - state.windowStart > 1000) {
        state.windowStart = now;
        state.hits = 0;
      }
      state.hits += 1;
      if (state.hits > LOOP_LIMIT) {
        state.paused = true;
        this.events.onError?.(`alteração "${edit.label ?? edit.op}"`, 'A página desfaz esta alteração sem parar; ela foi pausada nesta visita.');
      }
    }
  }

  // Aplica uma alteração a um elemento. Devolve true quando mexeu no DOM (para o limite de reaplicações).
  private applyTo(edit: Edit, element: HTMLElement, state: EditState): boolean {
    const scope = this.scope();
    const existing = state.records.get(element);
    switch (edit.op) {
      case 'text':
        return this.setText(element, renderTemplate(edit.value, scope), state, existing);
      case 'html':
        return this.setHtml(element, renderTemplate(edit.value, scope, true), state, existing);
      case 'attr':
        return this.setAttr(element, edit.name, edit.value === null ? null : renderTemplate(edit.value, scope), state, existing);
      case 'style': {
        const props = Object.fromEntries(Object.entries(edit.props).map(([prop, value]) => [prop, renderTemplate(value, scope)]));
        return this.setStyle(element, props, state, existing);
      }
      case 'class': {
        if (!existing) {
          const original = element.getAttribute('class');
          state.records.set(element, { restore: () => (original === null ? element.removeAttribute('class') : element.setAttribute('class', original)) });
        }
        let changed = false;
        for (const name of edit.add) if (name && !element.classList.contains(name)) (element.classList.add(name), (changed = true));
        for (const name of edit.remove) if (name && element.classList.contains(name)) (element.classList.remove(name), (changed = true));
        return changed;
      }
      case 'hide':
        return this.setFlag(element, HIDDEN, true, state, existing);
      case 'blur':
        return this.setStyle(element, { filter: `blur(${edit.amount}px)`, 'user-select': 'none' }, state, existing);
      case 'remove': {
        if (existing || !element.parentNode) return false;
        const parent = element.parentNode;
        const next = element.nextSibling;
        element.remove();
        state.records.set(element, { restore: () => parent.insertBefore(element, next && next.parentNode === parent ? next : null) });
        return true;
      }
      case 'insert':
        return this.insert(element, edit.position, renderTemplate(edit.html, scope, true), edit.id, state, existing);
      case 'move': {
        const ref = safeQueryAll(this.doc, edit.ref.selector).find((candidate) => !isOurs(candidate) && candidate !== element && !element.contains(candidate));
        if (!ref) return false;
        if (!existing) {
          const parent = element.parentNode;
          const next = element.nextSibling;
          state.records.set(element, { restore: () => parent?.insertBefore(element, next && next.parentNode === parent ? next : null) });
        }
        if (placedAt(element, ref, edit.position)) return false;
        place(element, ref, edit.position);
        return true;
      }
      case 'replace':
        return this.replaceText(element, edit.find, renderTemplate(edit.replace, scope), edit.regex === true, edit.caseSensitive === true, state);
      case 'bind':
        return this.bind(edit, element, scope, state, existing);
      case 'repeat':
        return this.repeat(edit, element, scope, state, existing);
    }
  }

  private setText(element: HTMLElement, text: string, state: EditState, existing: ElementRecord | undefined): boolean {
    if (!existing) {
      const original = Array.from(element.childNodes);
      // o nó de texto é alterado no lugar (abaixo), então o texto dele também precisa ser guardado
      const texts = original.map((node) => (node.nodeType === Node.TEXT_NODE ? (node as Text).data : null));
      const value = element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement ? element.value : null;
      state.records.set(element, {
        restore: () => {
          original.forEach((node, at) => {
            const text = texts[at];
            if (text !== null && text !== undefined && (node as Text).data !== text) (node as Text).data = text;
          });
          element.replaceChildren(...original);
          if (value !== null) (element as HTMLInputElement).value = value;
        },
      });
    }
    if (element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement) {
      if (element.value === text) return false;
      element.value = text;
      return true;
    }
    if (element.textContent === text) return false;
    // um único nó de texto: troca só o texto, e o sistema que guardou a referência a ele continua a achá-lo
    const only = element.childNodes.length === 1 ? element.firstChild : null;
    if (only && only.nodeType === Node.TEXT_NODE) (only as Text).data = text;
    else element.textContent = text;
    return true;
  }

  private setHtml(element: HTMLElement, html: string, state: EditState, existing: ElementRecord | undefined): boolean {
    if (!existing) {
      const original = Array.from(element.childNodes);
      state.records.set(element, { restore: () => element.replaceChildren(...original) });
    }
    const record = state.records.get(element);
    if (record && record.last === html && element.getAttribute('data-wce-html') === hash(html)) return false;
    element.innerHTML = html;
    element.setAttribute('data-wce-html', hash(html));
    if (record) {
      record.last = html;
      const restore = record.restore;
      record.restore = () => {
        element.removeAttribute('data-wce-html');
        restore();
      };
    }
    attachBehaviors(element, this);
    return true;
  }

  private setAttr(element: HTMLElement, name: string, value: string | null, state: EditState, existing: ElementRecord | undefined): boolean {
    if (!existing) {
      const original = element.getAttribute(name);
      const srcset = name === 'src' ? element.getAttribute('srcset') : null;
      const sources = name === 'src' && element.parentElement?.localName === 'picture' ? Array.from(element.parentElement.querySelectorAll('source')).map((source) => [source, source.getAttribute('srcset')] as const) : [];
      const property = name === 'value' && 'value' in element ? (element as HTMLInputElement).value : null;
      state.records.set(element, {
        restore: () => {
          if (original === null) element.removeAttribute(name);
          else element.setAttribute(name, original);
          if (srcset !== null) element.setAttribute('srcset', srcset);
          for (const [source, set] of sources) if (set !== null) source.setAttribute('srcset', set);
          if (property !== null) (element as HTMLInputElement).value = property;
        },
      });
    }
    let changed = false;
    if (value === null) {
      if (element.hasAttribute(name)) (element.removeAttribute(name), (changed = true));
      return changed;
    }
    if (element.getAttribute(name) !== value) (element.setAttribute(name, value), (changed = true));
    if (name === 'src') {
      // uma imagem com srcset ignora o src: a imagem trocada só aparece sem ele
      if (element.hasAttribute('srcset')) (element.removeAttribute('srcset'), (changed = true));
      if (element.parentElement?.localName === 'picture') for (const source of Array.from(element.parentElement.querySelectorAll('source'))) if (source.hasAttribute('srcset')) (source.removeAttribute('srcset'), (changed = true));
    }
    if (name === 'value' && 'value' in element && (element as HTMLInputElement).value !== value) {
      (element as HTMLInputElement).value = value;
      changed = true;
    }
    if (name === 'checked' && element instanceof HTMLInputElement) element.checked = value !== 'false';
    return changed;
  }

  private setStyle(element: HTMLElement, props: Record<string, string>, state: EditState, existing: ElementRecord | undefined): boolean {
    if (!existing) {
      const original = element.getAttribute('style');
      state.records.set(element, { restore: () => (original === null ? element.removeAttribute('style') : element.setAttribute('style', original)) });
    }
    let changed = false;
    for (const [prop, value] of Object.entries(props)) {
      const name = prop.startsWith('--') ? prop : prop.replace(/[A-Z]/g, (ch) => `-${ch.toLowerCase()}`);
      if (value === '') {
        if (element.style.getPropertyValue(name) !== '') (element.style.removeProperty(name), (changed = true));
        continue;
      }
      if (element.style.getPropertyValue(name) !== value || element.style.getPropertyPriority(name) !== 'important') {
        element.style.setProperty(name, value, 'important');
        changed = true;
      }
    }
    return changed;
  }

  private setFlag(element: HTMLElement, attribute: string, on: boolean, state: EditState, existing: ElementRecord | undefined): boolean {
    if (!existing) state.records.set(element, { restore: () => element.removeAttribute(attribute) });
    if (on === element.hasAttribute(attribute)) return false;
    if (on) element.setAttribute(attribute, '');
    else element.removeAttribute(attribute);
    return true;
  }

  private insert(element: HTMLElement, position: InsertPosition, html: string, editId: string, state: EditState, existing: ElementRecord | undefined): boolean {
    let record = existing;
    if (!record) {
      const holder = this.doc.createElement(INSERT_TAG);
      holder.setAttribute('data-wce-edit', editId);
      record = { nodes: [holder], restore: () => holder.remove() };
      state.records.set(element, record);
    }
    const holder = record.nodes?.[0] as HTMLElement;
    let changed = false;
    if (record.last !== html) {
      holder.innerHTML = html;
      record.last = html;
      attachBehaviors(holder, this);
      changed = true;
    }
    const placed =
      (position === 'before' && holder.nextSibling === element) ||
      (position === 'after' && element.nextSibling === holder) ||
      (position === 'prepend' && element.firstChild === holder) ||
      (position === 'append' && element.lastChild === holder);
    if (!placed) {
      place(holder, element, position);
      changed = true;
    }
    return changed;
  }

  private replaceText(root: HTMLElement, find: string, replacement: string, regex: boolean, caseSensitive: boolean, state: EditState): boolean {
    if (find === '') return false;
    let pattern: RegExp;
    try {
      pattern = regex ? new RegExp(find, caseSensitive ? 'g' : 'gi') : new RegExp(find.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), caseSensitive ? 'g' : 'gi');
    } catch {
      return false;
    }
    let record = state.records.get(root);
    if (!record) {
      const touched: { node: Node; original: string }[] = [];
      const attrs: { element: Element; name: string; original: string }[] = [];
      record = {
        nodes: [],
        restore: () => {
          for (const { node, original } of touched) if ((node as Text).data !== undefined) (node as Text).data = original;
          for (const { element, name, original } of attrs) element.setAttribute(name, original);
          touched.length = 0;
          attrs.length = 0;
        },
      };
      (record as ElementRecord & { touched?: typeof touched; attrs?: typeof attrs }).touched = touched;
      (record as ElementRecord & { touched?: typeof touched; attrs?: typeof attrs }).attrs = attrs;
      state.records.set(root, record);
    }
    const holder = record as ElementRecord & { touched: { node: Node; original: string }[]; attrs: { element: Element; name: string; original: string }[] };
    let changed = false;
    const walker = this.doc.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: (node) => {
        const parent = node.parentElement;
        if (!parent || /^(script|style|noscript|textarea|template)$/i.test(parent.localName) || isOurs(node) || parent.isContentEditable) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      },
    });
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
      const text = node as Text;
      const known = this.replaced.get(text);
      const source = known !== undefined && text.data === known.split('\u0000')[1] ? known.split('\u0000')[0] ?? text.data : text.data;
      pattern.lastIndex = 0;
      if (!pattern.test(source)) continue;
      pattern.lastIndex = 0;
      const next = source.replace(pattern, replacement);
      if (next === text.data) continue;
      if (!holder.touched.some((entry) => entry.node === text)) holder.touched.push({ node: text, original: source });
      text.data = next;
      this.replaced.set(text, `${source}\u0000${next}`);
      changed = true;
    }
    for (const element of [root, ...Array.from(root.querySelectorAll('[placeholder],[title],[alt],[aria-label],input[type=submit],input[type=button]'))]) {
      if (isOurs(element)) continue;
      for (const name of ['placeholder', 'title', 'alt', 'aria-label', 'value']) {
        if (name === 'value' && !(element instanceof HTMLInputElement && /^(submit|button)$/.test(element.type))) continue;
        const value = element.getAttribute(name);
        if (value === null) continue;
        const memory = this.replacedAttributes.get(element) ?? new Map<string, string>();
        const recorded = memory.get(name);
        const source = recorded !== undefined && value === recorded.split('\u0000')[1] ? recorded.split('\u0000')[0] ?? value : value;
        pattern.lastIndex = 0;
        if (!pattern.test(source)) continue;
        pattern.lastIndex = 0;
        const next = source.replace(pattern, replacement);
        if (next === value) continue;
        if (!holder.attrs.some((entry) => entry.element === element && entry.name === name)) holder.attrs.push({ element, name, original: source });
        element.setAttribute(name, next);
        memory.set(name, `${source}\u0000${next}`);
        this.replacedAttributes.set(element, memory);
        changed = true;
      }
    }
    return changed;
  }

  private bind(edit: Extract<Edit, { op: 'bind' }>, element: HTMLElement, scope: Scope, state: EditState, existing: ElementRecord | undefined): boolean {
    const value = run(edit.expr, scope);
    switch (edit.kind) {
      case 'text':
        return this.setText(element, toText(value), state, existing);
      case 'html':
        return this.setHtml(element, toText(value), state, existing);
      case 'attr':
        return this.setAttr(element, edit.name ?? 'title', value === false || value === null || value === undefined ? null : toText(value), state, existing);
      case 'style':
        return this.setStyle(element, { [edit.name ?? 'color']: toText(value) }, state, existing);
      case 'class': {
        if (!existing) {
          const original = element.getAttribute('class');
          state.records.set(element, { restore: () => (original === null ? element.removeAttribute('class') : element.setAttribute('class', original)) });
        }
        const name = edit.name ?? '';
        if (!name) return false;
        const on = truthy(value);
        if (on === element.classList.contains(name)) return false;
        element.classList.toggle(name, on);
        return true;
      }
      case 'show':
        return this.setFlag(element, BIND_HIDDEN, !truthy(value), state, existing);
      case 'value': {
        const changed = this.setAttr(element, 'value', toText(value), state, existing);
        const name = edit.expr.trim();
        // ligação de mão dupla: o campo ligado a uma variável grava nela o que a pessoa digita
        if (/^[A-Za-z_][A-Za-z0-9_]*$/.test(name) && !element.hasAttribute('data-wce-two-way')) {
          element.setAttribute('data-wce-two-way', name);
          const listener = (): void => {
            const input = element as HTMLInputElement;
            this.setVariable(name, input.type === 'checkbox' ? input.checked : input.value);
          };
          element.addEventListener('input', listener);
          element.addEventListener('change', listener);
          const record = state.records.get(element);
          if (record) {
            const restore = record.restore;
            record.restore = () => {
              element.removeEventListener('input', listener);
              element.removeEventListener('change', listener);
              element.removeAttribute('data-wce-two-way');
              restore();
            };
          }
        }
        return changed;
      }
    }
  }

  private repeat(edit: Extract<Edit, { op: 'repeat' }>, element: HTMLElement, scope: Scope, state: EditState, existing: ElementRecord | undefined): boolean {
    const raw = run(edit.expr, scope);
    const items = Array.isArray(raw) ? raw : raw && typeof raw === 'object' ? Object.values(raw) : [];
    const itemName = edit.itemName || 'item';
    const pieces = items.map((item, index) => renderTemplate(edit.template, { ...scope, [itemName]: item, index, position: index + 1, first: index === 0, last: index === items.length - 1 }, true));
    const html = pieces.join('\u0000');
    let record = existing;
    if (!record) {
      const made: ElementRecord = {
        nodes: [],
        restore: () => {
          for (const node of made.nodes ?? []) (node as ChildNode).remove();
          made.nodes = [];
          element.removeAttribute(HIDDEN);
        },
      };
      record = made;
      state.records.set(element, record);
    }
    let changed = false;
    if (!element.hasAttribute(HIDDEN)) {
      element.setAttribute(HIDDEN, '');
      changed = true;
    }
    const nodes = record.nodes ?? [];
    const inPlace = nodes.length > 0 ? nodes.every((node) => node.isConnected) && element.nextSibling === nodes[0] : pieces.length === 0;
    if (record.last !== html || !inPlace) {
      for (const node of nodes) (node as ChildNode).remove();
      // um <template> lê <tr>, <li> e <option> fora da tabela ou da lista sem descartar as tags
      const made: Node[] = [];
      pieces.forEach((piece, index) => {
        const template = this.doc.createElement('template');
        template.innerHTML = piece;
        for (const node of Array.from(template.content.childNodes)) {
          if (node.nodeType === Node.ELEMENT_NODE) {
            (node as Element).setAttribute('data-wce-index', String(index));
            (node as Element).setAttribute('data-wce-edit', edit.id);
          }
          made.push(node);
        }
      });
      const fragment = this.doc.createDocumentFragment();
      made.forEach((node) => fragment.appendChild(node));
      element.parentNode?.insertBefore(fragment, element.nextSibling);
      for (const node of made) if (node.nodeType === Node.ELEMENT_NODE) attachBehaviors(node as HTMLElement, this);
      record.nodes = made;
      record.last = html;
      changed = true;
    }
    return changed;
  }

  // ---------------------------------------------------------------- observar a página

  private observe(): void {
    this.observer?.disconnect();
    this.observer = new MutationObserver((mutations) => {
      if (this.applying || !this.running || this.suspended || this.holding > 0) return;
      const relevant = mutations.some((mutation) => !isOurs(mutation.target));
      if (!relevant) return;
      if (this.win.location.href !== this.lastHref) this.onUrlChange();
      this.applyAll();
      this.watchVisible();
    });
    this.observer.observe(this.doc.documentElement, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['class', 'style', 'src', 'href', 'hidden', 'value'] });
    // navegação de aplicações de página única: pushState não avisa a extensão (outro mundo de JavaScript)
    const poll = this.win.setInterval(() => {
      if (this.win.location.href !== this.lastHref) this.onUrlChange();
    }, 400);
    this.timers.push(poll);
    const pop = (): void => this.onUrlChange();
    this.win.addEventListener('popstate', pop);
    this.win.addEventListener('hashchange', pop);
  }

  private onUrlChange(): void {
    if (this.win.location.href === this.lastHref) return;
    const previous = this.lastHref;
    this.lastHref = this.win.location.href;
    for (const variable of this.project.variables) {
      if (variable.source?.kind === 'query') {
        const value = this.readSource(variable);
        if (value !== undefined) this.vars[variable.name] = coerce(variable, value);
      }
    }
    this.recomputeDerived();
    this.applyAll();
    this.fireTrigger('urlchange', null, { from: previous, to: this.lastHref });
    this.events.onVariables?.(this.vars);
  }

  // ---------------------------------------------------------------- relógio: textos com now() se atualizam

  private startClock(): void {
    if (this.clockTimer !== null) this.win.clearInterval(this.clockTimer);
    this.clockTimer = null;
    const usesClock = this.project.edits.some((edit) => {
      const sources = [edit.when ?? '', 'value' in edit ? String(edit.value ?? '') : '', 'expr' in edit ? edit.expr : '', 'html' in edit ? edit.html : '', 'template' in edit ? edit.template : ''];
      return sources.some((source) => namesIn(source, source.includes('{{')).has('now'));
    });
    if (usesClock) this.clockTimer = this.win.setInterval(() => this.refreshDynamic(), 1000);
  }

  // ---------------------------------------------------------------- fontes de dados

  private startSources(): void {
    for (const timer of this.sourceTimers) this.win.clearInterval(timer);
    this.sourceTimers.length = 0;
    for (const source of this.project.sources) {
      if (source.kind !== 'http') void this.loadSource(source.id);
      else if (source.auto) void this.loadSource(source.id);
      if (source.kind === 'http' && source.refreshSec && source.refreshSec >= 5) this.sourceTimers.push(this.win.setInterval(() => void this.loadSource(source.id), source.refreshSec * 1000));
    }
  }

  async loadSource(sourceId: string): Promise<unknown> {
    const source = this.project.sources.find((candidate) => candidate.id === sourceId || candidate.name === sourceId);
    if (!source) return undefined;
    try {
      const value = await this.readDataSource(source);
      this.data[source.name] = value;
      for (const variable of this.project.variables) {
        if (variable.source?.kind === 'source' && variable.source.sourceId === source.id) this.vars[variable.name] = coerce(variable, getPath(value, variable.source.path));
      }
      this.recomputeDerived();
      this.refreshDynamic();
      this.events.onVariables?.(this.vars);
      this.fireTrigger('varchange', null, { variable: `data.${source.name}`, value });
      return value;
    } catch (error) {
      this.report(`fonte de dados ${source.name}`, error);
      return undefined;
    }
  }

  private async readDataSource(source: DataSource): Promise<unknown> {
    if (source.kind === 'json') return getPath(JSON.parse(source.data || 'null') as unknown, source.path);
    if (source.kind === 'csv') return parseCsv(source.data ?? '');
    const scope = this.scope();
    const url = renderTemplate(source.url ?? '', scope);
    if (!url) throw new Error('a fonte não tem endereço');
    const headers = Object.fromEntries(Object.entries(source.headers ?? {}).map(([key, value]) => [key, renderTemplate(value, scope)]));
    const answer = await this.host.fetchText({ url: new URL(url, this.win.location.href).href, method: source.method ?? 'GET', headers, ...(source.body ? { body: renderTemplate(source.body, scope) } : {}) });
    if (!answer.ok) throw new Error(`o servidor respondeu ${answer.status}`);
    const format = source.format ?? 'json';
    if (format === 'csv') return parseCsv(answer.text);
    if (format === 'text') return answer.text;
    return getPath(JSON.parse(answer.text) as unknown, source.path);
  }

  // ---------------------------------------------------------------- regras (eventos e ações)

  private bindRules(): void {
    const on = (type: string, handler: (event: Event) => void, capture = true): void => {
      const listener = handler as EventListener;
      this.doc.addEventListener(type, listener, capture);
      this.listeners.push([type, listener, capture]);
    };
    const domTriggers: Record<string, string> = { click: 'click', dblclick: 'dblclick', submit: 'submit', change: 'change', input: 'input', keydown: 'keydown' };
    for (const [trigger, type] of Object.entries(domTriggers)) {
      on(type, (event) => {
        if (this.suspended) return;
        const origin = event.target instanceof Element ? event.target : null;
        if (origin && isOurs(origin) && !origin.closest('[data-wce-modal-body]')) return;
        this.handleDomEvent(trigger as Rule['trigger']['type'], event);
      });
    }
    on('mouseover', (event) => {
      if (this.suspended) return;
      const origin = event.target instanceof Element ? event.target : null;
      if (!origin || isOurs(origin)) return;
      const related = (event as MouseEvent).relatedTarget instanceof Element ? ((event as MouseEvent).relatedTarget as Element) : null;
      for (const rule of this.activeRules('hover')) {
        const matched = rule.trigger.selector ? origin.closest(rule.trigger.selector) : null;
        if (!matched || (related && matched.contains(related))) continue;
        void this.runRule(rule, event, matched);
      }
    });
    this.rebindTimers();
    this.watchVisible();
  }

  private rebindTimers(): void {
    // os temporizadores das regras ficam depois do primeiro (o do observador de endereço)
    const keep = this.timers.splice(0, 1);
    for (const timer of this.timers) this.win.clearInterval(timer);
    this.timers.length = 0;
    this.timers.push(...keep);
    for (const rule of this.project.rules) {
      if (!rule.enabled) continue;
      if (rule.trigger.type === 'interval') this.timers.push(this.win.setInterval(() => !this.suspended && void this.runRule(rule, null, null), Math.max(250, rule.trigger.ms ?? 1000)));
      if (rule.trigger.type === 'timeout') this.timers.push(this.win.setTimeout(() => !this.suspended && void this.runRule(rule, null, null), Math.max(0, rule.trigger.ms ?? 1000)));
    }
    this.intersection?.disconnect();
    this.intersection = null;
  }

  private watchVisible(): void {
    const rules = this.activeRules('visible');
    if (rules.length === 0) return;
    if (!this.intersection) {
      this.intersection = new IntersectionObserver((entries) => {
        for (const entry of entries) {
          if (!entry.isIntersecting) continue;
          for (const rule of this.activeRules('visible')) {
            if (rule.trigger.selector && entry.target.matches(rule.trigger.selector)) void this.runRule(rule, null, entry.target);
          }
        }
      });
    }
    for (const rule of rules) {
      for (const element of safeQueryAll(this.doc, rule.trigger.selector ?? '')) {
        if (this.watched.has(element)) continue;
        this.watched.add(element);
        this.intersection.observe(element);
      }
    }
  }

  private activeRules(type: Rule['trigger']['type']): Rule[] {
    return this.project.rules.filter((rule) => rule.enabled && rule.trigger.type === type && pageMatches(rule.page, this.win.location));
  }

  private handleDomEvent(type: Rule['trigger']['type'], event: Event): void {
    const origin = event.target instanceof Element ? event.target : null;
    for (const rule of this.activeRules(type)) {
      let matched: Element | null = null;
      if (rule.trigger.selector) {
        try {
          matched = origin?.closest(rule.trigger.selector) ?? null;
        } catch {
          matched = null;
        }
        if (!matched) continue;
      }
      if (type === 'keydown' && rule.trigger.key && !keyMatches(rule.trigger.key, event as KeyboardEvent)) continue;
      void this.runRule(rule, event, matched ?? origin);
    }
  }

  fireTrigger(type: Rule['trigger']['type'], element: Element | null, extra: Record<string, unknown> = {}): void {
    if (this.suspended) return;
    for (const rule of this.activeRules(type)) {
      if (type === 'varchange' && rule.trigger.variable && rule.trigger.variable !== extra.variable) continue;
      void this.runRule(rule, null, element, extra);
    }
  }

  private eventScope(event: Event | null, element: Element | null, extra: Record<string, unknown>): Record<string, unknown> {
    const info: Record<string, unknown> = { ...extra, type: event?.type ?? '' };
    if (element) {
      info.text = element.textContent?.trim() ?? '';
      info.id = element.id;
      info.data = { ...(element as HTMLElement).dataset };
      if (element instanceof HTMLInputElement || element instanceof HTMLSelectElement || element instanceof HTMLTextAreaElement) info.value = element.value;
      if (element instanceof HTMLInputElement) info.checked = element.checked;
      info.href = element.getAttribute('href') ?? '';
      const form = element instanceof HTMLFormElement ? element : element.closest('form');
      if (form) {
        const fields: Record<string, unknown> = {};
        new FormData(form).forEach((value, key) => {
          fields[key] = typeof value === 'string' ? value : value.name;
        });
        info.form = fields;
      }
      const repeated = element.closest('[data-wce-index]');
      if (repeated) info.index = Number(repeated.getAttribute('data-wce-index'));
    }
    if (event instanceof KeyboardEvent) info.key = event.key;
    return info;
  }

  async runRule(rule: Rule, event: Event | null, element: Element | null, extra: Record<string, unknown> = {}): Promise<void> {
    const eventInfo = this.eventScope(event, element, extra);
    if (rule.condition) {
      try {
        if (!truthy(run(rule.condition, this.scope({ event: eventInfo })))) return;
      } catch (error) {
        this.report(`condição da regra "${rule.name}"`, error);
        return;
      }
    }
    if (rule.preventDefault && event) {
      event.preventDefault();
      event.stopPropagation();
    }
    await this.runActions(rule.actions, eventInfo, rule.name, element);
  }

  async runActions(actions: readonly Action[], eventInfo: Record<string, unknown>, ruleName: string, element: Element | null = null): Promise<void> {
    for (const action of actions) {
      try {
        await this.runAction(action, eventInfo, ruleName, element);
      } catch (error) {
        this.report(`ação ${action.type} da regra "${ruleName}"`, error);
      }
    }
  }

  private targets(selector: string, element: Element | null): HTMLElement[] {
    if (selector === 'this' || selector === '') return element ? [element as HTMLElement] : [];
    return safeQueryAll(this.doc, selector).filter((candidate) => !isOurs(candidate) || candidate.closest('[data-wce-modal-body]')) as HTMLElement[];
  }

  private async runAction(action: Action, eventInfo: Record<string, unknown>, ruleName: string, element: Element | null): Promise<void> {
    const scope = (): Scope => this.scope({ event: eventInfo });
    const value = (expr: string): unknown => run(expr, scope());
    const text = (template: string): string => renderTemplate(template, scope());
    switch (action.type) {
      case 'set':
        this.setVariable(action.variable, value(action.expr));
        return;
      case 'toggle':
        this.setVariable(action.variable, toggled(this.project.variables.find((variable) => variable.name === action.variable), this.vars[action.variable]));
        return;
      case 'reset':
        this.resetVariable(action.variable);
        return;
      case 'push': {
        const current = Array.isArray(this.vars[action.variable]) ? (this.vars[action.variable] as unknown[]) : [];
        this.setVariable(action.variable, [...current, value(action.expr)]);
        return;
      }
      case 'show':
      case 'hide':
      case 'toggleVisible':
        for (const target of this.targets(action.selector, element)) {
          const hide = action.type === 'hide' || (action.type === 'toggleVisible' && !target.hasAttribute(RULE_HIDDEN) && target.offsetParent !== null);
          if (hide) target.setAttribute(RULE_HIDDEN, '');
          else {
            target.removeAttribute(RULE_HIDDEN);
            target.removeAttribute(HIDDEN);
          }
        }
        return;
      case 'addClass':
      case 'removeClass':
      case 'toggleClass':
        for (const target of this.targets(action.selector, element)) {
          if (action.type === 'addClass') target.classList.add(action.className);
          else if (action.type === 'removeClass') target.classList.remove(action.className);
          else target.classList.toggle(action.className);
        }
        return;
      case 'setText':
        for (const target of this.targets(action.selector, element)) target.textContent = toText(value(action.expr));
        return;
      case 'setHtml':
        for (const target of this.targets(action.selector, element)) {
          target.innerHTML = toText(value(action.expr));
          attachBehaviors(target, this);
        }
        return;
      case 'setAttr':
        for (const target of this.targets(action.selector, element)) target.setAttribute(action.name, toText(value(action.expr)));
        return;
      case 'setStyle':
        for (const target of this.targets(action.selector, element)) target.style.setProperty(action.prop, toText(value(action.expr)), 'important');
        return;
      case 'setValue':
        for (const target of this.targets(action.selector, element)) {
          const input = target as HTMLInputElement;
          input.value = toText(value(action.expr));
          input.dispatchEvent(new Event('input', { bubbles: true }));
          input.dispatchEvent(new Event('change', { bubbles: true }));
        }
        return;
      case 'click':
        this.targets(action.selector, element)[0]?.click();
        return;
      case 'focus':
        this.targets(action.selector, element)[0]?.focus();
        return;
      case 'scroll':
        this.targets(action.selector, element)[0]?.scrollIntoView({ behavior: 'smooth', block: 'center' });
        return;
      case 'navigate': {
        const url = toText(value(action.expr));
        if (!url) return;
        const absolute = new URL(url, this.win.location.href);
        if (!/^(https?|mailto|tel):$/.test(absolute.protocol)) throw new Error('endereço não permitido');
        if (action.newTab) this.win.open(absolute.href, '_blank', 'noopener');
        else this.win.location.assign(absolute.href);
        return;
      }
      case 'toast':
        this.ui.toast(toText(value(action.expr)), action.tone ?? 'info');
        return;
      case 'modal': {
        const body = this.ui.modal(text(action.title), renderTemplate(action.html, scope(), true));
        attachBehaviors(body, this);
        return;
      }
      case 'closeModal':
        this.ui.closeModal();
        return;
      case 'fetch':
        await this.loadSource(action.sourceId);
        return;
      case 'copy':
        await this.win.navigator.clipboard.writeText(toText(value(action.expr)));
        return;
      case 'delay':
        await new Promise((resolve) => this.win.setTimeout(resolve, Math.min(60000, Math.max(0, action.ms))));
        return;
      case 'log':
        this.events.onLog?.(`${ruleName}: ${toText(value(action.expr))}`);
        this.win.console.info('[Site Editor]', ruleName, value(action.expr));
        return;
      case 'script': {
        if (!this.host.runScript) throw new Error('scripts próprios não estão liberados neste navegador');
        const result = await this.host.runScript(action.code, { vars: { ...this.vars }, data: this.data, event: eventInfo, page: (this.scope() as Record<string, unknown>).page });
        if (result && typeof result === 'object' && 'set' in result && typeof (result as { set: unknown }).set === 'object') {
          for (const [name, next] of Object.entries((result as { set: Record<string, unknown> }).set)) this.setVariable(name, next);
        }
        return;
      }
      case 'if':
        await this.runActions(truthy(value(action.condition)) ? action.then : action.else, eventInfo, ruleName, element);
        return;
    }
  }

  private report(where: string, error: unknown): void {
    const message = error instanceof Error ? error.message : String(error);
    this.events.onError?.(where, message);
  }
}

export function isDynamicEdit(edit: Edit): boolean {
  if (edit.when) return true;
  switch (edit.op) {
    case 'bind':
    case 'repeat':
      return true;
    case 'text':
    case 'html':
      return edit.value.includes('{{');
    case 'attr':
      return (edit.value ?? '').includes('{{');
    case 'style':
      return Object.values(edit.props).some((value) => value.includes('{{'));
    case 'insert':
      return edit.html.includes('{{');
    case 'replace':
      return edit.replace.includes('{{');
    default:
      return false;
  }
}

function hash(text: string): string {
  let h = 5381;
  for (let i = 0; i < text.length; i += 1) h = ((h << 5) + h + text.charCodeAt(i)) | 0;
  return (h >>> 0).toString(36);
}

function placedAt(element: Element, ref: Element, position: string): boolean {
  if (position === 'before') return ref.previousSibling === element;
  if (position === 'after') return ref.nextSibling === element;
  if (position === 'prepend') return ref.firstChild === element;
  return ref.lastChild === element;
}

function place(node: Node, ref: Element, position: string): void {
  if (position === 'before') ref.parentNode?.insertBefore(node, ref);
  else if (position === 'after') ref.parentNode?.insertBefore(node, ref.nextSibling);
  else if (position === 'prepend') ref.insertBefore(node, ref.firstChild);
  else ref.appendChild(node);
}

function keyMatches(wanted: string, event: KeyboardEvent): boolean {
  const parts = wanted.toLowerCase().split('+').map((part) => part.trim());
  const key = parts.pop() ?? '';
  const mods = new Set(parts);
  if (mods.has('ctrl') !== event.ctrlKey || mods.has('shift') !== event.shiftKey || mods.has('alt') !== event.altKey || mods.has('meta') !== event.metaKey) return false;
  return event.key.toLowerCase() === key || event.code.toLowerCase() === key;
}

function toggled(definition: VariableDef | undefined, current: unknown): unknown {
  if (definition?.type === 'state' && definition.options && definition.options.length > 0) {
    const index = definition.options.indexOf(toText(current));
    return definition.options[(index + 1) % definition.options.length];
  }
  return !truthy(current);
}

export function coerce(definition: VariableDef, value: unknown): unknown {
  switch (definition.type) {
    case 'number': {
      if (typeof value === 'number') return value;
      const n = Number(toText(value).replace(',', '.'));
      return Number.isFinite(n) ? n : 0;
    }
    case 'boolean':
      return typeof value === 'boolean' ? value : truthy(value);
    case 'list':
      if (Array.isArray(value)) return value;
      if (typeof value === 'string') {
        try {
          const parsed = JSON.parse(value) as unknown;
          if (Array.isArray(parsed)) return parsed;
        } catch {
          return value
            .split(/\n|,/)
            .map((part) => part.trim())
            .filter(Boolean);
        }
      }
      return value === null || value === undefined ? [] : [value];
    case 'json':
      if (typeof value === 'string') {
        try {
          return JSON.parse(value) as unknown;
        } catch {
          return value;
        }
      }
      return value;
    case 'state':
    case 'text':
    case 'color':
    case 'image':
    case 'url':
      return value === null || value === undefined ? '' : typeof value === 'string' ? value : toText(value);
  }
}
