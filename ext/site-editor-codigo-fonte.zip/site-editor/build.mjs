// Monta a extensão em dist/chrome (ou dist/firefox com --target=firefox) e o motor avulso em dist/runtime.
// node build.mjs [--target=firefox] [--zip] [--watch]
// Os scripts de conteúdo não podem ser módulos ES (developer.chrome.com/docs/extensions/develop/concepts/content-scripts),
// então tudo sai em IIFE; o service worker também, o que serve igual à página de eventos do Firefox.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import * as esbuild from 'esbuild';
import { makeZipNode } from './tools/zip-node.mjs';

const root = path.dirname(fileURLToPath(import.meta.url));
const args = new Set(process.argv.slice(2));
const target = [...args].find((arg) => arg.startsWith('--target='))?.split('=')[1] ?? 'chrome';
const out = path.join(root, 'dist', target);
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));

const entries = {
  content: 'src/content/content.ts',
  editor: 'src/editor/editor.ts',
  background: 'src/background/background.ts',
  popup: 'src/popup/popup.ts',
  manager: 'src/manager/manager.ts',
  'wc-runtime': 'src/runtime/runtime.ts',
};

function manifest() {
  const base = {
    manifest_version: 3,
    name: 'Webconstructor Site Editor',
    short_name: 'Site Editor',
    version: pkg.version,
    description: 'Edite qualquer site, sistema ou aplicação web e salve as alterações: textos, imagens, estilos, componentes, variáveis, estados, eventos e dados, com um conteúdo para cada cliente.',
    icons: { 16: 'icons/16.png', 32: 'icons/32.png', 48: 'icons/48.png', 128: 'icons/128.png' },
    permissions: ['storage', 'unlimitedStorage', 'scripting', 'activeTab', 'contextMenus', 'tabs'],
    host_permissions: ['<all_urls>'],
    content_scripts: [{ matches: ['<all_urls>'], js: ['content.js'], run_at: 'document_start', all_frames: true }],
    action: { default_title: 'Site Editor', default_popup: 'popup.html', default_icon: { 16: 'icons/16.png', 32: 'icons/32.png' } },
    options_ui: { page: 'manager.html', open_in_tab: true },
    commands: {
      'toggle-editor': { suggested_key: { default: 'Alt+Shift+E' }, description: 'Abrir ou fechar o editor nesta página' },
    },
  };
  if (target === 'firefox') {
    return {
      ...base,
      background: { scripts: ['background.js'] },
      optional_permissions: ['userScripts'],
      browser_specific_settings: { gecko: { id: 'site-editor@webconstructor.app', strict_min_version: '128.0' } },
    };
  }
  return { ...base, permissions: [...base.permissions, 'userScripts'], background: { service_worker: 'background.js' }, minimum_chrome_version: '120' };
}

async function build() {
  fs.rmSync(out, { recursive: true, force: true });
  fs.mkdirSync(out, { recursive: true });
  await esbuild.build({
    absWorkingDir: root,
    entryPoints: entries,
    outdir: out,
    bundle: true,
    format: 'iife',
    target: ['chrome120', 'firefox128'],
    sourcemap: false,
    minify: false,
    legalComments: 'none',
    logLevel: 'warning',

  });
  // o motor avulso também minificado, para os sites
  await esbuild.build({ absWorkingDir: root, entryPoints: { 'wc-runtime.min': entries['wc-runtime'] }, outdir: out, bundle: true, format: 'iife', target: ['es2020'], minify: true, legalComments: 'none' });
  for (const page of ['popup.html', 'manager.html']) fs.copyFileSync(path.join(root, 'src', page.replace('.html', ''), page), path.join(out, page));
  fs.cpSync(path.join(root, 'icons'), path.join(out, 'icons'), { recursive: true });
  fs.writeFileSync(path.join(out, 'manifest.json'), JSON.stringify(manifest(), null, 2));
  const runtimeDir = path.join(root, 'dist', 'runtime');
  fs.mkdirSync(runtimeDir, { recursive: true });
  for (const file of ['wc-runtime.js', 'wc-runtime.min.js']) fs.copyFileSync(path.join(out, file), path.join(runtimeDir, file));
  if (args.has('--zip')) {
    const zipPath = path.join(root, 'dist', `site-editor-${target}-${pkg.version}.zip`);
    fs.writeFileSync(zipPath, makeZipNode(out));
    console.log(`pacote: ${path.relative(root, zipPath)}`);
  }
  console.log(`extensão (${target}) em ${path.relative(root, out)}`);
}

await build();
