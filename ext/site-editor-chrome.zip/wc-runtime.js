"use strict";
(() => {
  // src/shared/model.ts
  var FORMAT_VERSION = 1;
  function uid(prefix = "") {
    const random = crypto.getRandomValues(new Uint8Array(8));
    return prefix + Array.from(random, (b) => b.toString(16).padStart(2, "0")).join("");
  }
  function newProject(name, matches) {
    const now = Date.now();
    const client = { id: uid("c_"), name: "Padr\xE3o", values: {} };
    return {
      format: FORMAT_VERSION,
      id: uid("p_"),
      name,
      matches,
      enabled: true,
      clients: [client],
      activeClientId: client.id,
      variables: [],
      edits: [],
      rules: [],
      sources: [],
      css: "",
      scripts: [],
      createdAt: now,
      updatedAt: now
    };
  }
  function normalizeProject(raw) {
    if (typeof raw !== "object" || raw === null) throw new Error("O arquivo n\xE3o cont\xE9m um projeto.");
    const input = raw;
    if (typeof input.name !== "string" || input.name.trim() === "") throw new Error("O projeto n\xE3o tem nome.");
    const base = newProject(input.name, []);
    const list = (value) => Array.isArray(value) ? value : [];
    const project = {
      ...base,
      ...input,
      format: FORMAT_VERSION,
      id: typeof input.id === "string" && input.id ? input.id : base.id,
      matches: list(input.matches).filter((m) => typeof m === "string"),
      enabled: input.enabled !== false,
      clients: list(input.clients),
      variables: list(input.variables),
      edits: list(input.edits),
      rules: list(input.rules),
      sources: list(input.sources),
      scripts: list(input.scripts),
      css: typeof input.css === "string" ? input.css : "",
      createdAt: typeof input.createdAt === "number" ? input.createdAt : base.createdAt,
      updatedAt: typeof input.updatedAt === "number" ? input.updatedAt : base.updatedAt
    };
    if (project.clients.length === 0) project.clients = base.clients;
    if (project.activeClientId === null || !project.clients.some((c) => c.id === project.activeClientId)) project.activeClientId = project.clients[0]?.id ?? null;
    for (const edit of project.edits) {
      if (typeof edit.target?.selector !== "string") throw new Error("Uma altera\xE7\xE3o do projeto n\xE3o tem seletor.");
      if (edit.enabled === void 0) edit.enabled = true;
    }
    return project;
  }
  function activeClient(project, clientId) {
    const id = clientId ?? project.activeClientId;
    return project.clients.find((c) => c.id === id) ?? project.clients[0] ?? null;
  }

  // src/shared/expr.ts
  var OPERATORS = ["===", "!==", "==", "!=", "<=", ">=", "&&", "||", "??", "?.", "<", ">", "+", "-", "*", "/", "%", "!", "?", ":", ".", ",", "(", ")", "[", "]", "{", "}", "|"];
  var ExpressionError = class extends Error {
  };
  function lex(source) {
    const tokens = [];
    let at = 0;
    while (at < source.length) {
      const ch = source[at] ?? "";
      if (/\s/.test(ch)) {
        at += 1;
        continue;
      }
      if (/[0-9]/.test(ch) || ch === "." && /[0-9]/.test(source[at + 1] ?? "")) {
        const match = /^(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?/.exec(source.slice(at));
        const text = match?.[0] ?? ch;
        tokens.push({ t: "num", v: Number(text) });
        at += text.length;
        continue;
      }
      if (ch === '"' || ch === "'" || ch === "`") {
        let value = "";
        let end = at + 1;
        while (end < source.length && source[end] !== ch) {
          if (source[end] === "\\") {
            const next = source[end + 1] ?? "";
            value += next === "n" ? "\n" : next === "t" ? "	" : next;
            end += 2;
          } else {
            value += source[end];
            end += 1;
          }
        }
        if (end >= source.length) throw new ExpressionError("Texto sem aspas de fechamento.");
        tokens.push({ t: "str", v: value });
        at = end + 1;
        continue;
      }
      if (/[A-Za-z_$\u00C0-\u024F]/.test(ch)) {
        const match = /^[A-Za-z_$\u00C0-\u024F][A-Za-z0-9_$\u00C0-\u024F]*/.exec(source.slice(at));
        const text = match?.[0] ?? ch;
        tokens.push({ t: "id", v: text });
        at += text.length;
        continue;
      }
      const op = OPERATORS.find((candidate) => source.startsWith(candidate, at));
      if (op === void 0) throw new ExpressionError(`Caractere inesperado: ${ch}`);
      tokens.push({ t: "op", v: op });
      at += op.length;
    }
    tokens.push({ t: "end" });
    return tokens;
  }
  var BINARY = {
    "|": 1,
    "??": 3,
    "||": 4,
    "&&": 5,
    "==": 6,
    "!=": 6,
    "===": 6,
    "!==": 6,
    "<": 7,
    ">": 7,
    "<=": 7,
    ">=": 7,
    "+": 8,
    "-": 8,
    "*": 9,
    "/": 9,
    "%": 9
  };
  var Parser = class {
    constructor(tokens) {
      this.tokens = tokens;
    }
    at = 0;
    peek() {
      return this.tokens[this.at] ?? { t: "end" };
    }
    next() {
      const token = this.peek();
      this.at += 1;
      return token;
    }
    isOp(value) {
      const token = this.peek();
      return token.t === "op" && token.v === value;
    }
    expect(value) {
      if (!this.isOp(value)) throw new ExpressionError(`Esperava "${value}".`);
      this.at += 1;
    }
    parseAll() {
      const node = this.expression(0);
      if (this.peek().t !== "end") throw new ExpressionError("Sobrou texto depois da express\xE3o.");
      return node;
    }
    expression(minPrecedence) {
      let left = this.unary();
      for (; ; ) {
        const token = this.peek();
        if (token.t === "op" && token.v === "?" && minPrecedence <= 2) {
          this.next();
          const yes = this.expression(0);
          this.expect(":");
          const no = this.expression(2);
          left = { k: "cond", test: left, yes, no };
          continue;
        }
        if (token.t !== "op") break;
        const precedence = BINARY[token.v];
        if (precedence === void 0 || precedence < minPrecedence) break;
        this.next();
        if (token.v === "|") {
          const name = this.next();
          if (name.t !== "id") throw new ExpressionError('Esperava o nome de um filtro depois de "|".');
          const args = [left];
          if (this.isOp("(")) args.push(...this.args());
          left = { k: "call", fn: name.v, args };
          continue;
        }
        const right = this.expression(precedence + 1);
        left = { k: "binary", op: token.v, left, right };
      }
      return left;
    }
    args() {
      this.expect("(");
      const args = [];
      while (!this.isOp(")")) {
        args.push(this.expression(2));
        if (!this.isOp(")")) this.expect(",");
      }
      this.expect(")");
      return args;
    }
    unary() {
      const token = this.peek();
      if (token.t === "op" && (token.v === "!" || token.v === "-" || token.v === "+")) {
        this.next();
        return { k: "unary", op: token.v, arg: this.unary() };
      }
      return this.postfix(this.primary());
    }
    postfix(start) {
      let node = start;
      for (; ; ) {
        if (this.isOp(".") || this.isOp("?.")) {
          const optional = this.isOp("?.");
          this.next();
          const name = this.next();
          if (name.t !== "id") throw new ExpressionError("Esperava um nome depois do ponto.");
          node = { k: "member", obj: node, prop: { k: "lit", v: name.v }, optional };
        } else if (this.isOp("[")) {
          this.next();
          const prop = this.expression(0);
          this.expect("]");
          node = { k: "member", obj: node, prop, optional: false };
        } else break;
      }
      return node;
    }
    primary() {
      const token = this.next();
      switch (token.t) {
        case "num":
        case "str":
          return { k: "lit", v: token.v };
        case "id": {
          if (token.v === "true") return { k: "lit", v: true };
          if (token.v === "false") return { k: "lit", v: false };
          if (token.v === "null" || token.v === "undefined") return { k: "lit", v: null };
          if (this.isOp("(")) return { k: "call", fn: token.v, args: this.args() };
          return { k: "name", v: token.v };
        }
        case "op": {
          if (token.v === "(") {
            const inner = this.expression(0);
            this.expect(")");
            return inner;
          }
          if (token.v === "[") {
            const items = [];
            while (!this.isOp("]")) {
              items.push(this.expression(2));
              if (!this.isOp("]")) this.expect(",");
            }
            this.expect("]");
            return { k: "array", items };
          }
          if (token.v === "{") {
            const entries = [];
            while (!this.isOp("}")) {
              const key = this.next();
              if (key.t !== "id" && key.t !== "str") throw new ExpressionError("Esperava o nome de um campo.");
              this.expect(":");
              entries.push([String(key.v), this.expression(2)]);
              if (!this.isOp("}")) this.expect(",");
            }
            this.expect("}");
            return { k: "object", entries };
          }
          throw new ExpressionError(`S\xEDmbolo inesperado: ${token.v}`);
        }
        default:
          throw new ExpressionError("A express\xE3o terminou cedo demais.");
      }
    }
  };
  var cache = /* @__PURE__ */ new Map();
  function parse(source) {
    const hit = cache.get(source);
    if (hit) return hit;
    const node = new Parser(lex(source)).parseAll();
    if (cache.size > 2e3) cache.clear();
    cache.set(source, node);
    return node;
  }
  var BLOCKED = /* @__PURE__ */ new Set(["__proto__", "constructor", "prototype"]);
  function member(obj, prop) {
    if (obj === null || obj === void 0) return void 0;
    const key = String(prop);
    if (BLOCKED.has(key)) return void 0;
    if (typeof obj === "string") {
      if (key === "length") return obj.length;
      const index = Number(key);
      return Number.isInteger(index) ? obj[index] : void 0;
    }
    if (Array.isArray(obj) && key === "length") return obj.length;
    if (typeof obj !== "object") return void 0;
    return Object.prototype.hasOwnProperty.call(obj, key) ? obj[key] : void 0;
  }
  function truthy(value) {
    if (Array.isArray(value)) return value.length > 0;
    if (value === "false" || value === "0") return false;
    return Boolean(value);
  }
  function num(value) {
    if (typeof value === "number") return value;
    if (typeof value === "string") {
      const cleaned = value.trim().replace(/\s/g, "");
      if (/^-?[\d.]+,\d+$/.test(cleaned)) return Number(cleaned.replace(/\./g, "").replace(",", "."));
      return Number(cleaned.replace(/,/g, ""));
    }
    if (typeof value === "boolean") return value ? 1 : 0;
    return Number(value);
  }
  function toText(value) {
    if (value === null || value === void 0) return "";
    if (typeof value === "string") return value;
    if (typeof value === "number") return Number.isFinite(value) ? String(value) : "";
    if (typeof value === "boolean") return value ? "true" : "false";
    if (value instanceof Date) return value.toISOString();
    return JSON.stringify(value);
  }
  function looseEqual(a, b) {
    if (a === b) return true;
    if (a === null || a === void 0 || b === null || b === void 0) return (a ?? null) === (b ?? null);
    if (typeof a === "object" || typeof b === "object") return JSON.stringify(a) === JSON.stringify(b);
    return toText(a) === toText(b);
  }
  function toDate(value) {
    if (value instanceof Date) return value;
    if (typeof value === "number") return new Date(value);
    if (typeof value === "string" && /^\d{2}\/\d{2}\/\d{4}/.test(value)) {
      const [d, m, y] = value.split(/[/\s]/);
      return new Date(Number(y), Number(m) - 1, Number(d));
    }
    return value === void 0 || value === null || value === "" ? /* @__PURE__ */ new Date() : new Date(String(value));
  }
  function pad(n, size = 2) {
    return String(n).padStart(size, "0");
  }
  function formatDate(value, pattern = "dd/MM/yyyy") {
    const date = toDate(value);
    if (Number.isNaN(date.getTime())) return "";
    const months = ["janeiro", "fevereiro", "mar\xE7o", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"];
    const days = ["domingo", "segunda-feira", "ter\xE7a-feira", "quarta-feira", "quinta-feira", "sexta-feira", "s\xE1bado"];
    const parts = {
      yyyy: String(date.getFullYear()),
      yy: String(date.getFullYear()).slice(-2),
      MMMM: months[date.getMonth()] ?? "",
      MMM: (months[date.getMonth()] ?? "").slice(0, 3),
      MM: pad(date.getMonth() + 1),
      M: String(date.getMonth() + 1),
      dddd: days[date.getDay()] ?? "",
      dd: pad(date.getDate()),
      d: String(date.getDate()),
      HH: pad(date.getHours()),
      H: String(date.getHours()),
      mm: pad(date.getMinutes()),
      ss: pad(date.getSeconds())
    };
    return pattern.replace(/yyyy|yy|MMMM|MMM|MM|M|dddd|dd|d|HH|H|mm|ss/g, (token) => parts[token] ?? token);
  }
  function pick(item, field) {
    if (field === void 0 || field === null || field === "") return item;
    return String(field).split(".").reduce((value, key) => member(value, key), item);
  }
  function asList(value) {
    if (Array.isArray(value)) return value;
    if (value === null || value === void 0 || value === "") return [];
    if (typeof value === "object") return Object.values(value);
    return [value];
  }
  var FUNCTIONS = {
    upper: (v) => toText(v).toUpperCase(),
    lower: (v) => toText(v).toLowerCase(),
    capitalize: (v) => toText(v).replace(new RegExp("(^|\\s)(\\p{L})", "gu"), (_m, s, c) => s + c.toUpperCase()),
    trim: (v) => toText(v).trim(),
    len: (v) => Array.isArray(v) ? v.length : typeof v === "object" && v !== null ? Object.keys(v).length : toText(v).length,
    default: (v, fallback) => v === null || v === void 0 || v === "" ? fallback : v,
    money: (v, currency = "BRL", locale = "pt-BR") => {
      const n = num(v);
      return Number.isFinite(n) ? n.toLocaleString(String(locale), { style: "currency", currency: String(currency) }) : "";
    },
    number: (v, decimals = 0, locale = "pt-BR") => {
      const n = num(v);
      const d = num(decimals);
      return Number.isFinite(n) ? n.toLocaleString(String(locale), { minimumFractionDigits: d, maximumFractionDigits: d }) : "";
    },
    percent: (v, decimals = 0) => {
      const n = num(v);
      return Number.isFinite(n) ? `${n.toLocaleString("pt-BR", { maximumFractionDigits: num(decimals) })}%` : "";
    },
    date: (v, pattern) => formatDate(v, pattern === void 0 ? "dd/MM/yyyy" : toText(pattern)),
    datetime: (v) => formatDate(v, "dd/MM/yyyy HH:mm"),
    now: () => Date.now(),
    today: () => formatDate(/* @__PURE__ */ new Date(), "dd/MM/yyyy"),
    addDays: (v, days) => {
      const date = toDate(v);
      date.setDate(date.getDate() + num(days));
      return date.getTime();
    },
    daysBetween: (a, b) => Math.round((toDate(b).getTime() - toDate(a).getTime()) / 864e5),
    round: (v, decimals = 0) => {
      const factor = 10 ** num(decimals);
      return Math.round(num(v) * factor) / factor;
    },
    floor: (v) => Math.floor(num(v)),
    ceil: (v) => Math.ceil(num(v)),
    abs: (v) => Math.abs(num(v)),
    min: (...v) => Math.min(...(v.length === 1 ? asList(v[0]) : v).map(num)),
    max: (...v) => Math.max(...(v.length === 1 ? asList(v[0]) : v).map(num)),
    sum: (list, field) => asList(list).reduce((total, item) => total + (num(pick(item, field)) || 0), 0),
    avg: (list, field) => {
      const items = asList(list);
      return items.length === 0 ? 0 : items.reduce((total, item) => total + (num(pick(item, field)) || 0), 0) / items.length;
    },
    count: (list, field, value) => field === void 0 ? asList(list).length : asList(list).filter((item) => looseEqual(pick(item, field), value)).length,
    int: (v) => Math.trunc(num(v)) || 0,
    float: (v) => num(v) || 0,
    str: (v) => toText(v),
    bool: (v) => truthy(v),
    json: (v) => JSON.stringify(v, null, 2),
    parse: (v) => {
      try {
        return JSON.parse(toText(v));
      } catch {
        return null;
      }
    },
    join: (list, separator = ", ") => asList(list).map(toText).join(toText(separator)),
    split: (v, separator = ",") => toText(v).split(toText(separator)).map((part) => part.trim()),
    includes: (haystack, needle) => Array.isArray(haystack) ? haystack.some((item) => looseEqual(item, needle)) : toText(haystack).toLowerCase().includes(toText(needle).toLowerCase()),
    startsWith: (v, prefix) => toText(v).startsWith(toText(prefix)),
    endsWith: (v, suffix) => toText(v).endsWith(toText(suffix)),
    replace: (v, find, replacement = "") => toText(v).split(toText(find)).join(toText(replacement)),
    slice: (v, start = 0, end) => Array.isArray(v) ? v.slice(num(start), end === void 0 ? void 0 : num(end)) : toText(v).slice(num(start), end === void 0 ? void 0 : num(end)),
    truncate: (v, size = 80) => {
      const text = toText(v);
      const max = num(size);
      return text.length > max ? `${text.slice(0, Math.max(0, max - 1))}\u2026` : text;
    },
    first: (v) => asList(v)[0],
    last: (v) => asList(v).at(-1),
    keys: (v) => typeof v === "object" && v !== null ? Object.keys(v) : [],
    values: (v) => asList(v),
    map: (list, field) => asList(list).map((item) => pick(item, field)),
    filter: (list, field, value) => asList(list).filter((item) => value === void 0 ? truthy(pick(item, field)) : looseEqual(pick(item, field), value)),
    search: (list, text, field) => {
      const needle = toText(text).toLowerCase();
      if (!needle) return asList(list);
      return asList(list).filter((item) => toText(field === void 0 ? item : pick(item, field)).toLowerCase().includes(needle));
    },
    find: (list, field, value) => asList(list).find((item) => looseEqual(pick(item, field), value)),
    sort: (list, field, direction = "asc") => {
      const items = [...asList(list)];
      const sign = toText(direction) === "desc" ? -1 : 1;
      return items.sort((a, b) => {
        const x = pick(a, field);
        const y = pick(b, field);
        const nx = num(x);
        const ny = num(y);
        if (Number.isFinite(nx) && Number.isFinite(ny)) return (nx - ny) * sign;
        return toText(x).localeCompare(toText(y), "pt-BR") * sign;
      });
    },
    reverse: (list) => [...asList(list)].reverse(),
    unique: (list) => [...new Set(asList(list).map((item) => JSON.stringify(item)))].map((item) => JSON.parse(item)),
    range: (a, b) => {
      const start = b === void 0 ? 0 : num(a);
      const end = b === void 0 ? num(a) : num(b);
      const out = [];
      for (let i = start; i < end && out.length < 1e4; i += 1) out.push(i);
      return out;
    },
    concat: (...v) => Array.isArray(v[0]) ? v.flatMap(asList) : v.map(toText).join(""),
    if: (test, yes, no) => truthy(test) ? yes : no,
    random: (a, b) => a === void 0 ? Math.random() : Math.floor(num(a) + Math.random() * (num(b ?? a) - num(b === void 0 ? 0 : a) + 1)),
    uuid: () => crypto.randomUUID(),
    encode: (v) => encodeURIComponent(toText(v)),
    escape: (v) => escapeHtml(toText(v)),
    pluralize: (n, one, many) => num(n) === 1 ? toText(one) : toText(many),
    initials: (v) => toText(v).split(/\s+/).filter(Boolean).slice(0, 2).map((part) => part[0]?.toUpperCase() ?? "").join(""),
    cpf: (v) => toText(v).replace(/\D/g, "").replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4"),
    cnpj: (v) => toText(v).replace(/\D/g, "").replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, "$1.$2.$3/$4-$5"),
    phone: (v) => {
      const digits = toText(v).replace(/\D/g, "");
      return digits.length === 11 ? digits.replace(/(\d{2})(\d{5})(\d{4})/, "($1) $2-$3") : digits.replace(/(\d{2})(\d{4})(\d{4})/, "($1) $2-$3");
    }
  };
  function evaluate(node, scope) {
    switch (node.k) {
      case "lit":
        return node.v;
      case "name":
        if (Object.prototype.hasOwnProperty.call(scope, node.v)) return scope[node.v];
        if (node.v === "Infinity") return Infinity;
        return void 0;
      case "member":
        return member(evaluate(node.obj, scope), evaluate(node.prop, scope));
      case "array":
        return node.items.map((item) => evaluate(item, scope));
      case "object":
        return Object.fromEntries(node.entries.filter(([key]) => !BLOCKED.has(key)).map(([key, value]) => [key, evaluate(value, scope)]));
      case "call": {
        const fn = FUNCTIONS[node.fn];
        if (!fn) throw new ExpressionError(`Fun\xE7\xE3o desconhecida: ${node.fn}`);
        return fn(...node.args.map((arg) => evaluate(arg, scope)));
      }
      case "unary": {
        const value = evaluate(node.arg, scope);
        if (node.op === "!") return !truthy(value);
        if (node.op === "-") return -num(value);
        return num(value);
      }
      case "cond":
        return truthy(evaluate(node.test, scope)) ? evaluate(node.yes, scope) : evaluate(node.no, scope);
      case "binary": {
        if (node.op === "&&") {
          const left2 = evaluate(node.left, scope);
          return truthy(left2) ? evaluate(node.right, scope) : left2;
        }
        if (node.op === "||") {
          const left2 = evaluate(node.left, scope);
          return truthy(left2) ? left2 : evaluate(node.right, scope);
        }
        if (node.op === "??") {
          const left2 = evaluate(node.left, scope);
          return left2 === null || left2 === void 0 ? evaluate(node.right, scope) : left2;
        }
        const left = evaluate(node.left, scope);
        const right = evaluate(node.right, scope);
        switch (node.op) {
          case "+": {
            if (Array.isArray(left)) return [...left, ...asList(right)];
            const bothNumeric = (typeof left === "number" || typeof left === "boolean") && (typeof right === "number" || typeof right === "boolean");
            return bothNumeric ? num(left) + num(right) : toText(left) + toText(right);
          }
          case "-":
            return num(left) - num(right);
          case "*":
            return num(left) * num(right);
          case "/":
            return num(right) === 0 ? 0 : num(left) / num(right);
          case "%":
            return num(right) === 0 ? 0 : num(left) % num(right);
          case "==":
          case "===":
            return looseEqual(left, right);
          case "!=":
          case "!==":
            return !looseEqual(left, right);
          case "<":
          case ">":
          case "<=":
          case ">=": {
            const numeric = Number.isFinite(num(left)) && Number.isFinite(num(right)) && left !== "" && right !== "";
            const a = numeric ? num(left) : toText(left);
            const b = numeric ? num(right) : toText(right);
            if (node.op === "<") return a < b;
            if (node.op === ">") return a > b;
            if (node.op === "<=") return a <= b;
            return a >= b;
          }
          default:
            throw new ExpressionError(`Operador desconhecido: ${node.op}`);
        }
      }
    }
  }
  function run(source, scope) {
    if (source.trim() === "") return void 0;
    return evaluate(parse(source), scope);
  }
  function escapeHtml(text) {
    return text.replace(/[&<>"']/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[ch] ?? ch);
  }
  var TEMPLATE = /\{\{\{([\s\S]+?)\}\}\}|\{\{([\s\S]+?)\}\}/g;
  function renderTemplate(text, scope, html = false) {
    if (!text.includes("{{")) return text;
    return text.replace(TEMPLATE, (_match, raw, escaped) => {
      const source = (raw ?? escaped ?? "").trim();
      let value;
      try {
        value = run(source, scope);
      } catch {
        value = "";
      }
      const textValue = toText(value);
      return html && raw === void 0 ? escapeHtml(textValue) : textValue;
    });
  }
  function namesIn(source, isTemplate) {
    const names = /* @__PURE__ */ new Set();
    const visit = (node) => {
      switch (node.k) {
        case "name":
          names.add(node.v);
          break;
        case "member":
          visit(node.obj);
          visit(node.prop);
          break;
        case "call":
          node.args.forEach(visit);
          if (node.fn === "now" || node.fn === "today" || node.fn === "random" || node.fn === "uuid") names.add("now");
          break;
        case "unary":
          visit(node.arg);
          break;
        case "binary":
          visit(node.left);
          visit(node.right);
          break;
        case "cond":
          visit(node.test);
          visit(node.yes);
          visit(node.no);
          break;
        case "array":
          node.items.forEach(visit);
          break;
        case "object":
          node.entries.forEach(([, value]) => visit(value));
          break;
        case "lit":
          break;
      }
    };
    const sources = isTemplate ? [...source.matchAll(TEMPLATE)].map((m) => (m[1] ?? m[2] ?? "").trim()) : [source];
    for (const piece of sources) {
      try {
        if (piece) visit(parse(piece));
      } catch {
      }
    }
    return names;
  }
  function parseCsv(text) {
    const firstLine = text.split(/\r?\n/, 1)[0] ?? "";
    const separator = (firstLine.match(/;/g)?.length ?? 0) > (firstLine.match(/,/g)?.length ?? 0) ? ";" : ",";
    const rows = [];
    let row = [];
    let cell = "";
    let quoted = false;
    for (let i = 0; i < text.length; i += 1) {
      const ch = text[i];
      if (quoted) {
        if (ch === '"' && text[i + 1] === '"') {
          cell += '"';
          i += 1;
        } else if (ch === '"') quoted = false;
        else cell += ch;
      } else if (ch === '"') quoted = true;
      else if (ch === separator) {
        row.push(cell);
        cell = "";
      } else if (ch === "\n" || ch === "\r") {
        if (ch === "\r" && text[i + 1] === "\n") i += 1;
        row.push(cell);
        rows.push(row);
        row = [];
        cell = "";
      } else cell += ch;
    }
    if (cell !== "" || row.length > 0) {
      row.push(cell);
      rows.push(row);
    }
    const [header, ...body] = rows.filter((r) => r.some((c) => c.trim() !== ""));
    if (!header) return [];
    const keys = header.map((h) => h.trim());
    return body.map((cells) => Object.fromEntries(keys.map((key, index) => [key, (cells[index] ?? "").trim()])));
  }
  function getPath(source, path) {
    return pick(source, path);
  }

  // src/shared/match.ts
  function globToRegex(glob) {
    const escaped = glob.replace(/[.+^${}()|[\]\\?]/g, "\\$&").replace(/\*/g, ".*");
    return new RegExp(`^${escaped}$`, "i");
  }
  function urlMatches(pattern, href) {
    const trimmed = pattern.trim();
    if (trimmed === "") return false;
    if (trimmed === "<all_urls>" || trimmed === "*") return /^(https?|file):/.test(href);
    if (trimmed.length > 2 && trimmed.startsWith("/") && trimmed.lastIndexOf("/") > 0) {
      const end = trimmed.lastIndexOf("/");
      try {
        return new RegExp(trimmed.slice(1, end), trimmed.slice(end + 1)).test(href);
      } catch {
        return false;
      }
    }
    let url;
    try {
      url = new URL(href);
    } catch {
      return false;
    }
    const scheme = /^([a-z*]+):\/\//i.exec(trimmed);
    if (scheme) {
      const wantedScheme = (scheme[1] ?? "").toLowerCase();
      if (wantedScheme !== "*" && wantedScheme !== url.protocol.replace(":", "")) return false;
      if (wantedScheme === "*" && !/^https?:$/.test(url.protocol)) return false;
      const rest = trimmed.slice(scheme[0].length);
      const slash = rest.indexOf("/");
      const hostPattern = slash === -1 ? rest : rest.slice(0, slash);
      const pathPattern = slash === -1 ? "/*" : rest.slice(slash);
      const host2 = hostPattern.replace(/:(\d+|\*)$/, "").toLowerCase();
      const port = /:(\d+)$/.exec(hostPattern)?.[1];
      if (port !== void 0 && port !== url.port) return false;
      const hostOk = host2 === "*" || (host2.startsWith("*.") ? url.hostname === host2.slice(2) || url.hostname.endsWith(host2.slice(1)) : globToRegex(host2).test(url.hostname));
      if (!hostOk) return false;
      return globToRegex(pathPattern).test(url.pathname + url.search + url.hash) || globToRegex(pathPattern).test(url.pathname);
    }
    const withoutScheme = href.replace(/^[a-z]+:\/\//i, "");
    return globToRegex(trimmed).test(withoutScheme) || globToRegex(trimmed.endsWith("*") ? trimmed : `${trimmed}*`).test(withoutScheme);
  }
  function anyMatches(patterns, href) {
    return patterns.some((pattern) => urlMatches(pattern, href));
  }
  function pageMatches(pattern, location2) {
    if (pattern === void 0 || pattern.trim() === "" || pattern.trim() === "*") return true;
    const trimmed = pattern.trim();
    const regex = globToRegex(trimmed);
    return regex.test(location2.pathname) || regex.test(location2.pathname + location2.search) || regex.test(location2.pathname + location2.search + location2.hash) || trimmed.startsWith("#") && regex.test(location2.hash);
  }

  // src/shared/selector.ts
  function safeQueryAll(root, selector) {
    try {
      return Array.from(root.querySelectorAll(selector));
    } catch {
      return [];
    }
  }

  // src/engine/behaviors.ts
  var ready = /* @__PURE__ */ new WeakSet();
  function once(element) {
    if (ready.has(element)) return false;
    ready.add(element);
    return true;
  }
  function carousel(root) {
    const track = root.querySelector("[data-wce-track]") ?? root;
    const slides = Array.from(track.querySelectorAll(":scope > [data-wce-slide]"));
    if (slides.length === 0) return;
    const dots = root.querySelector("[data-wce-dots]");
    let index = 0;
    const show = (next) => {
      index = (next + slides.length) % slides.length;
      slides.forEach((slide, at) => {
        slide.style.display = at === index ? "" : "none";
        slide.setAttribute("aria-hidden", String(at !== index));
      });
      dots?.querySelectorAll("button").forEach((dot, at) => dot.setAttribute("aria-current", String(at === index)));
    };
    if (dots) {
      dots.replaceChildren(
        ...slides.map((_slide, at) => {
          const dot = root.ownerDocument.createElement("button");
          dot.type = "button";
          dot.setAttribute("aria-label", `Slide ${at + 1}`);
          dot.addEventListener("click", () => show(at));
          return dot;
        })
      );
    }
    root.querySelector("[data-wce-prev]")?.addEventListener("click", () => show(index - 1));
    root.querySelector("[data-wce-next]")?.addEventListener("click", () => show(index + 1));
    const ms = Number(root.getAttribute("data-wce-autoplay") ?? 0);
    if (ms >= 1e3) {
      const win = root.ownerDocument.defaultView;
      const timer = win?.setInterval(() => {
        if (!root.isConnected) win.clearInterval(timer);
        else if (!root.matches(":hover")) show(index + 1);
      }, ms);
    }
    show(0);
  }
  function tabs(root) {
    const buttons = Array.from(root.querySelectorAll("[data-wce-tab]"));
    const panels = Array.from(root.querySelectorAll("[data-wce-panel]"));
    const select = (name) => {
      buttons.forEach((button) => {
        const on = button.getAttribute("data-wce-tab") === name;
        button.setAttribute("aria-selected", String(on));
        button.classList.toggle("is-active", on);
      });
      panels.forEach((panel) => {
        panel.hidden = panel.getAttribute("data-wce-panel") !== name;
      });
    };
    buttons.forEach((button) => button.addEventListener("click", () => select(button.getAttribute("data-wce-tab") ?? "")));
    const first = buttons[0]?.getAttribute("data-wce-tab");
    if (first) select(first);
  }
  function countdown(element) {
    const target = new Date(element.getAttribute("data-wce-countdown") ?? "").getTime();
    if (Number.isNaN(target)) return;
    const win = element.ownerDocument.defaultView;
    const done = element.getAttribute("data-wce-done") ?? "Encerrado";
    const tick = () => {
      const left = target - Date.now();
      if (left <= 0) {
        element.textContent = done;
        return;
      }
      const days = Math.floor(left / 864e5);
      const hours = Math.floor(left % 864e5 / 36e5);
      const minutes = Math.floor(left % 36e5 / 6e4);
      const seconds = Math.floor(left % 6e4 / 1e3);
      const pad2 = (n) => String(n).padStart(2, "0");
      element.textContent = `${days > 0 ? `${days}d ` : ""}${pad2(hours)}:${pad2(minutes)}:${pad2(seconds)}`;
    };
    tick();
    const timer = win?.setInterval(() => {
      if (!element.isConnected) win.clearInterval(timer);
      else tick();
    }, 1e3);
  }
  function lightbox(root, host2) {
    root.addEventListener("click", (event) => {
      const image = event.target instanceof Element ? event.target.closest("img") : null;
      if (!image || !root.contains(image)) return;
      event.preventDefault();
      const src = image.getAttribute("data-full") ?? image.currentSrc ?? image.src;
      const alt = image.alt || "Imagem";
      const safe = src.replace(/"/g, "&quot;");
      host2.ui.modal(alt, `<img src="${safe}" alt="" style="display:block;max-width:100%;height:auto;margin:auto">`);
    });
  }
  function actions(element, host2) {
    let list;
    try {
      const parsed = JSON.parse(element.getAttribute("data-wce-actions") ?? "[]");
      list = Array.isArray(parsed) ? parsed : [parsed];
    } catch {
      return;
    }
    const type = element.getAttribute("data-wce-on") ?? (element instanceof HTMLFormElement ? "submit" : "click");
    element.addEventListener(type, (event) => {
      event.preventDefault();
      const info = { type, text: element.textContent?.trim() ?? "", data: { ...element.dataset } };
      const form = element instanceof HTMLFormElement ? element : element.closest("form");
      if (form) {
        const fields = {};
        new FormData(form).forEach((value, key) => {
          fields[key] = typeof value === "string" ? value : value.name;
        });
        info.form = fields;
        if (element instanceof HTMLFormElement) element.reset();
      }
      const repeated = element.closest("[data-wce-index]");
      if (repeated) info.index = Number(repeated.getAttribute("data-wce-index"));
      void host2.runActions(list, info, element.getAttribute("aria-label") ?? "componente", element);
    });
  }
  function attachBehaviors(root, host2) {
    const all = (selector) => [...root.matches(selector) ? [root] : [], ...Array.from(root.querySelectorAll(selector))];
    for (const element of all("[data-wce-carousel]")) if (once(element)) carousel(element);
    for (const element of all("[data-wce-tabs]")) if (once(element)) tabs(element);
    for (const element of all("[data-wce-countdown]")) if (once(element)) countdown(element);
    for (const element of all("[data-wce-lightbox]")) if (once(element)) lightbox(element, host2);
    for (const element of all("[data-wce-actions]")) if (once(element)) actions(element, host2);
  }

  // src/engine/ui.ts
  var STYLE = `
:host{all:initial}
.toasts{position:fixed;z-index:2147483646;right:16px;bottom:16px;display:flex;flex-direction:column;gap:8px;max-width:min(360px,calc(100vw - 32px));font:14px/1.4 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
.toast{background:#111827;color:#fff;padding:10px 14px;border-radius:10px;box-shadow:0 8px 24px rgba(0,0,0,.25);animation:in .2s ease-out}
.toast.success{background:#047857}.toast.error{background:#b91c1c}
@keyframes in{from{transform:translateY(8px);opacity:0}to{transform:none;opacity:1}}
.backdrop{position:fixed;inset:0;z-index:2147483645;background:rgba(15,23,42,.55);display:flex;align-items:center;justify-content:center;padding:16px;font:15px/1.5 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
.dialog{background:#fff;color:#111827;border-radius:14px;max-width:560px;width:100%;max-height:calc(100vh - 32px);overflow:auto;box-shadow:0 24px 64px rgba(0,0,0,.3)}
.head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:14px 18px;border-bottom:1px solid #e5e7eb}
.head h2{margin:0;font-size:17px}
.close{border:0;background:transparent;font-size:22px;line-height:1;cursor:pointer;color:#6b7280;padding:4px 8px;border-radius:6px}
.close:hover{background:#f3f4f6}
.body{padding:16px 18px}
.body img{max-width:100%}
`;
  var UiLayer = class {
    constructor(doc, marker) {
      this.doc = doc;
      this.marker = marker;
    }
    host = null;
    root = null;
    toasts = null;
    backdrop = null;
    ensure() {
      if (this.root && this.host?.isConnected) return this.root;
      this.host = this.doc.createElement("wce-layer");
      this.host.setAttribute(this.marker, "layer");
      this.root = this.host.attachShadow({ mode: "open" });
      const style = this.doc.createElement("style");
      style.textContent = STYLE;
      this.toasts = this.doc.createElement("div");
      this.toasts.className = "toasts";
      this.toasts.setAttribute("role", "status");
      this.toasts.setAttribute("aria-live", "polite");
      this.root.append(style, this.toasts);
      this.doc.documentElement.appendChild(this.host);
      return this.root;
    }
    toast(message, tone = "info", ms = 3500) {
      this.ensure();
      const item = this.doc.createElement("div");
      item.className = `toast ${tone}`;
      item.textContent = message;
      this.toasts?.appendChild(item);
      this.doc.defaultView?.setTimeout(() => item.remove(), ms);
    }
    modal(title, html) {
      const root = this.ensure();
      this.closeModal();
      const backdrop = this.doc.createElement("div");
      backdrop.className = "backdrop";
      const dialog = this.doc.createElement("div");
      dialog.className = "dialog";
      dialog.setAttribute("role", "dialog");
      dialog.setAttribute("aria-modal", "true");
      dialog.setAttribute("aria-label", title);
      const head = this.doc.createElement("div");
      head.className = "head";
      const heading = this.doc.createElement("h2");
      heading.textContent = title;
      const close = this.doc.createElement("button");
      close.className = "close";
      close.type = "button";
      close.setAttribute("aria-label", "Fechar");
      close.textContent = "\xD7";
      close.addEventListener("click", () => this.closeModal());
      head.append(heading, close);
      const body = this.doc.createElement("div");
      body.className = "body";
      body.setAttribute("data-wce-modal-body", "");
      body.innerHTML = html;
      dialog.append(head, body);
      backdrop.appendChild(dialog);
      backdrop.addEventListener("click", (event) => {
        if (event.target === backdrop) this.closeModal();
      });
      backdrop.addEventListener("keydown", (event) => {
        if (event.key === "Escape") this.closeModal();
      });
      root.appendChild(backdrop);
      this.backdrop = backdrop;
      close.focus();
      return body;
    }
    closeModal() {
      this.backdrop?.remove();
      this.backdrop = null;
    }
    destroy() {
      this.host?.remove();
      this.host = null;
      this.root = null;
    }
  };

  // src/engine/engine.ts
  var UI_ATTRIBUTE = "data-wce-ui";
  var HIDDEN = "data-wce-hidden";
  var BIND_HIDDEN = "data-wce-bind-hidden";
  var RULE_HIDDEN = "data-wce-rule-hidden";
  var INSERT_TAG = "wce-insert";
  var LOOP_LIMIT = 40;
  function isOurs(node) {
    const element = node.nodeType === 1 ? node : node.parentElement;
    return element?.closest(`[${UI_ATTRIBUTE}]`) !== null && element?.closest(`[${UI_ATTRIBUTE}]`) !== void 0;
  }
  var Engine = class {
    constructor(doc, project, clientId, host2, events = {}) {
      this.doc = doc;
      this.host = host2;
      this.events = events;
      this.project = project;
      this.client = activeClient(project, clientId);
      this.ui = new UiLayer(doc, UI_ATTRIBUTE);
    }
    vars = {};
    data = {};
    project;
    client;
    states = /* @__PURE__ */ new Map();
    observer = null;
    style = null;
    timers = [];
    sourceTimers = [];
    listeners = [];
    intersection = null;
    watched = /* @__PURE__ */ new WeakSet();
    lastHref = "";
    running = false;
    suspended = false;
    applying = false;
    scheduled = false;
    clockTimer = null;
    holding = 0;
    replaced = /* @__PURE__ */ new WeakMap();
    replacedAttributes = /* @__PURE__ */ new WeakMap();
    ui;
    get currentProject() {
      return this.project;
    }
    get currentClient() {
      return this.client;
    }
    get isRunning() {
      return this.running && !this.suspended;
    }
    get win() {
      return this.doc.defaultView;
    }
    persistKey() {
      return `${this.project.id}:${this.client?.id ?? ""}`;
    }
    // ---------------------------------------------------------------- escopo das expressões
    scope(extra = {}) {
      const location2 = this.win.location;
      const query = {};
      new URLSearchParams(location2.search).forEach((value, key) => {
        query[key] = value;
      });
      return {
        ...this.vars,
        vars: this.vars,
        data: this.data,
        page: { url: location2.href, path: location2.pathname, query, hash: location2.hash.replace(/^#/, ""), host: location2.host, title: this.doc.title },
        client: { id: this.client?.id ?? "", name: this.client?.name ?? "", ...this.client?.values ?? {} },
        now: Date.now(),
        ...extra
      };
    }
    // ---------------------------------------------------------------- ciclo de vida
    async start() {
      if (this.running) return;
      this.running = true;
      this.lastHref = this.win.location.href;
      this.installStyle();
      await this.initVariables();
      this.applyAll();
      this.observe();
      this.bindRules();
      this.startSources();
      this.startClock();
      this.fireTrigger("load", null);
    }
    stop() {
      if (!this.running) return;
      this.running = false;
      this.observer?.disconnect();
      this.observer = null;
      this.intersection?.disconnect();
      this.intersection = null;
      for (const [type, listener, capture] of this.listeners) this.doc.removeEventListener(type, listener, capture);
      this.listeners.length = 0;
      for (const timer of [...this.timers, ...this.sourceTimers]) this.win.clearInterval(timer);
      this.timers.length = 0;
      this.sourceTimers.length = 0;
      if (this.clockTimer !== null) this.win.clearInterval(this.clockTimer);
      this.clockTimer = null;
      this.revertAll();
      this.style?.remove();
      this.style = null;
      this.ui.destroy();
    }
    // Enquanto a pessoa digita no lugar, o motor não reaplica (senão desfaria a digitação).
    hold() {
      this.holding += 1;
    }
    release() {
      this.holding = Math.max(0, this.holding - 1);
      this.observer?.takeRecords();
    }
    get suspendedNow() {
      return this.suspended;
    }
    // A prévia do original: desfaz tudo sem parar o motor; resume volta a aplicar.
    suspend() {
      if (this.suspended) return;
      this.suspended = true;
      this.revertAll();
      if (this.style) this.style.disabled = true;
    }
    resume() {
      if (!this.suspended) return;
      this.suspended = false;
      if (this.style) this.style.disabled = false;
      this.applyAll();
    }
    // O projeto mudou (o editor gravou algo, ou o cliente foi trocado): desfaz e aplica de novo.
    async update(project, clientId) {
      const clientChanged = clientId !== void 0 && clientId !== this.client?.id;
      const sourcesChanged = JSON.stringify(project.sources) !== JSON.stringify(this.project.sources);
      const rulesChanged = JSON.stringify(project.rules) !== JSON.stringify(this.project.rules);
      const variablesChanged = JSON.stringify(project.variables) !== JSON.stringify(this.project.variables) || clientChanged || JSON.stringify(activeClient(project, clientId ?? this.client?.id)?.values) !== JSON.stringify(this.client?.values);
      this.revertAll();
      this.project = project;
      this.client = activeClient(project, clientId === void 0 ? this.client?.id : clientId);
      this.states.clear();
      if (variablesChanged) await this.initVariables();
      this.installStyle();
      if (sourcesChanged) this.startSources();
      if (rulesChanged) this.rebindTimers();
      if (!this.suspended) this.applyAll();
      this.startClock();
    }
    // ---------------------------------------------------------------- variáveis
    async initVariables() {
      for (const key of Object.keys(this.vars)) delete this.vars[key];
      const [local, session] = await Promise.all([this.host.loadPersisted("local", this.persistKey()), this.host.loadPersisted("session", this.persistKey())]);
      for (const variable of this.project.variables) {
        let value = variable.default;
        if (this.client && Object.prototype.hasOwnProperty.call(this.client.values, variable.name)) value = this.client.values[variable.name];
        if (variable.persist === "local" && Object.prototype.hasOwnProperty.call(local, variable.name)) value = local[variable.name];
        if (variable.persist === "session" && Object.prototype.hasOwnProperty.call(session, variable.name)) value = session[variable.name];
        const fromSource = this.readSource(variable);
        if (fromSource !== void 0) value = fromSource;
        this.vars[variable.name] = coerce(variable, value);
      }
      this.recomputeDerived();
      this.events.onVariables?.(this.vars);
    }
    readSource(variable) {
      const source = variable.source;
      if (!source || source.kind === "static" || source.kind === "expression") return void 0;
      try {
        switch (source.kind) {
          case "query": {
            const value = new URLSearchParams(this.win.location.search).get(source.param);
            return value === null ? void 0 : value;
          }
          case "cookie": {
            const match = this.doc.cookie.split(";").map((part) => part.trim()).find((part) => part.startsWith(`${source.name}=`));
            return match === void 0 ? void 0 : decodeURIComponent(match.slice(source.name.length + 1));
          }
          case "storage": {
            const value = this.win.localStorage.getItem(source.key);
            if (value === null) return void 0;
            try {
              return JSON.parse(value);
            } catch {
              return value;
            }
          }
          case "element": {
            const element = safeQueryAll(this.doc, source.selector).find((candidate) => !isOurs(candidate));
            if (!element) return void 0;
            if (source.attr) return element.getAttribute(source.attr) ?? void 0;
            if (element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement || element instanceof HTMLSelectElement) return element.value;
            return element.textContent?.trim();
          }
          case "source": {
            const owner = this.project.sources.find((candidate) => candidate.id === source.sourceId);
            if (!owner || !(owner.name in this.data)) return void 0;
            return getPath(this.data[owner.name], source.path);
          }
        }
      } catch (error) {
        this.report(`vari\xE1vel ${variable.name}`, error);
      }
      return void 0;
    }
    recomputeDerived() {
      const derived = this.project.variables.filter((variable) => variable.source?.kind === "expression");
      for (let pass = 0; pass < 4 && derived.length > 0; pass += 1) {
        for (const variable of derived) {
          if (variable.source?.kind !== "expression") continue;
          try {
            this.vars[variable.name] = coerce(variable, run(variable.source.expr, this.scope()));
          } catch (error) {
            this.report(`vari\xE1vel ${variable.name}`, error);
          }
        }
      }
    }
    setVariable(name, value, options = {}) {
      const definition = this.project.variables.find((variable) => variable.name === name);
      const next = definition ? coerce(definition, value) : value;
      const before = this.vars[name];
      if (JSON.stringify(before) === JSON.stringify(next)) return;
      this.vars[name] = next;
      if (definition && definition.persist !== "none") {
        const persisted = Object.fromEntries(this.project.variables.filter((variable) => variable.persist === definition.persist).map((variable) => [variable.name, this.vars[variable.name]]));
        this.host.savePersisted(definition.persist, this.persistKey(), persisted);
      }
      this.recomputeDerived();
      this.refreshDynamic();
      this.events.onVariables?.(this.vars);
      if (!options.silent) this.fireTrigger("varchange", null, { variable: name, value: next, previous: before });
    }
    resetVariable(name) {
      const definition = this.project.variables.find((variable) => variable.name === name);
      if (!definition) return;
      const value = this.client && name in this.client.values ? this.client.values[name] : definition.default;
      this.setVariable(name, value);
    }
    // ---------------------------------------------------------------- CSS do projeto
    installStyle() {
      if (!this.style) {
        this.style = this.doc.createElement("style");
        this.style.setAttribute(UI_ATTRIBUTE, "style");
        this.style.id = `wce-style-${this.project.id}`;
      }
      const parent = this.doc.head ?? this.doc.documentElement;
      if (this.style.parentNode !== parent) parent.appendChild(this.style);
      const scope = this.scope();
      const projectCss = renderTemplate(this.project.css ?? "", scope);
      const clientCss = renderTemplate(this.client?.css ?? "", scope);
      this.style.textContent = [
        `[${HIDDEN}],[${BIND_HIDDEN}],[${RULE_HIDDEN}]{display:none !important}`,
        `html.wce-show-hidden [${HIDDEN}]{display:revert !important;opacity:.35 !important;outline:2px dashed #f97316 !important}`,
        `${INSERT_TAG}{display:contents}`,
        projectCss,
        clientCss
      ].join("\n");
    }
    // ---------------------------------------------------------------- aplicar as alterações
    inScope(item) {
      if (!pageMatches(item.page, this.win.location)) return false;
      if (item.clients && item.clients.length > 0 && !item.clients.includes(this.client?.id ?? "")) return false;
      return true;
    }
    state(edit) {
      let state = this.states.get(edit.id);
      if (!state) {
        state = { records: /* @__PURE__ */ new Map(), hits: 0, windowStart: Date.now(), paused: false };
        this.states.set(edit.id, state);
      }
      return state;
    }
    applyAll() {
      if (!this.running || this.suspended) return;
      this.applying = true;
      try {
        for (const edit of this.project.edits) this.applyEdit(edit);
      } finally {
        this.applying = false;
        this.observer?.takeRecords();
      }
    }
    refreshDynamic() {
      if (!this.running || this.suspended) return;
      this.applying = true;
      try {
        this.installStyle();
        for (const edit of this.project.edits) if (isDynamicEdit(edit)) this.applyEdit(edit);
      } finally {
        this.applying = false;
        this.observer?.takeRecords();
      }
    }
    revertEdit(editId) {
      const state = this.states.get(editId);
      if (!state) return;
      this.applying = true;
      for (const [, record] of [...state.records.entries()].reverse()) {
        try {
          record.restore();
        } catch {
        }
      }
      state.records.clear();
      this.applying = false;
      this.observer?.takeRecords();
    }
    revertAll() {
      for (const edit of [...this.project.edits].reverse()) this.revertEdit(edit.id);
      this.states.clear();
      this.ui.closeModal();
    }
    applyEdit(edit) {
      const state = this.state(edit);
      let active = edit.enabled && this.inScope(edit);
      if (active && edit.when) {
        try {
          active = truthy(run(edit.when, this.scope()));
        } catch (error) {
          this.report(`condi\xE7\xE3o de "${edit.label ?? edit.op}"`, error);
          active = false;
        }
      }
      if (!active) {
        if (state.records.size > 0) this.revertEdit(edit.id);
        return;
      }
      if (state.paused) return;
      const targets = edit.op === "replace" && (edit.target.selector === "" || edit.target.selector === "body") ? [this.doc.body].filter(Boolean) : safeQueryAll(this.doc, edit.target.selector).filter((element) => !isOurs(element));
      for (const [element, record] of state.records) {
        if (!element.isConnected && edit.op !== "remove" && edit.op !== "move") {
          record.nodes?.forEach((node) => node.remove?.());
          state.records.delete(element);
        }
      }
      let changed = false;
      for (const element of targets) {
        try {
          if (this.applyTo(edit, element, state)) changed = true;
        } catch (error) {
          this.report(`altera\xE7\xE3o "${edit.label ?? edit.op}"`, error);
        }
      }
      if (changed) {
        const now = Date.now();
        if (now - state.windowStart > 1e3) {
          state.windowStart = now;
          state.hits = 0;
        }
        state.hits += 1;
        if (state.hits > LOOP_LIMIT) {
          state.paused = true;
          this.events.onError?.(`altera\xE7\xE3o "${edit.label ?? edit.op}"`, "A p\xE1gina desfaz esta altera\xE7\xE3o sem parar; ela foi pausada nesta visita.");
        }
      }
    }
    // Aplica uma alteração a um elemento. Devolve true quando mexeu no DOM (para o limite de reaplicações).
    applyTo(edit, element, state) {
      const scope = this.scope();
      const existing = state.records.get(element);
      switch (edit.op) {
        case "text":
          return this.setText(element, renderTemplate(edit.value, scope), state, existing);
        case "html":
          return this.setHtml(element, renderTemplate(edit.value, scope, true), state, existing);
        case "attr":
          return this.setAttr(element, edit.name, edit.value === null ? null : renderTemplate(edit.value, scope), state, existing);
        case "style": {
          const props = Object.fromEntries(Object.entries(edit.props).map(([prop, value]) => [prop, renderTemplate(value, scope)]));
          return this.setStyle(element, props, state, existing);
        }
        case "class": {
          if (!existing) {
            const original = element.getAttribute("class");
            state.records.set(element, { restore: () => original === null ? element.removeAttribute("class") : element.setAttribute("class", original) });
          }
          let changed = false;
          for (const name of edit.add) if (name && !element.classList.contains(name)) element.classList.add(name), changed = true;
          for (const name of edit.remove) if (name && element.classList.contains(name)) element.classList.remove(name), changed = true;
          return changed;
        }
        case "hide":
          return this.setFlag(element, HIDDEN, true, state, existing);
        case "blur":
          return this.setStyle(element, { filter: `blur(${edit.amount}px)`, "user-select": "none" }, state, existing);
        case "remove": {
          if (existing || !element.parentNode) return false;
          const parent = element.parentNode;
          const next = element.nextSibling;
          element.remove();
          state.records.set(element, { restore: () => parent.insertBefore(element, next && next.parentNode === parent ? next : null) });
          return true;
        }
        case "insert":
          return this.insert(element, edit.position, renderTemplate(edit.html, scope, true), edit.id, state, existing);
        case "move": {
          const ref = safeQueryAll(this.doc, edit.ref.selector).find((candidate) => !isOurs(candidate) && candidate !== element && !element.contains(candidate));
          if (!ref) return false;
          if (!existing) {
            const parent = element.parentNode;
            const next = element.nextSibling;
            state.records.set(element, { restore: () => parent?.insertBefore(element, next && next.parentNode === parent ? next : null) });
          }
          if (placedAt(element, ref, edit.position)) return false;
          place(element, ref, edit.position);
          return true;
        }
        case "replace":
          return this.replaceText(element, edit.find, renderTemplate(edit.replace, scope), edit.regex === true, edit.caseSensitive === true, state);
        case "bind":
          return this.bind(edit, element, scope, state, existing);
        case "repeat":
          return this.repeat(edit, element, scope, state, existing);
      }
    }
    setText(element, text, state, existing) {
      if (!existing) {
        const original = Array.from(element.childNodes);
        const texts = original.map((node) => node.nodeType === Node.TEXT_NODE ? node.data : null);
        const value = element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement ? element.value : null;
        state.records.set(element, {
          restore: () => {
            original.forEach((node, at) => {
              const text2 = texts[at];
              if (text2 !== null && text2 !== void 0 && node.data !== text2) node.data = text2;
            });
            element.replaceChildren(...original);
            if (value !== null) element.value = value;
          }
        });
      }
      if (element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement) {
        if (element.value === text) return false;
        element.value = text;
        return true;
      }
      if (element.textContent === text) return false;
      const only = element.childNodes.length === 1 ? element.firstChild : null;
      if (only && only.nodeType === Node.TEXT_NODE) only.data = text;
      else element.textContent = text;
      return true;
    }
    setHtml(element, html, state, existing) {
      if (!existing) {
        const original = Array.from(element.childNodes);
        state.records.set(element, { restore: () => element.replaceChildren(...original) });
      }
      const record = state.records.get(element);
      if (record && record.last === html && element.getAttribute("data-wce-html") === hash(html)) return false;
      element.innerHTML = html;
      element.setAttribute("data-wce-html", hash(html));
      if (record) {
        record.last = html;
        const restore = record.restore;
        record.restore = () => {
          element.removeAttribute("data-wce-html");
          restore();
        };
      }
      attachBehaviors(element, this);
      return true;
    }
    setAttr(element, name, value, state, existing) {
      if (!existing) {
        const original = element.getAttribute(name);
        const srcset = name === "src" ? element.getAttribute("srcset") : null;
        const sources = name === "src" && element.parentElement?.localName === "picture" ? Array.from(element.parentElement.querySelectorAll("source")).map((source) => [source, source.getAttribute("srcset")]) : [];
        const property = name === "value" && "value" in element ? element.value : null;
        state.records.set(element, {
          restore: () => {
            if (original === null) element.removeAttribute(name);
            else element.setAttribute(name, original);
            if (srcset !== null) element.setAttribute("srcset", srcset);
            for (const [source, set] of sources) if (set !== null) source.setAttribute("srcset", set);
            if (property !== null) element.value = property;
          }
        });
      }
      let changed = false;
      if (value === null) {
        if (element.hasAttribute(name)) element.removeAttribute(name), changed = true;
        return changed;
      }
      if (element.getAttribute(name) !== value) element.setAttribute(name, value), changed = true;
      if (name === "src") {
        if (element.hasAttribute("srcset")) element.removeAttribute("srcset"), changed = true;
        if (element.parentElement?.localName === "picture") {
          for (const source of Array.from(element.parentElement.querySelectorAll("source"))) if (source.hasAttribute("srcset")) source.removeAttribute("srcset"), changed = true;
        }
      }
      if (name === "value" && "value" in element && element.value !== value) {
        element.value = value;
        changed = true;
      }
      if (name === "checked" && element instanceof HTMLInputElement) element.checked = value !== "false";
      return changed;
    }
    setStyle(element, props, state, existing) {
      if (!existing) {
        const original = element.getAttribute("style");
        state.records.set(element, { restore: () => original === null ? element.removeAttribute("style") : element.setAttribute("style", original) });
      }
      let changed = false;
      for (const [prop, value] of Object.entries(props)) {
        const name = prop.startsWith("--") ? prop : prop.replace(/[A-Z]/g, (ch) => `-${ch.toLowerCase()}`);
        if (value === "") {
          if (element.style.getPropertyValue(name) !== "") element.style.removeProperty(name), changed = true;
          continue;
        }
        if (element.style.getPropertyValue(name) !== value || element.style.getPropertyPriority(name) !== "important") {
          element.style.setProperty(name, value, "important");
          changed = true;
        }
      }
      return changed;
    }
    setFlag(element, attribute, on, state, existing) {
      if (!existing) state.records.set(element, { restore: () => element.removeAttribute(attribute) });
      if (on === element.hasAttribute(attribute)) return false;
      if (on) element.setAttribute(attribute, "");
      else element.removeAttribute(attribute);
      return true;
    }
    insert(element, position, html, editId, state, existing) {
      let record = existing;
      if (!record) {
        const holder2 = this.doc.createElement(INSERT_TAG);
        holder2.setAttribute("data-wce-edit", editId);
        record = { nodes: [holder2], restore: () => holder2.remove() };
        state.records.set(element, record);
      }
      const holder = record.nodes?.[0];
      let changed = false;
      if (record.last !== html) {
        holder.innerHTML = html;
        record.last = html;
        attachBehaviors(holder, this);
        changed = true;
      }
      const placed = position === "before" && holder.nextSibling === element || position === "after" && element.nextSibling === holder || position === "prepend" && element.firstChild === holder || position === "append" && element.lastChild === holder;
      if (!placed) {
        place(holder, element, position);
        changed = true;
      }
      return changed;
    }
    replaceText(root, find, replacement, regex, caseSensitive, state) {
      if (find === "") return false;
      let pattern;
      try {
        pattern = regex ? new RegExp(find, caseSensitive ? "g" : "gi") : new RegExp(find.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), caseSensitive ? "g" : "gi");
      } catch {
        return false;
      }
      let record = state.records.get(root);
      if (!record) {
        const touched = [];
        const attrs = [];
        record = {
          nodes: [],
          restore: () => {
            for (const { node, original } of touched) if (node.data !== void 0) node.data = original;
            for (const { element, name, original } of attrs) element.setAttribute(name, original);
            touched.length = 0;
            attrs.length = 0;
          }
        };
        record.touched = touched;
        record.attrs = attrs;
        state.records.set(root, record);
      }
      const holder = record;
      let changed = false;
      const walker = this.doc.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
        acceptNode: (node) => {
          const parent = node.parentElement;
          if (!parent || /^(script|style|noscript|textarea|template)$/i.test(parent.localName) || isOurs(node) || parent.isContentEditable) return NodeFilter.FILTER_REJECT;
          return NodeFilter.FILTER_ACCEPT;
        }
      });
      for (let node = walker.nextNode(); node; node = walker.nextNode()) {
        const text = node;
        const known = this.replaced.get(text);
        const source = known !== void 0 && text.data === known.split("\0")[1] ? known.split("\0")[0] ?? text.data : text.data;
        pattern.lastIndex = 0;
        if (!pattern.test(source)) continue;
        pattern.lastIndex = 0;
        const next = source.replace(pattern, replacement);
        if (next === text.data) continue;
        if (!holder.touched.some((entry) => entry.node === text)) holder.touched.push({ node: text, original: source });
        text.data = next;
        this.replaced.set(text, `${source}\0${next}`);
        changed = true;
      }
      for (const element of [root, ...Array.from(root.querySelectorAll("[placeholder],[title],[alt],[aria-label],input[type=submit],input[type=button]"))]) {
        if (isOurs(element)) continue;
        for (const name of ["placeholder", "title", "alt", "aria-label", "value"]) {
          if (name === "value" && !(element instanceof HTMLInputElement && /^(submit|button)$/.test(element.type))) continue;
          const value = element.getAttribute(name);
          if (value === null) continue;
          const memory = this.replacedAttributes.get(element) ?? /* @__PURE__ */ new Map();
          const recorded = memory.get(name);
          const source = recorded !== void 0 && value === recorded.split("\0")[1] ? recorded.split("\0")[0] ?? value : value;
          pattern.lastIndex = 0;
          if (!pattern.test(source)) continue;
          pattern.lastIndex = 0;
          const next = source.replace(pattern, replacement);
          if (next === value) continue;
          if (!holder.attrs.some((entry) => entry.element === element && entry.name === name)) holder.attrs.push({ element, name, original: source });
          element.setAttribute(name, next);
          memory.set(name, `${source}\0${next}`);
          this.replacedAttributes.set(element, memory);
          changed = true;
        }
      }
      return changed;
    }
    bind(edit, element, scope, state, existing) {
      const value = run(edit.expr, scope);
      switch (edit.kind) {
        case "text":
          return this.setText(element, toText(value), state, existing);
        case "html":
          return this.setHtml(element, toText(value), state, existing);
        case "attr":
          return this.setAttr(element, edit.name ?? "title", value === false || value === null || value === void 0 ? null : toText(value), state, existing);
        case "style":
          return this.setStyle(element, { [edit.name ?? "color"]: toText(value) }, state, existing);
        case "class": {
          if (!existing) {
            const original = element.getAttribute("class");
            state.records.set(element, { restore: () => original === null ? element.removeAttribute("class") : element.setAttribute("class", original) });
          }
          const name = edit.name ?? "";
          if (!name) return false;
          const on = truthy(value);
          if (on === element.classList.contains(name)) return false;
          element.classList.toggle(name, on);
          return true;
        }
        case "show":
          return this.setFlag(element, BIND_HIDDEN, !truthy(value), state, existing);
        case "value": {
          const changed = this.setAttr(element, "value", toText(value), state, existing);
          const name = edit.expr.trim();
          if (/^[A-Za-z_][A-Za-z0-9_]*$/.test(name) && !element.hasAttribute("data-wce-two-way")) {
            element.setAttribute("data-wce-two-way", name);
            const listener = () => {
              const input = element;
              this.setVariable(name, input.type === "checkbox" ? input.checked : input.value);
            };
            element.addEventListener("input", listener);
            element.addEventListener("change", listener);
            const record = state.records.get(element);
            if (record) {
              const restore = record.restore;
              record.restore = () => {
                element.removeEventListener("input", listener);
                element.removeEventListener("change", listener);
                element.removeAttribute("data-wce-two-way");
                restore();
              };
            }
          }
          return changed;
        }
      }
    }
    repeat(edit, element, scope, state, existing) {
      const raw = run(edit.expr, scope);
      const items = Array.isArray(raw) ? raw : raw && typeof raw === "object" ? Object.values(raw) : [];
      const itemName = edit.itemName || "item";
      const pieces = items.map((item, index) => renderTemplate(edit.template, { ...scope, [itemName]: item, index, position: index + 1, first: index === 0, last: index === items.length - 1 }, true));
      const html = pieces.join("\0");
      let record = existing;
      if (!record) {
        const made = {
          nodes: [],
          restore: () => {
            for (const node of made.nodes ?? []) node.remove();
            made.nodes = [];
            element.removeAttribute(HIDDEN);
          }
        };
        record = made;
        state.records.set(element, record);
      }
      let changed = false;
      if (!element.hasAttribute(HIDDEN)) {
        element.setAttribute(HIDDEN, "");
        changed = true;
      }
      const nodes = record.nodes ?? [];
      const inPlace = nodes.length > 0 ? nodes.every((node) => node.isConnected) && element.nextSibling === nodes[0] : pieces.length === 0;
      if (record.last !== html || !inPlace) {
        for (const node of nodes) node.remove();
        const made = [];
        pieces.forEach((piece, index) => {
          const template = this.doc.createElement("template");
          template.innerHTML = piece;
          for (const node of Array.from(template.content.childNodes)) {
            if (node.nodeType === Node.ELEMENT_NODE) {
              node.setAttribute("data-wce-index", String(index));
              node.setAttribute("data-wce-edit", edit.id);
            }
            made.push(node);
          }
        });
        const fragment = this.doc.createDocumentFragment();
        made.forEach((node) => fragment.appendChild(node));
        element.parentNode?.insertBefore(fragment, element.nextSibling);
        for (const node of made) if (node.nodeType === Node.ELEMENT_NODE) attachBehaviors(node, this);
        record.nodes = made;
        record.last = html;
        changed = true;
      }
      return changed;
    }
    // ---------------------------------------------------------------- observar a página
    observe() {
      this.observer?.disconnect();
      this.observer = new MutationObserver((mutations) => {
        if (this.applying || !this.running || this.suspended || this.holding > 0) return;
        const relevant = mutations.some((mutation) => !isOurs(mutation.target));
        if (!relevant) return;
        if (this.win.location.href !== this.lastHref) this.onUrlChange();
        this.applyAll();
        this.watchVisible();
      });
      this.observer.observe(this.doc.documentElement, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ["class", "style", "src", "href", "hidden", "value"] });
      const poll = this.win.setInterval(() => {
        if (this.win.location.href !== this.lastHref) this.onUrlChange();
      }, 400);
      this.timers.push(poll);
      const pop = () => this.onUrlChange();
      this.win.addEventListener("popstate", pop);
      this.win.addEventListener("hashchange", pop);
    }
    onUrlChange() {
      if (this.win.location.href === this.lastHref) return;
      const previous = this.lastHref;
      this.lastHref = this.win.location.href;
      for (const variable of this.project.variables) {
        if (variable.source?.kind === "query") {
          const value = this.readSource(variable);
          if (value !== void 0) this.vars[variable.name] = coerce(variable, value);
        }
      }
      this.recomputeDerived();
      this.applyAll();
      this.fireTrigger("urlchange", null, { from: previous, to: this.lastHref });
      this.events.onVariables?.(this.vars);
    }
    // ---------------------------------------------------------------- relógio: textos com now() se atualizam
    startClock() {
      if (this.clockTimer !== null) this.win.clearInterval(this.clockTimer);
      this.clockTimer = null;
      const usesClock = this.project.edits.some((edit) => {
        const sources = [edit.when ?? "", "value" in edit ? String(edit.value ?? "") : "", "expr" in edit ? edit.expr : "", "html" in edit ? edit.html : "", "template" in edit ? edit.template : ""];
        return sources.some((source) => namesIn(source, source.includes("{{")).has("now"));
      });
      if (usesClock) this.clockTimer = this.win.setInterval(() => this.refreshDynamic(), 1e3);
    }
    // ---------------------------------------------------------------- fontes de dados
    startSources() {
      for (const timer of this.sourceTimers) this.win.clearInterval(timer);
      this.sourceTimers.length = 0;
      for (const source of this.project.sources) {
        if (source.kind !== "http") void this.loadSource(source.id);
        else if (source.auto) void this.loadSource(source.id);
        if (source.kind === "http" && source.refreshSec && source.refreshSec >= 5) this.sourceTimers.push(this.win.setInterval(() => void this.loadSource(source.id), source.refreshSec * 1e3));
      }
    }
    async loadSource(sourceId) {
      const source = this.project.sources.find((candidate) => candidate.id === sourceId || candidate.name === sourceId);
      if (!source) return void 0;
      try {
        const value = await this.readDataSource(source);
        this.data[source.name] = value;
        for (const variable of this.project.variables) {
          if (variable.source?.kind === "source" && variable.source.sourceId === source.id) this.vars[variable.name] = coerce(variable, getPath(value, variable.source.path));
        }
        this.recomputeDerived();
        this.refreshDynamic();
        this.events.onVariables?.(this.vars);
        this.fireTrigger("varchange", null, { variable: `data.${source.name}`, value });
        return value;
      } catch (error) {
        this.report(`fonte de dados ${source.name}`, error);
        return void 0;
      }
    }
    async readDataSource(source) {
      if (source.kind === "json") return getPath(JSON.parse(source.data || "null"), source.path);
      if (source.kind === "csv") return parseCsv(source.data ?? "");
      const scope = this.scope();
      const url = renderTemplate(source.url ?? "", scope);
      if (!url) throw new Error("a fonte n\xE3o tem endere\xE7o");
      const headers = Object.fromEntries(Object.entries(source.headers ?? {}).map(([key, value]) => [key, renderTemplate(value, scope)]));
      const answer = await this.host.fetchText({ url: new URL(url, this.win.location.href).href, method: source.method ?? "GET", headers, ...source.body ? { body: renderTemplate(source.body, scope) } : {} });
      if (!answer.ok) throw new Error(`o servidor respondeu ${answer.status}`);
      const format = source.format ?? "json";
      if (format === "csv") return parseCsv(answer.text);
      if (format === "text") return answer.text;
      return getPath(JSON.parse(answer.text), source.path);
    }
    // ---------------------------------------------------------------- regras (eventos e ações)
    bindRules() {
      const on = (type, handler, capture = true) => {
        const listener = handler;
        this.doc.addEventListener(type, listener, capture);
        this.listeners.push([type, listener, capture]);
      };
      const domTriggers = { click: "click", dblclick: "dblclick", submit: "submit", change: "change", input: "input", keydown: "keydown" };
      for (const [trigger, type] of Object.entries(domTriggers)) {
        on(type, (event) => {
          if (this.suspended) return;
          const origin = event.target instanceof Element ? event.target : null;
          if (origin && isOurs(origin) && !origin.closest("[data-wce-modal-body]")) return;
          this.handleDomEvent(trigger, event);
        });
      }
      on("mouseover", (event) => {
        if (this.suspended) return;
        const origin = event.target instanceof Element ? event.target : null;
        if (!origin || isOurs(origin)) return;
        const related = event.relatedTarget instanceof Element ? event.relatedTarget : null;
        for (const rule of this.activeRules("hover")) {
          const matched = rule.trigger.selector ? origin.closest(rule.trigger.selector) : null;
          if (!matched || related && matched.contains(related)) continue;
          void this.runRule(rule, event, matched);
        }
      });
      this.rebindTimers();
      this.watchVisible();
    }
    rebindTimers() {
      const keep = this.timers.splice(0, 1);
      for (const timer of this.timers) this.win.clearInterval(timer);
      this.timers.length = 0;
      this.timers.push(...keep);
      for (const rule of this.project.rules) {
        if (!rule.enabled) continue;
        if (rule.trigger.type === "interval") this.timers.push(this.win.setInterval(() => !this.suspended && void this.runRule(rule, null, null), Math.max(250, rule.trigger.ms ?? 1e3)));
        if (rule.trigger.type === "timeout") this.timers.push(this.win.setTimeout(() => !this.suspended && void this.runRule(rule, null, null), Math.max(0, rule.trigger.ms ?? 1e3)));
      }
      this.intersection?.disconnect();
      this.intersection = null;
    }
    watchVisible() {
      const rules = this.activeRules("visible");
      if (rules.length === 0) return;
      if (!this.intersection) {
        this.intersection = new IntersectionObserver((entries) => {
          for (const entry of entries) {
            if (!entry.isIntersecting) continue;
            for (const rule of this.activeRules("visible")) {
              if (rule.trigger.selector && entry.target.matches(rule.trigger.selector)) void this.runRule(rule, null, entry.target);
            }
          }
        });
      }
      for (const rule of rules) {
        for (const element of safeQueryAll(this.doc, rule.trigger.selector ?? "")) {
          if (this.watched.has(element)) continue;
          this.watched.add(element);
          this.intersection.observe(element);
        }
      }
    }
    activeRules(type) {
      return this.project.rules.filter((rule) => rule.enabled && rule.trigger.type === type && pageMatches(rule.page, this.win.location));
    }
    handleDomEvent(type, event) {
      const origin = event.target instanceof Element ? event.target : null;
      for (const rule of this.activeRules(type)) {
        let matched = null;
        if (rule.trigger.selector) {
          try {
            matched = origin?.closest(rule.trigger.selector) ?? null;
          } catch {
            matched = null;
          }
          if (!matched) continue;
        }
        if (type === "keydown" && rule.trigger.key && !keyMatches(rule.trigger.key, event)) continue;
        void this.runRule(rule, event, matched ?? origin);
      }
    }
    fireTrigger(type, element, extra = {}) {
      if (this.suspended) return;
      for (const rule of this.activeRules(type)) {
        if (type === "varchange" && rule.trigger.variable && rule.trigger.variable !== extra.variable) continue;
        void this.runRule(rule, null, element, extra);
      }
    }
    eventScope(event, element, extra) {
      const info = { ...extra, type: event?.type ?? "" };
      if (element) {
        info.text = element.textContent?.trim() ?? "";
        info.id = element.id;
        info.data = { ...element.dataset };
        if (element instanceof HTMLInputElement || element instanceof HTMLSelectElement || element instanceof HTMLTextAreaElement) info.value = element.value;
        if (element instanceof HTMLInputElement) info.checked = element.checked;
        info.href = element.getAttribute("href") ?? "";
        const form = element instanceof HTMLFormElement ? element : element.closest("form");
        if (form) {
          const fields = {};
          new FormData(form).forEach((value, key) => {
            fields[key] = typeof value === "string" ? value : value.name;
          });
          info.form = fields;
        }
        const repeated = element.closest("[data-wce-index]");
        if (repeated) info.index = Number(repeated.getAttribute("data-wce-index"));
      }
      if (event instanceof KeyboardEvent) info.key = event.key;
      return info;
    }
    async runRule(rule, event, element, extra = {}) {
      const eventInfo = this.eventScope(event, element, extra);
      if (rule.condition) {
        try {
          if (!truthy(run(rule.condition, this.scope({ event: eventInfo })))) return;
        } catch (error) {
          this.report(`condi\xE7\xE3o da regra "${rule.name}"`, error);
          return;
        }
      }
      if (rule.preventDefault && event) {
        event.preventDefault();
        event.stopPropagation();
      }
      await this.runActions(rule.actions, eventInfo, rule.name, element);
    }
    async runActions(actions2, eventInfo, ruleName, element = null) {
      for (const action of actions2) {
        try {
          await this.runAction(action, eventInfo, ruleName, element);
        } catch (error) {
          this.report(`a\xE7\xE3o ${action.type} da regra "${ruleName}"`, error);
        }
      }
    }
    targets(selector, element) {
      if (selector === "this" || selector === "") return element ? [element] : [];
      return safeQueryAll(this.doc, selector).filter((candidate) => !isOurs(candidate) || candidate.closest("[data-wce-modal-body]"));
    }
    async runAction(action, eventInfo, ruleName, element) {
      const scope = () => this.scope({ event: eventInfo });
      const value = (expr) => run(expr, scope());
      const text = (template) => renderTemplate(template, scope());
      switch (action.type) {
        case "set":
          this.setVariable(action.variable, value(action.expr));
          return;
        case "toggle":
          this.setVariable(action.variable, toggled(this.project.variables.find((variable) => variable.name === action.variable), this.vars[action.variable]));
          return;
        case "reset":
          this.resetVariable(action.variable);
          return;
        case "push": {
          const current = Array.isArray(this.vars[action.variable]) ? this.vars[action.variable] : [];
          this.setVariable(action.variable, [...current, value(action.expr)]);
          return;
        }
        case "show":
        case "hide":
        case "toggleVisible":
          for (const target of this.targets(action.selector, element)) {
            const hide = action.type === "hide" || action.type === "toggleVisible" && !target.hasAttribute(RULE_HIDDEN) && target.offsetParent !== null;
            if (hide) target.setAttribute(RULE_HIDDEN, "");
            else {
              target.removeAttribute(RULE_HIDDEN);
              target.removeAttribute(HIDDEN);
            }
          }
          return;
        case "addClass":
        case "removeClass":
        case "toggleClass":
          for (const target of this.targets(action.selector, element)) {
            if (action.type === "addClass") target.classList.add(action.className);
            else if (action.type === "removeClass") target.classList.remove(action.className);
            else target.classList.toggle(action.className);
          }
          return;
        case "setText":
          for (const target of this.targets(action.selector, element)) target.textContent = toText(value(action.expr));
          return;
        case "setHtml":
          for (const target of this.targets(action.selector, element)) {
            target.innerHTML = toText(value(action.expr));
            attachBehaviors(target, this);
          }
          return;
        case "setAttr":
          for (const target of this.targets(action.selector, element)) target.setAttribute(action.name, toText(value(action.expr)));
          return;
        case "setStyle":
          for (const target of this.targets(action.selector, element)) target.style.setProperty(action.prop, toText(value(action.expr)), "important");
          return;
        case "setValue":
          for (const target of this.targets(action.selector, element)) {
            const input = target;
            input.value = toText(value(action.expr));
            input.dispatchEvent(new Event("input", { bubbles: true }));
            input.dispatchEvent(new Event("change", { bubbles: true }));
          }
          return;
        case "click":
          this.targets(action.selector, element)[0]?.click();
          return;
        case "focus":
          this.targets(action.selector, element)[0]?.focus();
          return;
        case "scroll":
          this.targets(action.selector, element)[0]?.scrollIntoView({ behavior: "smooth", block: "center" });
          return;
        case "navigate": {
          const url = toText(value(action.expr));
          if (!url) return;
          const absolute = new URL(url, this.win.location.href);
          if (!/^(https?|mailto|tel):$/.test(absolute.protocol)) throw new Error("endere\xE7o n\xE3o permitido");
          if (action.newTab) this.win.open(absolute.href, "_blank", "noopener");
          else this.win.location.assign(absolute.href);
          return;
        }
        case "toast":
          this.ui.toast(toText(value(action.expr)), action.tone ?? "info");
          return;
        case "modal": {
          const body = this.ui.modal(text(action.title), renderTemplate(action.html, scope(), true));
          attachBehaviors(body, this);
          return;
        }
        case "closeModal":
          this.ui.closeModal();
          return;
        case "fetch":
          await this.loadSource(action.sourceId);
          return;
        case "copy":
          await this.win.navigator.clipboard.writeText(toText(value(action.expr)));
          return;
        case "delay":
          await new Promise((resolve) => this.win.setTimeout(resolve, Math.min(6e4, Math.max(0, action.ms))));
          return;
        case "log":
          this.events.onLog?.(`${ruleName}: ${toText(value(action.expr))}`);
          this.win.console.info("[Site Editor]", ruleName, value(action.expr));
          return;
        case "script": {
          if (!this.host.runScript) throw new Error("scripts pr\xF3prios n\xE3o est\xE3o liberados neste navegador");
          const result = await this.host.runScript(action.code, { vars: { ...this.vars }, data: this.data, event: eventInfo, page: this.scope().page });
          if (result && typeof result === "object" && "set" in result && typeof result.set === "object") {
            for (const [name, next] of Object.entries(result.set)) this.setVariable(name, next);
          }
          return;
        }
        case "if":
          await this.runActions(truthy(value(action.condition)) ? action.then : action.else, eventInfo, ruleName, element);
          return;
      }
    }
    report(where, error) {
      const message = error instanceof Error ? error.message : String(error);
      this.events.onError?.(where, message);
    }
  };
  function isDynamicEdit(edit) {
    if (edit.when) return true;
    switch (edit.op) {
      case "bind":
      case "repeat":
        return true;
      case "text":
      case "html":
        return edit.value.includes("{{");
      case "attr":
        return (edit.value ?? "").includes("{{");
      case "style":
        return Object.values(edit.props).some((value) => value.includes("{{"));
      case "insert":
        return edit.html.includes("{{");
      case "replace":
        return edit.replace.includes("{{");
      default:
        return false;
    }
  }
  function hash(text) {
    let h = 5381;
    for (let i = 0; i < text.length; i += 1) h = (h << 5) + h + text.charCodeAt(i) | 0;
    return (h >>> 0).toString(36);
  }
  function placedAt(element, ref, position) {
    if (position === "before") return ref.previousSibling === element;
    if (position === "after") return ref.nextSibling === element;
    if (position === "prepend") return ref.firstChild === element;
    return ref.lastChild === element;
  }
  function place(node, ref, position) {
    if (position === "before") ref.parentNode?.insertBefore(node, ref);
    else if (position === "after") ref.parentNode?.insertBefore(node, ref.nextSibling);
    else if (position === "prepend") ref.insertBefore(node, ref.firstChild);
    else ref.appendChild(node);
  }
  function keyMatches(wanted, event) {
    const parts = wanted.toLowerCase().split("+").map((part) => part.trim());
    const key = parts.pop() ?? "";
    const mods = new Set(parts);
    if (mods.has("ctrl") !== event.ctrlKey || mods.has("shift") !== event.shiftKey || mods.has("alt") !== event.altKey || mods.has("meta") !== event.metaKey) return false;
    return event.key.toLowerCase() === key || event.code.toLowerCase() === key;
  }
  function toggled(definition, current) {
    if (definition?.type === "state" && definition.options && definition.options.length > 0) {
      const index = definition.options.indexOf(toText(current));
      return definition.options[(index + 1) % definition.options.length];
    }
    return !truthy(current);
  }
  function coerce(definition, value) {
    switch (definition.type) {
      case "number": {
        if (typeof value === "number") return value;
        const n = Number(toText(value).replace(",", "."));
        return Number.isFinite(n) ? n : 0;
      }
      case "boolean":
        return typeof value === "boolean" ? value : truthy(value);
      case "list":
        if (Array.isArray(value)) return value;
        if (typeof value === "string") {
          try {
            const parsed = JSON.parse(value);
            if (Array.isArray(parsed)) return parsed;
          } catch {
            return value.split(/\n|,/).map((part) => part.trim()).filter(Boolean);
          }
        }
        return value === null || value === void 0 ? [] : [value];
      case "json":
        if (typeof value === "string") {
          try {
            return JSON.parse(value);
          } catch {
            return value;
          }
        }
        return value;
      case "state":
      case "text":
      case "color":
      case "image":
      case "url":
        return value === null || value === void 0 ? "" : typeof value === "string" ? value : toText(value);
    }
  }

  // src/runtime/runtime.ts
  var script = document.currentScript;
  var PREFIX = "wce:";
  var host = {
    async fetchText(request) {
      const response = await fetch(request.url, { method: request.method, headers: request.headers, ...request.body !== void 0 && request.method !== "GET" ? { body: request.body } : {} });
      return { ok: response.ok, status: response.status, text: await response.text() };
    },
    async loadPersisted(scope, key) {
      try {
        const storage = scope === "local" ? localStorage : sessionStorage;
        return JSON.parse(storage.getItem(PREFIX + key) ?? "{}");
      } catch {
        return {};
      }
    },
    savePersisted(scope, key, values) {
      try {
        (scope === "local" ? localStorage : sessionStorage).setItem(PREFIX + key, JSON.stringify(values));
      } catch {
      }
    },
    async runScript(code, scope) {
      const fn = new Function("vars", "data", "event", "page", `return (async () => {
${code}
})();`);
      return fn(scope.vars, scope.data, scope.event, scope.page);
    }
  };
  function chosenClient(project) {
    const wanted = script?.dataset.wceClient ?? window.WCE_CLIENT ?? new URLSearchParams(location.search).get("wce_client") ?? null;
    if (!wanted) return project.activeClientId;
    return project.clients.find((client) => client.id === wanted || client.name.toLowerCase() === wanted.toLowerCase())?.id ?? project.activeClientId;
  }
  var engines = [];
  async function load(raw, clientId) {
    const project = normalizeProject(raw);
    const engine = new Engine(document, project, clientId ?? chosenClient(project), host, {
      onError: (where, message) => console.warn("[Site Editor]", where, message)
    });
    engines.push(engine);
    await engine.start();
    for (const custom of project.scripts) {
      if (!custom.enabled) continue;
      try {
        await host.runScript?.(custom.code, { vars: { ...engine.vars }, data: engine.data, event: {}, page: { url: location.href } });
      } catch (error) {
        console.warn("[Site Editor] script", custom.name, error);
      }
    }
    return engine;
  }
  async function boot() {
    const strict = script?.hasAttribute("data-wce-strict") ?? false;
    const projects = [...window.WCE_PROJECTS ?? []];
    const endpoint = script?.dataset.wceEndpoint;
    const key = script?.dataset.wceKey;
    if (endpoint && key) {
      try {
        const address = new URL(endpoint);
        address.searchParams.set("key", key);
        const response = await fetch(address, { headers: { accept: "application/json" } });
        if (response.ok) {
          const body = await response.json();
          if (body.project) projects.push(body.project);
        } else console.warn("[Site Editor] a nuvem respondeu", response.status);
      } catch (error) {
        console.warn("[Site Editor] n\xE3o foi poss\xEDvel buscar o projeto", error);
      }
    }
    for (const raw of projects) {
      try {
        const project = normalizeProject(raw);
        if (strict && project.matches.length > 0 && !anyMatches(project.matches, location.href)) continue;
        await load(project);
      } catch (error) {
        console.warn("[Site Editor] projeto inv\xE1lido", error);
      }
    }
    document.dispatchEvent(new CustomEvent("wce:ready", { detail: { engines: engines.length } }));
  }
  window.WCE = {
    version: "1.0.0",
    engines,
    set: (name, value) => engines.forEach((engine) => engine.setVariable(name, value)),
    get: (name) => engines.find((engine) => name in engine.vars)?.vars[name],
    client: async (id) => {
      for (const engine of engines) await engine.update(engine.currentProject, id);
    },
    load
  };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", () => void boot(), { once: true });
  else void boot();
})();
