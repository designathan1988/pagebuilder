"use strict";
(() => {
  // src/shared/model.ts
  var FORMAT_VERSION = 1;
  function uid(prefix = "") {
    const random = crypto.getRandomValues(new Uint8Array(8));
    return prefix + Array.from(random, (b) => b.toString(16).padStart(2, "0")).join("");
  }
  function newProject(name, matches) {
    const now = Date.now();
    const client = { id: uid("c_"), name: "Padr\xE3o", values: {} };
    return {
      format: FORMAT_VERSION,
      id: uid("p_"),
      name,
      matches,
      enabled: true,
      clients: [client],
      activeClientId: client.id,
      variables: [],
      edits: [],
      rules: [],
      sources: [],
      css: "",
      scripts: [],
      createdAt: now,
      updatedAt: now
    };
  }
  var VARIABLE_NAME = /^[A-Za-z_][A-Za-z0-9_]*$/;
  var RESERVED_NAMES = /* @__PURE__ */ new Set(["page", "client", "data", "event", "item", "index", "now", "true", "false", "null", "vars", "this"]);
  function defaultFor(type, options) {
    switch (type) {
      case "number":
        return 0;
      case "boolean":
        return false;
      case "state":
        return options?.[0] ?? "";
      case "list":
        return [];
      case "json":
        return {};
      case "color":
        return "#2563eb";
      default:
        return "";
    }
  }

  // src/shared/match.ts
  function globToRegex(glob) {
    const escaped = glob.replace(/[.+^${}()|[\]\\?]/g, "\\$&").replace(/\*/g, ".*");
    return new RegExp(`^${escaped}$`, "i");
  }
  function urlMatches(pattern, href) {
    const trimmed = pattern.trim();
    if (trimmed === "") return false;
    if (trimmed === "<all_urls>" || trimmed === "*") return /^(https?|file):/.test(href);
    if (trimmed.length > 2 && trimmed.startsWith("/") && trimmed.lastIndexOf("/") > 0) {
      const end = trimmed.lastIndexOf("/");
      try {
        return new RegExp(trimmed.slice(1, end), trimmed.slice(end + 1)).test(href);
      } catch {
        return false;
      }
    }
    let url;
    try {
      url = new URL(href);
    } catch {
      return false;
    }
    const scheme = /^([a-z*]+):\/\//i.exec(trimmed);
    if (scheme) {
      const wantedScheme = (scheme[1] ?? "").toLowerCase();
      if (wantedScheme !== "*" && wantedScheme !== url.protocol.replace(":", "")) return false;
      if (wantedScheme === "*" && !/^https?:$/.test(url.protocol)) return false;
      const rest = trimmed.slice(scheme[0].length);
      const slash = rest.indexOf("/");
      const hostPattern = slash === -1 ? rest : rest.slice(0, slash);
      const pathPattern = slash === -1 ? "/*" : rest.slice(slash);
      const host = hostPattern.replace(/:(\d+|\*)$/, "").toLowerCase();
      const port = /:(\d+)$/.exec(hostPattern)?.[1];
      if (port !== void 0 && port !== url.port) return false;
      const hostOk = host === "*" || (host.startsWith("*.") ? url.hostname === host.slice(2) || url.hostname.endsWith(host.slice(1)) : globToRegex(host).test(url.hostname));
      if (!hostOk) return false;
      return globToRegex(pathPattern).test(url.pathname + url.search + url.hash) || globToRegex(pathPattern).test(url.pathname);
    }
    const withoutScheme = href.replace(/^[a-z]+:\/\//i, "");
    return globToRegex(trimmed).test(withoutScheme) || globToRegex(trimmed.endsWith("*") ? trimmed : `${trimmed}*`).test(withoutScheme);
  }
  function anyMatches(patterns, href) {
    return patterns.some((pattern) => urlMatches(pattern, href));
  }
  function suggestPattern(href) {
    try {
      const url = new URL(href);
      if (url.protocol === "file:") return `file://${url.pathname.replace(/[^/]*$/, "")}*`;
      return `${url.protocol}//${url.host}/*`;
    } catch {
      return href;
    }
  }

  // src/shared/selector.ts
  var STABLE_ATTRIBUTES = ["data-testid", "data-test", "data-test-id", "data-cy", "data-qa", "data-id", "data-key", "name", "aria-label", "title", "alt", "placeholder", "for", "role", "type"];
  var GENERATED = /^(css|sc|jsx|emotion|styled|svelte|astro|ng|_|mui|chakra|tw|v-)[-_]?[a-z0-9]*\d|[a-f0-9]{6,}|^[a-z]{1,3}\d{3,}|__[a-zA-Z0-9]{5}$|^\d|[:]/i;
  function cssEscape(value) {
    if (typeof CSS !== "undefined" && typeof CSS.escape === "function") return CSS.escape(value);
    return value.replace(/[^a-zA-Z0-9_-]/g, (ch) => `\\${ch}`);
  }
  function stableId(id) {
    return id.length > 0 && id.length < 60 && !GENERATED.test(id) && !/\d{4,}/.test(id);
  }
  function stableClasses(element) {
    return Array.from(element.classList).filter((name) => name.length < 40 && !GENERATED.test(name) && !name.startsWith("wce-") && !/\d{3,}/.test(name) && !/^(active|hover|focus|selected|open|show|is-|has-)/.test(name)).slice(0, 3);
  }
  function unique(root, selector, element) {
    try {
      const found = root.querySelectorAll(selector);
      return found.length === 1 && found[0] === element;
    } catch {
      return false;
    }
  }
  function attributeSelector(element, name) {
    const value = element.getAttribute(name);
    if (value === null || value === "" || value.length > 80) return null;
    return `${element.localName}[${name}="${value.replace(/["\\]/g, "\\$&")}"]`;
  }
  function step(element) {
    let part = element.localName;
    if (element.id && stableId(element.id)) return `#${cssEscape(element.id)}`;
    const classes = stableClasses(element);
    if (classes.length > 0) part += classes.map((name) => `.${cssEscape(name)}`).join("");
    const parent = element.parentElement;
    if (parent) {
      const siblings = Array.from(parent.children).filter((sibling) => sibling.localName === element.localName);
      const same = siblings.filter((sibling) => {
        try {
          return sibling.matches(part);
        } catch {
          return false;
        }
      });
      if (same.length > 1) part = `${element.localName}${classes.map((name) => `.${cssEscape(name)}`).join("")}:nth-of-type(${siblings.indexOf(element) + 1})`;
    }
    return part;
  }
  function selectorFor(element) {
    const doc = element.ownerDocument;
    const root = element.getRootNode() instanceof ShadowRoot ? element.getRootNode() : doc;
    if (element === doc.body) return "body";
    if (element === doc.documentElement) return "html";
    const holder = element.closest("wce-insert[data-wce-edit]");
    if (holder && holder !== element) {
      const steps = [];
      for (let cursor2 = element; cursor2 && cursor2 !== holder; cursor2 = cursor2.parentElement) steps.unshift(step(cursor2));
      const anchored = `wce-insert[data-wce-edit="${holder.getAttribute("data-wce-edit")}"] > ${steps.join(" > ")}`;
      if (unique(root, anchored, element)) return anchored;
    }
    if (element.id && stableId(element.id) && unique(root, `#${cssEscape(element.id)}`, element)) return `#${cssEscape(element.id)}`;
    for (const name of STABLE_ATTRIBUTES) {
      const candidate = attributeSelector(element, name);
      if (candidate && unique(root, candidate, element)) return candidate;
    }
    const classes = stableClasses(element);
    if (classes.length > 0) {
      const candidate = `${element.localName}${classes.map((name) => `.${cssEscape(name)}`).join("")}`;
      if (unique(root, candidate, element)) return candidate;
    }
    const parts = [];
    let cursor = element;
    while (cursor && cursor !== doc.documentElement) {
      parts.unshift(step(cursor));
      const candidate = parts.join(" > ");
      if (unique(root, candidate, element)) return candidate;
      const parent = cursor.parentElement;
      if (parent && parent !== doc.body && parent !== doc.documentElement) {
        if (parent.id && stableId(parent.id) && unique(root, `#${cssEscape(parent.id)}`, parent)) {
          const anchored = `#${cssEscape(parent.id)} > ${candidate}`;
          if (unique(root, anchored, element)) return anchored;
        }
        for (const name of STABLE_ATTRIBUTES) {
          const anchor = attributeSelector(parent, name);
          if (anchor && unique(root, anchor, parent)) {
            const anchored = `${anchor} > ${candidate}`;
            if (unique(root, anchored, element)) return anchored;
          }
        }
      }
      cursor = parent;
    }
    return parts.length > 0 ? `body > ${parts.join(" > ")}` : element.localName;
  }
  function similarSelector(element) {
    const exact = selectorFor(element);
    return exact.replace(/:nth-of-type\(\d+\)(?!.*:nth-of-type)/, "");
  }
  function safeQueryAll(root, selector) {
    try {
      return Array.from(root.querySelectorAll(selector));
    } catch {
      return [];
    }
  }
  function describe(element) {
    const tag = element.localName;
    const id = element.id ? `#${element.id}` : "";
    const cls = Array.from(element.classList).filter((name) => !name.startsWith("wce-")).slice(0, 2).map((name) => `.${name}`).join("");
    return `${tag}${id}${cls}`;
  }
  var TAG_NAMES = {
    a: "Link",
    button: "Bot\xE3o",
    img: "Imagem",
    h1: "T\xEDtulo 1",
    h2: "T\xEDtulo 2",
    h3: "T\xEDtulo 3",
    h4: "T\xEDtulo 4",
    h5: "T\xEDtulo 5",
    h6: "T\xEDtulo 6",
    p: "Par\xE1grafo",
    span: "Texto",
    div: "Bloco",
    section: "Se\xE7\xE3o",
    header: "Cabe\xE7alho",
    footer: "Rodap\xE9",
    nav: "Navega\xE7\xE3o",
    ul: "Lista",
    ol: "Lista numerada",
    li: "Item de lista",
    input: "Campo",
    textarea: "\xC1rea de texto",
    select: "Sele\xE7\xE3o",
    label: "R\xF3tulo",
    form: "Formul\xE1rio",
    table: "Tabela",
    tr: "Linha",
    td: "C\xE9lula",
    th: "Cabe\xE7alho de coluna",
    video: "V\xEDdeo",
    iframe: "Quadro incorporado",
    svg: "\xCDcone",
    main: "Conte\xFAdo principal",
    aside: "Barra lateral",
    article: "Artigo",
    figure: "Figura"
  };
  function friendlyName(element) {
    return TAG_NAMES[element.localName] ?? element.localName;
  }

  // src/shared/storage.ts
  var DEFAULT_SETTINGS = {
    builderUrl: "",
    supabaseUrl: "",
    supabaseKey: "",
    showHidden: false,
    toolbarSide: "right",
    companionPort: 5410,
    companionToken: "",
    allowedOrigins: []
  };
  var INDEX = "wce:index";
  var SETTINGS = "wce:settings";
  var projectKey = (id) => `wce:project:${id}`;
  var historyKey = (id) => `wce:history:${id}`;
  var HISTORY_SIZE = 30;
  function area() {
    return chrome.storage.local;
  }
  async function readIndex() {
    const stored = await area().get(INDEX);
    const list = stored[INDEX];
    return Array.isArray(list) ? list : [];
  }
  async function getProject(id) {
    const stored = await area().get(projectKey(id));
    return stored[projectKey(id)] ?? null;
  }
  async function projectsFor(href, includeDisabled = false) {
    const index = await readIndex();
    const wanted = index.filter((entry) => (includeDisabled || entry.enabled) && anyMatches(entry.matches, href));
    if (wanted.length === 0) return [];
    const stored = await area().get(wanted.map((entry) => projectKey(entry.id)));
    return wanted.flatMap((entry) => {
      const value = stored[projectKey(entry.id)];
      return value ? [value] : [];
    });
  }
  function entryOf(project) {
    return { id: project.id, name: project.name, matches: project.matches, enabled: project.enabled, updatedAt: project.updatedAt };
  }
  async function saveProject(project, label = "Altera\xE7\xE3o", options = {}) {
    const saved = { ...project, updatedAt: options.touch === false ? project.updatedAt : Date.now() };
    const index = await readIndex();
    const at = index.findIndex((entry) => entry.id === saved.id);
    const nextIndex = [...index];
    if (at === -1) nextIndex.push(entryOf(saved));
    else nextIndex[at] = entryOf(saved);
    const writes = { [projectKey(saved.id)]: saved, [INDEX]: nextIndex };
    if (options.history !== false) {
      const stored = await area().get(historyKey(saved.id));
      const history2 = Array.isArray(stored[historyKey(saved.id)]) ? stored[historyKey(saved.id)] : [];
      const last = history2[0];
      if (last && last.label === label && saved.updatedAt - last.at < 6e4) history2[0] = { at: saved.updatedAt, label, project: saved };
      else history2.unshift({ at: saved.updatedAt, label, project: saved });
      writes[historyKey(saved.id)] = history2.slice(0, HISTORY_SIZE);
    }
    await area().set(writes);
    return saved;
  }
  async function history(id) {
    const stored = await area().get(historyKey(id));
    const list = stored[historyKey(id)];
    return Array.isArray(list) ? list : [];
  }
  async function readSettings() {
    const stored = await area().get(SETTINGS);
    return { ...DEFAULT_SETTINGS, ...stored[SETTINGS] ?? {} };
  }
  async function writeSettings(patch) {
    const next = { ...await readSettings(), ...patch };
    await area().set({ [SETTINGS]: next });
    return next;
  }

  // src/editor/dom.ts
  function h(tag, props = null, ...children) {
    const element = document.createElement(tag);
    if (props) {
      for (const [key, value] of Object.entries(props)) {
        if (value === void 0 || value === null || value === false) continue;
        if (key.startsWith("on") && typeof value === "function") element.addEventListener(key.slice(2).toLowerCase(), value);
        else if (key === "class") element.className = String(value);
        else if (key === "value" && "value" in element) element.value = String(value);
        else if (key === "checked" && element instanceof HTMLInputElement) element.checked = Boolean(value);
        else if (key === "selected" && element instanceof HTMLOptionElement) element.selected = Boolean(value);
        else if (key === "html") element.innerHTML = String(value);
        else if (value === true) element.setAttribute(key, "");
        else element.setAttribute(key, String(value));
      }
    }
    append(element, children);
    return element;
  }
  function append(parent, children) {
    for (const child of children) {
      if (child === null || child === void 0 || child === false) continue;
      if (Array.isArray(child)) append(parent, child);
      else if (typeof child === "string" || typeof child === "number") parent.appendChild(document.createTextNode(String(child)));
      else parent.appendChild(child);
    }
  }
  function clear(element) {
    element.replaceChildren();
  }
  var PATHS = {
    cursor: '<path d="M4 4l7 16 2.5-6.5L20 11z"/>',
    text: '<path d="M4 7V4h16v3M9 20h6M12 4v16"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    eyeOff: '<path d="M3 3l18 18M10.6 10.6a2 2 0 002.8 2.8M9.9 5.2A10 10 0 0112 5c6.5 0 10 7 10 7a17 17 0 01-3.2 4.1M6.6 6.6C3.9 8.3 2 12 2 12s3.5 7 10 7a9.6 9.6 0 005.4-1.6"/>',
    undo: '<path d="M9 14L4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 010 11H11"/>',
    redo: '<path d="M15 14l5-5-5-5"/><path d="M20 9H9.5a5.5 5.5 0 000 11H13"/>',
    close: '<path d="M18 6L6 18M6 6l12 12"/>',
    panel: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M15 3v18"/>',
    up: '<path d="M12 19V5M5 12l7-7 7 7"/>',
    image: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="M21 15l-5-5L5 21"/>',
    link: '<path d="M10 13a5 5 0 007.5.5l3-3a5 5 0 00-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 00-7.5-.5l-3 3a5 5 0 007 7l1.7-1.7"/>',
    trash: '<path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"/>',
    copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/>',
    move: '<path d="M5 9l-3 3 3 3M9 5l3-3 3 3M15 19l-3 3-3-3M19 9l3 3-3 3M2 12h20M12 2v20"/>',
    zap: '<path d="M13 2L3 14h9l-1 8 10-12h-9z"/>',
    database: '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v14c0 1.7 4 3 9 3s9-1.3 9-3V5M3 12c0 1.7 4 3 9 3s9-1.3 9-3"/>',
    users: '<path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.9M16 3.1a4 4 0 010 7.8"/>',
    sliders: '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
    list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
    braces: '<path d="M8 3H7a2 2 0 00-2 2v5a2 2 0 01-2 2 2 2 0 012 2v5a2 2 0 002 2h1M16 21h1a2 2 0 002-2v-5a2 2 0 012-2 2 2 0 01-2-2V5a2 2 0 00-2-2h-1"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 00.3 1.8l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.8-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 11-4 0v-.1a1.7 1.7 0 00-1.1-1.5 1.7 1.7 0 00-1.8.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.7 1.7 0 00.3-1.8 1.7 1.7 0 00-1.5-1H3a2 2 0 110-4h.1a1.7 1.7 0 001.5-1.1 1.7 1.7 0 00-.3-1.8l-.1-.1a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 001.8.3H9a1.7 1.7 0 001-1.5V3a2 2 0 114 0v.1a1.7 1.7 0 001 1.5 1.7 1.7 0 001.8-.3l.1-.1a2 2 0 112.8 2.8l-.1.1a1.7 1.7 0 00-.3 1.8V9a1.7 1.7 0 001.5 1H21a2 2 0 110 4h-.1a1.7 1.7 0 00-1.5 1z"/>',
    check: '<path d="M20 6L9 17l-5-5"/>',
    edit: '<path d="M12 20h9M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4z"/>',
    layers: '<path d="M12 2l10 5-10 5L2 7z"/><path d="M2 17l10 5 10-5M2 12l10 5 10-5"/>',
    target: '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>',
    play: '<path d="M5 3l14 9-14 9z"/>',
    download: '<path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M7 10l5 5 5-5M12 15V3"/>',
    upload: '<path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M17 8l-5-5-5 5M12 3v12"/>',
    cloud: '<path d="M18 10h-1.3A8 8 0 109 20h9a5 5 0 000-10z"/>',
    grip: '<circle cx="9" cy="5" r="1"/><circle cx="9" cy="12" r="1"/><circle cx="9" cy="19" r="1"/><circle cx="15" cy="5" r="1"/><circle cx="15" cy="12" r="1"/><circle cx="15" cy="19" r="1"/>',
    blur: '<circle cx="12" cy="12" r="3"/><circle cx="12" cy="12" r="7" stroke-dasharray="2 3"/><circle cx="12" cy="12" r="10.5" stroke-dasharray="1 4"/>',
    code: '<path d="M16 18l6-6-6-6M8 6l-6 6 6 6"/>',
    history: '<path d="M3 3v5h5"/><path d="M3.1 13a9 9 0 102.1-8.5L3 8"/><path d="M12 7v5l4 2"/>',
    palette: '<circle cx="13.5" cy="6.5" r="1"/><circle cx="17.5" cy="10.5" r="1"/><circle cx="8.5" cy="7.5" r="1"/><circle cx="6.5" cy="12.5" r="1"/><path d="M12 2a10 10 0 000 20c1 0 1.7-.8 1.7-1.7 0-.4-.2-.8-.4-1.1-.3-.3-.4-.7-.4-1.1 0-.9.8-1.7 1.7-1.7h2a5.6 5.6 0 005.6-5.6C22.1 6 17.6 2 12 2z"/>',
    chevronDown: '<path d="M6 9l6 6 6-6"/>',
    search: '<circle cx="11" cy="11" r="8"/><path d="M21 21l-4.3-4.3"/>'
  };
  function icon(name, size = 16) {
    const wrapper = document.createElement("span");
    wrapper.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${PATHS[name] ?? ""}</svg>`;
    return wrapper.firstElementChild;
  }
  function button(label, onClick, options = {}) {
    const classes = ["btn", `btn-${options.variant ?? "default"}`];
    if (options.small) classes.push("btn-sm");
    if (options.iconOnly) classes.push("btn-icon");
    const element = h(
      "button",
      {
        type: "button",
        class: classes.join(" "),
        title: options.title ?? (options.iconOnly ? label : void 0),
        "aria-label": options.iconOnly ? label : void 0,
        "aria-pressed": options.pressed === void 0 ? void 0 : String(options.pressed),
        disabled: options.disabled,
        "data-testid": options.testid,
        onclick: (event) => {
          event.preventDefault();
          event.stopPropagation();
          onClick(event);
        }
      },
      options.icon ? icon(options.icon) : null,
      options.iconOnly ? null : h("span", null, label)
    );
    return element;
  }
  function field(label, control, hint) {
    const id = `f-${Math.random().toString(36).slice(2, 9)}`;
    const target = control.matches("input,select,textarea") ? control : control.querySelector("input,select,textarea");
    if (target && !target.id) target.id = id;
    return h("div", { class: "field" }, h("label", { for: target?.id ?? id }, label), control, hint ? h("div", { class: "hint" }, hint) : null);
  }
  function input(value, onChange, options = {}) {
    const element = h("input", { type: options.type ?? "text", value, placeholder: options.placeholder, class: options.mono ? "mono" : void 0, "data-testid": options.testid, list: options.list, spellcheck: "false" });
    element.addEventListener(options.live ? "input" : "change", () => onChange(element.value));
    element.addEventListener("keydown", (event) => event.stopPropagation());
    return element;
  }
  function textarea(value, onChange, options = {}) {
    const element = h("textarea", { rows: options.rows ?? 3, placeholder: options.placeholder, class: options.mono ? "mono" : void 0, "data-testid": options.testid, spellcheck: options.mono ? "false" : void 0 });
    element.value = value;
    element.addEventListener(options.live ? "input" : "change", () => onChange(element.value));
    element.addEventListener("keydown", (event) => event.stopPropagation());
    return element;
  }
  function select(value, options, onChange, testid) {
    const element = h("select", { "data-testid": testid }, options.map(([key, label]) => h("option", { value: key, selected: key === value }, label)));
    element.addEventListener("change", () => onChange(element.value));
    element.addEventListener("keydown", (event) => event.stopPropagation());
    return element;
  }
  function checkbox(label, checked, onChange, testid) {
    const box = h("input", { type: "checkbox", checked, "data-testid": testid });
    box.addEventListener("change", () => onChange(box.checked));
    return h("label", { class: "check" }, box, h("span", null, label));
  }
  function section(title, ...children) {
    return h("section", { class: "sec" }, h("h3", null, title), ...children);
  }
  function empty(text) {
    return h("p", { class: "empty" }, text);
  }

  // src/editor/styles.ts
  var EDITOR_CSS = `
:host{all:initial;--ac:#2563eb;--ac-2:#1d4ed8;--ac-soft:#eff6ff;--bg:#fff;--bg-2:#f8fafc;--bg-3:#f1f5f9;--line:#e2e8f0;--line-2:#cbd5e1;--tx:#0f172a;--tx-2:#475569;--tx-3:#64748b;--ok:#047857;--warn:#b45309;--bad:#b91c1c;--r:10px;--shadow:0 12px 40px rgba(15,23,42,.18),0 2px 6px rgba(15,23,42,.08);font:13px/1.45 system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;color:var(--tx)}
@media (prefers-color-scheme:dark){:host{--ac:#3b82f6;--ac-2:#60a5fa;--ac-soft:#172554;--bg:#0f172a;--bg-2:#111c33;--bg-3:#1e293b;--line:#1e293b;--line-2:#334155;--tx:#e2e8f0;--tx-2:#cbd5e1;--tx-3:#94a3b8;--ok:#34d399;--warn:#fbbf24;--bad:#f87171}}
*{box-sizing:border-box}
button,input,select,textarea{font:inherit;color:inherit}
.hl{position:fixed;pointer-events:none;z-index:2147483640;border:2px solid var(--ac);border-radius:3px;transition:all .06s linear;display:none}
.hl.hover{border-style:dashed;background:rgba(37,99,235,.06)}
.hl.sel{border-width:2px;box-shadow:0 0 0 9999px rgba(15,23,42,.0)}
.hl.pick{border-color:#f97316;background:rgba(249,115,22,.08)}
.tag{position:fixed;z-index:2147483641;pointer-events:none;background:var(--ac);color:#fff;font-size:11px;padding:2px 6px;border-radius:4px;white-space:nowrap;display:none;max-width:60vw;overflow:hidden;text-overflow:ellipsis}
.tag.pick{background:#f97316}
.minibar{position:fixed;z-index:2147483643;display:none;gap:2px;background:var(--bg);border:1px solid var(--line);border-radius:10px;padding:3px;box-shadow:var(--shadow)}
.minibar .btn{padding:5px 7px}
.toolbar{position:fixed;z-index:2147483644;bottom:14px;left:10px;right:10px;margin:0 auto;width:max-content;display:flex;align-items:center;gap:4px;background:var(--bg);border:1px solid var(--line);border-radius:12px;padding:5px 6px;box-shadow:var(--shadow);max-width:calc(100vw - 20px);flex-wrap:nowrap;overflow-x:auto;scrollbar-width:thin}
.toolbar>*{flex-shrink:0}
.toolbar .brand{white-space:nowrap;display:flex;align-items:center;gap:6px;font-weight:650;padding:0 6px 0 4px;cursor:grab;user-select:none}
.toolbar .brand .dot{width:10px;height:10px;border-radius:50%;background:var(--ac)}
.toolbar .sep{width:1px;height:22px;background:var(--line);margin:0 3px}
.toolbar select{width:160px;max-width:160px;padding:5px 8px;border:1px solid var(--line);border-radius:8px;background:var(--bg-2)}
.status{font-size:12px;color:var(--tx-3);padding:0 6px;min-width:56px;text-align:center}
.status.err{color:var(--bad)}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;border:1px solid var(--line);background:var(--bg);padding:6px 10px;border-radius:8px;cursor:pointer;white-space:nowrap;line-height:1.2}
.btn:hover{background:var(--bg-3)}
.btn:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible{outline:2px solid var(--ac);outline-offset:1px}
.btn-primary{background:var(--ac);border-color:var(--ac);color:#fff}
.btn-primary:hover{background:var(--ac-2)}
.btn-ghost{border-color:transparent;background:transparent}
.btn-danger{color:var(--bad)}
.btn-sm{padding:4px 8px;font-size:12px}
.btn-icon{padding:6px}
.btn[aria-pressed=true]{background:var(--ac-soft);border-color:var(--ac);color:var(--ac)}
.btn:disabled{opacity:.45;cursor:default}
.panel{position:fixed;z-index:2147483642;top:0;bottom:0;width:380px;max-width:100vw;background:var(--bg);border-left:1px solid var(--line);box-shadow:var(--shadow);display:flex;flex-direction:column}
.panel.right{right:0}.panel.left{left:0;border-left:0;border-right:1px solid var(--line)}
.panel.hidden{display:none}
.panel-head{display:flex;align-items:center;gap:6px;padding:10px 10px 0 12px}
.panel-head h2{font-size:14px;margin:0;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.tabs{display:flex;gap:2px;padding:8px 8px 0;border-bottom:1px solid var(--line);overflow-x:auto;scrollbar-width:thin}
.tab{display:flex;align-items:center;gap:5px;border:0;background:transparent;padding:7px 9px;border-radius:8px 8px 0 0;cursor:pointer;color:var(--tx-2);border-bottom:2px solid transparent;white-space:nowrap}
.tab[aria-selected=true]{color:var(--ac);border-bottom-color:var(--ac);font-weight:600}
.tab:hover{background:var(--bg-3)}
.body{flex:1;overflow:auto;padding:12px;scrollbar-width:thin}
.sec{border:1px solid var(--line);border-radius:var(--r);padding:10px 12px;margin:0 0 10px;background:var(--bg)}
.sec h3{margin:0 0 8px;font-size:12px;letter-spacing:.02em;text-transform:uppercase;color:var(--tx-3)}
.field{display:flex;flex-direction:column;gap:4px;margin:0 0 8px}
.field label{font-size:12px;color:var(--tx-2);font-weight:550}
.hint{font-size:11.5px;color:var(--tx-3)}
input[type=text],input[type=url],input[type=number],input:not([type]),input[type=color],input[type=search],select,textarea{width:100%;border:1px solid var(--line-2);border-radius:8px;padding:6px 8px;background:var(--bg)}
input[type=color]{padding:2px;height:32px}
textarea{resize:vertical;min-height:34px}
.mono{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:12px}
.row{display:flex;gap:6px;align-items:center;flex-wrap:wrap}
.row>*{min-width:0}
.grow{flex:1}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:6px 8px}
.check{display:flex;align-items:center;gap:6px;cursor:pointer;margin:2px 0}
.empty{color:var(--tx-3);font-size:12.5px;margin:4px 0 8px}
.crumbs{display:flex;flex-wrap:wrap;gap:2px;font-size:11.5px;margin:0 0 8px}
.crumbs button{border:0;background:var(--bg-3);padding:2px 6px;border-radius:5px;cursor:pointer;color:var(--tx-2)}
.crumbs button:last-child{background:var(--ac-soft);color:var(--ac);font-weight:600}
.item{border:1px solid var(--line);border-radius:9px;padding:8px 10px;margin:0 0 6px;display:flex;flex-direction:column;gap:4px;background:var(--bg)}
.item.off{opacity:.55}
.item .top{display:flex;align-items:center;gap:6px}
.item .title{font-weight:600;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.item .sub{font-size:11.5px;color:var(--tx-3);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.badge{display:inline-block;font-size:10.5px;padding:1px 6px;border-radius:999px;background:var(--bg-3);color:var(--tx-2);white-space:nowrap}
.badge.ac{background:var(--ac-soft);color:var(--ac)}
.badge.warn{background:#fef3c7;color:#92400e}
.err{color:var(--bad);font-size:12px}
.ok{color:var(--ok);font-size:12px}
.value{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:11.5px;background:var(--bg-3);border-radius:6px;padding:4px 6px;white-space:pre-wrap;word-break:break-all;max-height:120px;overflow:auto}
.lib{display:grid;grid-template-columns:repeat(auto-fill,minmax(104px,1fr));gap:6px}
.lib button{display:flex;flex-direction:column;align-items:flex-start;gap:2px;text-align:left;border:1px solid var(--line);background:var(--bg);border-radius:9px;padding:8px;cursor:pointer;min-height:58px}
.lib button:hover{border-color:var(--ac);background:var(--ac-soft)}
.lib b{font-size:12.5px}
.lib small{font-size:11px;color:var(--tx-3)}
.cat{font-size:11.5px;font-weight:650;color:var(--tx-3);margin:10px 0 6px;text-transform:uppercase;letter-spacing:.03em}
.actions{display:flex;flex-direction:column;gap:6px}
.action{border:1px dashed var(--line-2);border-radius:8px;padding:8px;display:flex;flex-direction:column;gap:6px}
.banner{position:fixed;z-index:2147483644;left:50%;top:14px;transform:translateX(-50%);background:#f97316;color:#fff;padding:8px 14px;border-radius:10px;box-shadow:var(--shadow);display:flex;gap:10px;align-items:center}
.banner .btn{background:rgba(255,255,255,.15);border-color:rgba(255,255,255,.4);color:#fff}
.toast{position:fixed;z-index:2147483646;left:50%;top:14px;transform:translateX(-50%);background:#0f172a;color:#fff;padding:8px 14px;border-radius:10px;box-shadow:var(--shadow);max-width:calc(100vw - 32px)}
.toast.err{background:#b91c1c}
.welcome{position:fixed;z-index:2147483645;inset:0;background:rgba(15,23,42,.45);display:flex;align-items:center;justify-content:center;padding:16px}
.welcome .card{background:var(--bg);border-radius:14px;max-width:440px;width:100%;padding:18px;box-shadow:var(--shadow)}
.welcome h2{margin:0 0 6px;font-size:17px}
.welcome p{margin:0 0 12px;color:var(--tx-2)}
.inline-edit{outline:2px solid #f97316 !important;outline-offset:2px}
.kbd{font-family:ui-monospace,Menlo,monospace;font-size:11px;background:var(--bg-3);border:1px solid var(--line);border-radius:4px;padding:0 4px}
details>summary{cursor:pointer;color:var(--tx-2);font-weight:550;margin:2px 0 6px}
@media (max-width:720px){.panel{width:100vw;top:auto;height:55vh;border-left:0;border-top:1px solid var(--line)}.toolbar{bottom:auto;top:6px;gap:2px;padding:4px;flex-wrap:wrap}.toolbar .brand-label,.toolbar .sep{display:none}.toolbar select{width:104px;max-width:104px;padding:5px 4px}.toolbar .btn-icon{padding:5px}.status{min-width:0;padding:0 3px}}
`;
  var PAGE_CSS = `
html.wce-editing [data-wce-editing]{outline:2px solid #f97316 !important;outline-offset:2px !important;cursor:text !important;min-height:1em}
html.wce-editing.wce-pick *{cursor:crosshair !important}
`;

  // src/shared/expr.ts
  var OPERATORS = ["===", "!==", "==", "!=", "<=", ">=", "&&", "||", "??", "?.", "<", ">", "+", "-", "*", "/", "%", "!", "?", ":", ".", ",", "(", ")", "[", "]", "{", "}", "|"];
  var ExpressionError = class extends Error {
  };
  function lex(source) {
    const tokens = [];
    let at = 0;
    while (at < source.length) {
      const ch = source[at] ?? "";
      if (/\s/.test(ch)) {
        at += 1;
        continue;
      }
      if (/[0-9]/.test(ch) || ch === "." && /[0-9]/.test(source[at + 1] ?? "")) {
        const match = /^(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?/.exec(source.slice(at));
        const text = match?.[0] ?? ch;
        tokens.push({ t: "num", v: Number(text) });
        at += text.length;
        continue;
      }
      if (ch === '"' || ch === "'" || ch === "`") {
        let value = "";
        let end = at + 1;
        while (end < source.length && source[end] !== ch) {
          if (source[end] === "\\") {
            const next = source[end + 1] ?? "";
            value += next === "n" ? "\n" : next === "t" ? "	" : next;
            end += 2;
          } else {
            value += source[end];
            end += 1;
          }
        }
        if (end >= source.length) throw new ExpressionError("Texto sem aspas de fechamento.");
        tokens.push({ t: "str", v: value });
        at = end + 1;
        continue;
      }
      if (/[A-Za-z_$\u00C0-\u024F]/.test(ch)) {
        const match = /^[A-Za-z_$\u00C0-\u024F][A-Za-z0-9_$\u00C0-\u024F]*/.exec(source.slice(at));
        const text = match?.[0] ?? ch;
        tokens.push({ t: "id", v: text });
        at += text.length;
        continue;
      }
      const op = OPERATORS.find((candidate) => source.startsWith(candidate, at));
      if (op === void 0) throw new ExpressionError(`Caractere inesperado: ${ch}`);
      tokens.push({ t: "op", v: op });
      at += op.length;
    }
    tokens.push({ t: "end" });
    return tokens;
  }
  var BINARY = {
    "|": 1,
    "??": 3,
    "||": 4,
    "&&": 5,
    "==": 6,
    "!=": 6,
    "===": 6,
    "!==": 6,
    "<": 7,
    ">": 7,
    "<=": 7,
    ">=": 7,
    "+": 8,
    "-": 8,
    "*": 9,
    "/": 9,
    "%": 9
  };
  var Parser = class {
    constructor(tokens) {
      this.tokens = tokens;
    }
    at = 0;
    peek() {
      return this.tokens[this.at] ?? { t: "end" };
    }
    next() {
      const token = this.peek();
      this.at += 1;
      return token;
    }
    isOp(value) {
      const token = this.peek();
      return token.t === "op" && token.v === value;
    }
    expect(value) {
      if (!this.isOp(value)) throw new ExpressionError(`Esperava "${value}".`);
      this.at += 1;
    }
    parseAll() {
      const node = this.expression(0);
      if (this.peek().t !== "end") throw new ExpressionError("Sobrou texto depois da express\xE3o.");
      return node;
    }
    expression(minPrecedence) {
      let left = this.unary();
      for (; ; ) {
        const token = this.peek();
        if (token.t === "op" && token.v === "?" && minPrecedence <= 2) {
          this.next();
          const yes = this.expression(0);
          this.expect(":");
          const no = this.expression(2);
          left = { k: "cond", test: left, yes, no };
          continue;
        }
        if (token.t !== "op") break;
        const precedence = BINARY[token.v];
        if (precedence === void 0 || precedence < minPrecedence) break;
        this.next();
        if (token.v === "|") {
          const name = this.next();
          if (name.t !== "id") throw new ExpressionError('Esperava o nome de um filtro depois de "|".');
          const args = [left];
          if (this.isOp("(")) args.push(...this.args());
          left = { k: "call", fn: name.v, args };
          continue;
        }
        const right = this.expression(precedence + 1);
        left = { k: "binary", op: token.v, left, right };
      }
      return left;
    }
    args() {
      this.expect("(");
      const args = [];
      while (!this.isOp(")")) {
        args.push(this.expression(2));
        if (!this.isOp(")")) this.expect(",");
      }
      this.expect(")");
      return args;
    }
    unary() {
      const token = this.peek();
      if (token.t === "op" && (token.v === "!" || token.v === "-" || token.v === "+")) {
        this.next();
        return { k: "unary", op: token.v, arg: this.unary() };
      }
      return this.postfix(this.primary());
    }
    postfix(start) {
      let node = start;
      for (; ; ) {
        if (this.isOp(".") || this.isOp("?.")) {
          const optional = this.isOp("?.");
          this.next();
          const name = this.next();
          if (name.t !== "id") throw new ExpressionError("Esperava um nome depois do ponto.");
          node = { k: "member", obj: node, prop: { k: "lit", v: name.v }, optional };
        } else if (this.isOp("[")) {
          this.next();
          const prop = this.expression(0);
          this.expect("]");
          node = { k: "member", obj: node, prop, optional: false };
        } else break;
      }
      return node;
    }
    primary() {
      const token = this.next();
      switch (token.t) {
        case "num":
        case "str":
          return { k: "lit", v: token.v };
        case "id": {
          if (token.v === "true") return { k: "lit", v: true };
          if (token.v === "false") return { k: "lit", v: false };
          if (token.v === "null" || token.v === "undefined") return { k: "lit", v: null };
          if (this.isOp("(")) return { k: "call", fn: token.v, args: this.args() };
          return { k: "name", v: token.v };
        }
        case "op": {
          if (token.v === "(") {
            const inner = this.expression(0);
            this.expect(")");
            return inner;
          }
          if (token.v === "[") {
            const items = [];
            while (!this.isOp("]")) {
              items.push(this.expression(2));
              if (!this.isOp("]")) this.expect(",");
            }
            this.expect("]");
            return { k: "array", items };
          }
          if (token.v === "{") {
            const entries = [];
            while (!this.isOp("}")) {
              const key = this.next();
              if (key.t !== "id" && key.t !== "str") throw new ExpressionError("Esperava o nome de um campo.");
              this.expect(":");
              entries.push([String(key.v), this.expression(2)]);
              if (!this.isOp("}")) this.expect(",");
            }
            this.expect("}");
            return { k: "object", entries };
          }
          throw new ExpressionError(`S\xEDmbolo inesperado: ${token.v}`);
        }
        default:
          throw new ExpressionError("A express\xE3o terminou cedo demais.");
      }
    }
  };
  var cache = /* @__PURE__ */ new Map();
  function parse(source) {
    const hit = cache.get(source);
    if (hit) return hit;
    const node = new Parser(lex(source)).parseAll();
    if (cache.size > 2e3) cache.clear();
    cache.set(source, node);
    return node;
  }
  function toText(value) {
    if (value === null || value === void 0) return "";
    if (typeof value === "string") return value;
    if (typeof value === "number") return Number.isFinite(value) ? String(value) : "";
    if (typeof value === "boolean") return value ? "true" : "false";
    if (value instanceof Date) return value.toISOString();
    return JSON.stringify(value);
  }
  function check(source) {
    try {
      if (source.trim() !== "") parse(source);
      return null;
    } catch (error) {
      return error instanceof Error ? error.message : String(error);
    }
  }
  function hasTemplate(text) {
    return text.includes("{{");
  }

  // src/editor/components.ts
  var BASE = `font-family:inherit;box-sizing:border-box`;
  var COMPONENTS = [
    // ------------------------------------------------------------- básico
    { id: "heading", name: "T\xEDtulo", category: "B\xE1sico", description: "Um t\xEDtulo de se\xE7\xE3o", html: `<h2 class="wce-c-heading" style="${BASE};margin:16px 0 8px;font-size:28px;line-height:1.2">Novo t\xEDtulo</h2>` },
    { id: "paragraph", name: "Par\xE1grafo", category: "B\xE1sico", description: "Texto corrido", html: `<p class="wce-c-p" style="${BASE};margin:8px 0;line-height:1.6">Escreva aqui o seu texto. Use {{ variavel }} para dados din\xE2micos.</p>` },
    {
      id: "button",
      name: "Bot\xE3o",
      category: "B\xE1sico",
      description: "Bot\xE3o com link",
      html: `<a class="wce-c-btn" href="#" style="${BASE};display:inline-block;background:#2563eb;color:#fff;padding:10px 18px;border-radius:8px;text-decoration:none;font-weight:600">Clique aqui</a>`
    },
    { id: "link", name: "Link", category: "B\xE1sico", description: "Um link de texto", html: `<a class="wce-c-link" href="https://" style="color:#2563eb">Novo link</a>` },
    { id: "image", name: "Imagem", category: "B\xE1sico", description: "Imagem responsiva", html: `<img class="wce-c-img" src="https://picsum.photos/seed/wce/800/450" alt="Imagem" style="display:block;max-width:100%;height:auto;border-radius:8px">` },
    { id: "divider", name: "Divisor", category: "B\xE1sico", description: "Linha horizontal", html: `<hr class="wce-c-hr" style="border:0;border-top:1px solid #e5e7eb;margin:20px 0">` },
    { id: "spacer", name: "Espa\xE7o", category: "B\xE1sico", description: "Espa\xE7o vertical", html: `<div class="wce-c-spacer" style="height:32px" aria-hidden="true"></div>` },
    { id: "list", name: "Lista", category: "B\xE1sico", description: "Lista com marcadores", html: `<ul class="wce-c-list" style="${BASE};margin:8px 0;padding-left:20px;line-height:1.7"><li>Primeiro item</li><li>Segundo item</li><li>Terceiro item</li></ul>` },
    {
      id: "html",
      name: "HTML livre",
      category: "B\xE1sico",
      description: "Qualquer HTML",
      html: `<div class="wce-c-html">[[html]]</div>`,
      asks: [{ key: "html", label: "HTML", value: '<div style="padding:16px;border:1px dashed #94a3b8;border-radius:8px">Seu HTML aqui</div>' }]
    },
    // ------------------------------------------------------------- seções
    {
      id: "banner",
      name: "Aviso",
      category: "Se\xE7\xF5es",
      description: "Faixa de aviso",
      html: `<div class="wce-c-banner" role="status" style="${BASE};background:#eff6ff;border:1px solid #bfdbfe;color:#1e3a8a;padding:12px 16px;border-radius:10px;margin:12px 0">\u{1F4E3} Aviso importante para {{ client.name }}.</div>`
    },
    {
      id: "announcement",
      name: "Barra de an\xFAncio",
      category: "Se\xE7\xF5es",
      description: "Faixa fixa no topo",
      html: `<div class="wce-c-bar" style="${BASE};position:sticky;top:0;z-index:999;background:#111827;color:#fff;text-align:center;padding:8px 12px;font-size:14px">Frete gr\xE1tis nesta semana \xB7 <a href="#" style="color:#93c5fd">saiba mais</a></div>`
    },
    {
      id: "hero",
      name: "Destaque (hero)",
      category: "Se\xE7\xF5es",
      description: "T\xEDtulo, texto e bot\xE3o",
      html: `<section class="wce-c-hero" style="${BASE};padding:56px 24px;text-align:center;background:linear-gradient(135deg,#1e3a8a,#2563eb);color:#fff;border-radius:16px;margin:16px 0"><h1 style="margin:0 0 12px;font-size:40px;line-height:1.1">Bem-vindo, {{ client.name }}</h1><p style="margin:0 auto 20px;max-width:560px;font-size:18px;opacity:.9">Uma frase que explica o valor do produto em poucas palavras.</p><a href="#" style="display:inline-block;background:#fff;color:#1e3a8a;padding:12px 22px;border-radius:10px;font-weight:700;text-decoration:none">Come\xE7ar agora</a></section>`
    },
    {
      id: "card",
      name: "Cart\xE3o",
      category: "Se\xE7\xF5es",
      description: "Imagem, t\xEDtulo e texto",
      html: `<article class="wce-c-card" style="${BASE};border:1px solid #e5e7eb;border-radius:14px;overflow:hidden;max-width:360px;background:#fff;color:#111827"><img src="https://picsum.photos/seed/card/720/400" alt="" style="display:block;width:100%;height:auto"><div style="padding:14px 16px"><h3 style="margin:0 0 6px;font-size:18px">T\xEDtulo do cart\xE3o</h3><p style="margin:0;color:#4b5563;line-height:1.5">Descri\xE7\xE3o curta do conte\xFAdo.</p></div></article>`
    },
    {
      id: "features",
      name: "Recursos (3 colunas)",
      category: "Se\xE7\xF5es",
      description: "Tr\xEAs benef\xEDcios lado a lado",
      html: `<section class="wce-c-features" style="${BASE};display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px;margin:16px 0">${["\u26A1 R\xE1pido", "\u{1F512} Seguro", "\u{1F4AC} Suporte"].map((title) => `<div style="padding:18px;border:1px solid #e5e7eb;border-radius:12px;background:#fff;color:#111827"><h3 style="margin:0 0 6px;font-size:17px">${title}</h3><p style="margin:0;color:#4b5563">Explique o benef\xEDcio em uma frase.</p></div>`).join("")}</section>`
    },
    {
      id: "stats",
      name: "N\xFAmeros",
      category: "Se\xE7\xF5es",
      description: "Estat\xEDsticas em destaque",
      html: `<section class="wce-c-stats" style="${BASE};display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin:16px 0;text-align:center">${[
        ["+1.200", "clientes"],
        ["98%", "satisfa\xE7\xE3o"],
        ["24h", "suporte"]
      ].map(([n, l]) => `<div style="padding:16px;border-radius:12px;background:#f8fafc;color:#0f172a"><div style="font-size:30px;font-weight:800">${n}</div><div style="color:#64748b">${l}</div></div>`).join("")}</section>`
    },
    {
      id: "testimonial",
      name: "Depoimento",
      category: "Se\xE7\xF5es",
      description: "Cita\xE7\xE3o de cliente",
      html: `<figure class="wce-c-quote" style="${BASE};margin:16px 0;padding:20px;border-left:4px solid #2563eb;background:#f8fafc;color:#0f172a;border-radius:8px"><blockquote style="margin:0 0 8px;font-size:17px;line-height:1.5">\u201CO melhor servi\xE7o que j\xE1 contratamos.\u201D</blockquote><figcaption style="color:#64748b">\u2014 Maria Souza, Empresa X</figcaption></figure>`
    },
    {
      id: "pricing",
      name: "Tabela de pre\xE7os",
      category: "Se\xE7\xF5es",
      description: "Planos lado a lado",
      html: `<section class="wce-c-pricing" style="${BASE};display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:14px;margin:16px 0">${[
        ["B\xE1sico", "49"],
        ["Pro", "99"],
        ["Empresa", "199"]
      ].map(([name, price], i) => `<div style="padding:20px;border:${i === 1 ? "2px solid #2563eb" : "1px solid #e5e7eb"};border-radius:14px;background:#fff;color:#111827"><h3 style="margin:0 0 4px">${name}</h3><div style="font-size:30px;font-weight:800;margin:6px 0">{{ ${price} | money }}<small style="font-size:14px;color:#64748b">/m\xEAs</small></div><ul style="padding-left:18px;color:#4b5563;line-height:1.8"><li>Recurso inclu\xEDdo</li><li>Outro recurso</li></ul><a href="#" style="display:block;text-align:center;background:#2563eb;color:#fff;padding:10px;border-radius:8px;text-decoration:none;font-weight:600">Assinar</a></div>`).join("")}</section>`
    },
    {
      id: "faq",
      name: "Perguntas frequentes",
      category: "Se\xE7\xF5es",
      description: "Acorde\xE3o nativo",
      html: `<section class="wce-c-faq" style="${BASE};margin:16px 0">${["Como funciona?", "Quanto custa?", "Posso cancelar?"].map((q) => `<details style="border:1px solid #e5e7eb;border-radius:10px;padding:10px 14px;margin:0 0 8px;background:#fff;color:#111827"><summary style="cursor:pointer;font-weight:600">${q}</summary><p style="margin:8px 0 0;color:#4b5563">Resposta para a pergunta.</p></details>`).join("")}</section>`
    },
    {
      id: "timeline",
      name: "Linha do tempo",
      category: "Se\xE7\xF5es",
      description: "Etapas em sequ\xEAncia",
      html: `<ol class="wce-c-timeline" style="${BASE};list-style:none;margin:16px 0;padding:0;border-left:2px solid #2563eb">${["Pedido recebido", "Em prepara\xE7\xE3o", "Enviado", "Entregue"].map((s) => `<li style="position:relative;padding:0 0 14px 18px"><span style="position:absolute;left:-7px;top:4px;width:12px;height:12px;border-radius:50%;background:#2563eb"></span><b>${s}</b><div style="color:#64748b;font-size:14px">Descri\xE7\xE3o da etapa</div></li>`).join("")}</ol>`
    },
    {
      id: "footer",
      name: "Rodap\xE9",
      category: "Se\xE7\xF5es",
      description: "Links e direitos",
      html: `<footer class="wce-c-footer" style="${BASE};padding:24px;background:#0f172a;color:#cbd5e1;display:flex;flex-wrap:wrap;gap:16px;justify-content:space-between;align-items:center;margin-top:24px"><span>\xA9 {{ date(now(), 'yyyy') }} {{ client.name }}</span><nav style="display:flex;gap:14px"><a href="#" style="color:#cbd5e1">Privacidade</a><a href="#" style="color:#cbd5e1">Termos</a><a href="#" style="color:#cbd5e1">Contato</a></nav></footer>`
    },
    // ------------------------------------------------------------- mídia
    {
      id: "carousel",
      name: "Carrossel de fotos",
      category: "M\xEDdia",
      description: "Slides com setas e pontos",
      html: `<div class="wce-c-carousel" data-wce-carousel data-wce-autoplay="5000" style="${BASE};position:relative;max-width:100%;border-radius:14px;overflow:hidden;margin:16px 0;background:#000"><div data-wce-track>${[1, 2, 3].map((n) => `<figure data-wce-slide style="margin:0;aspect-ratio:2/1;background:#1e293b"><img src="https://picsum.photos/seed/slide${n}/1200/600" alt="Foto ${n}" style="display:block;width:100%;height:100%;object-fit:cover"></figure>`).join("")}</div><button type="button" data-wce-prev aria-label="Anterior" style="position:absolute;left:10px;top:50%;transform:translateY(-50%);border:0;border-radius:50%;width:38px;height:38px;background:rgba(255,255,255,.85);cursor:pointer;font-size:20px">\u2039</button><button type="button" data-wce-next aria-label="Pr\xF3xima" style="position:absolute;right:10px;top:50%;transform:translateY(-50%);border:0;border-radius:50%;width:38px;height:38px;background:rgba(255,255,255,.85);cursor:pointer;font-size:20px">\u203A</button><div data-wce-dots style="position:absolute;bottom:10px;left:0;right:0;display:flex;gap:6px;justify-content:center;pointer-events:none"></div><style>.wce-c-carousel [data-wce-dots] button{pointer-events:auto;width:9px;height:9px;border-radius:50%;border:0;background:rgba(255,255,255,.5);cursor:pointer;padding:0}.wce-c-carousel [data-wce-dots] button[aria-current=true]{background:#fff}</style></div>`
    },
    {
      id: "gallery",
      name: "Galeria",
      category: "M\xEDdia",
      description: "Grade de fotos com amplia\xE7\xE3o",
      html: `<div class="wce-c-gallery" data-wce-lightbox style="${BASE};display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:8px;margin:16px 0">${[1, 2, 3, 4, 5, 6].map((n) => `<img src="https://picsum.photos/seed/g${n}/600/600" data-full="https://picsum.photos/seed/g${n}/1400/1400" alt="Foto ${n}" style="width:100%;aspect-ratio:1;object-fit:cover;border-radius:8px;cursor:zoom-in">`).join("")}</div>`
    },
    {
      id: "video",
      name: "V\xEDdeo (YouTube/Vimeo)",
      category: "M\xEDdia",
      description: "V\xEDdeo incorporado",
      html: `<div class="wce-c-video" style="${BASE};position:relative;aspect-ratio:16/9;margin:16px 0;border-radius:12px;overflow:hidden;background:#000"><iframe src="[[url]]" title="V\xEDdeo" style="position:absolute;inset:0;width:100%;height:100%;border:0" allow="accelerometer;autoplay;clipboard-write;encrypted-media;gyroscope;picture-in-picture" allowfullscreen loading="lazy"></iframe></div>`,
      asks: [{ key: "url", label: "Endere\xE7o do v\xEDdeo (YouTube, Vimeo ou embed)", value: "https://www.youtube.com/watch?v=dQw4w9WgXcQ" }]
    },
    {
      id: "video-file",
      name: "V\xEDdeo (arquivo)",
      category: "M\xEDdia",
      description: "MP4/WebM com controles",
      html: `<video class="wce-c-video-file" src="[[url]]" controls playsinline style="display:block;max-width:100%;border-radius:12px;margin:16px 0"></video>`,
      asks: [{ key: "url", label: "Endere\xE7o do arquivo de v\xEDdeo", value: "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4" }]
    },
    {
      id: "audio",
      name: "\xC1udio",
      category: "M\xEDdia",
      description: "Player de \xE1udio",
      html: `<audio class="wce-c-audio" src="[[url]]" controls style="width:100%;margin:12px 0"></audio>`,
      asks: [{ key: "url", label: "Endere\xE7o do \xE1udio", value: "https://interactive-examples.mdn.mozilla.net/media/cc0-audio/t-rex-roar.mp3" }]
    },
    {
      id: "map",
      name: "Mapa",
      category: "M\xEDdia",
      description: "Google Maps por endere\xE7o",
      html: `<div class="wce-c-map" style="${BASE};aspect-ratio:16/9;margin:16px 0;border-radius:12px;overflow:hidden"><iframe title="Mapa" src="https://maps.google.com/maps?q=[[address]]&output=embed" style="width:100%;height:100%;border:0" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></div>`,
      asks: [{ key: "address", label: "Endere\xE7o ou lugar", value: "Avenida Paulista, 1000, S\xE3o Paulo" }]
    },
    {
      id: "embed",
      name: "Incorporar p\xE1gina",
      category: "M\xEDdia",
      description: "Iframe de outro endere\xE7o",
      html: `<iframe class="wce-c-embed" src="[[url]]" title="Conte\xFAdo incorporado" style="width:100%;height:480px;border:1px solid #e5e7eb;border-radius:12px;margin:16px 0" loading="lazy"></iframe>`,
      asks: [{ key: "url", label: "Endere\xE7o", value: "https://example.com" }]
    },
    // ------------------------------------------------------------- interativos
    {
      id: "tabs",
      name: "Abas",
      category: "Interativos",
      description: "Conte\xFAdo em abas",
      html: `<div class="wce-c-tabs" data-wce-tabs style="${BASE};margin:16px 0"><div role="tablist" style="display:flex;gap:4px;border-bottom:1px solid #e5e7eb">${["Vis\xE3o geral", "Detalhes", "Avalia\xE7\xF5es"].map((t, i) => `<button type="button" role="tab" data-wce-tab="t${i}" style="border:0;background:none;padding:8px 14px;cursor:pointer;font:inherit;border-bottom:2px solid transparent">${t}</button>`).join("")}</div>${["Conte\xFAdo da vis\xE3o geral.", "Conte\xFAdo dos detalhes.", "Conte\xFAdo das avalia\xE7\xF5es."].map((c, i) => `<div role="tabpanel" data-wce-panel="t${i}" style="padding:14px 4px">${c}</div>`).join("")}<style>.wce-c-tabs [data-wce-tab].is-active{border-bottom-color:#2563eb!important;color:#2563eb;font-weight:600}</style></div>`
    },
    {
      id: "countdown",
      name: "Contagem regressiva",
      category: "Interativos",
      description: "Tempo at\xE9 uma data",
      html: `<div class="wce-c-countdown" style="${BASE};display:inline-flex;align-items:center;gap:10px;padding:10px 16px;border-radius:10px;background:#111827;color:#fff;margin:12px 0"><span>Oferta termina em</span><b data-wce-countdown="[[date]]" style="font-variant-numeric:tabular-nums;font-size:20px">--:--:--</b></div>`,
      asks: [{ key: "date", label: "Data e hora (AAAA-MM-DDTHH:MM)", value: new Date(Date.now() + 3 * 864e5).toISOString().slice(0, 16) }]
    },
    {
      id: "modal-button",
      name: "Bot\xE3o com janela",
      category: "Interativos",
      description: "Abre uma janela com conte\xFAdo",
      html: `<button type="button" class="wce-c-modal-btn" data-wce-actions='[{"type":"modal","title":"Saiba mais","html":"<p>Conte\xFAdo da janela para {{ client.name }}.</p>"}]' style="${BASE};background:#2563eb;color:#fff;border:0;padding:10px 18px;border-radius:8px;font-weight:600;cursor:pointer">Saiba mais</button>`
    },
    {
      id: "contact-form",
      name: "Formul\xE1rio de contato",
      category: "Interativos",
      description: "Guarda os envios numa vari\xE1vel",
      variables: [{ name: "contatos", type: "list", default: [], persist: "local", description: "Mensagens enviadas pelo formul\xE1rio inserido" }],
      html: `<form class="wce-c-form" data-wce-actions='[{"type":"push","variable":"contatos","expr":"event.form"},{"type":"toast","expr":"\\"Obrigado, \\" + event.form.nome + \\"! Recebemos sua mensagem.\\"","tone":"success"}]' style="${BASE};display:grid;gap:10px;max-width:460px;margin:16px 0;padding:18px;border:1px solid #e5e7eb;border-radius:14px;background:#fff;color:#111827"><label style="display:grid;gap:4px">Nome<input name="nome" required style="padding:8px;border:1px solid #cbd5e1;border-radius:8px;font:inherit"></label><label style="display:grid;gap:4px">E-mail<input name="email" type="email" required style="padding:8px;border:1px solid #cbd5e1;border-radius:8px;font:inherit"></label><label style="display:grid;gap:4px">Mensagem<textarea name="mensagem" rows="3" style="padding:8px;border:1px solid #cbd5e1;border-radius:8px;font:inherit"></textarea></label><button type="submit" style="background:#2563eb;color:#fff;border:0;padding:10px;border-radius:8px;font-weight:600;cursor:pointer">Enviar</button></form>`
    },
    {
      id: "rating",
      name: "Avalia\xE7\xE3o",
      category: "Interativos",
      description: "Estrelas de 1 a 5",
      variables: [{ name: "nota", type: "number", default: 4, persist: "local" }],
      html: `<div class="wce-c-rating" style="font-size:24px;color:#f59e0b;margin:8px 0" aria-label="Nota {{ nota }} de 5">${[1, 2, 3, 4, 5].map((n) => `<button type="button" aria-label="${n} estrelas" data-wce-actions='[{"type":"set","variable":"nota","expr":"${n}"}]' style="border:0;background:none;cursor:pointer;font-size:inherit;color:inherit;padding:0 2px">{{ nota >= ${n} ? '\u2605' : '\u2606' }}</button>`).join("")}</div>`
    },
    {
      id: "whatsapp",
      name: "Bot\xE3o do WhatsApp",
      category: "Interativos",
      description: "Bot\xE3o flutuante",
      html: `<a class="wce-c-whatsapp" href="https://wa.me/[[phone]]?text={{ encode('Ol\xE1! Vim pelo site.') }}" target="_blank" rel="noopener" aria-label="Conversar no WhatsApp" style="position:fixed;right:20px;bottom:20px;z-index:99999;width:56px;height:56px;border-radius:50%;background:#25d366;color:#fff;display:flex;align-items:center;justify-content:center;box-shadow:0 8px 24px rgba(0,0,0,.25);font-size:28px;text-decoration:none">\u2706</a>`,
      asks: [{ key: "phone", label: "N\xFAmero com DDI e DDD (s\xF3 d\xEDgitos)", value: "5511999999999" }]
    },
    {
      id: "social",
      name: "Redes sociais",
      category: "Interativos",
      description: "Links para as redes",
      html: `<nav class="wce-c-social" aria-label="Redes sociais" style="display:flex;gap:10px;margin:12px 0">${["Instagram", "Facebook", "LinkedIn", "YouTube"].map((n) => `<a href="#" style="padding:6px 12px;border-radius:999px;background:#f1f5f9;color:#0f172a;text-decoration:none;font-size:14px">${n}</a>`).join("")}</nav>`
    },
    // ------------------------------------------------------------- comércio
    {
      id: "product",
      name: "Produto",
      category: "Com\xE9rcio",
      description: "Adiciona ao carrinho",
      variables: [{ name: "carrinho", type: "list", default: [], persist: "local", description: "Itens do carrinho" }],
      html: `<article class="wce-c-product" style="${BASE};border:1px solid #e5e7eb;border-radius:14px;overflow:hidden;max-width:300px;background:#fff;color:#111827"><img src="https://picsum.photos/seed/produto/600/600" alt="Produto" style="display:block;width:100%;height:auto"><div style="padding:14px"><h3 style="margin:0 0 4px;font-size:17px">Nome do produto</h3><div style="font-size:20px;font-weight:800;margin:4px 0 10px">{{ 129.9 | money }}</div><button type="button" data-wce-actions='[{"type":"push","variable":"carrinho","expr":"{nome: \\"Nome do produto\\", preco: 129.9, qtd: 1}"},{"type":"toast","expr":"\\"Adicionado ao carrinho\\"","tone":"success"}]' style="width:100%;background:#16a34a;color:#fff;border:0;padding:10px;border-radius:8px;font-weight:600;cursor:pointer">Adicionar ao carrinho</button></div></article>`
    },
    {
      id: "cart",
      name: "Carrinho",
      category: "Com\xE9rcio",
      description: "Itens, total e esvaziar",
      variables: [{ name: "carrinho", type: "list", default: [], persist: "local", description: "Itens do carrinho" }],
      html: `<aside class="wce-c-cart" style="${BASE};border:1px solid #e5e7eb;border-radius:14px;padding:16px;max-width:360px;background:#fff;color:#111827;margin:16px 0"><h3 style="margin:0 0 10px">Carrinho ({{ len(carrinho) }})</h3>{{{ len(carrinho) == 0 ? '<p style="color:#64748b;margin:0">Seu carrinho est\xE1 vazio.</p>' : '' }}}<ul style="list-style:none;margin:0;padding:0"><li data-wce-repeat-slot></li></ul><div style="display:flex;justify-content:space-between;font-weight:800;margin:12px 0">Total <span>{{ sum(carrinho, 'preco') | money }}</span></div><button type="button" data-wce-actions='[{"type":"set","variable":"carrinho","expr":"[]"}]' style="width:100%;background:#f1f5f9;border:0;padding:9px;border-radius:8px;cursor:pointer">Esvaziar</button></aside>`
    },
    {
      id: "cart-count",
      name: "Contador do carrinho",
      category: "Com\xE9rcio",
      description: "Selo com a quantidade",
      variables: [{ name: "carrinho", type: "list", default: [], persist: "local", description: "Itens do carrinho" }],
      html: `<span class="wce-c-cart-count" style="display:inline-flex;align-items:center;gap:4px;background:#16a34a;color:#fff;border-radius:999px;padding:2px 10px;font-size:13px;font-weight:700">\u{1F6D2} {{ len(carrinho) }}</span>`
    },
    {
      id: "coupon",
      name: "Cupom",
      category: "Com\xE9rcio",
      description: "C\xF3digo para copiar",
      html: `<div class="wce-c-coupon" style="${BASE};display:inline-flex;gap:10px;align-items:center;border:2px dashed #16a34a;border-radius:12px;padding:10px 14px;margin:12px 0;background:#f0fdf4;color:#14532d"><span>Use o cupom <b>[[code]]</b></span><button type="button" data-wce-actions='[{"type":"copy","expr":"\\"[[code]]\\""},{"type":"toast","expr":"\\"Cupom copiado\\"","tone":"success"}]' style="border:0;background:#16a34a;color:#fff;border-radius:8px;padding:6px 10px;cursor:pointer">Copiar</button></div>`,
      asks: [{ key: "code", label: "C\xF3digo do cupom", value: "BEMVINDO10" }]
    },
    // ------------------------------------------------------------- dados
    {
      id: "data-list",
      name: "Lista de posts",
      category: "Dados",
      description: "Cart\xF5es a partir de uma lista",
      variables: [
        {
          name: "posts",
          type: "list",
          default: [
            { titulo: "Primeiro post", resumo: "Um resumo curto do post.", data: "2026-10-01", imagem: "https://picsum.photos/seed/p1/600/340" },
            { titulo: "Segundo post", resumo: "Outro resumo para mostrar.", data: "2026-10-08", imagem: "https://picsum.photos/seed/p2/600/340" },
            { titulo: "Terceiro post", resumo: "Mais um exemplo de conte\xFAdo.", data: "2026-10-15", imagem: "https://picsum.photos/seed/p3/600/340" }
          ],
          persist: "none",
          description: "Posts (troque por uma fonte de dados em Dados)"
        }
      ],
      html: `<section class="wce-c-posts" style="${BASE};display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:14px;margin:16px 0">{{{ len(posts) == 0 ? '<p>Nenhum post.</p>' : '' }}}<div data-wce-repeat-slot></div></section>`
    },
    {
      id: "data-table",
      name: "Tabela de dados",
      category: "Dados",
      description: "Tabela a partir de uma lista",
      variables: [
        {
          name: "linhas",
          type: "list",
          default: [
            { nome: "Ana", cidade: "S\xE3o Paulo", valor: 1200 },
            { nome: "Bruno", cidade: "Recife", valor: 860 },
            { nome: "Carla", cidade: "Curitiba", valor: 1530 }
          ],
          persist: "none"
        }
      ],
      html: `<table class="wce-c-table" style="${BASE};width:100%;border-collapse:collapse;margin:16px 0;font-size:14px"><thead><tr style="background:#f8fafc"><th style="text-align:left;padding:8px;border-bottom:1px solid #e5e7eb">Nome</th><th style="text-align:left;padding:8px;border-bottom:1px solid #e5e7eb">Cidade</th><th style="text-align:right;padding:8px;border-bottom:1px solid #e5e7eb">Valor</th></tr></thead><tbody><tr data-wce-repeat-slot></tr></tbody></table>`
    },
    {
      id: "value",
      name: "Valor de vari\xE1vel",
      category: "Dados",
      description: "Mostra uma vari\xE1vel",
      html: `<span class="wce-c-value">{{ [[name]] }}</span>`,
      asks: [{ key: "name", label: "Express\xE3o (ex.: client.name, total | money)", value: "client.name" }]
    },
    {
      id: "search",
      name: "Campo de busca",
      category: "Dados",
      description: "Filtra listas pela vari\xE1vel busca",
      variables: [{ name: "busca", type: "text", default: "", persist: "none" }],
      html: `<input class="wce-c-search" type="search" placeholder="Buscar\u2026" data-wce-actions='[{"type":"set","variable":"busca","expr":"event.value"}]' data-wce-on="input" style="${BASE};width:100%;max-width:420px;padding:10px 12px;border:1px solid #cbd5e1;border-radius:10px;font:inherit;margin:8px 0">`
    }
  ];
  var REPEATERS = {
    "data-list": {
      expr: "search(posts, busca ?? '', 'titulo')",
      template: `<article style="border:1px solid #e5e7eb;border-radius:12px;overflow:hidden;background:#fff;color:#111827"><img src="{{ item.imagem }}" alt="" style="display:block;width:100%;height:auto"><div style="padding:12px"><small style="color:#64748b">{{ date(item.data) }}</small><h3 style="margin:4px 0 6px;font-size:17px">{{ item.titulo }}</h3><p style="margin:0;color:#4b5563">{{ item.resumo }}</p></div></article>`
    },
    cart: {
      expr: "carrinho",
      template: `<li style="display:flex;justify-content:space-between;gap:8px;padding:6px 0;border-bottom:1px solid #f1f5f9"><span>{{ item.nome }}</span><span>{{ item.preco | money }} <button type="button" aria-label="Remover" data-wce-actions='[{"type":"set","variable":"carrinho","expr":"concat(slice(carrinho, 0, event.index), slice(carrinho, event.index + 1))"}]' style="border:0;background:none;cursor:pointer;color:#b91c1c">\xD7</button></span></li>`
    },
    "data-table": {
      expr: "linhas",
      template: `<tr><td style="padding:8px;border-bottom:1px solid #f1f5f9">{{ item.nome }}</td><td style="padding:8px;border-bottom:1px solid #f1f5f9">{{ item.cidade }}</td><td style="padding:8px;border-bottom:1px solid #f1f5f9;text-align:right">{{ item.valor | money }}</td></tr>`
    }
  };
  function embedUrl(url) {
    const youtube = /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/shorts\/)([\w-]{6,})/.exec(url);
    if (youtube) return `https://www.youtube-nocookie.com/embed/${youtube[1]}`;
    const vimeo = /vimeo\.com\/(\d+)/.exec(url);
    if (vimeo) return `https://player.vimeo.com/video/${vimeo[1]}`;
    return url;
  }
  function fillAsks(component, answers) {
    return component.html.replace(/\[\[(\w+)\]\]/g, (_m, key) => {
      const raw = answers[key] ?? component.asks?.find((ask) => ask.key === key)?.value ?? "";
      if (key === "url" && component.id === "video") return embedUrl(raw).replace(/"/g, "&quot;");
      if (key === "address") return encodeURIComponent(raw);
      if (key === "html") return raw;
      return raw.replace(/[<>"]/g, "");
    });
  }

  // src/engine/engine.ts
  function isDynamicEdit(edit) {
    if (edit.when) return true;
    switch (edit.op) {
      case "bind":
      case "repeat":
        return true;
      case "text":
      case "html":
        return edit.value.includes("{{");
      case "attr":
        return (edit.value ?? "").includes("{{");
      case "style":
        return Object.values(edit.props).some((value) => value.includes("{{"));
      case "insert":
        return edit.html.includes("{{");
      case "replace":
        return edit.replace.includes("{{");
      default:
        return false;
    }
  }

  // src/shared/zip.ts
  var TABLE = (() => {
    const table = new Uint32Array(256);
    for (let n = 0; n < 256; n += 1) {
      let c = n;
      for (let k = 0; k < 8; k += 1) c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
      table[n] = c >>> 0;
    }
    return table;
  })();
  function crc32(bytes) {
    let crc = 4294967295;
    for (let i = 0; i < bytes.length; i += 1) crc = (TABLE[(crc ^ (bytes[i] ?? 0)) & 255] ?? 0) ^ crc >>> 8;
    return (crc ^ 4294967295) >>> 0;
  }
  function dosTime(date) {
    return {
      time: date.getHours() << 11 | date.getMinutes() << 5 | Math.floor(date.getSeconds() / 2),
      day: date.getFullYear() - 1980 << 9 | date.getMonth() + 1 << 5 | date.getDate()
    };
  }
  function makeZip(files) {
    const encoder = new TextEncoder();
    const chunks = [];
    const central = [];
    let offset = 0;
    const { time, day } = dosTime(/* @__PURE__ */ new Date());
    for (const file of files) {
      const name = encoder.encode(file.path);
      const data = typeof file.data === "string" ? encoder.encode(file.data) : file.data;
      const crc = crc32(data);
      const local = new DataView(new ArrayBuffer(30));
      local.setUint32(0, 67324752, true);
      local.setUint16(4, 20, true);
      local.setUint16(6, 2048, true);
      local.setUint16(8, 0, true);
      local.setUint16(10, time, true);
      local.setUint16(12, day, true);
      local.setUint32(14, crc, true);
      local.setUint32(18, data.length, true);
      local.setUint32(22, data.length, true);
      local.setUint16(26, name.length, true);
      local.setUint16(28, 0, true);
      chunks.push(new Uint8Array(local.buffer), name, data);
      const entry = new DataView(new ArrayBuffer(46));
      entry.setUint32(0, 33639248, true);
      entry.setUint16(4, 20, true);
      entry.setUint16(6, 20, true);
      entry.setUint16(8, 2048, true);
      entry.setUint16(10, 0, true);
      entry.setUint16(12, time, true);
      entry.setUint16(14, day, true);
      entry.setUint32(16, crc, true);
      entry.setUint32(20, data.length, true);
      entry.setUint32(24, data.length, true);
      entry.setUint16(28, name.length, true);
      entry.setUint32(42, offset, true);
      central.push(new Uint8Array(entry.buffer), name);
      offset += 30 + name.length + data.length;
    }
    const centralSize = central.reduce((total, chunk) => total + chunk.length, 0);
    const end = new DataView(new ArrayBuffer(22));
    end.setUint32(0, 101010256, true);
    end.setUint16(8, files.length, true);
    end.setUint16(10, files.length, true);
    end.setUint32(12, centralSize, true);
    end.setUint32(16, offset, true);
    const all = [...chunks, ...central, new Uint8Array(end.buffer)];
    const out = new Uint8Array(all.reduce((total, chunk) => total + chunk.length, 0));
    let at = 0;
    for (const chunk of all) {
      out.set(chunk, at);
      at += chunk.length;
    }
    return out;
  }

  // src/shared/exporters.ts
  function projectFile(projects) {
    return JSON.stringify({ kind: "webconstructor-site-editor", format: 1, exportedAt: (/* @__PURE__ */ new Date()).toISOString(), projects }, null, 2);
  }
  function safeJson(value) {
    return JSON.stringify(value).replace(/</g, "\\u003c").replace(/>/g, "\\u003e").replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029");
  }
  function installSnippet(project, options) {
    const client = options.clientId ? ` data-wce-client="${options.clientId}"` : "";
    if (options.cloud) return `<script src="${options.runtimeUrl}" data-wce-endpoint="${options.cloud.endpoint}" data-wce-key="${options.cloud.key}"${client} defer><\/script>`;
    return `<script>window.WCE_PROJECTS = (window.WCE_PROJECTS || []).concat(${safeJson([project])});<\/script>
<script src="${options.runtimeUrl}"${client} defer><\/script>`;
  }
  function standaloneScript(project, runtimeSource2, clientId) {
    return `/* Webconstructor Site Editor: ${project.name.replace(/\*\//g, "")} */
window.WCE_PROJECTS = (window.WCE_PROJECTS || []).concat(${safeJson([project])});
${clientId ? `window.WCE_CLIENT = ${JSON.stringify(clientId)};
` : ""}${runtimeSource2}`;
  }
  var URL_ATTRIBUTES = ["src", "href", "poster", "action", "data-full"];
  function absolutize(root, base) {
    for (const element of [root, ...Array.from(root.querySelectorAll("*"))]) {
      for (const name of URL_ATTRIBUTES) {
        const value = element.getAttribute(name);
        if (value === null || value === "" || value.startsWith("#") || /^(data|blob|javascript|mailto|tel):/i.test(value)) continue;
        try {
          element.setAttribute(name, new URL(value, base).href);
        } catch {
        }
      }
      const srcset = element.getAttribute("srcset");
      if (srcset) {
        element.setAttribute(
          "srcset",
          srcset.split(",").map((part) => {
            const [address, ...rest] = part.trim().split(/\s+/);
            try {
              return [new URL(address ?? "", base).href, ...rest].join(" ");
            } catch {
              return part.trim();
            }
          }).join(", ")
        );
      }
    }
  }
  function sheetText(sheet, base) {
    let rules;
    try {
      rules = sheet.cssRules;
    } catch {
      return null;
    }
    const sheetBase = sheet.href ?? base;
    return Array.from(rules).map((rule) => rule.cssText).join("\n").replace(/url\(\s*(['"]?)([^'")]+)\1\s*\)/g, (match, quote, address) => {
      if (/^(data|blob):/i.test(address) || address.startsWith("#")) return match;
      try {
        return `url(${quote}${new URL(address, sheetBase).href}${quote})`;
      } catch {
        return match;
      }
    });
  }
  function pageZip(doc, project, runtimeSource2, options = {}) {
    const base = doc.baseURI;
    const originals = Array.from(doc.querySelectorAll('link[rel~="stylesheet"], style'));
    originals.forEach((node, index) => node.setAttribute("data-wce-sheet", String(index)));
    const clone = doc.documentElement.cloneNode(true);
    originals.forEach((node) => node.removeAttribute("data-wce-sheet"));
    clone.querySelectorAll("[data-wce-ui]").forEach((node) => node.remove());
    clone.querySelectorAll("wce-editor,wce-layer,wce-pair").forEach((node) => node.remove());
    const dynamicIds = new Set(project.edits.filter(isDynamicEdit).map((edit) => edit.id));
    const hasDynamic = runtimeSource2 !== null && (dynamicIds.size > 0 || project.rules.length > 0 || project.sources.length > 0 || project.variables.length > 0);
    clone.querySelectorAll("[data-wce-index]").forEach((node) => {
      if (hasDynamic) node.remove();
      else node.removeAttribute("data-wce-index");
    });
    clone.querySelectorAll("wce-insert").forEach((holder) => {
      const id = holder.getAttribute("data-wce-edit") ?? "";
      if (hasDynamic && dynamicIds.has(id)) holder.remove();
      else holder.replaceWith(...Array.from(holder.childNodes));
    });
    clone.querySelectorAll("[data-wce-hidden],[data-wce-bind-hidden],[data-wce-rule-hidden]").forEach((node) => {
      if (!hasDynamic) node.remove();
    });
    clone.querySelectorAll("[data-wce-html],[data-wce-two-way]").forEach((node) => {
      node.removeAttribute("data-wce-html");
      node.removeAttribute("data-wce-two-way");
    });
    clone.classList.remove("wce-editing", "wce-show-hidden", "wce-pick");
    clone.removeAttribute("data-wce-bridge");
    clone.querySelectorAll("[data-wce-editing]").forEach((node) => {
      node.removeAttribute("data-wce-editing");
      node.removeAttribute("contenteditable");
    });
    if (!options.keepScripts) clone.querySelectorAll("script").forEach((node) => node.remove());
    clone.querySelectorAll("noscript").forEach((node) => node.remove());
    const css = [];
    const copies = Array.from(clone.querySelectorAll('link[rel~="stylesheet"], style'));
    copies.forEach((node, index) => {
      const original = originals[Number(node.getAttribute("data-wce-sheet"))];
      node.removeAttribute("data-wce-sheet");
      const sheet = original?.sheet ?? null;
      const text = sheet ? sheetText(sheet, base) : null;
      if (text !== null) {
        css.push(`/* ${sheet?.href ?? `estilo ${index + 1}`} */
${text}`);
        node.remove();
      }
    });
    const ourStyle = Array.from(doc.querySelectorAll('style[data-wce-ui="style"]')).map((node) => node.textContent ?? "").join("\n");
    css.push(`/* Site Editor */
${ourStyle.replace(/html\.wce-show-hidden[^\n]*\n/g, "")}`);
    absolutize(clone, base);
    const head = clone.querySelector("head") ?? clone.insertBefore(doc.createElement("head"), clone.firstChild);
    head.querySelectorAll("base").forEach((node) => node.remove());
    const link = doc.createElement("link");
    link.rel = "stylesheet";
    link.href = "styles.css";
    head.appendChild(link);
    const files = [];
    if (hasDynamic && runtimeSource2 !== null) {
      const subset = { ...project, css: "", clients: project.clients, edits: project.edits.filter((edit) => dynamicIds.has(edit.id)) };
      const script = doc.createElement("script");
      script.src = "wc-runtime.js";
      script.defer = true;
      const config = doc.createElement("script");
      config.textContent = `window.WCE_PROJECTS = ${safeJson([{ ...subset, matches: ["*"] }])};`;
      clone.querySelector("body")?.append(config, script);
      files.push({ path: "wc-runtime.js", data: runtimeSource2 });
    }
    const html = `<!doctype html>
${clone.outerHTML}`;
    files.unshift({ path: "index.html", data: html }, { path: "styles.css", data: css.join("\n\n") });
    return { bytes: makeZip(files), files: files.map((file) => file.path) };
  }
  function download(doc, name, data, type) {
    const blob = new Blob([typeof data === "string" ? data : new Uint8Array(data)], { type });
    const url = URL.createObjectURL(blob);
    const anchor = doc.createElement("a");
    anchor.href = url;
    anchor.download = name;
    anchor.setAttribute("data-wce-ui", "download");
    anchor.style.display = "none";
    doc.documentElement.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 3e4);
  }
  function slug(text) {
    return text.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 60) || "projeto";
  }

  // src/editor/panels-logic.ts
  var TYPES = [
    ["text", "Texto"],
    ["number", "N\xFAmero"],
    ["boolean", "Sim/N\xE3o"],
    ["state", "Estado (op\xE7\xF5es)"],
    ["list", "Lista"],
    ["json", "Objeto (JSON)"],
    ["color", "Cor"],
    ["image", "Imagem (endere\xE7o)"],
    ["url", "Endere\xE7o"]
  ];
  var SOURCES = [
    ["static", "Valor do cliente ou padr\xE3o"],
    ["query", "Par\xE2metro do endere\xE7o (?x=)"],
    ["cookie", "Cookie"],
    ["storage", "localStorage da p\xE1gina"],
    ["element", "Texto de um elemento"],
    ["expression", "Calculada (express\xE3o)"],
    ["source", "Fonte de dados"]
  ];
  function show(value) {
    return typeof value === "string" ? value : JSON.stringify(value, null, 2);
  }
  function parseLoose(type, raw) {
    if (type === "number") return Number(raw.replace(",", ".")) || 0;
    if (type === "boolean") return raw === "true" || raw === "1" || raw === "sim";
    if (type === "list" || type === "json") {
      try {
        return JSON.parse(raw);
      } catch {
        return type === "list" ? raw.split(/\n|,/).map((part) => part.trim()).filter(Boolean) : raw;
      }
    }
    return raw;
  }
  function valueControl(variable, value, onChange, testid) {
    switch (variable.type) {
      case "boolean":
        return checkbox(value ? "Sim" : "N\xE3o", Boolean(value), (on) => onChange(on), testid);
      case "state":
        return h(
          "div",
          { class: "row" },
          (variable.options ?? []).map((option) => button(option, () => onChange(option), { small: true, pressed: toText(value) === option, ...testid ? { testid: `${testid}-${option}` } : {} }))
        );
      case "list":
      case "json":
        return textarea(show(value), (raw) => onChange(parseLoose(variable.type, raw)), { rows: 3, mono: true, ...testid ? { testid } : {} });
      case "color": {
        const text = toText(value) || "#000000";
        const picker = h("input", { type: "color", value: /^#[0-9a-f]{6}$/i.test(text) ? text : "#000000", style: "width:38px;flex:none" });
        const box = input(text, (next) => onChange(next), { mono: true, ...testid ? { testid } : {} });
        picker.addEventListener("change", () => {
          box.value = picker.value;
          onChange(picker.value);
        });
        return h("div", { class: "row", style: "flex-wrap:nowrap" }, picker, box);
      }
      case "number":
        return input(toText(value), (raw) => onChange(parseLoose("number", raw)), { type: "number", ...testid ? { testid } : {} });
      default:
        return input(toText(value), (raw) => onChange(raw), { ...testid ? { testid } : {} });
    }
  }
  function variableEditor(ctx, variable) {
    const mutate = (label, change) => void ctx.commit(label, (project) => {
      const target = project.variables.find((candidate) => candidate.id === variable.id);
      if (target) change(target);
    });
    const source = variable.source ?? { kind: "static" };
    const sourceFields = h("div");
    const sourceParam = (label, key, value, placeholder = "") => field(label, input(value, (next) => mutate("Origem", (target) => target.source = { ...target.source ?? { kind: "static" }, [key]: next }), { mono: true, placeholder }));
    if (source.kind === "query") sourceFields.append(sourceParam("Par\xE2metro", "param", source.param, "cliente"));
    if (source.kind === "cookie") sourceFields.append(sourceParam("Nome do cookie", "name", source.name));
    if (source.kind === "storage") sourceFields.append(sourceParam("Chave", "key", source.key));
    if (source.kind === "element") {
      sourceFields.append(
        sourceParam("Seletor do elemento", "selector", source.selector, ".usuario-nome"),
        button("Escolher na p\xE1gina", () => ctx.pick("Clique no elemento de onde vem o valor", (element) => mutate("Origem", (target) => target.source = { kind: "element", selector: selectorOf(element) })), { small: true, icon: "target" }),
        sourceParam("Atributo (vazio: o texto)", "attr", source.attr ?? "")
      );
    }
    if (source.kind === "expression") sourceFields.append(field("Express\xE3o", expressionInput(source.expr, (expr) => mutate("Origem", (target) => target.source = { kind: "expression", expr }), { placeholder: "ex.: preco * quantidade" })));
    if (source.kind === "source") {
      sourceFields.append(
        field("Fonte", select(source.sourceId, [["", "\u2014"], ...ctx.project.sources.map((item) => [item.id, item.name])], (sourceId) => mutate("Origem", (target) => target.source = { kind: "source", sourceId, path: source.path ?? "" }))),
        field("Caminho nos dados", input(source.path ?? "", (path) => mutate("Origem", (target) => target.source = { kind: "source", sourceId: source.sourceId, path }), { mono: true, placeholder: "ex.: usuario.nome" }))
      );
    }
    const optionsInput = variable.type === "state" ? field("Op\xE7\xF5es (uma por linha)", textarea((variable.options ?? []).join("\n"), (raw) => mutate("Op\xE7\xF5es", (target) => target.options = raw.split("\n").map((line) => line.trim()).filter(Boolean)), { rows: 3 })) : null;
    return h(
      "details",
      null,
      h("summary", null, "Defini\xE7\xE3o"),
      field("Tipo", select(variable.type, TYPES, (type) => mutate("Tipo", (target) => {
        target.type = type;
        target.default = defaultFor(type, target.options);
        if (type === "state" && (!target.options || target.options.length === 0)) target.options = ["inicial", "ativo"];
      }))),
      optionsInput,
      field("Valor padr\xE3o", valueControl(variable, variable.default, (value) => mutate("Valor padr\xE3o", (target) => target.default = value))),
      field("Guardar o valor", select(variable.persist, [
        ["none", "N\xE3o (volta ao padr\xE3o a cada p\xE1gina)"],
        ["session", "Enquanto a aba estiver aberta"],
        ["local", "Sempre, neste navegador"]
      ], (persist) => mutate("Guardar", (target) => target.persist = persist))),
      field("Origem do valor", select(source.kind, SOURCES, (kind) => mutate("Origem", (target) => {
        target.source = kind === "static" ? { kind } : kind === "query" ? { kind, param: target.name } : kind === "cookie" ? { kind, name: target.name } : kind === "storage" ? { kind, key: target.name } : kind === "element" ? { kind, selector: "" } : kind === "expression" ? { kind, expr: "" } : { kind, sourceId: ctx.project.sources[0]?.id ?? "", path: "" };
      }))),
      sourceFields,
      field("Descri\xE7\xE3o", input(variable.description ?? "", (description) => mutate("Descri\xE7\xE3o", (target) => target.description = description))),
      button("Excluir vari\xE1vel", () => window.confirm(`Excluir a vari\xE1vel ${variable.name}?`) && void ctx.commit("Excluir vari\xE1vel", (project) => project.variables = project.variables.filter((candidate) => candidate.id !== variable.id)), { small: true, variant: "danger", icon: "trash" })
    );
  }
  var selectorOf = selectorFor;
  function renderVariables(body, ctx) {
    const name = input("", () => void 0, { placeholder: "nome (ex.: plano, logado, cor_marca)", mono: true, testid: "var-name" });
    let type = "text";
    const typeSelect = select("text", TYPES, (value) => type = value, "var-type");
    const add = () => {
      const value = name.value.trim();
      if (!VARIABLE_NAME.test(value)) return ctx.toast("Nome inv\xE1lido: use letras, n\xFAmeros e _, come\xE7ando por letra.", true);
      if (RESERVED_NAMES.has(value)) return ctx.toast(`"${value}" \xE9 um nome reservado.`, true);
      if (ctx.project.variables.some((variable) => variable.name === value)) return ctx.toast("J\xE1 existe uma vari\xE1vel com esse nome.", true);
      const options = type === "state" ? ["inicial", "ativo"] : void 0;
      void ctx.commit("Nova vari\xE1vel", (project) => {
        project.variables.push({ id: uid("v_"), name: value, type, default: defaultFor(type, options), persist: "none", ...options ? { options } : {} });
      });
    };
    body.append(
      section(
        "Nova vari\xE1vel ou estado",
        h("div", { class: "grid2" }, name, typeSelect),
        h("div", { class: "row", style: "margin-top:6px" }, button("Criar", add, { variant: "primary", small: true, icon: "plus", testid: "var-add" })),
        h("p", { class: "hint", style: "margin:8px 0 0" }, 'Use nos textos como {{ nome }}, em condi\xE7\xF5es (plano == "pro") e nas regras. Um estado tem op\xE7\xF5es fixas (ex.: aberto/fechado) e as regras alternam entre elas.')
      )
    );
    if (ctx.project.variables.length === 0) {
      body.append(empty("Nenhuma vari\xE1vel ainda."));
      return;
    }
    for (const variable of ctx.project.variables) {
      const live = ctx.engine.vars[variable.name];
      body.append(
        h(
          "div",
          { class: "item", "data-testid": `var-${variable.name}` },
          h("div", { class: "top" }, icon(variable.type === "state" ? "layers" : "braces", 14), h("span", { class: "title mono" }, variable.name), h("span", { class: "badge" }, TYPES.find(([key]) => key === variable.type)?.[1] ?? variable.type), variable.persist !== "none" ? h("span", { class: "badge ac" }, variable.persist === "local" ? "guardada" : "na aba") : null),
          variable.description ? h("div", { class: "sub" }, variable.description) : null,
          field("Valor agora (s\xF3 nesta visita)", valueControl(variable, live, (value) => {
            ctx.engine.setVariable(variable.name, value);
            ctx.rerender();
          }, `var-live-${variable.name}`)),
          h("div", { class: "row" }, button("Guardar como padr\xE3o", () => void ctx.commit("Valor padr\xE3o", (project) => {
            const target = project.variables.find((candidate) => candidate.id === variable.id);
            if (target) target.default = ctx.engine.vars[variable.name];
          }), { small: true }), button("Voltar ao valor inicial", () => {
            ctx.engine.resetVariable(variable.name);
            ctx.rerender();
          }, { small: true })),
          variableEditor(ctx, variable)
        )
      );
    }
  }
  var TRIGGERS = [
    ["click", "Clique em um elemento"],
    ["dblclick", "Duplo clique"],
    ["hover", "Mouse sobre um elemento"],
    ["submit", "Envio de formul\xE1rio"],
    ["change", "Mudan\xE7a de campo"],
    ["input", "Digita\xE7\xE3o em campo"],
    ["keydown", "Tecla pressionada"],
    ["visible", "Elemento aparece na tela"],
    ["load", "P\xE1gina carregada"],
    ["urlchange", "Mudan\xE7a de endere\xE7o (navega\xE7\xE3o)"],
    ["varchange", "Vari\xE1vel mudou"],
    ["interval", "A cada intervalo"],
    ["timeout", "Depois de um tempo"]
  ];
  var ACTIONS = [
    ["set", "Definir vari\xE1vel"],
    ["toggle", "Alternar vari\xE1vel/estado"],
    ["reset", "Voltar vari\xE1vel ao inicial"],
    ["push", "Adicionar item \xE0 lista"],
    ["show", "Mostrar elemento"],
    ["hide", "Ocultar elemento"],
    ["toggleVisible", "Mostrar/ocultar elemento"],
    ["addClass", "Adicionar classe"],
    ["removeClass", "Remover classe"],
    ["toggleClass", "Alternar classe"],
    ["setText", "Trocar texto"],
    ["setHtml", "Trocar HTML"],
    ["setAttr", "Definir atributo"],
    ["setStyle", "Definir estilo"],
    ["setValue", "Preencher campo"],
    ["click", "Clicar em elemento"],
    ["focus", "Focar elemento"],
    ["scroll", "Rolar at\xE9 elemento"],
    ["navigate", "Ir para endere\xE7o"],
    ["toast", "Mostrar aviso"],
    ["modal", "Abrir janela"],
    ["closeModal", "Fechar janela"],
    ["fetch", "Recarregar fonte de dados"],
    ["copy", "Copiar texto"],
    ["delay", "Esperar"],
    ["log", "Registrar no console"],
    ["if", "Se\u2026 sen\xE3o\u2026"],
    ["script", "Script pr\xF3prio (JavaScript)"]
  ];
  function defaultAction(type, ctx) {
    const variable = ctx.project.variables[0]?.name ?? "";
    switch (type) {
      case "set":
        return { type, variable, expr: "" };
      case "toggle":
      case "reset":
        return { type, variable };
      case "push":
        return { type, variable, expr: "" };
      case "show":
      case "hide":
      case "toggleVisible":
      case "click":
      case "focus":
      case "scroll":
        return { type, selector: "" };
      case "addClass":
      case "removeClass":
      case "toggleClass":
        return { type, selector: "", className: "" };
      case "setText":
      case "setHtml":
      case "setValue":
        return { type, selector: "", expr: "" };
      case "setAttr":
        return { type, selector: "", name: "", expr: "" };
      case "setStyle":
        return { type, selector: "", prop: "", expr: "" };
      case "navigate":
        return { type, expr: '"/"' };
      case "toast":
        return { type, expr: '"Pronto!"', tone: "success" };
      case "modal":
        return { type, title: "T\xEDtulo", html: "<p>Conte\xFAdo</p>" };
      case "closeModal":
        return { type };
      case "fetch":
        return { type, sourceId: ctx.project.sources[0]?.id ?? "" };
      case "copy":
        return { type, expr: "" };
      case "delay":
        return { type, ms: 1e3 };
      case "log":
        return { type, expr: "vars" };
      case "if":
        return { type, condition: "true", then: [], else: [] };
      case "script":
        return { type, code: "// vars, data, event e page est\xE3o dispon\xEDveis\n// devolva { set: { variavel: valor } } para mudar vari\xE1veis\nreturn { set: {} };" };
    }
  }
  function actionsEditor(ctx, actions, onChange, depth = 0) {
    const wrap = h("div", { class: "actions" });
    const update = (index, patch) => {
      const next = actions.map((action, at) => at === index ? { ...action, ...patch } : action);
      onChange(next);
    };
    actions.forEach((action, index) => {
      const variables = ctx.project.variables.map((variable) => [variable.name, variable.name]);
      const selectorField = (key, value) => field('Elemento (seletor; "this" = o do evento)', h("div", { class: "row", style: "flex-wrap:nowrap" }, input(value, (next) => update(index, { [key]: next }), { mono: true, placeholder: ".minha-caixa ou this" }), button("Escolher", () => ctx.pick("Clique no elemento da a\xE7\xE3o", (element) => update(index, { [key]: selectorOf(element) })), { small: true, icon: "target", iconOnly: true })));
      const exprField = (label, key, value, placeholder = "") => field(label, expressionInput(value, (next) => update(index, { [key]: next }), { placeholder }));
      const fields = [];
      switch (action.type) {
        case "set":
        case "push":
          fields.push(field("Vari\xE1vel", select(action.variable, [["", "\u2014"], ...variables], (variable) => update(index, { variable }))), exprField(action.type === "set" ? "Novo valor (express\xE3o)" : "Item (express\xE3o)", "expr", action.expr, 'ex.: "pro", contador + 1, event.value'));
          break;
        case "toggle":
        case "reset":
          fields.push(field("Vari\xE1vel", select(action.variable, [["", "\u2014"], ...variables], (variable) => update(index, { variable }))));
          break;
        case "show":
        case "hide":
        case "toggleVisible":
        case "click":
        case "focus":
        case "scroll":
          fields.push(selectorField("selector", action.selector));
          break;
        case "addClass":
        case "removeClass":
        case "toggleClass":
          fields.push(selectorField("selector", action.selector), field("Classe", input(action.className, (className) => update(index, { className }), { mono: true })));
          break;
        case "setText":
        case "setHtml":
        case "setValue":
          fields.push(selectorField("selector", action.selector), exprField("Valor (express\xE3o)", "expr", action.expr, '"Ol\xE1, " + nome'));
          break;
        case "setAttr":
          fields.push(selectorField("selector", action.selector), field("Atributo", input(action.name, (name) => update(index, { name }), { mono: true })), exprField("Valor", "expr", action.expr));
          break;
        case "setStyle":
          fields.push(selectorField("selector", action.selector), field("Propriedade CSS", input(action.prop, (prop) => update(index, { prop }), { mono: true, placeholder: "background-color" })), exprField("Valor", "expr", action.expr, '"#16a34a"'));
          break;
        case "navigate":
          fields.push(exprField("Endere\xE7o (express\xE3o)", "expr", action.expr, '"/painel"'), checkbox("Abrir em nova aba", action.newTab === true, (newTab) => update(index, { newTab })));
          break;
        case "toast":
          fields.push(exprField("Mensagem (express\xE3o)", "expr", action.expr, '"Salvo!"'), field("Tom", select(action.tone ?? "info", [
            ["info", "Informa\xE7\xE3o"],
            ["success", "Sucesso"],
            ["error", "Erro"]
          ], (tone) => update(index, { tone }))));
          break;
        case "modal":
          fields.push(field("T\xEDtulo", input(action.title, (title) => update(index, { title }))), field("Conte\xFAdo (HTML com {{ }})", textarea(action.html, (html) => update(index, { html }), { rows: 4, mono: true })));
          break;
        case "fetch":
          fields.push(field("Fonte", select(action.sourceId, [["", "\u2014"], ...ctx.project.sources.map((source) => [source.id, source.name])], (sourceId) => update(index, { sourceId }))));
          break;
        case "copy":
        case "log":
          fields.push(exprField("Valor (express\xE3o)", "expr", action.expr));
          break;
        case "delay":
          fields.push(field("Milissegundos", input(String(action.ms), (raw) => update(index, { ms: Number(raw) || 0 }), { type: "number" })));
          break;
        case "if":
          fields.push(
            exprField("Condi\xE7\xE3o", "condition", action.condition, 'plano == "pro"'),
            h("div", { class: "hint" }, "Ent\xE3o:"),
            depth < 3 ? actionsEditor(ctx, action.then, (then) => update(index, { then }), depth + 1) : null,
            h("div", { class: "hint" }, "Sen\xE3o:"),
            depth < 3 ? actionsEditor(ctx, action.else, (otherwise) => update(index, { else: otherwise }), depth + 1) : null
          );
          break;
        case "script":
          fields.push(field("JavaScript (roda no mundo da p\xE1gina)", textarea(action.code, (code) => update(index, { code }), { rows: 6, mono: true })), h("div", { class: "hint" }, 'Precisa de "Permitir scripts de usu\xE1rio" ligado na p\xE1gina da extens\xE3o (chrome://extensions). No script dos sites, roda direto.'));
          break;
        case "closeModal":
          break;
      }
      wrap.append(
        h(
          "div",
          { class: "action", "data-testid": "action" },
          h(
            "div",
            { class: "row", style: "flex-wrap:nowrap" },
            h("b", { class: "grow" }, `${index + 1}. ${ACTIONS.find(([key]) => key === action.type)?.[1] ?? action.type}`),
            button("Subir", () => index > 0 && onChange(actions.map((item, at) => at === index - 1 ? action : at === index ? actions[index - 1] : item)), { icon: "up", iconOnly: true, small: true, variant: "ghost", disabled: index === 0 }),
            button("Excluir a\xE7\xE3o", () => onChange(actions.filter((_item, at) => at !== index)), { icon: "trash", iconOnly: true, small: true, variant: "ghost" })
          ),
          ...fields
        )
      );
    });
    const adder = select("", [["", "+ Adicionar a\xE7\xE3o\u2026"], ...ACTIONS], (type) => type && onChange([...actions, defaultAction(type, ctx)]), depth === 0 ? "add-action" : void 0);
    wrap.append(adder);
    return wrap;
  }
  function ruleEditor(ctx, rule) {
    const mutate = (label, change) => void ctx.commit(label, (project) => {
      const target = project.rules.find((candidate) => candidate.id === rule.id);
      if (target) change(target);
    });
    const trigger = rule.trigger;
    const needsSelector = ["click", "dblclick", "hover", "submit", "change", "input", "visible"].includes(trigger.type);
    return h(
      "div",
      { class: "item", "data-testid": "rule", "data-section": rule.id },
      h(
        "div",
        { class: "top" },
        h("input", { type: "checkbox", checked: rule.enabled, "aria-label": "Ligada", onchange: (event) => mutate("Ligar regra", (target) => target.enabled = event.target.checked) }),
        input(rule.name, (name) => mutate("Nome da regra", (target) => target.name = name), { testid: "rule-name" }),
        button("Testar agora", () => void ctx.engine.runRule(rule, null, null).then(() => ctx.toast("Regra executada.")), { icon: "play", iconOnly: true, small: true, variant: "ghost", testid: "rule-test" }),
        button("Excluir regra", () => void ctx.commit("Excluir regra", (project) => project.rules = project.rules.filter((candidate) => candidate.id !== rule.id)), { icon: "trash", iconOnly: true, small: true, variant: "ghost" })
      ),
      field("Quando", select(trigger.type, TRIGGERS, (type) => mutate("Gatilho", (target) => target.trigger = { ...target.trigger, type }), "rule-trigger")),
      needsSelector ? field("Em qual elemento", h("div", { class: "row", style: "flex-wrap:nowrap" }, input(trigger.selector ?? "", (selector) => mutate("Elemento do gatilho", (target) => target.trigger = { ...target.trigger, selector }), { mono: true, testid: "rule-selector" }), button("Escolher", () => ctx.pick("Clique no elemento que dispara a regra", (element) => mutate("Elemento do gatilho", (target) => target.trigger = { ...target.trigger, selector: selectorOf(element) })), { small: true, icon: "target", iconOnly: true }))) : null,
      trigger.type === "keydown" ? field("Tecla", input(trigger.key ?? "", (key) => mutate("Tecla", (target) => target.trigger = { ...target.trigger, key }), { placeholder: "ex.: Enter, ctrl+k, Escape", mono: true })) : null,
      trigger.type === "interval" || trigger.type === "timeout" ? field("Milissegundos", input(String(trigger.ms ?? 1e3), (raw) => mutate("Tempo", (target) => target.trigger = { ...target.trigger, ms: Number(raw) || 1e3 }), { type: "number" })) : null,
      trigger.type === "varchange" ? field("Vari\xE1vel", select(trigger.variable ?? "", [["", "qualquer"], ...ctx.project.variables.map((variable) => [variable.name, variable.name])], (variable) => mutate("Vari\xE1vel do gatilho", (target) => target.trigger = { ...target.trigger, variable }))) : null,
      field("S\xF3 se (condi\xE7\xE3o)", expressionInput(rule.condition ?? "", (condition) => mutate("Condi\xE7\xE3o", (target) => condition.trim() ? target.condition = condition : delete target.condition), { placeholder: 'vazio: sempre \xB7 ex.: event.value != ""' })),
      ["click", "submit", "keydown"].includes(trigger.type) ? checkbox("Impedir a a\xE7\xE3o normal do sistema (link, envio)", rule.preventDefault === true, (on) => mutate("Impedir padr\xE3o", (target) => target.preventDefault = on)) : null,
      field("S\xF3 nas p\xE1ginas", input(rule.page ?? "", (page) => mutate("P\xE1gina da regra", (target) => page.trim() ? target.page = page.trim() : delete target.page), { mono: true, placeholder: "vazio: todas" })),
      h("div", { class: "hint" }, "Ent\xE3o:"),
      actionsEditor(ctx, rule.actions, (actions) => mutate("A\xE7\xF5es", (target) => target.actions = actions))
    );
  }
  function renderRules(body, ctx) {
    body.append(
      section(
        "Eventos e a\xE7\xF5es",
        h("p", { class: "hint", style: "margin:0 0 8px" }, "Uma regra diz: quando algo acontece (clique, envio, navega\xE7\xE3o, vari\xE1vel mudou, tempo\u2026), se a condi\xE7\xE3o valer, fa\xE7a as a\xE7\xF5es em ordem. As express\xF5es veem as vari\xE1veis, data, page, client e event (value, text, form, key, index)."),
        button("Nova regra", () => {
          const id = uid("r_");
          void ctx.commit("Nova regra", (project) => project.rules.push({ id, name: `Regra ${project.rules.length + 1}`, enabled: true, trigger: { type: "click", selector: "" }, actions: [] })).then(() => ctx.setTab("rules", id));
        }, { variant: "primary", small: true, icon: "plus", testid: "rule-add" })
      )
    );
    if (ctx.project.rules.length === 0) body.append(empty("Nenhuma regra ainda. Tamb\xE9m d\xE1 para criar pelo elemento: selecione e use \u201CAo clicar\u2026\u201D."));
    for (const rule of ctx.project.rules) body.append(ruleEditor(ctx, rule));
  }
  function sourceEditor(ctx, source) {
    const mutate = (label, change) => void ctx.commit(label, (project) => {
      const target = project.sources.find((candidate) => candidate.id === source.id);
      if (target) change(target);
    });
    const preview = h("div", { class: "value", "data-testid": `source-preview-${source.name}` }, ctx.engine.data[source.name] === void 0 ? "(n\xE3o carregada)" : JSON.stringify(ctx.engine.data[source.name], null, 2).slice(0, 4e3));
    return h(
      "div",
      { class: "item", "data-testid": "source" },
      h(
        "div",
        { class: "top" },
        icon("database", 14),
        input(source.name, (name) => /^[A-Za-z_]\w*$/.test(name) ? mutate("Nome da fonte", (target) => target.name = name) : ctx.toast("Nome inv\xE1lido.", true), { mono: true, testid: "source-name" }),
        button("Carregar agora", () => void ctx.engine.loadSource(source.id).then(() => ctx.rerender()), { icon: "download", iconOnly: true, small: true, variant: "ghost", testid: "source-load" }),
        button("Excluir fonte", () => void ctx.commit("Excluir fonte", (project) => project.sources = project.sources.filter((candidate) => candidate.id !== source.id)), { icon: "trash", iconOnly: true, small: true, variant: "ghost" })
      ),
      h("div", { class: "sub" }, `Nas express\xF5es: data.${source.name}`),
      field("Tipo", select(source.kind, [
        ["json", "JSON escrito aqui"],
        ["csv", "Planilha (CSV) colada aqui"],
        ["http", "API / endere\xE7o na internet"]
      ], (kind) => mutate("Tipo da fonte", (target) => target.kind = kind), "source-kind")),
      source.kind !== "http" ? field(source.kind === "json" ? "JSON" : "CSV (primeira linha: nomes das colunas)", textarea(source.data ?? "", (data) => mutate("Dados", (target) => target.data = data), { rows: 6, mono: true, testid: "source-data" })) : null,
      source.kind === "http" ? h(
        "div",
        null,
        field("Endere\xE7o", input(source.url ?? "", (url) => mutate("Endere\xE7o da fonte", (target) => target.url = url), { mono: true, placeholder: "https://api.exemplo.com/itens?cliente={{ client.id }}", testid: "source-url" })),
        h("div", { class: "grid2" }, field("M\xE9todo", select(source.method ?? "GET", [
          ["GET", "GET"],
          ["POST", "POST"]
        ], (method) => mutate("M\xE9todo", (target) => target.method = method))), field("Formato", select(source.format ?? "json", [
          ["json", "JSON"],
          ["csv", "CSV"],
          ["text", "Texto"]
        ], (format) => mutate("Formato", (target) => target.format = format)))),
        field("Cabe\xE7alhos (JSON)", textarea(JSON.stringify(source.headers ?? {}, null, 1), (raw) => {
          try {
            const headers = JSON.parse(raw || "{}");
            mutate("Cabe\xE7alhos", (target) => target.headers = headers);
          } catch {
            ctx.toast("Cabe\xE7alhos: JSON inv\xE1lido.", true);
          }
        }, { rows: 2, mono: true })),
        source.method === "POST" ? field("Corpo", textarea(source.body ?? "", (value) => mutate("Corpo", (target) => target.body = value), { rows: 3, mono: true })) : null,
        h("div", { class: "grid2" }, field("Atualizar a cada (s)", input(String(source.refreshSec ?? 0), (raw) => mutate("Atualiza\xE7\xE3o", (target) => target.refreshSec = Number(raw) || 0), { type: "number" })), field("Carregar ao abrir", checkbox("Sim", source.auto, (auto) => mutate("Carregar ao abrir", (target) => target.auto = auto))))
      ) : null,
      field("Caminho dentro dos dados", input(source.path ?? "", (path) => mutate("Caminho", (target) => target.path = path), { mono: true, placeholder: "ex.: results ou data.items" })),
      h("details", null, h("summary", null, "Ver dados carregados"), preview)
    );
  }
  function renderData(body, ctx) {
    body.append(
      section(
        "Fontes de dados",
        h("p", { class: "hint", style: "margin:0 0 8px" }, "Dados que alimentam textos, listas repetidas e regras: JSON, planilha CSV ou uma API. Chamadas a outros dom\xEDnios passam pela extens\xE3o, sem bloqueio de CORS."),
        button("Nova fonte", () => void ctx.commit("Nova fonte", (project) => project.sources.push({ id: uid("s_"), name: `dados${project.sources.length + 1}`, kind: "json", data: '[\n  { "nome": "Exemplo", "valor": 10 }\n]', auto: true })), { variant: "primary", small: true, icon: "plus", testid: "source-add" })
      )
    );
    if (ctx.project.sources.length === 0) body.append(empty("Nenhuma fonte ainda."));
    for (const source of ctx.project.sources) body.append(sourceEditor(ctx, source));
  }
  function clientCard(ctx, client, active) {
    const mutate = (label, change) => void ctx.commit(label, (project) => {
      const target = project.clients.find((candidate) => candidate.id === client.id);
      if (target) change(target);
    });
    const demo = new URL(location.href);
    demo.searchParams.set("wce_client", client.id);
    const values = ctx.project.variables.filter((variable) => variable.source?.kind !== "expression");
    return h(
      "div",
      { class: `item${active ? "" : ""}`, "data-testid": `client-${client.name}` },
      h(
        "div",
        { class: "top" },
        h("input", { type: "radio", name: "wce-client", checked: active, "aria-label": `Mostrar ${client.name}`, "data-testid": "client-activate", onchange: () => void ctx.commit("Trocar cliente", (project) => project.activeClientId = client.id) }),
        input(client.name, (name) => name.trim() && mutate("Nome do cliente", (target) => target.name = name.trim()), { testid: "client-name" }),
        active ? h("span", { class: "badge ac" }, "na tela") : null,
        button("Duplicar cliente", () => void ctx.commit("Duplicar cliente", (project) => project.clients.push({ ...JSON.parse(JSON.stringify(client)), id: uid("c_"), name: `${client.name} (c\xF3pia)` })), { icon: "copy", iconOnly: true, small: true, variant: "ghost" }),
        ctx.project.clients.length > 1 ? button("Excluir cliente", () => window.confirm(`Excluir o cliente ${client.name}?`) && void ctx.commit("Excluir cliente", (project) => {
          project.clients = project.clients.filter((candidate) => candidate.id !== client.id);
          if (project.activeClientId === client.id) project.activeClientId = project.clients[0]?.id ?? null;
          for (const edit of project.edits) if (edit.clients) edit.clients = edit.clients.filter((id) => id !== client.id);
        }), { icon: "trash", iconOnly: true, small: true, variant: "ghost" }) : null
      ),
      values.length === 0 ? h("div", { class: "hint" }, "Crie vari\xE1veis (aba Vari\xE1veis) para dar a cada cliente os seus valores: nome, logo, cores, pre\xE7os\u2026") : null,
      ...values.map(
        (variable) => field(
          `${variable.name}${Object.prototype.hasOwnProperty.call(client.values, variable.name) ? "" : " (padr\xE3o)"}`,
          valueControl(variable, Object.prototype.hasOwnProperty.call(client.values, variable.name) ? client.values[variable.name] : variable.default, (value) => mutate("Valor do cliente", (target) => target.values = { ...target.values, [variable.name]: value }), `client-value-${variable.name}`)
        )
      ),
      h(
        "details",
        null,
        h("summary", null, "CSS e notas deste cliente"),
        field("CSS s\xF3 deste cliente", textarea(client.css ?? "", (css) => mutate("CSS do cliente", (target) => target.css = css), { rows: 4, mono: true, placeholder: ":root { --cor-principal: #e11d48; }" })),
        field("Notas", textarea(client.notes ?? "", (notes) => mutate("Notas do cliente", (target) => target.notes = notes), { rows: 2 }))
      ),
      h(
        "div",
        { class: "row" },
        button("Copiar link de demonstra\xE7\xE3o", () => void navigator.clipboard.writeText(demo.href).then(() => ctx.toast("Link copiado: quem tem a extens\xE3o e o projeto v\xEA este cliente.")), { small: true, icon: "link" })
      )
    );
  }
  function renderClients(body, ctx) {
    const current = ctx.engine.currentClient?.id ?? ctx.project.activeClientId;
    body.append(
      section(
        "Clientes",
        h("p", { class: "hint", style: "margin:0 0 8px" }, "O mesmo sistema, um conte\xFAdo para cada cliente: as altera\xE7\xF5es valem para todos, e cada cliente d\xE1 os seus valores \xE0s vari\xE1veis. Uma altera\xE7\xE3o tamb\xE9m pode valer s\xF3 para alguns clientes (aba Altera\xE7\xF5es \u203A Op\xE7\xF5es)."),
        button("Novo cliente", () => {
          const name = window.prompt("Nome do cliente");
          if (name?.trim()) void ctx.commit("Novo cliente", (project) => {
            const client = { id: uid("c_"), name: name.trim(), values: {} };
            project.clients.push(client);
            project.activeClientId = client.id;
          });
        }, { variant: "primary", small: true, icon: "plus", testid: "client-add" })
      )
    );
    for (const client of ctx.project.clients) body.append(clientCard(ctx, client, client.id === current));
  }
  async function runtimeSource() {
    const answer = await chrome.runtime.sendMessage({ type: "wce:runtime-source" });
    if (!answer?.ok || !answer.source) throw new Error("n\xE3o foi poss\xEDvel ler o wc-runtime.js da extens\xE3o");
    return answer.source;
  }
  function renderProject(body, ctx) {
    const project = ctx.project;
    const status = h("div", { class: "hint", "data-testid": "project-status" });
    const say = (text, error = false) => {
      status.textContent = text;
      status.className = error ? "err" : "ok";
    };
    body.append(
      section(
        "Projeto",
        field("Nome", input(project.name, (name) => name.trim() && void ctx.commit("Nome do projeto", (target) => target.name = name.trim()), { testid: "project-name" })),
        field("Vale nos endere\xE7os (um por linha)", textarea(project.matches.join("\n"), (raw) => void ctx.commit("Endere\xE7os", (target) => target.matches = raw.split("\n").map((line) => line.trim()).filter(Boolean)), { rows: 3, mono: true, testid: "project-matches" }), "Ex.: https://app.exemplo.com/* \xB7 *.exemplo.com/clientes/* \xB7 /regex/"),
        checkbox("Projeto ligado (aplica as altera\xE7\xF5es ao abrir as p\xE1ginas)", project.enabled, (enabled) => void ctx.commit("Ligar projeto", (target) => target.enabled = enabled)),
        field("Descri\xE7\xE3o", textarea(project.description ?? "", (description) => void ctx.commit("Descri\xE7\xE3o", (target) => target.description = description), { rows: 2 }))
      ),
      section(
        "Exportar e instalar",
        h("p", { class: "hint", style: "margin:0 0 8px" }, "Entregue a personaliza\xE7\xE3o ao cliente: o script aplica as mesmas altera\xE7\xF5es, vari\xE1veis, eventos e dados em qualquer site, sem a extens\xE3o."),
        h(
          "div",
          { class: "row" },
          button("Arquivo do projeto (.json)", () => {
            download(document, `${slug(project.name)}.wce.json`, projectFile([project]), "application/json");
            say("Arquivo do projeto baixado.");
          }, { small: true, icon: "download", testid: "export-json" }),
          button("Script para o site (.js)", () => {
            void runtimeSource().then(
              (source) => {
                download(document, `${slug(project.name)}.wce.js`, standaloneScript(project, source, ctx.engine.currentClient?.id), "text/javascript");
                say('Script baixado. No site: <script src="\u2026wce.js" defer><\/script>.');
              },
              (error) => say(String(error), true)
            );
          }, { small: true, icon: "code", testid: "export-script" }),
          button("P\xE1gina para o Webconstructor (.zip)", () => {
            void runtimeSource().catch(() => null).then((source) => {
              const zip = pageZip(document, project, source);
              download(document, `${slug(project.name)}-pagina.zip`, zip.bytes, "application/zip");
              say(`ZIP com ${zip.files.join(", ")}. No Webconstructor: Arquivo \u203A Importar HTML/ZIP.`);
            });
          }, { small: true, icon: "download", testid: "export-zip" })
        ),
        h("details", null, h("summary", null, "C\xF3digo de instala\xE7\xE3o com o projeto embutido"), h("div", { class: "value", "data-testid": "install-snippet" }, installSnippet(project, { runtimeUrl: "https://SEU-SITE/wc-runtime.js", clientId: ctx.engine.currentClient?.id ?? null }).slice(0, 1200) + "\u2026"), h("div", { class: "hint" }, "Hospede o wc-runtime.js (vem no ZIP da extens\xE3o) e cole o c\xF3digo antes do </body>. O modo nuvem (publicar e buscar por chave) fica no gerenciador.")),
        status
      ),
      section(
        "Integra\xE7\xE3o",
        h(
          "div",
          { class: "row" },
          button("Abrir o gerenciador", () => void chrome.runtime.sendMessage({ type: "wce:open-manager", hash: `#project=${project.id}` }), { small: true, icon: "settings" }),
          button("Enviar ao Builder Companion", () => void chrome.runtime.sendMessage({ type: "wce:companion" }).then((answer) => say(answer?.said ?? "Sem resposta.", !answer?.ok)), { small: true, icon: "upload" })
        ),
        h("p", { class: "hint", style: "margin:8px 0 0" }, "No gerenciador: entrar na conta do Webconstructor, sincronizar com a nuvem, publicar para o script buscar por chave e ligar a um projeto do editor.")
      ),
      section(
        "Prefer\xEAncias do editor",
        field("Lado do painel", select(ctx.settings.toolbarSide, [
          ["right", "Direita"],
          ["left", "Esquerda"]
        ], (toolbarSide) => void ctx.setSettings({ toolbarSide }))),
        checkbox("Mostrar os elementos ocultos (tracejados)", ctx.settings.showHidden, (showHidden) => void ctx.setSettings({ showHidden }))
      )
    );
    const scripts = h("div");
    const userScripts = h("div", { class: "hint" }, "Verificando\u2026");
    void chrome.runtime.sendMessage({ type: "wce:user-scripts-status" }).then((answer) => {
      userScripts.textContent = answer?.available ? "Scripts pr\xF3prios liberados neste navegador." : `Para rodar scripts pr\xF3prios, ative \u201CPermitir scripts de usu\xE1rio\u201D nos detalhes da extens\xE3o (chrome://extensions)${answer?.chrome && answer.chrome < 138 ? " ou o Modo do desenvolvedor" : ""}. Sem isso, as regras e liga\xE7\xF5es funcionam normalmente.`;
      userScripts.className = answer?.available ? "ok" : "hint";
    });
    for (const script of project.scripts) {
      const mutate = (label, change) => void ctx.commit(label, (target) => {
        const found = target.scripts.find((candidate) => candidate.id === script.id);
        if (found) change(found);
      });
      scripts.append(
        h(
          "div",
          { class: "item" },
          h("div", { class: "top" }, h("input", { type: "checkbox", checked: script.enabled, "aria-label": "Ligado", onchange: (event) => mutate("Ligar script", (target) => target.enabled = event.target.checked) }), input(script.name, (name) => mutate("Nome do script", (target) => target.name = name)), button("Excluir", () => void ctx.commit("Excluir script", (target) => target.scripts = target.scripts.filter((candidate) => candidate.id !== script.id)), { icon: "trash", iconOnly: true, small: true, variant: "ghost" })),
          textarea(script.code, (code) => mutate("C\xF3digo", (target) => target.code = code), { rows: 6, mono: true }),
          field("S\xF3 nas p\xE1ginas", input(script.page ?? "", (page) => mutate("P\xE1gina do script", (target) => page ? target.page = page : delete target.page), { mono: true, placeholder: "vazio: todas" }))
        )
      );
    }
    body.append(
      section(
        "Scripts pr\xF3prios (ao carregar a p\xE1gina)",
        userScripts,
        scripts,
        button("Novo script", () => void ctx.commit("Novo script", (target) => target.scripts.push({ id: uid("x_"), name: "Meu script", code: '// roda no mundo da p\xE1gina quando ela abre\n// vars, data, event e page est\xE3o dispon\xEDveis\nconsole.log("Ol\xE1", vars);', enabled: true })), { small: true, icon: "plus" })
      )
    );
    const versions = h("div", { "data-testid": "versions" }, empty("Carregando\u2026"));
    void history(project.id).then((list) => {
      versions.replaceChildren();
      if (list.length === 0) versions.append(empty("Nenhuma vers\xE3o guardada ainda."));
      for (const revision of list.slice(0, 30)) {
        versions.append(
          h(
            "div",
            { class: "item" },
            h(
              "div",
              { class: "top" },
              icon("history", 14),
              h("span", { class: "title" }, revision.label),
              h("span", { class: "sub" }, new Date(revision.at).toLocaleString("pt-BR")),
              button("Voltar a esta vers\xE3o", () => window.confirm("Voltar o projeto para esta vers\xE3o? (d\xE1 para desfazer com Ctrl+Z)") && void ctx.commit("Voltar vers\xE3o", (target) => Object.assign(target, JSON.parse(JSON.stringify(revision.project)))), { small: true })
            ),
            h("div", { class: "sub" }, `${revision.project.edits.length} altera\xE7\xF5es \xB7 ${revision.project.variables.length} vari\xE1veis \xB7 ${revision.project.rules.length} regras`)
          )
        );
      }
    });
    body.append(section("Vers\xF5es", versions));
    body.append(
      section(
        "Zona de perigo",
        button("Excluir projeto", () => {
          if (!window.confirm(`Excluir o projeto "${project.name}" e todas as altera\xE7\xF5es? Isso n\xE3o tem volta.`)) return;
          void chrome.runtime.sendMessage({ type: "wce:delete-project", id: project.id }).then(() => ctx.close());
        }, { variant: "danger", small: true, icon: "trash" })
      )
    );
  }

  // src/editor/panels.ts
  function renderPanel(tab, body, ctx) {
    switch (tab) {
      case "element":
        renderElement(body, ctx);
        break;
      case "insert":
        renderInsert(body, ctx);
        break;
      case "changes":
        renderChanges(body, ctx);
        break;
      case "variables":
        renderVariables(body, ctx);
        break;
      case "rules":
        renderRules(body, ctx);
        break;
      case "data":
        renderData(body, ctx);
        break;
      case "clients":
        renderClients(body, ctx);
        break;
      case "project":
        renderProject(body, ctx);
        break;
    }
  }
  function variablePicker(ctx, onPick) {
    const names = [
      ...ctx.project.variables.map((variable) => variable.name),
      ...ctx.project.sources.map((source) => `data.${source.name}`),
      "client.name",
      "page.path",
      "page.query",
      "date(now(), 'dd/MM/yyyy')"
    ];
    const element = h("select", { "aria-label": "Inserir vari\xE1vel", class: "grow", "data-testid": "insert-variable" }, h("option", { value: "" }, "{ } Inserir vari\xE1vel\u2026"), names.map((name) => h("option", { value: name }, name)));
    element.addEventListener("change", () => {
      if (element.value) onPick(`{{ ${element.value} }}`);
      element.value = "";
    });
    return element;
  }
  function expressionInput(value, onChange, options = {}) {
    const status = h("div", { class: "hint" });
    const control = input(value, (next) => {
      const problem2 = options.template ? null : check(next);
      status.textContent = problem2 ? `\u26A0 ${problem2}` : "";
      status.className = problem2 ? "err" : "hint";
      if (!problem2) onChange(next);
    }, { mono: true, placeholder: options.placeholder ?? 'ex.: plano == "pro"', ...options.testid ? { testid: options.testid } : {} });
    const problem = value && !options.template ? check(value) : null;
    if (problem) {
      status.textContent = `\u26A0 ${problem}`;
      status.className = "err";
    }
    return h("div", null, control, status);
  }
  function insertAtCursor(area2, text) {
    const start = area2.selectionStart ?? area2.value.length;
    const end = area2.selectionEnd ?? area2.value.length;
    area2.value = area2.value.slice(0, start) + text + area2.value.slice(end);
    area2.dispatchEvent(new Event("change"));
  }
  function scopeBadges(ctx, edit) {
    const badges = [];
    if (edit.page) badges.push(h("span", { class: "badge", title: "S\xF3 nesta p\xE1gina" }, `\u{1F4C4} ${edit.page}`));
    if (edit.clients && edit.clients.length > 0) badges.push(h("span", { class: "badge ac" }, `\u{1F464} ${edit.clients.map((id) => ctx.project.clients.find((client) => client.id === id)?.name ?? "?").join(", ")}`));
    if (edit.when) badges.push(h("span", { class: "badge warn", title: edit.when }, "condicional"));
    return badges;
  }
  function describeEdit(edit) {
    switch (edit.op) {
      case "text":
        return `Texto: \u201C${edit.value.slice(0, 60)}\u201D`;
      case "html":
        return "Conte\xFAdo HTML";
      case "attr":
        return edit.value === null ? `Remover atributo ${edit.name}` : `${edit.name} = ${edit.value.slice(0, 50)}`;
      case "style":
        return `Estilo: ${Object.entries(edit.props).map(([key, value]) => `${key}: ${value}`).join("; ").slice(0, 70)}`;
      case "class":
        return `Classes ${edit.add.map((name) => `+${name}`).join(" ")} ${edit.remove.map((name) => `\u2212${name}`).join(" ")}`;
      case "hide":
        return "Ocultar";
      case "remove":
        return "Remover da p\xE1gina";
      case "blur":
        return `Desfocar (${edit.amount}px)`;
      case "insert":
        return `Inserir ${edit.component ? `\u201C${COMPONENTS.find((component) => component.id === edit.component)?.name ?? edit.component}\u201D` : "HTML"} (${positionName(edit.position)})`;
      case "move":
        return `Mover para ${positionName(edit.position)} de ${edit.ref.selector}`;
      case "replace":
        return `Substituir \u201C${edit.find}\u201D por \u201C${edit.replace}\u201D`;
      case "bind":
        return `Liga\xE7\xE3o (${edit.kind}${edit.name ? ` ${edit.name}` : ""}): ${edit.expr}`;
      case "repeat":
        return `Repetir para cada item de ${edit.expr}`;
    }
  }
  function positionName(position) {
    return { before: "antes", after: "depois", prepend: "no in\xEDcio de dentro", append: "no fim de dentro" }[position];
  }
  function currentEdit(ctx, op, extra) {
    return ctx.project.edits.find((edit) => edit.target.selector === ctx.selector && edit.op === op && (!extra || extra(edit)));
  }
  function scopeSection(ctx) {
    const client = ctx.engine.currentClient;
    return h(
      "div",
      { class: "row", style: "margin:0 0 10px" },
      h("span", { class: "hint" }, "Novas altera\xE7\xF5es valem para"),
      select(ctx.scope.page, [
        ["all", "todas as p\xE1ginas"],
        ["this", "s\xF3 esta p\xE1gina"]
      ], (page) => ctx.setScope({ ...ctx.scope, page }), "scope-page"),
      select(ctx.scope.clients, [
        ["all", "todos os clientes"],
        ["current", `s\xF3 ${client?.name ?? "este cliente"}`]
      ], (clients) => ctx.setScope({ ...ctx.scope, clients }), "scope-clients")
    );
  }
  var STYLE_FIELDS = [
    { prop: "color", label: "Cor do texto", kind: "color" },
    { prop: "background-color", label: "Cor de fundo", kind: "color" },
    { prop: "font-size", label: "Tamanho da fonte", kind: "text", placeholder: "16px" },
    { prop: "font-weight", label: "Peso", kind: "select", options: ["", "300", "400", "500", "600", "700", "800"] },
    { prop: "font-family", label: "Fonte", kind: "text", placeholder: "Inter, sans-serif" },
    { prop: "text-align", label: "Alinhamento", kind: "select", options: ["", "left", "center", "right", "justify"] },
    { prop: "margin", label: "Margem", kind: "text", placeholder: "0 0 16px" },
    { prop: "padding", label: "Espa\xE7o interno", kind: "text", placeholder: "12px 16px" },
    { prop: "border-radius", label: "Arredondamento", kind: "text", placeholder: "8px" },
    { prop: "border", label: "Borda", kind: "text", placeholder: "1px solid #ddd" },
    { prop: "width", label: "Largura", kind: "text", placeholder: "auto, 100%, 320px" },
    { prop: "height", label: "Altura", kind: "text", placeholder: "auto" },
    { prop: "opacity", label: "Opacidade", kind: "text", placeholder: "0 a 1" },
    { prop: "display", label: "Exibi\xE7\xE3o", kind: "select", options: ["", "block", "inline-block", "flex", "grid", "inline", "none"] },
    { prop: "box-shadow", label: "Sombra", kind: "text", placeholder: "0 4px 12px rgba(0,0,0,.1)" },
    { prop: "background-image", label: "Imagem de fundo", kind: "text", placeholder: "url(https://\u2026)" }
  ];
  function rgbToHex(value) {
    const match = /rgba?\((\d+),\s*(\d+),\s*(\d+)/.exec(value);
    if (!match) return /^#[0-9a-f]{6}$/i.test(value) ? value : "#000000";
    return `#${[match[1], match[2], match[3]].map((n) => Number(n).toString(16).padStart(2, "0")).join("")}`;
  }
  function renderElement(body, ctx) {
    const element = ctx.selected;
    body.append(scopeSection(ctx));
    if (!element) {
      body.append(
        section(
          "Comece por aqui",
          h("p", null, "Clique em qualquer parte da p\xE1gina para selecionar. D\xEA ", h("b", null, "duplo clique"), " para editar o texto no lugar."),
          h(
            "ul",
            { class: "hint", style: "padding-left:18px;margin:6px 0" },
            h("li", null, h("span", { class: "kbd" }, "Delete"), " oculta o selecionado"),
            h("li", null, h("span", { class: "kbd" }, "Alt"), " + ", h("span", { class: "kbd" }, "\u2191"), " seleciona o elemento de fora"),
            h("li", null, h("span", { class: "kbd" }, "Ctrl"), " + ", h("span", { class: "kbd" }, "Z"), " desfaz"),
            h("li", null, "O bot\xE3o de cursor na barra liga o modo de navegar no sistema, para chegar a outra tela.")
          )
        ),
        section(
          "Substituir texto no site todo",
          replaceForm(ctx)
        )
      );
      return;
    }
    const html = element;
    const selector = ctx.selector;
    const matches = safeQueryAll(ctx.doc, selector).filter((candidate) => !candidate.closest("[data-wce-ui]")).length;
    const chain = [];
    for (let cursor = element; cursor && cursor !== ctx.doc.documentElement && chain.length < 6; cursor = cursor.parentElement) chain.unshift(cursor);
    body.append(
      h(
        "div",
        { class: "crumbs", "aria-label": "Caminho do elemento" },
        chain.map((node) => h("button", { type: "button", onclick: () => ctx.select(node), title: selectorFor(node) }, friendlyName(node)))
      )
    );
    const selectorField = input(selector, (value) => ctx.setSelector(value), { mono: true, testid: "selector" });
    body.append(
      section(
        friendlyName(element),
        field("Seletor", selectorField, `${matches} elemento${matches === 1 ? "" : "s"} na p\xE1gina`),
        h(
          "div",
          { class: "row" },
          button("Todos os parecidos", () => ctx.setSelector(similarSelector(element)), { small: true, title: "Aplicar as altera\xE7\xF5es a todos os itens iguais (linhas, cart\xF5es\u2026)" }),
          button("S\xF3 este", () => ctx.setSelector(selectorFor(element)), { small: true })
        )
      )
    );
    const textEdit = currentEdit(ctx, "text");
    const htmlEdit = currentEdit(ctx, "html");
    const simple = Array.from(element.children).every((child) => child.localName === "br");
    if (!/^(img|input|select|video|iframe|hr|br|svg|audio)$/.test(element.localName)) {
      const area2 = textarea(textEdit?.value ?? (simple ? (html.innerText ?? element.textContent ?? "").trim() : ""), (value) => void ctx.upsert({ op: "text", value }, { label: "Texto" }), { rows: 3, testid: "text-value", placeholder: simple ? "" : "Este elemento tem outros dentro. Escrever aqui troca tudo por texto." });
      const htmlArea = textarea(htmlEdit?.value ?? element.innerHTML, (value) => void ctx.upsert({ op: "html", value }, { label: "Conte\xFAdo" }), { rows: 5, mono: true, testid: "html-value" });
      body.append(
        h(
          "section",
          { class: "sec", "data-section": "content" },
          h("h3", null, "Conte\xFAdo"),
          field("Texto", area2, hasTemplate(area2.value) ? "Com dados din\xE2micos: o {{ }} \xE9 trocado pelo valor." : "Use {{ nome_da_variavel }} para dados din\xE2micos."),
          h("div", { class: "row" }, variablePicker(ctx, (text) => insertAtCursor(area2, text)), button("Editar no lugar", () => ctx.startInline(element), { small: true, icon: "edit" })),
          h("details", null, h("summary", null, "HTML do conte\xFAdo"), htmlArea, h("div", { class: "row", style: "margin-top:6px" }, variablePicker(ctx, (text) => insertAtCursor(htmlArea, text))))
        )
      );
    }
    if (element.localName === "img") {
      const image = element;
      const srcEdit = currentEdit(ctx, "attr", (edit) => edit.name === "src");
      const altEdit = currentEdit(ctx, "attr", (edit) => edit.name === "alt");
      const file = h("input", { type: "file", accept: "image/*", "data-testid": "image-file", style: "display:none" });
      file.addEventListener("change", () => {
        const chosen = file.files?.[0];
        if (!chosen) return;
        if (chosen.size > 2e6) ctx.toast("Imagem grande (mais de 2 MB): ela fica dentro do projeto. Prefira um endere\xE7o da internet.", true);
        const reader = new FileReader();
        reader.onload = () => void ctx.upsert({ op: "attr", name: "src", value: String(reader.result) }, { label: "Imagem" });
        reader.readAsDataURL(chosen);
      });
      body.append(
        h(
          "section",
          { class: "sec", "data-section": "image" },
          h("h3", null, "Imagem"),
          h("img", { src: image.currentSrc || image.src, alt: "", style: "max-width:100%;max-height:120px;border-radius:6px;display:block;margin:0 0 8px;background:var(--bg-3)" }),
          field("Endere\xE7o da imagem", input(srcEdit?.value ?? image.getAttribute("src") ?? "", (value) => void ctx.upsert({ op: "attr", name: "src", value }, { label: "Imagem" }), { mono: true, testid: "image-src" }), "Aceita {{ variavel }}: cada cliente com a sua logo."),
          h("div", { class: "row" }, button("Enviar arquivo\u2026", () => file.click(), { small: true, icon: "upload" }), file),
          field("Texto alternativo", input(altEdit?.value ?? image.alt, (value) => void ctx.upsert({ op: "attr", name: "alt", value }, { label: "Texto alternativo" }), { testid: "image-alt" }))
        )
      );
    }
    const anchor = element.closest("a");
    if (anchor) {
      const anchorSelector = anchor === element ? selector : selectorFor(anchor);
      const hrefEdit = ctx.project.edits.find((edit) => edit.target.selector === anchorSelector && edit.op === "attr" && edit.name === "href");
      const blank = anchor.getAttribute("target") === "_blank";
      body.append(
        h(
          "section",
          { class: "sec", "data-section": "link" },
          h("h3", null, "Link"),
          field("Endere\xE7o", input(hrefEdit && hrefEdit.op === "attr" ? hrefEdit.value ?? "" : anchor.getAttribute("href") ?? "", (value) => void ctx.upsert({ op: "attr", name: "href", value }, { target: { selector: anchorSelector }, label: "Link" }), { mono: true, testid: "link-href" })),
          checkbox("Abrir em nova aba", blank, (on) => void ctx.upsert({ op: "attr", name: "target", value: on ? "_blank" : null }, { target: { selector: anchorSelector }, label: "Nova aba" }))
        )
      );
    }
    if (/^(input|textarea|select)$/.test(element.localName)) {
      const control = element;
      body.append(
        section(
          "Campo",
          field("Texto de exemplo (placeholder)", input(control.getAttribute("placeholder") ?? "", (value) => void ctx.upsert({ op: "attr", name: "placeholder", value }, { label: "Placeholder" }), { testid: "field-placeholder" })),
          field("Valor", input(control.value ?? "", (value) => void ctx.upsert({ op: "attr", name: "value", value }, { label: "Valor" }), { testid: "field-value" }), "Preenche o campo (\xFAtil em demonstra\xE7\xF5es).")
        )
      );
    }
    const styleEdit = currentEdit(ctx, "style");
    const computed = getComputedStyle(element);
    const styleGrid = h("div", { class: "grid2" });
    for (const spec of STYLE_FIELDS) {
      const current = styleEdit?.props[spec.prop] ?? "";
      const shown = current || (spec.kind === "color" ? "" : "");
      let control;
      const save = (value) => void ctx.upsert({ op: "style", props: { [spec.prop]: value } }, { label: "Estilo" });
      if (spec.kind === "color") {
        const picker = h("input", { type: "color", value: rgbToHex(current || computed.getPropertyValue(spec.prop)), "aria-label": spec.label, "data-testid": `style-${spec.prop}-picker`, style: "width:38px;flex:none" });
        const text = input(shown, save, { placeholder: computed.getPropertyValue(spec.prop), mono: true, testid: `style-${spec.prop}` });
        picker.addEventListener("change", () => {
          text.value = picker.value;
          save(picker.value);
        });
        control = h("div", { class: "row", style: "flex-wrap:nowrap" }, picker, text);
      } else if (spec.kind === "select") control = select(current, (spec.options ?? []).map((option) => [option, option || "\u2014"]), save, `style-${spec.prop}`);
      else control = input(current, save, { placeholder: spec.placeholder ?? computed.getPropertyValue(spec.prop), mono: true, testid: `style-${spec.prop}` });
      styleGrid.append(field(spec.label, control));
    }
    const free = textarea(
      Object.entries(styleEdit?.props ?? {}).filter(([prop]) => !STYLE_FIELDS.some((spec) => spec.prop === prop)).map(([prop, value]) => `${prop}: ${value};`).join("\n"),
      (value) => {
        const props = {};
        for (const line of value.split(/;|\n/)) {
          const at = line.indexOf(":");
          if (at > 0) props[line.slice(0, at).trim()] = line.slice(at + 1).trim();
        }
        void ctx.upsert({ op: "style", props }, { label: "Estilo" });
      },
      { rows: 3, mono: true, placeholder: "letter-spacing: .02em;\ntransform: rotate(-2deg);", testid: "style-free" }
    );
    body.append(
      h(
        "section",
        { class: "sec", "data-section": "style" },
        h("h3", null, "Estilo"),
        styleGrid,
        field("Mais CSS", free, "Uma propriedade por linha. Aceita {{ }} (ex.: cor do cliente)."),
        styleEdit ? button("Limpar estilo", () => void ctx.removeEdits((edit) => edit.id === styleEdit.id, "Limpar estilo"), { small: true, variant: "danger" }) : null
      )
    );
    const classEdit = currentEdit(ctx, "class");
    const attrName = input("", () => void 0, { placeholder: "nome (ex.: title, data-x)", mono: true, testid: "attr-name" });
    const attrValue = input("", () => void 0, { placeholder: "valor", mono: true, testid: "attr-value" });
    body.append(
      h(
        "details",
        { class: "sec" },
        h("summary", null, "Classes e atributos"),
        field("Adicionar classes", input(classEdit?.add.join(" ") ?? "", (value) => void ctx.upsert({ op: "class", add: value.split(/\s+/).filter(Boolean), remove: classEdit?.remove ?? [] }, { label: "Classes", match: (edit) => edit.id === classEdit?.id }), { mono: true, testid: "class-add" })),
        field("Remover classes", input(classEdit?.remove.join(" ") ?? "", (value) => void ctx.upsert({ op: "class", add: classEdit?.add ?? [], remove: value.split(/\s+/).filter(Boolean) }, { label: "Classes", match: (edit) => edit.id === classEdit?.id }), { mono: true, testid: "class-remove" }), `Classes atuais: ${Array.from(element.classList).join(" ") || "(nenhuma)"}`),
        h("div", { class: "grid2" }, attrName, attrValue),
        h(
          "div",
          { class: "row", style: "margin-top:6px" },
          button("Definir atributo", () => attrName.value.trim() && void ctx.upsert({ op: "attr", name: attrName.value.trim(), value: attrValue.value }, { label: "Atributo" }), { small: true }),
          button("Remover atributo", () => attrName.value.trim() && void ctx.upsert({ op: "attr", name: attrName.value.trim(), value: null }, { label: "Atributo" }), { small: true })
        )
      )
    );
    const showBind = currentEdit(ctx, "bind", (edit) => edit.kind === "show");
    const hidden = currentEdit(ctx, "hide");
    body.append(
      h(
        "section",
        { class: "sec", "data-section": "visibility" },
        h("h3", null, "Visibilidade"),
        h(
          "div",
          { class: "row" },
          hidden ? button("Mostrar de novo", () => void ctx.removeEdits((edit) => edit.id === hidden.id, "Mostrar"), { small: true, icon: "eye" }) : button("Ocultar", () => void ctx.upsert({ op: "hide" }, { label: "Ocultar" }), { small: true, icon: "eyeOff", testid: "hide" }),
          button("Desfocar", () => void ctx.upsert({ op: "blur", amount: 6 }, { label: "Desfocar" }), { small: true, icon: "blur" }),
          button("Remover da p\xE1gina", () => void ctx.upsert({ op: "remove" }, { label: "Remover" }), { small: true, icon: "trash", variant: "danger" })
        ),
        field("Mostrar s\xF3 quando", expressionInput(showBind?.expr ?? "", (expr) => expr.trim() ? void ctx.upsert({ op: "bind", kind: "show", expr }, { label: "Mostrar quando" }) : showBind && void ctx.removeEdits((edit) => edit.id === showBind.id), { placeholder: 'ex.: logado == true, plano == "pro"', testid: "show-when" }), "Express\xE3o com vari\xE1veis e estados. Vazio: sempre.")
      )
    );
    const textBind = currentEdit(ctx, "bind", (edit) => edit.kind === "text");
    const attrBind = currentEdit(ctx, "bind", (edit) => edit.kind === "attr");
    const classBind = currentEdit(ctx, "bind", (edit) => edit.kind === "class");
    const repeat = currentEdit(ctx, "repeat");
    const bindAttrName = input(attrBind?.name ?? (element.localName === "img" ? "src" : element.localName === "a" ? "href" : ""), () => void 0, { placeholder: "atributo", mono: true, testid: "bind-attr-name" });
    const bindClassName = input(classBind?.name ?? "", () => void 0, { placeholder: "classe", mono: true, testid: "bind-class-name" });
    const isField = /^(input|textarea|select)$/.test(element.localName);
    const valueBind = currentEdit(ctx, "bind", (edit) => edit.kind === "value");
    const repeatTemplate = textarea(repeat?.template ?? element.outerHTML.replace(/\sdata-wce-[a-z-]+(="[^"]*")?/g, ""), () => void 0, { rows: 4, mono: true, testid: "repeat-template" });
    const repeatExpr = input(repeat?.expr ?? "", () => void 0, { mono: true, placeholder: 'ex.: data.produtos, filter(lista, "ativo")', testid: "repeat-expr" });
    body.append(
      h(
        "section",
        { class: "sec", "data-section": "dynamic" },
        h("h3", null, "Dados din\xE2micos"),
        field("Texto vem de", expressionInput(textBind?.expr ?? "", (expr) => expr.trim() ? void ctx.upsert({ op: "bind", kind: "text", expr }, { label: "Texto ligado" }) : textBind && void ctx.removeEdits((edit) => edit.id === textBind.id), { placeholder: "ex.: usuario.nome | upper", testid: "bind-text" })),
        h("div", { class: "field" }, h("label", null, "Atributo ligado"), h("div", { class: "grid2" }, bindAttrName, expressionInput(attrBind?.expr ?? "", (expr) => bindAttrName.value.trim() && void ctx.upsert({ op: "bind", kind: "attr", name: bindAttrName.value.trim(), expr }, { label: "Atributo ligado" }), { placeholder: "express\xE3o", testid: "bind-attr-expr" }))),
        h("div", { class: "field" }, h("label", null, "Classe quando"), h("div", { class: "grid2" }, bindClassName, expressionInput(classBind?.expr ?? "", (expr) => bindClassName.value.trim() && void ctx.upsert({ op: "bind", kind: "class", name: bindClassName.value.trim(), expr }, { label: "Classe ligada" }), { placeholder: "condi\xE7\xE3o", testid: "bind-class-expr" }))),
        isField ? field(
          "Campo ligado \xE0 vari\xE1vel",
          select(valueBind?.expr ?? "", [["", "\u2014"], ...ctx.project.variables.map((variable) => [variable.name, variable.name])], (name) => name ? void ctx.upsert({ op: "bind", kind: "value", expr: name }, { label: "Campo ligado" }) : valueBind && void ctx.removeEdits((edit) => edit.id === valueBind.id), "bind-value"),
          "O que a pessoa digita vai para a vari\xE1vel, e a vari\xE1vel preenche o campo."
        ) : null,
        h(
          "details",
          { open: repeat || /^(tr|li|option)$/.test(element.localName) ? true : void 0 },
          h("summary", null, "Repetir para cada item de uma lista"),
          field("Lista", repeatExpr),
          field("Modelo de cada item", repeatTemplate, "Use {{ item.campo }}, {{ index }} e {{ position }}."),
          h(
            "div",
            { class: "row" },
            button("Aplicar repeti\xE7\xE3o", () => {
              if (check(repeatExpr.value)) return ctx.toast(`Lista inv\xE1lida: ${check(repeatExpr.value) ?? ""}`, true);
              void ctx.upsert({ op: "repeat", expr: repeatExpr.value, template: repeatTemplate.value, itemName: "item" }, { label: "Repetir" });
            }, { small: true, variant: "primary", testid: "repeat-apply" }),
            repeat ? button("Tirar repeti\xE7\xE3o", () => void ctx.removeEdits((edit) => edit.id === repeat.id, "Tirar repeti\xE7\xE3o"), { small: true, variant: "danger" }) : null
          )
        )
      )
    );
    const rules = ctx.project.rules.filter((rule) => rule.trigger.selector === selector);
    body.append(
      h(
        "section",
        { class: "sec", "data-section": "events" },
        h("h3", null, "Eventos"),
        rules.length === 0 ? empty("Nenhuma regra come\xE7a neste elemento.") : rules.map((rule) => h("div", { class: "item" }, h("div", { class: "top" }, icon("zap", 14), h("span", { class: "title" }, rule.name), button("Editar", () => ctx.setTab("rules", rule.id), { small: true })))),
        h(
          "div",
          { class: "row" },
          ...["click", "hover", "submit", "change"].map(
            (type) => button(
              { click: "Ao clicar\u2026", hover: "Ao passar o mouse\u2026", submit: "Ao enviar\u2026", change: "Ao mudar\u2026" }[type],
              () => {
                const id = uid("r_");
                void ctx.commit("Nova regra", (project) => {
                  project.rules.push({ id, name: `${{ click: "Clique", hover: "Mouse sobre", submit: "Envio", change: "Mudan\xE7a" }[type]} em ${friendlyName(element)}`, enabled: true, trigger: { type, selector }, preventDefault: type === "click" || type === "submit", actions: [{ type: "toast", expr: '"Funcionou!"' }] });
                }).then(() => ctx.setTab("rules", id));
              },
              { small: true, testid: `new-rule-${type}` }
            )
          )
        )
      )
    );
    const mine = ctx.project.edits.filter((edit) => edit.target.selector === selector);
    body.append(
      section(
        `Altera\xE7\xF5es neste elemento (${mine.length})`,
        mine.length === 0 ? empty("Nenhuma ainda.") : mine.map((edit) => editItem(ctx, edit, false))
      )
    );
  }
  var insertPosition = "after";
  function renderInsert(body, ctx) {
    const element = ctx.selected;
    const positionSelect = select(
      insertPosition,
      [
        ["after", "Depois do selecionado"],
        ["before", "Antes do selecionado"],
        ["prepend", "Dentro, no in\xEDcio"],
        ["append", "Dentro, no fim"]
      ],
      (value) => {
        insertPosition = value;
      },
      "insert-position"
    );
    body.append(scopeSection(ctx));
    body.append(
      section(
        "Onde inserir",
        element ? h("p", { class: "hint", style: "margin:0 0 6px" }, `Selecionado: ${friendlyName(element)} (${ctx.selector})`) : h("p", { class: "hint", style: "margin:0 0 6px" }, "Nada selecionado: entra no fim da p\xE1gina. Clique num elemento para escolher o lugar."),
        positionSelect
      )
    );
    const asks = h("div", { "data-testid": "insert-asks" });
    body.append(asks);
    const insert = async (component, answers) => {
      const target = element ? { selector: ctx.selector } : { selector: "body" };
      const where = element ? insertPosition : "append";
      const html = fillAsks(component, answers);
      const insertId = uid("e_");
      const repeater = REPEATERS[component.id];
      const page = ctx.scope.page === "this" ? location.pathname : void 0;
      const clients = ctx.scope.clients === "current" && ctx.engine.currentClient ? [ctx.engine.currentClient.id] : void 0;
      await ctx.commit(`Inserir ${component.name}`, (project) => {
        for (const variable of component.variables ?? []) {
          if (!project.variables.some((existing) => existing.name === variable.name)) project.variables.push({ ...variable, id: uid("v_") });
        }
        const base = { enabled: true, createdAt: Date.now(), ...page ? { page } : {}, ...clients ? { clients } : {} };
        project.edits.push({ op: "insert", position: where, html, component: component.id, id: insertId, target, label: component.name, ...base });
        if (repeater) project.edits.push({ op: "repeat", expr: repeater.expr, template: repeater.template, itemName: "item", id: uid("e_"), target: { selector: `wce-insert[data-wce-edit="${insertId}"] [data-wce-repeat-slot]` }, label: `${component.name}: itens`, ...base });
      });
      const inserted = ctx.doc.querySelector(`wce-insert[data-wce-edit="${insertId}"]`);
      const first = inserted?.firstElementChild ?? null;
      if (first) {
        first.scrollIntoView({ block: "nearest" });
        ctx.select(first);
        ctx.toast(`${component.name} inserido e selecionado.`);
      }
    };
    const categories = [...new Set(COMPONENTS.map((component) => component.category))];
    for (const category of categories) {
      body.append(h("div", { class: "cat" }, category));
      body.append(
        h(
          "div",
          { class: "lib" },
          COMPONENTS.filter((component) => component.category === category).map(
            (component) => h(
              "button",
              {
                type: "button",
                "data-testid": `component-${component.id}`,
                onclick: () => {
                  if (!component.asks || component.asks.length === 0) {
                    void insert(component, {});
                    return;
                  }
                  asks.replaceChildren();
                  const answers = {};
                  const fields = component.asks.map((ask) => {
                    answers[ask.key] = ask.value;
                    const control = ask.key === "html" ? textarea(ask.value, (value) => answers[ask.key] = value, { rows: 4, mono: true, live: true, testid: `ask-${ask.key}` }) : input(ask.value, (value) => answers[ask.key] = value, { live: true, testid: `ask-${ask.key}` });
                    return field(ask.label, control);
                  });
                  asks.append(
                    section(
                      component.name,
                      ...fields,
                      h("div", { class: "row" }, button("Inserir", () => void insert(component, answers).then(() => asks.replaceChildren()), { variant: "primary", small: true, testid: "ask-insert" }), button("Cancelar", () => asks.replaceChildren(), { small: true }))
                    )
                  );
                  asks.scrollIntoView({ block: "start" });
                  asks.querySelector("input,textarea")?.focus();
                }
              },
              h("b", null, component.name),
              h("small", null, component.description)
            )
          )
        )
      );
    }
  }
  function replaceForm(ctx) {
    const find = input("", () => void 0, { placeholder: "Procurar (ex.: Empresa Antiga)", testid: "replace-find" });
    const replace = input("", () => void 0, { placeholder: "Trocar por (aceita {{ client.name }})", testid: "replace-with" });
    let regex = false;
    let caseSensitive = false;
    return h(
      "div",
      null,
      field("Procurar", find),
      field("Trocar por", replace),
      h("div", { class: "row" }, checkbox("Express\xE3o regular", false, (on) => regex = on), checkbox("Diferenciar mai\xFAsculas", false, (on) => caseSensitive = on)),
      button(
        "Substituir em todas as p\xE1ginas",
        () => {
          if (!find.value) return ctx.toast("Diga o que procurar.", true);
          if (regex) {
            try {
              new RegExp(find.value);
            } catch {
              return ctx.toast("Express\xE3o regular inv\xE1lida.", true);
            }
          }
          void ctx.upsert({ op: "replace", find: find.value, replace: replace.value, regex, caseSensitive }, { target: { selector: "body" }, label: "Substituir texto", match: () => false }).then(() => {
            ctx.toast("Substitui\xE7\xE3o criada.");
            find.value = "";
            replace.value = "";
          });
        },
        { variant: "primary", small: true, testid: "replace-apply" }
      )
    );
  }
  function editItem(ctx, edit, showSelector) {
    const count = edit.target.selector === "body" ? 1 : safeQueryAll(ctx.doc, edit.target.selector).filter((element) => !element.closest("[data-wce-ui]")).length;
    const details = h("details", null, h("summary", null, "Op\xE7\xF5es"));
    const clientsBox = h("div", { class: "row" });
    for (const client of ctx.project.clients) {
      clientsBox.append(
        checkbox(
          client.name,
          (edit.clients ?? []).includes(client.id),
          (on) => void ctx.commit("Clientes da altera\xE7\xE3o", (project) => {
            const target = project.edits.find((candidate) => candidate.id === edit.id);
            if (!target) return;
            const set = new Set(target.clients ?? []);
            if (on) set.add(client.id);
            else set.delete(client.id);
            target.clients = [...set];
            if (target.clients.length === 0) delete target.clients;
          })
        )
      );
    }
    const mutate = (label, change) => void ctx.commit(label, (project) => {
      const target = project.edits.find((candidate) => candidate.id === edit.id);
      if (target) change(target);
    });
    append(details, [
      field("Seletor", input(edit.target.selector, (value) => mutate("Seletor", (target) => target.target = { ...target.target, selector: value }), { mono: true })),
      field("S\xF3 nas p\xE1ginas (padr\xE3o de caminho)", input(edit.page ?? "", (value) => mutate("P\xE1gina", (target) => value.trim() ? target.page = value.trim() : delete target.page), { mono: true, placeholder: "vazio: todas \xB7 ex.: /clientes/*" })),
      field("S\xF3 para os clientes", clientsBox, "Nenhum marcado: todos os clientes."),
      field("S\xF3 quando", expressionInput(edit.when ?? "", (value) => mutate("Condi\xE7\xE3o", (target) => value.trim() ? target.when = value.trim() : delete target.when), { placeholder: "express\xE3o" })),
      edit.op === "insert" || edit.op === "html" ? field("HTML", textarea(edit.op === "insert" ? edit.html : edit.value, (value) => mutate("HTML", (target) => target.op === "insert" ? target.html = value : target.op === "html" ? target.value = value : void 0), { rows: 5, mono: true })) : null,
      edit.op === "text" ? field("Texto", textarea(edit.value, (value) => mutate("Texto", (target) => target.op === "text" && (target.value = value)), { rows: 2 })) : null,
      edit.op === "repeat" ? field("Lista", input(edit.expr, (value) => mutate("Lista", (target) => target.op === "repeat" && (target.expr = value)), { mono: true })) : null,
      edit.op === "repeat" ? field("Modelo", textarea(edit.template, (value) => mutate("Modelo", (target) => target.op === "repeat" && (target.template = value)), { rows: 4, mono: true })) : null
    ]);
    return h(
      "div",
      { class: `item${edit.enabled ? "" : " off"}`, "data-testid": "edit-item", "data-edit-id": edit.id },
      h(
        "div",
        { class: "top" },
        h("input", {
          type: "checkbox",
          checked: edit.enabled,
          "aria-label": "Ligada",
          title: "Ligar ou desligar",
          onchange: (event) => mutate("Ligar/desligar", (target) => target.enabled = event.target.checked)
        }),
        h("span", { class: "title" }, edit.label ?? edit.op),
        count === 0 ? h("span", { class: "badge warn", title: "O seletor n\xE3o acha nada nesta p\xE1gina" }, "n\xE3o encontrado") : null,
        button("Localizar", () => {
          const found = safeQueryAll(ctx.doc, edit.target.selector).find((element) => !element.closest("[data-wce-ui]"));
          if (found) {
            found.scrollIntoView({ block: "center", behavior: "smooth" });
            ctx.select(found);
          } else ctx.toast("N\xE3o est\xE1 nesta p\xE1gina.", true);
        }, { icon: "target", iconOnly: true, variant: "ghost", small: true }),
        button("Excluir", () => void ctx.removeEdits((candidate) => candidate.id === edit.id), { icon: "trash", iconOnly: true, variant: "ghost", small: true, testid: "edit-delete" })
      ),
      h("div", { class: "sub" }, describeEdit(edit)),
      showSelector ? h("div", { class: "sub mono" }, edit.target.selector) : null,
      h("div", { class: "row" }, ...scopeBadges(ctx, edit)),
      details
    );
  }
  function renderChanges(body, ctx) {
    const filter = input("", () => void 0, { placeholder: "Filtrar altera\xE7\xF5es\u2026", live: true, testid: "changes-filter", type: "search" });
    const list = h("div");
    const draw = () => {
      list.replaceChildren();
      const text = filter.value.toLowerCase();
      const edits = ctx.project.edits.filter((edit) => !text || `${edit.label ?? ""} ${describeEdit(edit)} ${edit.target.selector}`.toLowerCase().includes(text));
      if (edits.length === 0) list.append(empty(ctx.project.edits.length === 0 ? "Nenhuma altera\xE7\xE3o ainda. Clique num elemento da p\xE1gina para come\xE7ar." : "Nada com esse filtro."));
      for (const edit of [...edits].reverse()) list.append(editItem(ctx, edit, true));
    };
    filter.addEventListener("input", draw);
    draw();
    const cssArea = textarea(ctx.project.css, (value) => void ctx.commit("CSS do projeto", (project) => project.css = value), { rows: 6, mono: true, placeholder: ".minha-classe { color: {{ cor_marca }}; }", testid: "project-css" });
    body.append(
      section("Substituir texto no site todo", replaceForm(ctx)),
      section("CSS do projeto", cssArea, h("div", { class: "hint" }, "Vale em todas as p\xE1ginas do projeto. Aceita {{ vari\xE1veis }}.")),
      h("div", { class: "row", style: "margin:0 0 8px" }, filter),
      h(
        "div",
        { class: "row", style: "margin:0 0 8px" },
        button("Desligar todas", () => void ctx.commit("Desligar todas", (project) => project.edits.forEach((edit) => edit.enabled = false)), { small: true }),
        button("Ligar todas", () => void ctx.commit("Ligar todas", (project) => project.edits.forEach((edit) => edit.enabled = true)), { small: true }),
        button("Excluir as n\xE3o encontradas aqui", () => {
          const missing = ctx.project.edits.filter((edit) => edit.target.selector !== "body" && !edit.page && safeQueryAll(ctx.doc, edit.target.selector).length === 0).map((edit) => edit.id);
          if (missing.length === 0) return ctx.toast("Todas as altera\xE7\xF5es acham o seu elemento nesta p\xE1gina.");
          if (window.confirm(`Excluir ${missing.length} altera\xE7\xE3o(\xF5es) cujo elemento n\xE3o est\xE1 nesta p\xE1gina? Elas podem ser de outra tela do sistema.`)) void ctx.removeEdits((edit) => missing.includes(edit.id), "Limpar n\xE3o encontradas");
        }, { small: true, variant: "danger" })
      ),
      list
    );
  }

  // src/editor/editor.ts
  var UNDO_LIMIT = 100;
  var Editor = class {
    constructor(api) {
      this.api = api;
    }
    host = null;
    root = null;
    pageStyle = null;
    project;
    engine;
    projects = [];
    settings;
    selected = null;
    hovered = null;
    selectorOverride = null;
    tab = "element";
    focusId = null;
    scope = { page: "all", clients: "all" };
    browsing = false;
    panelOpen = true;
    picking = null;
    inline = null;
    undoStack = [];
    redoStack = [];
    saveTimer = null;
    status = "Salvo";
    frame = 0;
    original = false;
    listeners = [];
    // elementos do Shadow DOM
    hoverBox;
    selBox;
    hoverTag;
    selTag;
    minibar;
    toolbar;
    panel;
    panelBody;
    toastEl = null;
    banner = null;
    statusEl;
    isOpen() {
      return this.host !== null;
    }
    async open(projectId, options = {}) {
      this.settings = await readSettings();
      this.projects = await projectsFor(location.href, true);
      let project = null;
      if (projectId) project = await getProject(projectId);
      if (!project && this.isOpen()) project = this.project;
      if (!project) project = [...this.projects].sort((a, b) => b.updatedAt - a.updatedAt)[0] ?? null;
      if (!project) {
        project = newProject(document.title.trim().slice(0, 80) || location.hostname || "Novo projeto", [suggestPattern(location.href)]);
        project = await saveProject(project, "Projeto criado");
        this.projects = [project];
      }
      await this.useProject(project);
      if (!this.isOpen()) this.mount();
      if (options.select) this.select(options.select);
      this.rerender();
    }
    async useProject(project) {
      if (this.project && this.project.id !== project.id) this.api.editorOwns.delete(this.project.id);
      this.project = project;
      this.api.editorOwns.add(project.id);
      this.engine = await this.api.engineFor(project);
      if (this.engine.currentProject.updatedAt !== project.updatedAt) await this.engine.update(project);
      this.undoStack = [];
      this.redoStack = [];
    }
    close() {
      if (!this.host) return;
      this.finishInline(true);
      for (const [target, type, listener, capture] of this.listeners) target.removeEventListener(type, listener, capture);
      this.listeners.length = 0;
      cancelAnimationFrame(this.frame);
      if (this.saveTimer !== null) {
        clearTimeout(this.saveTimer);
        void this.flush();
      }
      if (this.original) this.previewOriginal(false);
      this.host.remove();
      this.pageStyle?.remove();
      this.host = null;
      this.root = null;
      document.documentElement.classList.remove("wce-editing", "wce-pick", "wce-show-hidden");
      this.api.editorOwns.delete(this.project.id);
      void this.api.refresh();
    }
    // ---------------------------------------------------------------- montagem
    mount() {
      this.host = document.createElement("wce-editor");
      this.host.setAttribute("data-wce-ui", "editor");
      this.root = this.host.attachShadow({ mode: "open" });
      const style = document.createElement("style");
      style.textContent = EDITOR_CSS;
      this.hoverBox = h("div", { class: "hl hover" });
      this.selBox = h("div", { class: "hl sel" });
      this.hoverTag = h("div", { class: "tag" });
      this.selTag = h("div", { class: "tag" });
      this.minibar = h("div", { class: "minibar", role: "toolbar", "aria-label": "A\xE7\xF5es do elemento" });
      this.toolbar = h("div", { class: "toolbar", role: "toolbar", "aria-label": "Site Editor" });
      this.panelBody = h("div", { class: "body" });
      this.panel = h("aside", { class: `panel ${this.settings.toolbarSide}`, "aria-label": "Painel do Site Editor" });
      this.root.append(style, this.hoverBox, this.selBox, this.hoverTag, this.selTag, this.minibar, this.toolbar, this.panel);
      document.documentElement.appendChild(this.host);
      this.pageStyle = document.createElement("style");
      this.pageStyle.setAttribute("data-wce-ui", "editor-page");
      this.pageStyle.textContent = PAGE_CSS;
      (document.head ?? document.documentElement).appendChild(this.pageStyle);
      document.documentElement.classList.add("wce-editing");
      document.documentElement.classList.toggle("wce-show-hidden", this.settings.showHidden);
      this.listen();
      const loop = () => {
        this.position();
        this.frame = requestAnimationFrame(loop);
      };
      this.frame = requestAnimationFrame(loop);
    }
    on(target, type, listener, capture = true) {
      target.addEventListener(type, listener, capture);
      this.listeners.push([target, type, listener, capture]);
    }
    fromUs(event) {
      return event.composedPath().some((node) => node === this.host);
    }
    pageTarget(event) {
      const path = event.composedPath();
      if (path.some((node) => node === this.host)) return null;
      const first = path.find((node) => node instanceof Element);
      if (!first) return null;
      if (first.closest("[data-wce-ui]")) return null;
      return first;
    }
    listen() {
      const block = (event) => {
        if (this.browsing || this.fromUs(event)) return;
        const target = this.pageTarget(event);
        if (!target) return;
        if (this.inline && this.inline.element.contains(target)) return;
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
      };
      for (const type of ["pointerdown", "mousedown", "pointerup", "mouseup", "submit", "auxclick", "touchstart", "dragstart"]) this.on(window, type, block);
      this.on(window, "mousemove", (event) => {
        if (this.browsing && !this.picking) {
          this.hovered = null;
          return;
        }
        const target = this.pageTarget(event);
        this.hovered = target && target !== document.documentElement ? target : null;
      });
      this.on(window, "mouseleave", () => {
        this.hovered = null;
      });
      this.on(window, "click", (event) => {
        if (this.fromUs(event)) return;
        const target = this.pageTarget(event);
        if (!target) return;
        if (this.inline && this.inline.element.contains(target)) return;
        if (this.picking) {
          event.preventDefault();
          event.stopPropagation();
          event.stopImmediatePropagation();
          const { done } = this.picking;
          this.stopPicking();
          done(target);
          return;
        }
        if (this.browsing) return;
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        if (this.inline) this.finishInline(false);
        this.select(target);
        if (this.tab !== "element" && this.tab !== "insert") this.setTab("element");
      });
      this.on(window, "dblclick", (event) => {
        if (this.browsing || this.fromUs(event)) return;
        const target = this.pageTarget(event);
        if (!target) return;
        event.preventDefault();
        event.stopPropagation();
        this.startInline(target);
      });
      this.on(window, "keydown", (event) => {
        const key = event;
        if (this.inline) {
          if (key.key === "Escape") {
            key.preventDefault();
            this.finishInline(true);
          } else if (key.key === "Enter" && !key.shiftKey && !/^(div|section|article|td|li)$/.test(this.inline.element.localName)) {
            key.preventDefault();
            this.finishInline(false);
          }
          return;
        }
        if (this.fromUs(event)) {
          if (key.key === "Escape" && this.picking) this.stopPicking();
          return;
        }
        const typing = event.target instanceof HTMLElement && (event.target.isContentEditable || /^(input|textarea|select)$/i.test(event.target.localName));
        if (typing) return;
        const mod = key.ctrlKey || key.metaKey;
        if (mod && key.key.toLowerCase() === "z") {
          key.preventDefault();
          if (key.shiftKey) void this.redo();
          else void this.undo();
        } else if (mod && key.key.toLowerCase() === "y") {
          key.preventDefault();
          void this.redo();
        } else if (key.key === "Escape") {
          if (this.picking) this.stopPicking();
          else this.select(null);
        } else if ((key.key === "Delete" || key.key === "Backspace") && this.selected) {
          key.preventDefault();
          void this.upsert({ op: "hide" }, { label: "Ocultar" });
        } else if (key.key === "Enter" && this.selected) {
          key.preventDefault();
          this.startInline(this.selected);
        } else if (key.altKey && key.key === "ArrowUp" && this.selected?.parentElement) {
          key.preventDefault();
          this.select(this.selected.parentElement);
        }
      });
      this.on(window, "scroll", () => this.position(), true);
      this.on(window, "resize", () => {
        this.position();
        this.placeToolbar();
      }, false);
    }
    // ---------------------------------------------------------------- realces
    placeBox(box, tag, element, label) {
      if (!element || !element.isConnected) {
        box.style.display = "none";
        tag.style.display = "none";
        return;
      }
      const rect = element.getBoundingClientRect();
      if (rect.width === 0 && rect.height === 0) {
        box.style.display = "none";
        tag.style.display = "none";
        return;
      }
      box.style.display = "block";
      box.style.left = `${rect.left - 2}px`;
      box.style.top = `${rect.top - 2}px`;
      box.style.width = `${rect.width + 4}px`;
      box.style.height = `${rect.height + 4}px`;
      tag.style.display = "block";
      tag.textContent = label;
      const above = rect.top > 22;
      tag.style.left = `${Math.max(4, rect.left - 2)}px`;
      tag.style.top = `${above ? rect.top - 22 : Math.min(window.innerHeight - 22, rect.bottom + 4)}px`;
    }
    position() {
      if (!this.host) return;
      const hover = this.hovered && this.hovered !== this.selected ? this.hovered : null;
      this.hoverBox.classList.toggle("pick", this.picking !== null);
      this.hoverTag.classList.toggle("pick", this.picking !== null);
      this.placeBox(this.hoverBox, this.hoverTag, hover, hover ? `${friendlyName(hover)} \xB7 ${describe(hover)}` : "");
      this.placeBox(this.selBox, this.selTag, this.selected, this.selected ? `${friendlyName(this.selected)} \xB7 ${describe(this.selected)}` : "");
      if (this.selected && this.selected.isConnected && !this.picking && !this.inline) {
        const rect = this.selected.getBoundingClientRect();
        this.minibar.style.display = "flex";
        const bar = this.minibar.getBoundingClientRect();
        const width = bar.width || 300;
        const panelWidth = this.panelOpen && window.innerWidth > 720 ? this.panel.getBoundingClientRect().width : 0;
        const maxLeft = window.innerWidth - width - 8 - (this.settings.toolbarSide === "right" ? panelWidth : 0);
        const minLeft = 8 + (this.settings.toolbarSide === "left" ? panelWidth : 0);
        const left = Math.min(Math.max(minLeft, rect.left), Math.max(minLeft, maxLeft));
        let top = rect.bottom + 8;
        if (top + 40 > window.innerHeight) top = Math.max(60, rect.top - 46);
        this.minibar.style.left = `${left}px`;
        this.minibar.style.top = `${Math.min(window.innerHeight - 44, top)}px`;
      } else this.minibar.style.display = "none";
    }
    // ---------------------------------------------------------------- seleção
    select(element) {
      if (element && (element === document.documentElement || element.closest("[data-wce-ui]"))) element = null;
      this.selected = element;
      this.selectorOverride = null;
      this.renderMinibar();
      if (this.tab === "element" || this.tab === "insert") this.rerender();
    }
    get selector() {
      if (this.selectorOverride) return this.selectorOverride;
      return this.selected ? selectorFor(this.selected) : "";
    }
    renderMinibar() {
      clear(this.minibar);
      const element = this.selected;
      if (!element) return;
      const isImage = element.localName === "img";
      const isLink = element.closest("a") !== null;
      append(this.minibar, [
        button("Selecionar o elemento de fora", () => element.parentElement && this.select(element.parentElement), { icon: "up", iconOnly: true, variant: "ghost", testid: "mini-parent" }),
        button("Editar texto (duplo clique)", () => this.startInline(element), { icon: "text", iconOnly: true, variant: "ghost", testid: "mini-text" }),
        isImage ? button("Trocar imagem", () => this.setTab("element", "image"), { icon: "image", iconOnly: true, variant: "ghost", testid: "mini-image" }) : null,
        isLink ? button("Editar link", () => this.setTab("element", "link"), { icon: "link", iconOnly: true, variant: "ghost", testid: "mini-link" }) : null,
        button("Estilo", () => this.setTab("element", "style"), { icon: "palette", iconOnly: true, variant: "ghost", testid: "mini-style" }),
        button("Ocultar (Delete)", () => void this.upsert({ op: "hide" }, { label: "Ocultar" }), { icon: "eyeOff", iconOnly: true, variant: "ghost", testid: "mini-hide" }),
        button("Desfocar (dados sens\xEDveis)", () => void this.upsert({ op: "blur", amount: 6 }, { label: "Desfocar" }), { icon: "blur", iconOnly: true, variant: "ghost", testid: "mini-blur" }),
        button("Duplicar", () => void this.duplicate(element), { icon: "copy", iconOnly: true, variant: "ghost", testid: "mini-duplicate" }),
        button("Mover para\u2026", () => this.startMove(element), { icon: "move", iconOnly: true, variant: "ghost", testid: "mini-move" }),
        button("Inserir componente aqui", () => this.setTab("insert"), { icon: "plus", iconOnly: true, variant: "ghost", testid: "mini-insert" }),
        button("Dados din\xE2micos", () => this.setTab("element", "dynamic"), { icon: "braces", iconOnly: true, variant: "ghost", testid: "mini-dynamic" }),
        button("Evento ao clicar", () => this.setTab("element", "events"), { icon: "zap", iconOnly: true, variant: "ghost", testid: "mini-event" })
      ]);
    }
    async duplicate(element) {
      const clone = element.cloneNode(true);
      clone.removeAttribute("id");
      clone.querySelectorAll("[id]").forEach((node) => node.removeAttribute("id"));
      await this.upsert({ op: "insert", position: "after", html: clone.outerHTML }, { label: "C\xF3pia", match: () => false });
      this.toast("Elemento duplicado logo depois do original.");
    }
    startMove(element) {
      const selector = this.selector;
      this.pick("Clique no elemento ao lado do qual ele vai ficar", (target) => {
        if (target === element || element.contains(target)) {
          this.toast("Escolha um elemento fora do que est\xE1 sendo movido.", true);
          return;
        }
        const ref = { selector: selectorFor(target) };
        void this.choose("Onde colocar em rela\xE7\xE3o ao elemento clicado?", [
          ["before", "Antes"],
          ["after", "Depois"],
          ["prepend", "Dentro, no in\xEDcio"],
          ["append", "Dentro, no fim"]
        ]).then((position) => {
          if (!position) return;
          void this.upsert({ op: "move", ref, position }, { target: { selector }, label: "Mover" }).then(() => this.select(element));
        });
      });
    }
    // uma pergunta rápida no topo da tela, com botões (sem os diálogos do navegador)
    choose(prompt, options) {
      return new Promise((resolve) => {
        this.banner?.remove();
        const done = (value) => {
          this.banner?.remove();
          this.banner = null;
          resolve(value);
        };
        this.banner = h("div", { class: "banner", role: "dialog", "aria-label": prompt }, h("span", null, prompt), ...options.map(([value, label]) => button(label, () => done(value), { small: true, testid: `choose-${value}` })), button("Cancelar", () => done(null), { small: true }));
        this.root?.appendChild(this.banner);
      });
    }
    pick(prompt, done) {
      this.picking = { prompt, done };
      document.documentElement.classList.add("wce-pick");
      this.banner?.remove();
      this.banner = h("div", { class: "banner", role: "status" }, h("span", null, prompt), button("Cancelar", () => this.stopPicking(), { small: true }));
      this.root?.appendChild(this.banner);
    }
    stopPicking() {
      this.picking = null;
      document.documentElement.classList.remove("wce-pick");
      this.banner?.remove();
      this.banner = null;
    }
    // ---------------------------------------------------------------- texto no lugar
    startInline(element) {
      if (!(element instanceof HTMLElement) || element.closest("[data-wce-ui]")) return;
      if (/^(img|input|select|video|iframe|svg|hr|br)$/.test(element.localName)) {
        this.select(element);
        this.setTab("element");
        return;
      }
      this.finishInline(false);
      this.select(element);
      const selector = this.selector;
      const edit = this.project.edits.find((candidate) => candidate.target.selector === selector && (candidate.op === "text" || candidate.op === "html") && this.sameScope(candidate)) ?? null;
      this.engine.hold();
      const before = element.innerHTML;
      if (edit && edit.op === "text" && edit.value.includes("{{")) element.textContent = edit.value;
      if (edit && edit.op === "html" && edit.value.includes("{{")) element.innerHTML = edit.value;
      element.setAttribute("data-wce-editing", "");
      element.contentEditable = "true";
      element.focus();
      const range = document.createRange();
      range.selectNodeContents(element);
      const selection = window.getSelection();
      selection?.removeAllRanges();
      selection?.addRange(range);
      this.inline = { element, before, edit };
      const blur = () => {
        element.removeEventListener("blur", blur);
        if (this.inline?.element === element) this.finishInline(false);
      };
      element.addEventListener("blur", blur);
      this.renderMinibar();
    }
    finishInline(cancel) {
      const inline = this.inline;
      if (!inline) return;
      this.inline = null;
      const { element, before } = inline;
      element.removeAttribute("contenteditable");
      element.removeAttribute("data-wce-editing");
      const hasChildren = Array.from(element.children).some((child) => !/^(br)$/.test(child.localName));
      const html = element.innerHTML;
      const text = (element.innerText ?? element.textContent ?? "").replace(/\n$/, "");
      if (cancel || html === before) {
        element.innerHTML = before;
        this.engine.release();
        return;
      }
      element.innerHTML = before;
      this.engine.release();
      const selector = this.selector;
      const op = hasChildren ? { op: "html", value: html } : { op: "text", value: text };
      void this.removeEdits((edit) => edit.target.selector === selector && (edit.op === "text" || edit.op === "html") && edit.op !== op.op && this.sameScope(edit), null).then(() => this.upsert(op, { label: hasChildren ? "Conte\xFAdo" : "Texto" }));
    }
    // ---------------------------------------------------------------- gravar
    sameScope(edit) {
      const page = this.scope.page === "this" ? location.pathname : void 0;
      const clients = this.scope.clients === "current" && this.engine.currentClient ? [this.engine.currentClient.id] : void 0;
      return (edit.page ?? void 0) === page && JSON.stringify(edit.clients ?? []) === JSON.stringify(clients ?? []);
    }
    async commit(label, mutate) {
      const snapshot = JSON.stringify(this.project);
      const next = JSON.parse(snapshot);
      mutate(next);
      next.updatedAt = Date.now();
      if (JSON.stringify(next) === snapshot) return;
      this.undoStack.push(snapshot);
      if (this.undoStack.length > UNDO_LIMIT) this.undoStack.shift();
      this.redoStack = [];
      await this.apply(next, label);
    }
    async apply(next, label) {
      this.project = next;
      await this.engine.update(next, this.api.clientOverride.get(next.id) ?? next.activeClientId);
      this.queueSave(label);
      this.renderToolbar();
      this.rerender();
    }
    queueSave(label) {
      this.setStatus("Salvando\u2026");
      if (this.saveTimer !== null) clearTimeout(this.saveTimer);
      this.saveTimer = window.setTimeout(() => {
        this.saveTimer = null;
        void this.flush(label);
      }, 250);
    }
    async flush(label = "Altera\xE7\xE3o") {
      try {
        const saved = await saveProject(this.project, label, { touch: false });
        this.projects = this.projects.map((project) => project.id === saved.id ? saved : project);
        if (!this.projects.some((project) => project.id === saved.id)) this.projects.push(saved);
        this.setStatus("Salvo");
      } catch (error) {
        this.setStatus("Erro ao salvar", true);
        this.toast(`N\xE3o foi poss\xEDvel salvar: ${error instanceof Error ? error.message : String(error)}`, true);
      }
    }
    setStatus(text, error = false) {
      this.status = text;
      if (this.statusEl) {
        this.statusEl.textContent = text;
        this.statusEl.classList.toggle("err", error);
      }
    }
    async undo() {
      const previous = this.undoStack.pop();
      if (!previous) return;
      this.redoStack.push(JSON.stringify(this.project));
      const project = JSON.parse(previous);
      project.updatedAt = Date.now();
      await this.apply(project, "Desfazer");
    }
    async redo() {
      const next = this.redoStack.pop();
      if (!next) return;
      this.undoStack.push(JSON.stringify(this.project));
      const project = JSON.parse(next);
      project.updatedAt = Date.now();
      await this.apply(project, "Refazer");
    }
    async upsert(op, options = {}) {
      const target = options.target ?? { selector: this.selector, hint: (this.selected?.textContent ?? "").trim().slice(0, 60) };
      if (!target.selector) throw new Error("Selecione um elemento primeiro.");
      const page = this.scope.page === "this" ? location.pathname : void 0;
      const clients = this.scope.clients === "current" && this.engine.currentClient ? [this.engine.currentClient.id] : void 0;
      const sameKind = (edit) => {
        if (edit.target.selector !== target.selector || edit.op !== op.op || !this.sameScope(edit)) return false;
        if (op.op === "attr" && edit.op === "attr") return edit.name === op.name;
        if (op.op === "bind" && edit.op === "bind") return edit.kind === op.kind && (edit.name ?? "") === (op.name ?? "");
        if (op.op === "insert" || op.op === "replace") return false;
        return true;
      };
      const match = options.match ?? sameKind;
      let result = null;
      await this.commit(options.label ?? "Altera\xE7\xE3o", (project) => {
        const existing = project.edits.find(match);
        if (existing) {
          if (op.op === "style" && existing.op === "style") {
            const props = { ...existing.props, ...op.props };
            for (const [key, value] of Object.entries(props)) if (value === "") delete props[key];
            Object.assign(existing, { props });
          } else if (op.op === "class" && existing.op === "class") {
            Object.assign(existing, { add: [.../* @__PURE__ */ new Set([...existing.add, ...op.add])].filter((name) => !op.remove.includes(name)), remove: [.../* @__PURE__ */ new Set([...existing.remove, ...op.remove])].filter((name) => !op.add.includes(name)) });
          } else Object.assign(existing, op);
          existing.enabled = true;
          result = existing;
        } else {
          const edit = { ...op, id: uid("e_"), target, enabled: true, createdAt: Date.now(), ...page ? { page } : {}, ...clients ? { clients } : {}, ...options.label ? { label: options.label } : {} };
          project.edits.push(edit);
          result = edit;
        }
      });
      if (!result) {
        result = this.project.edits.find(match) ?? null;
      }
      if (!result) throw new Error("A altera\xE7\xE3o n\xE3o foi gravada.");
      return result;
    }
    async removeEdits(predicate, label = "Remover altera\xE7\xE3o") {
      if (!this.project.edits.some(predicate)) return;
      if (label === null) {
        this.project = { ...this.project, edits: this.project.edits.filter((edit) => !predicate(edit)) };
        await this.engine.update(this.project);
        return;
      }
      await this.commit(label, (project) => {
        project.edits = project.edits.filter((edit) => !predicate(edit));
      });
    }
    previewOriginal(on) {
      this.original = on;
      for (const engine of this.api.engines.values()) {
        if (on) engine.suspend();
        else engine.resume();
      }
      this.renderToolbar();
    }
    toast(message, error = false) {
      this.toastEl?.remove();
      this.toastEl = h("div", { class: `toast${error ? " err" : ""}`, role: "status" }, message);
      this.root?.appendChild(this.toastEl);
      const mine = this.toastEl;
      window.setTimeout(() => mine.remove(), 3200);
    }
    setTab(tab, focus) {
      this.tab = tab;
      this.focusId = focus ?? null;
      if (!this.panelOpen) this.panelOpen = true;
      this.rerender();
    }
    context() {
      return {
        doc: document,
        project: this.project,
        engine: this.engine,
        selected: this.selected,
        selector: this.selector,
        scope: this.scope,
        settings: this.settings,
        projects: this.projects,
        focusId: this.focusId,
        commit: (label, mutate) => this.commit(label, mutate),
        upsert: (op, options) => this.upsert(op, options),
        removeEdits: (predicate, label) => this.removeEdits(predicate, label ?? "Remover altera\xE7\xE3o"),
        select: (element) => this.select(element),
        setSelector: (selector) => {
          this.selectorOverride = selector;
          const first = safeQueryAll(document, selector).find((element) => !element.closest("[data-wce-ui]"));
          if (first) this.selected = first;
          this.renderMinibar();
          this.rerender();
        },
        pick: (prompt, done) => this.pick(prompt, done),
        toast: (message, error) => this.toast(message, error),
        rerender: () => this.rerender(),
        setTab: (tab, focus) => this.setTab(tab, focus),
        setScope: (scope) => {
          this.scope = scope;
          this.rerender();
        },
        startInline: (element) => this.startInline(element),
        switchProject: async (id) => {
          const project = this.projects.find((candidate) => candidate.id === id) ?? await getProject(id);
          if (!project) return;
          await this.useProject(project);
          this.select(null);
          this.renderToolbar();
          this.rerender();
        },
        createProject: async () => {
          const name = window.prompt("Nome do novo projeto", `${location.hostname} (c\xF3pia)`);
          if (!name) return;
          const project = await saveProject(newProject(name, [suggestPattern(location.href)]), "Projeto criado");
          this.projects.push(project);
          await this.useProject(project);
          this.renderToolbar();
          this.rerender();
        },
        setSettings: async (patch) => {
          this.settings = await writeSettings(patch);
          document.documentElement.classList.toggle("wce-show-hidden", this.settings.showHidden);
          this.panel.className = `panel ${this.settings.toolbarSide}${this.panelOpen ? "" : " hidden"}`;
          this.rerender();
        },
        previewOriginal: (on) => this.previewOriginal(on),
        close: () => this.close()
      };
    }
    // ---------------------------------------------------------------- barra e painel
    renderToolbar() {
      clear(this.toolbar);
      const brand = h("div", { class: "brand", title: "Arraste para mover a barra" }, h("span", { class: "dot" }), h("span", { class: "brand-label" }, "Site Editor"));
      this.dragToolbar(brand);
      const projectSelect = h(
        "select",
        { "aria-label": "Projeto", "data-testid": "project-select" },
        this.projects.map((project) => h("option", { value: project.id, selected: project.id === this.project.id }, project.name)),
        h("option", { value: "__new" }, "+ Novo projeto\u2026")
      );
      projectSelect.addEventListener("change", () => {
        if (projectSelect.value === "__new") void this.context().createProject();
        else void this.context().switchProject(projectSelect.value);
      });
      const currentClient = this.engine.currentClient?.id ?? "";
      const clientSelect = h(
        "select",
        { "aria-label": "Cliente", "data-testid": "client-select", title: "Cliente (variante) mostrado" },
        this.project.clients.map((client) => h("option", { value: client.id, selected: client.id === currentClient }, `\u{1F464} ${client.name}`))
      );
      clientSelect.addEventListener("change", () => {
        this.api.clientOverride.delete(this.project.id);
        void this.commit("Trocar cliente", (project) => {
          project.activeClientId = clientSelect.value;
        });
      });
      this.statusEl = h("span", { class: "status", role: "status", "data-testid": "save-status" }, this.status);
      this.toolbar.append(
        brand,
        projectSelect,
        clientSelect,
        h("span", { class: "sep" }),
        button(this.browsing ? "Navegando: clique para editar" : "Navegar no sistema", () => {
          this.browsing = !this.browsing;
          if (this.browsing) this.select(null);
          this.renderToolbar();
          this.toast(this.browsing ? "Modo navega\xE7\xE3o: use o sistema normalmente. Clique de novo para voltar a editar." : "Modo edi\xE7\xE3o: clique num elemento para editar.");
        }, { icon: "cursor", iconOnly: true, variant: "ghost", pressed: this.browsing, testid: "toggle-browse" }),
        button("Inserir componente", () => this.setTab("insert"), { icon: "plus", iconOnly: true, variant: "ghost", testid: "open-insert" }),
        button(this.settings.showHidden ? "Esconder ocultos" : "Mostrar ocultos", () => void this.context().setSettings({ showHidden: !this.settings.showHidden }).then(() => this.renderToolbar()), { icon: "eye", iconOnly: true, variant: "ghost", pressed: this.settings.showHidden, testid: "toggle-hidden" }),
        button(this.original ? "Voltar \xE0s altera\xE7\xF5es" : "Ver original", () => this.previewOriginal(!this.original), { icon: "layers", iconOnly: true, variant: "ghost", pressed: this.original, testid: "toggle-original" }),
        button("Desfazer (Ctrl+Z)", () => void this.undo(), { icon: "undo", iconOnly: true, variant: "ghost", disabled: this.undoStack.length === 0, testid: "undo" }),
        button("Refazer (Ctrl+Shift+Z)", () => void this.redo(), { icon: "redo", iconOnly: true, variant: "ghost", disabled: this.redoStack.length === 0, testid: "redo" }),
        this.statusEl,
        button(this.panelOpen ? "Fechar painel" : "Abrir painel", () => {
          this.panelOpen = !this.panelOpen;
          this.rerender();
        }, { icon: "panel", iconOnly: true, variant: "ghost", pressed: this.panelOpen, testid: "toggle-panel" }),
        button("Fechar o editor", () => this.close(), { icon: "close", iconOnly: true, variant: "ghost", testid: "close-editor" })
      );
    }
    toolbarMoved = false;
    // a barra fica centrada na área da página que o painel não cobre, até a pessoa arrastá-la
    placeToolbar() {
      if (this.toolbarMoved || !this.host) return;
      const panelWidth = this.panelOpen && window.innerWidth > 720 ? Math.min(380, window.innerWidth) : 0;
      const panelLeft = this.settings.toolbarSide === "left";
      this.toolbar.style.left = `${(panelLeft ? panelWidth : 0) + 10}px`;
      this.toolbar.style.right = `${(panelLeft ? 0 : panelWidth) + 10}px`;
      this.toolbar.style.maxWidth = "";
    }
    dragToolbar(handle) {
      handle.addEventListener("pointerdown", (event) => {
        this.toolbarMoved = true;
        const start = { x: event.clientX, y: event.clientY };
        const rect = this.toolbar.getBoundingClientRect();
        const move = (next) => {
          this.toolbar.style.bottom = "auto";
          this.toolbar.style.right = "auto";
          this.toolbar.style.margin = "0";
          this.toolbar.style.left = `${Math.max(0, Math.min(window.innerWidth - rect.width, rect.left + next.clientX - start.x))}px`;
          this.toolbar.style.top = `${Math.max(0, Math.min(window.innerHeight - rect.height, rect.top + next.clientY - start.y))}px`;
        };
        const up = () => {
          window.removeEventListener("pointermove", move, true);
          window.removeEventListener("pointerup", up, true);
        };
        window.addEventListener("pointermove", move, true);
        window.addEventListener("pointerup", up, true);
      });
    }
    rerender() {
      if (!this.host) return;
      this.renderToolbar();
      this.panel.className = `panel ${this.settings.toolbarSide}${this.panelOpen ? "" : " hidden"}`;
      this.placeToolbar();
      if (!this.panelOpen) return;
      const scrollTop = this.panelBody.scrollTop;
      const active = this.root?.activeElement;
      const activeTestId = active?.getAttribute("data-testid");
      clear(this.panel);
      const tabs = [
        ["element", "Elemento", "target"],
        ["insert", "Inserir", "plus"],
        ["changes", "Altera\xE7\xF5es", "list"],
        ["variables", "Vari\xE1veis", "braces"],
        ["rules", "Eventos", "zap"],
        ["data", "Dados", "database"],
        ["clients", "Clientes", "users"],
        ["project", "Projeto", "settings"]
      ];
      const tabBar = h(
        "div",
        { class: "tabs", role: "tablist" },
        tabs.map(
          ([id, label, glyph]) => h(
            "button",
            {
              type: "button",
              class: "tab",
              role: "tab",
              "aria-selected": String(this.tab === id),
              "data-testid": `tab-${id}`,
              onclick: () => this.setTab(id)
            },
            icon(glyph, 14),
            label,
            id === "changes" ? h("span", { class: "badge" }, String(this.project.edits.length)) : null
          )
        )
      );
      this.panelBody = h("div", { class: "body", "data-testid": "panel-body" });
      this.panel.append(h("div", { class: "panel-head" }, h("h2", null, this.project.name)), tabBar, this.panelBody);
      try {
        renderPanel(this.tab, this.panelBody, this.context());
      } catch (error) {
        this.panelBody.append(h("p", { class: "err" }, `Erro ao mostrar o painel: ${error instanceof Error ? error.message : String(error)}`));
      }
      this.panelBody.scrollTop = this.focusId ? 0 : scrollTop;
      if (this.focusId) {
        const target = this.panelBody.querySelector(`[data-section="${this.focusId}"]`);
        target?.scrollIntoView({ block: "start" });
        target?.querySelector("input,textarea,select")?.focus();
        this.focusId = null;
      } else if (activeTestId) this.panelBody.querySelector(`[data-testid="${activeTestId}"]`)?.focus();
    }
  };
  if (globalThis.__wce && !globalThis.__wce.editor) {
    const editor = new Editor(globalThis.__wce);
    globalThis.__wce.editor = {
      open: (projectId, options) => editor.open(projectId, options),
      close: () => editor.close(),
      isOpen: () => editor.isOpen()
    };
  }
})();
