"use strict";
(() => {
  // src/shared/model.ts
  function activeClient(project, clientId) {
    const id = clientId ?? project.activeClientId;
    return project.clients.find((c) => c.id === id) ?? project.clients[0] ?? null;
  }

  // src/shared/match.ts
  function globToRegex(glob) {
    const escaped = glob.replace(/[.+^${}()|[\]\\?]/g, "\\$&").replace(/\*/g, ".*");
    return new RegExp(`^${escaped}$`, "i");
  }
  function urlMatches(pattern, href) {
    const trimmed = pattern.trim();
    if (trimmed === "") return false;
    if (trimmed === "<all_urls>" || trimmed === "*") return /^(https?|file):/.test(href);
    if (trimmed.length > 2 && trimmed.startsWith("/") && trimmed.lastIndexOf("/") > 0) {
      const end = trimmed.lastIndexOf("/");
      try {
        return new RegExp(trimmed.slice(1, end), trimmed.slice(end + 1)).test(href);
      } catch {
        return false;
      }
    }
    let url;
    try {
      url = new URL(href);
    } catch {
      return false;
    }
    const scheme = /^([a-z*]+):\/\//i.exec(trimmed);
    if (scheme) {
      const wantedScheme = (scheme[1] ?? "").toLowerCase();
      if (wantedScheme !== "*" && wantedScheme !== url.protocol.replace(":", "")) return false;
      if (wantedScheme === "*" && !/^https?:$/.test(url.protocol)) return false;
      const rest = trimmed.slice(scheme[0].length);
      const slash = rest.indexOf("/");
      const hostPattern = slash === -1 ? rest : rest.slice(0, slash);
      const pathPattern = slash === -1 ? "/*" : rest.slice(slash);
      const host = hostPattern.replace(/:(\d+|\*)$/, "").toLowerCase();
      const port = /:(\d+)$/.exec(hostPattern)?.[1];
      if (port !== void 0 && port !== url.port) return false;
      const hostOk = host === "*" || (host.startsWith("*.") ? url.hostname === host.slice(2) || url.hostname.endsWith(host.slice(1)) : globToRegex(host).test(url.hostname));
      if (!hostOk) return false;
      return globToRegex(pathPattern).test(url.pathname + url.search + url.hash) || globToRegex(pathPattern).test(url.pathname);
    }
    const withoutScheme = href.replace(/^[a-z]+:\/\//i, "");
    return globToRegex(trimmed).test(withoutScheme) || globToRegex(trimmed.endsWith("*") ? trimmed : `${trimmed}*`).test(withoutScheme);
  }
  function anyMatches(patterns, href) {
    return patterns.some((pattern) => urlMatches(pattern, href));
  }

  // src/shared/storage.ts
  var INDEX = "wce:index";
  var projectKey = (id) => `wce:project:${id}`;
  var historyKey = (id) => `wce:history:${id}`;
  var HISTORY_SIZE = 30;
  function area() {
    return chrome.storage.local;
  }
  async function readIndex() {
    const stored = await area().get(INDEX);
    const list = stored[INDEX];
    return Array.isArray(list) ? list : [];
  }
  async function getProject(id) {
    const stored = await area().get(projectKey(id));
    return stored[projectKey(id)] ?? null;
  }
  async function projectsFor(href, includeDisabled = false) {
    const index = await readIndex();
    const wanted = index.filter((entry) => (includeDisabled || entry.enabled) && anyMatches(entry.matches, href));
    if (wanted.length === 0) return [];
    const stored = await area().get(wanted.map((entry) => projectKey(entry.id)));
    return wanted.flatMap((entry) => {
      const value = stored[projectKey(entry.id)];
      return value ? [value] : [];
    });
  }
  function entryOf(project) {
    return { id: project.id, name: project.name, matches: project.matches, enabled: project.enabled, updatedAt: project.updatedAt };
  }
  async function saveProject(project, label = "Altera\xE7\xE3o", options = {}) {
    const saved = { ...project, updatedAt: options.touch === false ? project.updatedAt : Date.now() };
    const index = await readIndex();
    const at = index.findIndex((entry) => entry.id === saved.id);
    const nextIndex = [...index];
    if (at === -1) nextIndex.push(entryOf(saved));
    else nextIndex[at] = entryOf(saved);
    const writes = { [projectKey(saved.id)]: saved, [INDEX]: nextIndex };
    if (options.history !== false) {
      const stored = await area().get(historyKey(saved.id));
      const history = Array.isArray(stored[historyKey(saved.id)]) ? stored[historyKey(saved.id)] : [];
      const last = history[0];
      if (last && last.label === label && saved.updatedAt - last.at < 6e4) history[0] = { at: saved.updatedAt, label, project: saved };
      else history.unshift({ at: saved.updatedAt, label, project: saved });
      writes[historyKey(saved.id)] = history.slice(0, HISTORY_SIZE);
    }
    await area().set(writes);
    return saved;
  }

  // src/popup/popup.ts
  var main = document.getElementById("main");
  function el(tag, props = {}, ...children) {
    const element = document.createElement(tag);
    for (const [key, value] of Object.entries(props)) element.setAttribute(key, value);
    for (const child of children) if (child !== null) element.append(child);
    return element;
  }
  async function tabStatus(tabId) {
    try {
      return await chrome.tabs.sendMessage(tabId, { type: "wce:status" }, { frameId: 0 }) ?? null;
    } catch {
      return null;
    }
  }
  async function render() {
    const forced = Number(new URLSearchParams(location.search).get("tab"));
    const [tab] = forced ? [await chrome.tabs.get(forced).catch(() => void 0)] : await chrome.tabs.query({ active: true, currentWindow: true });
    main.replaceChildren();
    if (!tab?.id || !tab.url || !/^(https?|file):/.test(tab.url)) {
      main.append(el("p", { class: "muted" }, "O navegador n\xE3o deixa extens\xF5es editarem esta p\xE1gina (p\xE1ginas internas, loja de extens\xF5es, PDF). Abra um site ou sistema."));
      return;
    }
    const tabId = tab.id;
    const url = tab.url;
    const status = await tabStatus(tabId);
    const projects = await projectsFor(url, true);
    main.append(el("div", { class: "site", title: url }, new URL(url).host + new URL(url).pathname));
    const edit = el("button", { type: "button", class: "primary", "data-testid": "popup-edit" }, status?.editing ? "Fechar o editor" : "Editar esta p\xE1gina");
    edit.addEventListener("click", async () => {
      edit.disabled = true;
      if (status?.editing) await chrome.tabs.sendMessage(tabId, { type: "wce:close-editor" }, { frameId: 0 });
      else {
        const answer = await chrome.runtime.sendMessage({ type: "wce:open-editor-tab", tabId });
        if (!answer.ok) {
          main.append(el("p", { class: "err" }, `N\xE3o foi poss\xEDvel abrir o editor: ${answer.error ?? ""}`));
          edit.disabled = false;
          return;
        }
      }
      window.close();
    });
    main.append(edit, el("p", { class: "muted" }, "Atalho: ", el("kbd", {}, "Alt"), "+", el("kbd", {}, "Shift"), "+", el("kbd", {}, "E"), " \xB7 ou clique com o bot\xE3o direito num elemento."));
    if (projects.length === 0) main.append(el("p", { class: "muted" }, "Nenhum projeto para este endere\xE7o ainda. \u201CEditar esta p\xE1gina\u201D cria um."));
    for (const project of projects) main.append(projectCard(project, tabId, status));
    if (status && status.errors.length > 0) {
      const box = el("details", {}, el("summary", { class: "err" }, `${status.errors.length} aviso(s) nesta p\xE1gina`));
      for (const error of status.errors) box.append(el("div", { class: "muted" }, `${error.where}: ${error.message}`));
      main.append(box);
    }
    if (!status) main.append(el("p", { class: "muted" }, "A p\xE1gina foi aberta antes da extens\xE3o: recarregue para aplicar os projetos (o editor funciona mesmo assim)."));
    const original = el("button", { type: "button", "data-testid": "popup-original" }, "Ver original");
    let showingOriginal = false;
    original.addEventListener("click", async () => {
      showingOriginal = !showingOriginal;
      await chrome.tabs.sendMessage(tabId, { type: "wce:preview-original", enabled: showingOriginal }, { frameId: 0 }).catch(() => void 0);
      original.textContent = showingOriginal ? "Ver com as altera\xE7\xF5es" : "Ver original";
    });
    const companion = el("button", { type: "button" }, "Enviar ao Builder Companion");
    const said = el("p", { class: "muted", role: "status" });
    companion.addEventListener("click", async () => {
      said.textContent = "Enviando\u2026";
      const answer = await chrome.runtime.sendMessage({ type: "wce:companion", tabId });
      said.textContent = answer.said;
      said.className = answer.ok ? "ok" : "err";
    });
    main.append(el("div", { class: "row" }, original, companion), said);
  }
  function projectCard(project, tabId, status) {
    const running = status?.running.find((item) => item.id === project.id);
    const card = el("div", { class: "card", "data-testid": "popup-project" });
    const toggle = el("input", { type: "checkbox", "aria-label": "Projeto ligado" });
    toggle.checked = project.enabled;
    toggle.addEventListener("change", async () => {
      const fresh = await getProject(project.id);
      if (fresh) await saveProject({ ...fresh, enabled: toggle.checked }, toggle.checked ? "Ligar" : "Desligar");
    });
    const open = el("button", { type: "button" }, "Editar");
    open.addEventListener("click", async () => {
      await chrome.runtime.sendMessage({ type: "wce:open-editor-tab", tabId, projectId: project.id });
      window.close();
    });
    card.append(el("div", { class: "top" }, el("label", { class: "switch" }, toggle), el("span", { class: "name", title: project.name }, project.name), open));
    const client = el("select", { "aria-label": "Cliente mostrado nesta aba" });
    const current = running?.client ?? activeClient(project)?.id ?? "";
    for (const item of project.clients) {
      const option = el("option", { value: item.id }, `Cliente: ${item.name}`);
      option.selected = item.id === current;
      client.append(option);
    }
    client.addEventListener("change", async () => {
      const fresh = await getProject(project.id);
      if (fresh) await saveProject({ ...fresh, activeClientId: client.value }, "Trocar cliente");
      await chrome.tabs.sendMessage(tabId, { type: "wce:client", projectId: project.id, clientId: client.value }, { frameId: 0 }).catch(() => void 0);
    });
    card.append(client, el("div", { class: "muted" }, `${project.edits.length} altera\xE7\xF5es \xB7 ${project.variables.length} vari\xE1veis \xB7 ${project.rules.length} regras${running ? " \xB7 aplicado" : ""}`));
    return card;
  }
  document.getElementById("manager")?.addEventListener("click", () => {
    void chrome.runtime.openOptionsPage();
    window.close();
  });
  void render();
})();
