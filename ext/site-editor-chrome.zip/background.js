"use strict";
(() => {
  // ../tools/companion/serialize.ts
  function serializePage(origin) {
    const HTML = "http://www.w3.org/1999/xhtml";
    const SETTLE = "animation-play-state:paused!important";
    const HINTS = /* @__PURE__ */ new Set(["preload", "modulepreload", "prefetch", "preconnect", "dns-prefetch", "prerender"]);
    let next = 0;
    const id = () => `k${next++}`;
    const scripts = [...document.querySelectorAll("script")].map((element) => ({
      src: element.hasAttribute("src") ? element.src : null,
      text: element.textContent ?? "",
      type: element.getAttribute("type") ?? ""
    }));
    const sheets = [];
    const cssomText = (sheet) => {
      if (sheet === null) return null;
      try {
        return [...sheet.cssRules].map((rule) => rule.cssText).join("\n");
      } catch {
        return null;
      }
    };
    const sheetPlaceholder = (entry) => {
      sheets.push(entry);
      return { kind: "comment", id: id(), value: `__capture_sheet_${sheets.length - 1}__` };
    };
    const adopted = (list) => list.flatMap((sheet) => {
      const text = cssomText(sheet);
      return text === null ? [] : [sheetPlaceholder({ href: null, text, media: null })];
    });
    const images = [];
    const opaque = [];
    const assetMarker = (value, folder = "img") => {
      if (value === "" || value.startsWith("#") || !URL.canParse(value, document.baseURI)) return value;
      const source = new URL(value, document.baseURI).href;
      if (!["http:", "https:", "data:"].includes(new URL(source).protocol)) return value;
      const index = images.length;
      images.push({ index, src: source, folder });
      return `__capture_image_${index}__`;
    };
    const markedSrcset = (value) => {
      const replacements = [];
      const space = (character) => character !== void 0 && /[\t\n\f\r ]/.test(character);
      let at = 0;
      while (at < value.length) {
        while (at < value.length && (space(value[at]) || value[at] === ",")) at += 1;
        const start = at;
        while (at < value.length && !space(value[at])) at += 1;
        let end = at;
        while (end > start && value[end - 1] === ",") end -= 1;
        const candidate = value.slice(start, end);
        if (candidate !== "" && URL.canParse(candidate, document.baseURI)) {
          const source = new URL(candidate, document.baseURI).href;
          const index = images.length;
          images.push({ index, src: source });
          replacements.push({ start, end, value: `__capture_image_${index}__` });
        }
        if (end === at) {
          let depth = 0;
          while (at < value.length) {
            const character = value[at];
            at += 1;
            if (character === "(") depth += 1;
            else if (character === ")") depth = Math.max(0, depth - 1);
            else if (character === "," && depth === 0) break;
          }
        }
      }
      let marked = value;
      for (const replacement of replacements.reverse()) marked = marked.slice(0, replacement.start) + replacement.value + marked.slice(replacement.end);
      return marked;
    };
    const links = [];
    const linkMark = (raw) => {
      if (raw === "" || raw.startsWith("#") || /^(mailto|tel|javascript):/i.test(raw) || !URL.canParse(raw, document.baseURI)) return raw;
      const at = new URL(raw, document.baseURI);
      if (at.origin !== origin) return at.href;
      links.push(`${at.origin}${at.pathname}`);
      return `__capture_link__${at.origin}${at.pathname}__${at.hash}__`;
    };
    const stateOf = (element) => {
      const state = {};
      if (element instanceof HTMLInputElement) {
        const typed = !["checkbox", "radio", "file", "password", "hidden", "submit", "reset", "button", "image"].includes(element.type);
        if (typed && element.value !== element.defaultValue) state.value = element.value;
        if (element.checked !== element.defaultChecked) state.checked = element.checked;
      }
      if (element instanceof HTMLTextAreaElement && element.value !== element.defaultValue) state.value = element.value;
      if (element instanceof HTMLOptionElement && element.selected !== element.defaultSelected) state.selected = element.selected;
      if (element.scrollLeft !== 0) state.scrollLeft = element.scrollLeft;
      if (element.scrollTop !== 0 && element !== document.documentElement && element !== document.body) state.scrollTop = element.scrollTop;
      return Object.keys(state).length === 0 ? void 0 : state;
    };
    const read = (node) => {
      if (node.nodeType === Node.TEXT_NODE) return { kind: "text", id: id(), value: node.nodeValue ?? "" };
      if (node.nodeType === Node.COMMENT_NODE) return { kind: "comment", id: id(), value: node.nodeValue ?? "" };
      if (!(node instanceof Element)) return null;
      const tag = node.localName;
      const html = node.namespaceURI === HTML;
      if (html && (tag === "script" || tag === "noscript")) return null;
      if (html && tag === "link") {
        const rel = (node.getAttribute("rel") ?? "").toLowerCase().split(/\s+/);
        if (rel.includes("stylesheet") && node.hasAttribute("href")) return sheetPlaceholder({ href: node.href, text: null, media: node.getAttribute("media")?.trim() || null });
        if (rel.some((one) => HINTS.has(one))) return null;
      }
      if (html && tag === "style") {
        const style = node;
        if ((style.textContent ?? "").includes(SETTLE)) return null;
        return sheetPlaceholder({ href: null, text: cssomText(style.sheet) ?? style.textContent ?? "", media: node.getAttribute("media")?.trim() || null });
      }
      const attributes = [];
      for (const attribute of node.attributes) {
        const name = attribute.name;
        let value = attribute.value;
        if (name === "data-capture-runtime") continue;
        if (html && tag === "img" && name === "src") continue;
        if (html && (tag === "img" || tag === "source") && name === "srcset") value = markedSrcset(value);
        else if (html && (tag === "video" || tag === "iframe") && (name === "src" || name === "srcdoc" || name === "autoplay")) continue;
        else if (html && tag === "video" && name === "poster") continue;
        else if (["src", "poster"].includes(name) || name === "data" && tag === "object") value = assetMarker(value, ["video", "audio", "source", "track"].includes(tag) && name === "src" ? "media" : "img");
        else if ((tag === "image" && !html || html && tag === "link" && /\bicon\b/i.test(node.getAttribute("rel") ?? "")) && (name === "href" || name === "xlink:href")) value = assetMarker(value);
        else if (html && tag === "a" && name === "href") value = linkMark(value);
        attributes.push({ name, namespace: attribute.namespaceURI, value });
      }
      if (html && tag === "img") {
        const image = node;
        const src = image.currentSrc || image.getAttribute("src") || "";
        const index = images.length;
        images.push({ index, src: src === "" ? "" : new URL(src, document.baseURI).href });
        attributes.push({ name: "src", namespace: null, value: `__capture_image_${index}__` });
      }
      if (html && tag === "canvas") {
        let paint;
        try {
          paint = assetMarker(node.toDataURL("image/png"));
        } catch {
          paint = `__capture_opaque_${opaque.length}__`;
          opaque.push({ path: node.getAttribute("data-capture-runtime") ?? "", marker: paint, kind: "canvas" });
        }
        attributes.push({ name: "data-capture-paint", namespace: null, value: paint });
      }
      if (html && tag === "video") {
        const marker = `__capture_opaque_${opaque.length}__`;
        opaque.push({ path: node.getAttribute("data-capture-runtime") ?? "", marker, kind: "video" });
        attributes.push({ name: "poster", namespace: null, value: marker });
        for (const source of node.querySelectorAll("source[src]")) assetMarker(source.getAttribute("src") ?? "", "media");
        const own = node.getAttribute("src");
        if (own !== null) assetMarker(own, "media");
      }
      if (html && tag === "iframe") {
        const marker = `__capture_opaque_${opaque.length}__`;
        opaque.push({ path: node.getAttribute("data-capture-runtime") ?? "", marker, kind: "frame" });
        attributes.push({ name: "data-capture-paint", namespace: null, value: marker });
      }
      const childOf = html && tag === "template" ? node.content.childNodes : node.childNodes;
      const children = [...childOf].flatMap((child) => read(child) ?? []);
      const root2 = node.shadowRoot;
      const shadow = root2 === null ? void 0 : { mode: root2.mode, children: [...[...root2.childNodes].flatMap((child) => read(child) ?? []), ...adopted(root2.adoptedStyleSheets)] };
      const state = stateOf(node);
      return { kind: "element", id: id(), namespace: node.namespaceURI ?? HTML, tag, attributes, children, ...shadow === void 0 ? {} : { shadow }, ...state === void 0 ? {} : { state } };
    };
    const root = read(document.documentElement);
    if (root === null || root.kind !== "element") throw new Error("the page has no document element");
    const extra = adopted(document.adoptedStyleSheets);
    const rootStyle = document.documentElement.getAttribute("style")?.trim();
    if (rootStyle) extra.push(sheetPlaceholder({ href: null, text: `html:root{${rootStyle}}`, media: null }));
    const withExtra = extra.length === 0 ? root : {
      ...root,
      children: root.children.map((child) => child.kind === "element" && child.tag === "body" && child.namespace === HTML ? { ...child, children: [...child.children, ...extra] } : child)
    };
    return { title: document.title, viewportWidth: window.innerWidth, root: withExtra, sheets, images: images.filter((one) => one.src !== ""), links, scripts, opaque };
  }

  // src/background/companion.ts
  async function readResources(read, base) {
    const out = {};
    const base64Of = (bytes) => {
      let binary = "";
      for (let at = 0; at < bytes.length; at += 32768) binary += String.fromCharCode(...bytes.subarray(at, at + 32768));
      return btoa(binary);
    };
    const fetchOne = async (url) => {
      if (url in out || url.startsWith("data:")) return null;
      try {
        const response = await fetch(url, { credentials: "include" });
        const bytes = new Uint8Array(await response.arrayBuffer());
        const type = response.headers.get("content-type") ?? "";
        out[url] = { status: response.status, type, base64: base64Of(bytes) };
        return type.includes("css") || /\.css(\?|#|$)/i.test(url) ? new TextDecoder().decode(bytes) : null;
      } catch {
        return null;
      }
    };
    const sheetNames = async (text, sheetUrl) => {
      for (const match of text.matchAll(/url\(\s*(['"]?)([^'")]+)\1\s*\)/g)) {
        const raw = match[2] ?? "";
        if (raw.startsWith("data:") || raw.startsWith("#")) continue;
        await fetchOne(new URL(raw, sheetUrl).href);
      }
      for (const match of text.matchAll(/@import\s+(?:url\()?\s*['"]?([^'")\s;]+)['"]?\s*\)?[^;]*;/g)) {
        const absolute = new URL(match[1] ?? "", sheetUrl).href;
        const inner = await fetchOne(absolute);
        if (inner !== null) await sheetNames(inner, absolute);
      }
    };
    for (const sheet of read.sheets) {
      if (sheet.href !== null) {
        const text = await fetchOne(sheet.href);
        if (text !== null) await sheetNames(text, sheet.href);
      } else if (sheet.text !== null) await sheetNames(sheet.text, base);
    }
    for (const image of read.images) if (!image.src.startsWith("data:")) await fetchOne(image.src);
    for (const script of read.scripts ?? []) if (script.src !== null) await fetchOne(script.src);
    const values = [];
    const walk = (node) => {
      if (node.kind !== "element") return;
      for (const attribute of node.attributes) values.push(attribute.value);
      node.children.forEach(walk);
      node.shadow?.children.forEach(walk);
    };
    walk(read.root);
    for (const match of values.join(" ").matchAll(/url\(\s*(['"]?)([^'")]+)\1\s*\)/g)) {
      const raw = match[2] ?? "";
      if (!raw.startsWith("data:") && !raw.startsWith("__capture")) await fetchOne(new URL(raw, base).href);
    }
    return out;
  }
  async function captureTab(tab) {
    if (tab.id === void 0 || tab.url === void 0 || !/^https?:/.test(tab.url)) return { ok: false, said: "this tab shows no web page" };
    const url = tab.url;
    const origin = new URL(url).origin;
    const [read] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: serializePage, args: [origin] });
    if (read?.result === void 0) return { ok: false, said: "the page could not be read" };
    const [resources] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: readResources, args: [read.result, url] });
    const stored = await chrome.storage.local.get("wce:settings");
    const settings = stored["wce:settings"] ?? {};
    const port = settings.companionPort ?? 5410;
    const token = settings.companionToken ?? "";
    try {
      const response = await fetch(`http://127.0.0.1:${port}/snapshot`, { method: "POST", headers: { "content-type": "application/json", "x-builder-token": token }, body: JSON.stringify({ url, read: read.result, resources: resources?.result ?? {} }) });
      const answer = await response.json();
      return answer.ok === true ? { ok: true, said: `captured ${String(answer.files ?? 0)} files: open ${url} in the Builder` } : { ok: false, said: answer.error ?? "the Companion refused the capture" };
    } catch {
      return { ok: false, said: "the Builder Companion does not answer (npm run companion)" };
    }
  }

  // src/shared/storage.ts
  var INDEX = "wce:index";
  var projectKey = (id) => `wce:project:${id}`;
  var historyKey = (id) => `wce:history:${id}`;
  function area() {
    return chrome.storage.local;
  }
  async function readIndex() {
    const stored = await area().get(INDEX);
    const list = stored[INDEX];
    return Array.isArray(list) ? list : [];
  }
  async function deleteProject(id) {
    const index = await readIndex();
    await area().set({ [INDEX]: index.filter((entry) => entry.id !== id) });
    await area().remove([projectKey(id), historyKey(id)]);
  }

  // src/background/background.ts
  var MENU_ELEMENT = "wce-edit-element";
  var MENU_PAGE = "wce-edit-page";
  chrome.runtime.onInstalled.addListener(() => {
    void chrome.contextMenus.removeAll().then(() => {
      chrome.contextMenus.create({ id: MENU_ELEMENT, title: "Editar este elemento com o Site Editor", contexts: ["all"] });
      chrome.contextMenus.create({ id: MENU_PAGE, title: "Editar esta p\xE1gina com o Site Editor", contexts: ["page"] });
    });
  });
  async function injectEditor(tabId) {
    const [probe] = await chrome.scripting.executeScript({ target: { tabId, frameIds: [0] }, func: () => Boolean(globalThis.__wce?.editor) });
    if (probe?.result === true) return;
    const [hasContent] = await chrome.scripting.executeScript({ target: { tabId, frameIds: [0] }, func: () => Boolean(globalThis.__wce) });
    if (hasContent?.result !== true) await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, files: ["content.js"] });
    await chrome.scripting.executeScript({ target: { tabId, frameIds: [0] }, files: ["editor.js"] });
  }
  async function openEditor(tabId, options = {}) {
    try {
      await injectEditor(tabId);
      await chrome.tabs.sendMessage(tabId, { type: "wce:open-editor", projectId: options.projectId, useContext: options.useContext === true }, { frameId: 0 });
      return { ok: true };
    } catch (error) {
      return { ok: false, error: error instanceof Error ? error.message : String(error) };
    }
  }
  chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (tab?.id === void 0) return;
    void openEditor(tab.id, { useContext: info.menuItemId === MENU_ELEMENT });
  });
  chrome.commands.onCommand.addListener((command, tab) => {
    if (command !== "toggle-editor") return;
    const run = async () => {
      const target = tab ?? (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
      if (target?.id === void 0) return;
      try {
        const status = await chrome.tabs.sendMessage(target.id, { type: "wce:status" }, { frameId: 0 });
        if (status?.editing) {
          await chrome.tabs.sendMessage(target.id, { type: "wce:close-editor" }, { frameId: 0 });
          return;
        }
      } catch {
      }
      await openEditor(target.id);
    };
    void run();
  });
  async function proxyFetch(request) {
    const url = new URL(request.url);
    if (!/^https?:$/.test(url.protocol)) return { ok: false, status: 0, text: "", error: "s\xF3 endere\xE7os http e https" };
    const response = await fetch(url, { method: request.method, headers: request.headers, ...request.body !== void 0 && request.method !== "GET" ? { body: request.body } : {}, credentials: "omit" });
    const text = await response.text();
    return { ok: response.ok, status: response.status, text: text.length > 5e6 ? text.slice(0, 5e6) : text };
  }
  function userScriptsAvailable() {
    try {
      const api = chrome.userScripts;
      if (!api?.getScripts) return false;
      void api.getScripts();
      return typeof api.execute === "function";
    } catch {
      return false;
    }
  }
  async function runUserScript(tabId, frameId, code, scope) {
    const api = chrome.userScripts;
    if (!api || !userScriptsAvailable()) throw new Error('Scripts pr\xF3prios desligados: ative "Permitir scripts de usu\xE1rio" nos detalhes da extens\xE3o (chrome://extensions).');
    const source = `(async (vars, data, event, page) => {
${code}
})(${JSON.stringify(scope.vars ?? {})}, ${JSON.stringify(scope.data ?? {})}, ${JSON.stringify(scope.event ?? {})}, ${JSON.stringify(scope.page ?? {})})`;
    const [result] = await api.execute({ target: { tabId, frameIds: [frameId] }, js: [{ code: source }], world: "MAIN", injectImmediately: true });
    if (result?.error) throw new Error(result.error);
    return result?.result;
  }
  async function openUrlWithEditor(url, projectId) {
    const parsed = new URL(url);
    if (!/^https?:$/.test(parsed.protocol)) return { ok: false, error: "endere\xE7o inv\xE1lido" };
    const tab = await chrome.tabs.create({ url: parsed.href });
    if (tab.id === void 0) return { ok: false, error: "a aba n\xE3o abriu" };
    const tabId = tab.id;
    await new Promise((resolve) => {
      const listener = (id, info) => {
        if (id === tabId && info.status === "complete") {
          chrome.tabs.onUpdated.removeListener(listener);
          resolve();
        }
      };
      chrome.tabs.onUpdated.addListener(listener);
    });
    return openEditor(tabId, projectId === void 0 ? {} : { projectId });
  }
  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    switch (message.type) {
      case "wce:fetch":
        proxyFetch(message.request).then(respond, (error) => respond({ ok: false, status: 0, text: "", error: error instanceof Error ? error.message : String(error) }));
        return true;
      case "wce:script": {
        const tabId = sender.tab?.id;
        if (tabId === void 0) {
          respond({ ok: false, error: "sem aba" });
          return false;
        }
        runUserScript(tabId, sender.frameId ?? 0, String(message.code ?? ""), message.scope ?? {}).then(
          (result) => respond({ ok: true, result }),
          (error) => respond({ ok: false, error: error instanceof Error ? error.message : String(error) })
        );
        return true;
      }
      case "wce:user-scripts-status":
        respond({ available: userScriptsAvailable(), chrome: Number(/(Chrome|Chromium)\/(\d+)/.exec(navigator.userAgent)?.[2] ?? 0) });
        return false;
      case "wce:open-editor-tab": {
        const tabId = Number(message.tabId);
        openEditor(tabId, typeof message.projectId === "string" ? { projectId: message.projectId } : {}).then(respond, (error) => respond({ ok: false, error: String(error) }));
        return true;
      }
      case "wce:open-url-editor":
        openUrlWithEditor(String(message.url ?? ""), typeof message.projectId === "string" ? message.projectId : void 0).then(respond, (error) => respond({ ok: false, error: String(error) }));
        return true;
      case "wce:companion": {
        const tabId = Number(message.tabId ?? sender.tab?.id);
        chrome.tabs.get(tabId).then(captureTab).then(respond, (error) => respond({ ok: false, said: String(error) }));
        return true;
      }
      case "wce:runtime-source":
        fetch(chrome.runtime.getURL("wc-runtime.js")).then((response) => response.text()).then((source) => respond({ ok: true, source }), (error) => respond({ ok: false, error: String(error) }));
        return true;
      case "wce:delete-project":
        void deleteProject(String(message.id ?? "")).then(() => respond({ ok: true }));
        return true;
      case "wce:open-manager":
        void chrome.tabs.create({ url: chrome.runtime.getURL(`manager.html${typeof message.hash === "string" ? message.hash : ""}`) });
        respond({ ok: true });
        return false;
      default:
        return false;
    }
  });
  globalThis.wceOpenEditor = openEditor;
})();
